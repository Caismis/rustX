#!/bin/sh
exec env LD_PRELOAD=/home/capi/.cache/rustx-pr485-checkpoint-window-20261110/policy-probe.so /home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/conformance "$@"
