#[unsafe(no_mangle)]
pub extern "C" fn size_content_source() -> usize { std::mem::size_of::<rustx::observation::content::ContentSource>() }
#[unsafe(no_mangle)]
pub extern "C" fn size_content_ref() -> usize { std::mem::size_of::<rustx::observation::content::ContentRef>() }
#[unsafe(no_mangle)]
pub extern "C" fn size_content_binding() -> usize { std::mem::size_of::<rustx::observation::cut::ContentBinding>() }
#[unsafe(no_mangle)]
pub extern "C" fn size_collection_frontier() -> usize { std::mem::size_of::<rustx::observation::cut::CollectionFrontier>() }
