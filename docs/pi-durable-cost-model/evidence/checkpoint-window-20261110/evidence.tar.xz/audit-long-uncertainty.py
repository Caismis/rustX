"""Preserve initial and predeclared extension results without selecting either."""
from pathlib import Path
import importlib
import json
import statistics
import sys

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0, str(repo / 'benchmarks/runtime'))
metrics = importlib.import_module('summarize-http')
from controller import validate_sample

rows = []
for pair in range(8):
    directory = root / ('ordinary' if pair < 4 else 'long-uncertainty')
    comparison = json.loads((directory / f'{pair}-short-large-comparison.json').read_text())
    assert all(value['coreSemanticEqual'] and value['fullSemanticRequestEqual'] for value in comparison['checked'])
    for side in ['before', 'after']:
        stem = directory / f'{pair}-short-large-{side}'
        raw = json.loads(stem.with_suffix('.json').read_text())
        validate_sample(json.loads(stem.with_suffix('.process.json').read_text()), raw, 'short-large', stem.with_suffix('.log').read_text())
        stages = metrics.validate_lifecycle(raw)
        warm = [point for point in raw['samples'] if point['measured']]
        point = metrics.sample(stem.with_suffix('.json'))
        values = sorted(value['settled_us'] / 1000 for value in warm)
        a, b = [x['process'] for x in [raw['samples'][raw['history'] - 1], warm[-1]]]
        io = lambda value: {key: int(n) for line in value['io'].splitlines() for key, n in [line.split(':')]}
        row = {'pair': pair, 'side': side, 'p50_ms': statistics.median(values), 'p95_ms': values[30],
               'cpu_ms_per_turn': point['turn_cpu_ms_per_turn'],
               'write_kib_per_turn': point['turn_write_mib_per_turn'] * 1024,
               'write_mib_through_close': metrics.delta(stages['before_initialization'], stages['after_final_writer_close'], 'write_bytes') / 2**20,
               'final_writer_close_ms': raw['final_writer_close_us'] / 1000,
               'max_sampled_wal_mib': max(sum(file['logical'] for file in sample['footprint'] if file['path'].endswith('.sqlite-wal')) for sample in warm) / 2**20}
        row.update({key + '_per_turn': (io(b)[key] - io(a)[key]) / 32 for key in ['rchar', 'syscr', 'wchar', 'syscw']})
        rows.append(row)
summary = {}
for name, pairs in [('initial', range(4)), ('extension', range(4, 8)), ('combined', range(8))]:
    included = [row for row in rows if row['pair'] in pairs]
    fields = [key for key in rows[0] if key not in ['pair', 'side']]
    result = {side: {key: {'median': statistics.median(row[key] for row in included if row['side'] == side),
                          'range': [min(row[key] for row in included if row['side'] == side), max(row[key] for row in included if row['side'] == side)]}
                     for key in fields} for side in ['before', 'after']}
    result['paired_percent'] = {}
    for key in fields:
        differences = []
        for pair in pairs:
            a, b = [next(row[key] for row in included if row['pair'] == pair and row['side'] == side) for side in ['before', 'after']]
            if a:
                differences.append((b - a) / a * 100)
        result['paired_percent'][key] = {'values': differences, 'median': statistics.median(differences)}
    summary[name] = result
report = {'scope': 'Four initial 64-history pairs and a fixed four-pair extension, declared before execution to investigate the initial same-direction P50 increase. Keep both groups and their combined result; no statistical significance claim. Extension uses the same binaries, affinity, input and live subscriber. The initial whole-window host monitor saw no compiler; no complete monitor was collected for the extension.', 'summary': summary, 'rows': rows}
(root / 'long-uncertainty-summary.json').write_text(json.dumps(report, indent=2) + '\n')
for group, values in summary.items():
    print(group)
    for field in ['p50_ms', 'p95_ms', 'cpu_ms_per_turn', 'write_kib_per_turn', 'write_mib_through_close', 'rchar_per_turn', 'syscr_per_turn', 'max_sampled_wal_mib', 'final_writer_close_ms']:
        print(field, *(round(values[side][field]['median'], 3) for side in ['before', 'after']), round(values['paired_percent'][field]['median'], 2), [round(x, 2) for x in values['paired_percent'][field]['values']])
