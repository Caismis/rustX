// Diagnostic only: select a checkpoint policy in one exact unchanged ELF.
// SQLite sets its default after auto-extensions, so apply the override at the
// first statement after open, then unregister the statement callback entirely.
#include <cstdio>
#include <cstdlib>
#include <unistd.h>
#include "/home/capi/.cache/rustx-pr485-process-cache-20261110/sqlite-status.h"

struct sqlite3;
using Trace = int (*)(unsigned, void*, void*, void*);
using TraceFn = int (*)(sqlite3*, unsigned, Trace, void*);
using CheckpointFn = int (*)(sqlite3*, int);
using ExecFn = int (*)(sqlite3*, const char*, int (*)(void*, int, char**, char**), void*, char**);
static TraceFn trace_fn;
static CheckpointFn checkpoint_fn;
static ExecFn exec_fn;
static int frames;

static int capture(void* context, int count, char** values, char**) {
  if (count != 1 || !values[0]) _exit(83);
  *static_cast<int*>(context) = std::atoi(values[0]);
  return 0;
}
static int first_statement(unsigned, void* context, void*, void*) {
  auto* database = static_cast<sqlite3*>(context);
  if (trace_fn(database, 0, nullptr, nullptr) != 0 || checkpoint_fn(database, frames) != 0)
    _exit(84);
  int actual = -1;
  if (exec_fn(database, "PRAGMA wal_autocheckpoint", capture, &actual, nullptr) != 0 || actual != frames)
    _exit(85);
  auto* output = std::fopen(std::getenv("RUSTX_CHECKPOINT_PROBE_LOG"), "a");
  if (!output) _exit(86);
  std::fprintf(output, "%d\n", actual);
  std::fclose(output);
  return 0;
}
static int opened(sqlite3* database, char**, const void*) {
  return trace_fn(database, 1, first_statement, database);
}
__attribute__((constructor)) static void install() {
  if (!std::getenv("RUSTX_CHECKPOINT_PROBE_LOG")) return;
  MainExecutable main;
  if (!dl_iterate_phdr(main_executable, &main) || !main.headers) _exit(87);
  frames = std::atoi(std::getenv("RUSTX_CHECKPOINT_PROBE_FRAMES"));
  if (frames != 1000 && frames != 2000) _exit(88);
  trace_fn = reinterpret_cast<TraceFn>(sqlite_address(main, "RUSTX_CHECKPOINT_TRACE_OFFSET"));
  checkpoint_fn = reinterpret_cast<CheckpointFn>(sqlite_address(main, "RUSTX_CHECKPOINT_WAL_OFFSET"));
  exec_fn = reinterpret_cast<ExecFn>(sqlite_address(main, "RUSTX_CHECKPOINT_EXEC_OFFSET"));
  using ExtensionFn = int (*)(void (*)());
  const auto extension = reinterpret_cast<ExtensionFn>(sqlite_address(main, "RUSTX_CHECKPOINT_EXTENSION_OFFSET"));
  if (extension(reinterpret_cast<void (*)()>(opened)) != 0) _exit(89);
}
