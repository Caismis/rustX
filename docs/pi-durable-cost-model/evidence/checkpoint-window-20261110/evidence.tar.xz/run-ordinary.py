"""Run the original four cells with four balanced, uninstrumented pairs."""
from pathlib import Path
import datetime
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
compilers = lambda: subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True, text=True).stdout.split()
assert not compilers(), 'do not start ordinary measurements during compilation'
command = [sys.executable, str(repo / 'benchmarks/runtime/compare-revisions.py'),
           '--before', '/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/conformance',
           '--after', str(root / 'build/conformance'), '--output', str(root / 'ordinary'),
           '--pairs', '4', '--observer-mode', 'live-subscriber']
host = []
with (root / 'ordinary.log').open('x') as log:
    process = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    while process.poll() is None:
        host.append({'monotonic_ns': time.monotonic_ns(), 'loadavg': Path('/proc/loadavg').read_text(),
                     'compiler_pids': compilers()})
        time.sleep(.5)
(root / 'ordinary-host.json').write_text(json.dumps(host, indent=2) + '\n')
(root / 'ordinary-command.json').write_text(json.dumps({'command': command, 'exit': process.returncode,
    'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'compiler_overlap_samples': sum(bool(point['compiler_pids']) for point in host)}, indent=2) + '\n')
assert process.returncode == 0
subprocess.run([sys.executable, str(root / 'ordinary_summary.py'), str(root)], check=True, cwd=repo)
