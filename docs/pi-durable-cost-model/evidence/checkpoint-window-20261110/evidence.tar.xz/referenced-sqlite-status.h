// Diagnostic-only calls into the exact measured PIE executable. Offsets and
// ELF hashes are bound by the wrapper manifest; no SQLite policy is changed.
#include <link.h>
#include <cstdint>
#include <cstring>
#include <sstream>

struct MainExecutable {
  uintptr_t base = 0;
  const ElfW(Phdr)* headers = nullptr;
  ElfW(Half) count = 0;
};
static int main_executable(dl_phdr_info* info, size_t, void* context) {
  if (info->dlpi_name && info->dlpi_name[0]) return 0;
  auto* main = static_cast<MainExecutable*>(context);
  main->base = info->dlpi_addr;
  main->headers = info->dlpi_phdr;
  main->count = info->dlpi_phnum;
  return 1;
}
static uintptr_t sqlite_address(const MainExecutable& main, const char* key) {
  const char* value = std::getenv(key);
  if (!value || !*value) _exit(93);
  char* end = nullptr;
  const auto offset = std::strtoull(value, &end, 16);
  if (!end || *end) _exit(94);
  for (size_t i = 0; i < main.count; ++i) {
    const auto& header = main.headers[i];
    if (header.p_type == PT_LOAD && (header.p_flags & PF_X) &&
        offset >= header.p_vaddr && offset < header.p_vaddr + header.p_memsz)
      return main.base + offset;
  }
  _exit(95);
}
static std::string sqlite_fields() {
  MainExecutable main;
  if (!dl_iterate_phdr(main_executable, &main) || !main.headers) _exit(96);
  using QueryLimit = long long (*)(long long);
  using QueryMemory = long long (*)();
  const auto memory = reinterpret_cast<QueryMemory>(sqlite_address(main, "RUSTX_SQLITE_MEMORY_OFFSET"));
  const auto soft = reinterpret_cast<QueryLimit>(sqlite_address(main, "RUSTX_SQLITE_SOFT_OFFSET"));
  const auto hard = reinterpret_cast<QueryLimit>(sqlite_address(main, "RUSTX_SQLITE_HARD_OFFSET"));
  std::ostringstream output;
  output << ",\"sqlite_memory_used\":" << memory()
         << ",\"sqlite_soft_heap_limit\":" << soft(-1)
         << ",\"sqlite_hard_heap_limit\":" << hard(-1);
  return output.str();
}
