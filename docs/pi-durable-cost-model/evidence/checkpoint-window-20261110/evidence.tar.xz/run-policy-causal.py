"""Same-ELF checkpoint intervention; diagnostic only, not ordinary timings."""
from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
binary = Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/conformance')
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == 'a682bdcf9cff9c049b150565ae0c83c701993d1f2f7bea920e5cb0702dbfaa80'
sys.path.insert(0, str(repo / 'benchmarks/runtime'))
from controller import TEST, run

symbols = {row.split()[-1]: row.split()[0] for row in subprocess.check_output(['nm', '-an', str(binary)], text=True).splitlines() if len(row.split()) == 3}
names = {'RUSTX_CHECKPOINT_TRACE_OFFSET': 'sqlite3_trace_v2', 'RUSTX_CHECKPOINT_WAL_OFFSET': 'sqlite3_wal_autocheckpoint',
         'RUSTX_CHECKPOINT_EXEC_OFFSET': 'sqlite3_exec', 'RUSTX_CHECKPOINT_EXTENSION_OFFSET': 'sqlite3_auto_extension'}
wrapper = root / 'same-elf-wrapper.sh'
wrapper.write_text('#!/bin/sh\nexec env LD_PRELOAD=' + shlex.quote(str(root / 'policy-probe.so')) + ' ' + shlex.quote(str(binary)) + ' "$@"\n')
wrapper.chmod(0o755)
identity = {'scope': 'Single unchanged baseline ELF, GNU allocator, four balanced diagnostic 64-history pairs. Only startup checkpoint selection differs. First-statement trace disables itself before the policy query; no retained per-statement hook. Provider does not inherit LD_PRELOAD. Not ordinary headline timing.',
            'binary': str(binary), 'binary_sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
            'helper_sha256': hashlib.file_digest((root / 'policy-probe.so').open('rb'), 'sha256').hexdigest(),
            'header_sha256': hashlib.file_digest(Path('/home/capi/.cache/rustx-pr485-process-cache-20261110/sqlite-status.h').open('rb'), 'sha256').hexdigest(),
            'elf_offsets': {key: symbols[name] for key, name in names.items()}, 'affinity': sorted(os.sched_getaffinity(0))}
(root / 'policy-causal-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
env = {key: value for key, value in os.environ.items() if not any(word in key.upper() for word in ['TOKEN', 'SECRET', 'CREDENTIAL', 'API_KEY'])}
env.update(identity['elf_offsets'])
directory = root / 'policy-causal'
directory.mkdir(exist_ok=False)
commands = []
for pair, case in [(-1, 'short-small'), *((pair, 'short-large') for pair in range(4))]:
    for frames in ([2000] if pair == -1 else [1000, 2000] if pair % 2 == 0 else [2000, 1000]):
        assert subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True).returncode != 0
        stem = directory / f'{pair}-{case}-{frames}'
        child = env | {'RUSTX_BENCH_CASE': case, 'RUSTX_BENCH_OBSERVER_MODE': 'live-subscriber',
                       'RUSTX_BENCH_OUTPUT': str(stem.with_suffix('.json')), 'RUSTX_CHECKPOINT_PROBE_FRAMES': str(frames),
                       'RUSTX_CHECKPOINT_PROBE_LOG': str(stem.with_suffix('.policy'))}
        result = run([str(wrapper), TEST, '--exact', '--ignored', '--nocapture'], stem, case, child,
                     repo / 'test-support/fake-provider')
        assert result['accepted'], result
        selected = [int(line) for line in stem.with_suffix('.policy').read_text().splitlines()]
        assert selected and all(value == frames for value in selected)
        commands.append({'pair': pair, 'case': case, 'frames': frames, 'policy_samples': len(selected), 'accepted': True})
        (root / 'policy-causal-products.json').write_text(json.dumps(commands, indent=2) + '\n')
        print(pair, case, frames, 'accepted', len(selected), flush=True)
    if pair >= 0:
        subprocess.run(['node', str(repo / 'benchmarks/runtime/compare-http.mjs'),
                        str(directory / f'{pair}-{case}-1000.json'), str(directory / f'{pair}-{case}-2000.json'),
                        str(directory / f'{pair}-{case}-comparison.json')], check=True, cwd=repo)
