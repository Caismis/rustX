"""Preserve rejected policy evidence without binaries, credentials or live roots."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parent
destination = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX/docs/pi-durable-cost-model/evidence/checkpoint-window-20261110')
destination.mkdir(parents=True, exist_ok=True)
files = sorted(path for path in root.rglob('*') if path.is_file()
               and not (set(path.relative_to(root).parts) & {'runtime', 'workspaces', '__pycache__'})
               and path.name not in {'conformance', 'rustx', 'token', 'pack.log'})
members = [{'path': str(path.relative_to(root)), 'bytes': path.stat().st_size,
            'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()} for path in files]
archive = destination / 'evidence.tar.xz'
with archive.open('wb') as output:
    compressor = subprocess.Popen(['xz', '-T4', '-6', '-c'], stdin=subprocess.PIPE, stdout=output)
    with tarfile.open(mode='w|', fileobj=compressor.stdin) as tar:
        for path in files:
            tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
    compressor.stdin.close()
    assert compressor.wait() == 0
expected = {member['path']: member for member in members}
seen = set()
with tarfile.open(archive, mode='r|xz') as tar:
    for member in tar:
        assert member.isfile() and member.name in expected and member.name not in seen
        assert member.size == expected[member.name]['bytes']
        assert hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest() == expected[member.name]['sha256']
        seen.add(member.name)
assert seen == expected.keys()
assert archive.stat().st_size < 100_000_000
manifest = {'scope': 'Rejected measured 2000-frame checkpoint candidate. Full ordinary and fixed long extension, same-ELF diagnostic intervention, authenticated physical products and native supplements, every negative observation and check. Actual product binaries, dependencies, tokens and live roots excluded. Historical helper paths, no portable replay claim.',
            'archive_bytes': archive.stat().st_size,
            'archive_sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
            'member_count': len(members), 'total_raw_bytes': sum(member['bytes'] for member in members),
            'verified_every_archived_member': True, 'members': members}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
for name in ['ordinary-summary.json', 'ordinary-per-run.csv', 'baseline-write-ledger.json', 'candidate-write-ledger.json', 'long-uncertainty-summary.json', 'policy-causal-identity.json', 'policy-causal-summary.json', 'native-summary.json', 'disposition.json']:
    (destination / name).write_bytes((root / name).read_bytes())
print(json.dumps({key: value for key, value in manifest.items() if key != 'members'}, indent=2))
