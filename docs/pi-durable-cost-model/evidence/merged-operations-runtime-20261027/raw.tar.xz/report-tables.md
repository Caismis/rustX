# Merged operations performance evidence

Fresh Rust comparison: five interleaved pairs per cell. Historical Pi/DeepSeek rows are fixed, separate batches; their ratios are ratios of medians, not paired results.

| Mode | Case | Paired median wall % [min,max] | Full CPU % | Full write bytes % | Sample anon PSS % | Sample RSS % |
|---|---|---:|---:|---:|---:|---:|
| no-live-subscriber | short-small | -10.615 [-43.059,74.505] | -3.497 | 0.000 | -0.335 | -0.417 |
| no-live-subscriber | short-large | -2.595 [-6.795,30.676] | -0.939 | -0.065 | -0.390 | -0.451 |
| no-live-subscriber | stream | 0.826 [-1.702,3.233] | 9.091 | 0.000 | 0.415 | 0.107 |
| no-live-subscriber | large | -1.555 [-30.435,23.685] | 0.000 | 0.000 | -0.615 | -0.620 |
| no-live-subscriber | tool | -1.829 [-16.415,2.944] | 5.882 | 0.000 | 0.035 | -0.111 |
| no-live-subscriber | cancel | 10.085 [-7.611,13.659] | 0.000 | 0.000 | 0.633 | 0.072 |
| live-subscriber | short-small | -5.377 [-50.131,55.080] | 8.589 | 0.056 | -0.308 | -0.386 |
| live-subscriber | short-large | -7.585 [-39.593,5.701] | -4.788 | -0.014 | 0.000 | -0.225 |
| live-subscriber | stream | 0.557 [-2.133,1.875] | 10.000 | 0.000 | 0.062 | -0.414 |
| live-subscriber | large | 8.848 [-12.764,31.481] | 6.250 | 0.000 | 0.244 | -0.178 |
| live-subscriber | tool | 6.081 [-11.592,34.233] | 5.556 | 0.000 | 0.018 | -0.092 |
| live-subscriber | cancel | -2.956 [-33.817,2.008] | -6.667 | 0.000 | -0.121 | -0.645 |

| Mode | Case | Mean wall / old Pi | Median wall / old Pi | Full CPU / old Pi | Full writes / old Pi |
|---|---|---:|---:|---:|---:|
| no-live-subscriber | short-small | 4.748 | 5.292 | 1.426 | 4.744 |
| no-live-subscriber | short-large | 4.871 | 5.738 | 2.986 | 5.228 |
| no-live-subscriber | stream | 0.929 | 0.929 | 0.255 | 4.009 |
| no-live-subscriber | large | 0.370 | 0.370 | 0.271 | 4.541 |
| no-live-subscriber | tool | 0.426 | 0.426 | 0.286 | 4.171 |
| no-live-subscriber | cancel | 0.332 | 0.332 | 0.246 | 4.767 |
| live-subscriber | short-small | 4.627 | 5.286 | 1.691 | 4.745 |
| live-subscriber | short-large | 4.321 | 4.811 | 3.253 | 5.228 |
| live-subscriber | stream | 0.921 | 0.921 | 0.279 | 4.009 |
| live-subscriber | large | 0.449 | 0.449 | 0.288 | 4.541 |
| live-subscriber | tool | 0.565 | 0.565 | 0.317 | 4.171 |
| live-subscriber | cancel | 0.309 | 0.309 | 0.233 | 4.767 |

Warm measured windows (per-product statistic, then median [minimum,maximum] across five Rust/Pi products; each has 32 measured turns):

| Mode | History | Engine/batch | Mean ms/turn | Median ms/turn | CPU ms/turn | Write bytes/turn |
|---|---:|---|---:|---:|---:|---:|
| no-live-subscriber | 8 | current Rust | 17.214 [10.156,18.134] | 16.590 [9.565,17.498] | 19.688 [11.875,20.312] | 1085056.000 [1084928.000,1085056.000] |
| no-live-subscriber | 8 | fixed old Pi | 3.625 [3.524,4.546] | 3.135 [3.014,3.328] | 7.188 [6.875,9.688] | 224512.000 [224512.000,224512.000] |
| no-live-subscriber | 64 | current Rust | 18.009 [16.615,20.154] | 18.929 [17.552,19.650] | 20.625 [19.062,22.812] | 1242496.000 [1241728.000,1243008.000] |
| no-live-subscriber | 64 | fixed old Pi | 3.697 [3.667,3.911] | 3.299 [3.159,3.524] | 6.250 [5.938,6.875] | 224384.000 [224384.000,224384.000] |
| live-subscriber | 8 | current Rust | 18.200 [10.986,20.712] | 18.078 [10.697,19.575] | 27.812 [16.562,30.938] | 1085184.000 [1085056.000,1085568.000] |
| live-subscriber | 8 | fixed old Pi | 3.934 [3.784,4.165] | 3.420 [3.309,3.699] | 7.500 [7.188,8.438] | 224512.000 [224512.000,224512.000] |
| live-subscriber | 64 | current Rust | 17.237 [15.202,23.252] | 17.032 [14.223,22.333] | 25.625 [22.812,34.375] | 1242880.000 [1241856.000,1243008.000] |
| live-subscriber | 64 | fixed old Pi | 3.989 [3.827,4.233] | 3.541 [3.482,3.679] | 6.875 [6.250,7.188] | 224384.000 [224384.000,224384.000] |

| Live case | Current mean ms/turn | Fixed DS mean ms/turn | Wall ratio | CPU ratio | Measured write ratio |
|---|---:|---:|---:|---:|---:|
| short-small | 18.200 | 15.541 | 1.171 | 1.534 | 50.464 |
| short-large | 17.237 | 15.450 | 1.116 | 1.464 | 58.144 |
| stream | 1599.048 | 1583.218 | 1.010 | 0.567 | 50.714 |
| large | 40.352 | 165.613 | 0.244 | 0.250 | 35.143 |

DeepSeek exit/flush CPU remains separate from measured turns and from Rust full-lifecycle CPU; full DeepSeek process write bytes remain unavailable. The JSON retains the exact wait4 metrics and source-specific limits.

All adverse metrics (including individual fresh paired reversals):

| Comparison | Mode | Case | Metric | Median % or cross-batch ratio | Adverse pairs |
|---|---|---|---|---:|---|
| fresh_paired_rust | no-live-subscriber | short-small | mean_turn_ms | -9.950 | 2:+27.488%,4:+70.725% |
| fresh_paired_rust | no-live-subscriber | short-small | turn_cpu_ms_per_turn | -7.143 | 2:+26.000%,4:+66.667% |
| fresh_paired_rust | no-live-subscriber | short-small | through_cleanup_self_cpu_ms | -3.497 | 2:+14.530%,4:+30.841% |
| fresh_paired_rust | no-live-subscriber | short-small | lifecycle_ms | -4.316 | 2:+12.617%,4:+26.448% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_anon_pss_mib | -0.335 | 1:+0.189% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_pss_mib | -0.420 | 1:+0.101% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_rss_mib | -0.417 | 1:+0.119% |
| fresh_paired_rust | no-live-subscriber | short-small | median_measured_turn_ms | -10.615 | 2:+41.286%,4:+74.505% |
| fresh_paired_rust | no-live-subscriber | short-small | lifecycle_self_cpu_ms | -3.497 | 2:+14.530%,4:+30.841% |
| fresh_paired_rust | no-live-subscriber | short-small | measured_turn_cpu_ms | -7.143 | 2:+26.000%,4:+66.667% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_turn_rss_mib | -0.323 | 1:+0.200% |
| fresh_paired_rust | no-live-subscriber | short-small | through_product_exit_wall_ms | -4.294 | 2:+12.290%,4:+25.654% |
| fresh_paired_rust | no-live-subscriber | short-small | complete_harness_lifecycle_wall_ms | -3.747 | 2:+12.124%,4:+24.861% |
| fresh_paired_rust | no-live-subscriber | short-small | closed_logical_bytes | 0.000 | 0:+0.055%,4:+0.110% |
| fresh_paired_rust | no-live-subscriber | short-small | closed_allocated_bytes | 0.000 | 0:+0.054%,4:+0.109% |
| fresh_paired_rust | no-live-subscriber | short-large | mean_turn_ms | -2.298 | 0:+17.918%,3:+6.359% |
| fresh_paired_rust | no-live-subscriber | short-large | turn_cpu_ms_per_turn | -1.493 | 0:+17.857%,3:+8.955% |
| fresh_paired_rust | no-live-subscriber | short-large | through_cleanup_self_cpu_ms | -0.939 | 0:+1.217%,3:+1.663% |
| fresh_paired_rust | no-live-subscriber | short-large | through_cleanup_process_write_mib | -0.065 | 0:+0.022%,3:+0.068% |
| fresh_paired_rust | no-live-subscriber | short-large | lifecycle_ms | -1.078 | 0:+0.826%,3:+1.611% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_anon_pss_mib | -0.390 | 3:+0.410% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_pss_mib | -0.468 | 3:+0.550% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_rss_mib | -0.451 | 3:+0.571% |
| fresh_paired_rust | no-live-subscriber | short-large | median_measured_turn_ms | -2.595 | 0:+30.676%,4:+0.913% |
| fresh_paired_rust | no-live-subscriber | short-large | measured_turn_write_bytes | -0.041 | 3:+0.052% |
| fresh_paired_rust | no-live-subscriber | short-large | turn_write_bytes_per_turn | -0.041 | 3:+0.052% |
| fresh_paired_rust | no-live-subscriber | short-large | through_cleanup_process_write_bytes | -0.065 | 0:+0.022%,3:+0.068% |
| fresh_paired_rust | no-live-subscriber | short-large | lifecycle_self_cpu_ms | -0.939 | 0:+1.217%,3:+1.663% |
| fresh_paired_rust | no-live-subscriber | short-large | measured_turn_cpu_ms | -1.493 | 0:+17.857%,3:+8.955% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_turn_rss_mib | -0.951 | 3:+1.177% |
| fresh_paired_rust | no-live-subscriber | short-large | through_product_exit_wall_ms | -1.276 | 0:+0.485%,3:+1.410% |
| fresh_paired_rust | no-live-subscriber | short-large | complete_harness_lifecycle_wall_ms | -1.207 | 0:+0.406%,3:+1.161% |
| fresh_paired_rust | no-live-subscriber | short-large | closed_logical_bytes | 0.038 | 1:+0.038%,2:+0.911%,4:+0.495% |
| fresh_paired_rust | no-live-subscriber | short-large | closed_allocated_bytes | 0.038 | 1:+0.038%,2:+0.904%,4:+0.531% |
| fresh_paired_rust | no-live-subscriber | stream | mean_turn_ms | 0.826 | 0:+3.233%,2:+1.873%,3:+0.631%,4:+0.826% |
| fresh_paired_rust | no-live-subscriber | stream | turn_cpu_ms_per_turn | 13.333 | 0:+28.571%,2:+13.333%,3:+6.667%,4:+20.000% |
| fresh_paired_rust | no-live-subscriber | stream | through_cleanup_self_cpu_ms | 9.091 | 0:+11.111%,2:+11.111%,3:+3.704%,4:+9.091% |
| fresh_paired_rust | no-live-subscriber | stream | lifecycle_ms | 1.690 | 0:+3.204%,2:+2.944%,3:+0.061%,4:+1.690% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_anon_pss_mib | 0.415 | 0:+0.415%,1:+0.530%,2:+0.143%,3:+0.348%,4:+1.215% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_pss_mib | 0.112 | 0:+0.533%,1:+0.112%,3:+0.045%,4:+0.539% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_rss_mib | 0.107 | 0:+0.467%,1:+0.107%,3:+0.055%,4:+0.523% |
| fresh_paired_rust | no-live-subscriber | stream | median_measured_turn_ms | 0.826 | 0:+3.233%,2:+1.873%,3:+0.631%,4:+0.826% |
| fresh_paired_rust | no-live-subscriber | stream | lifecycle_self_cpu_ms | 9.091 | 0:+11.111%,2:+11.111%,3:+3.704%,4:+9.091% |
| fresh_paired_rust | no-live-subscriber | stream | measured_turn_cpu_ms | 13.333 | 0:+28.571%,2:+13.333%,3:+6.667%,4:+20.000% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_turn_rss_mib | 0.384 | 0:+0.655%,1:+0.384%,3:+0.208%,4:+0.583% |
| fresh_paired_rust | no-live-subscriber | stream | through_product_exit_wall_ms | 1.591 | 0:+3.233%,2:+2.960%,3:+0.062%,4:+1.591% |
| fresh_paired_rust | no-live-subscriber | stream | complete_harness_lifecycle_wall_ms | 1.572 | 0:+3.452%,2:+2.764%,3:+0.685%,4:+1.572% |
| fresh_paired_rust | no-live-subscriber | large | mean_turn_ms | -1.555 | 1:+17.726%,3:+23.685% |
| fresh_paired_rust | no-live-subscriber | large | turn_cpu_ms_per_turn | -25.000 | 3:+25.000% |
| fresh_paired_rust | no-live-subscriber | large | through_cleanup_self_cpu_ms | 0.000 | 0:+6.667%,1:+6.250% |
| fresh_paired_rust | no-live-subscriber | large | lifecycle_ms | -0.304 | 0:+6.305%,1:+3.390% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_anon_pss_mib | -0.615 | 1:+1.706%,2:+0.102% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_pss_mib | -0.618 | 1:+0.977%,2:+0.205% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_rss_mib | -0.620 | 1:+0.889%,2:+0.261% |
| fresh_paired_rust | no-live-subscriber | large | median_measured_turn_ms | -1.555 | 1:+17.726%,3:+23.685% |
| fresh_paired_rust | no-live-subscriber | large | lifecycle_self_cpu_ms | 0.000 | 0:+6.667%,1:+6.250% |
| fresh_paired_rust | no-live-subscriber | large | measured_turn_cpu_ms | -25.000 | 3:+25.000% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_turn_rss_mib | -0.752 | 1:+1.162% |
| fresh_paired_rust | no-live-subscriber | large | through_product_exit_wall_ms | 1.710 | 0:+7.273%,1:+1.995%,2:+1.710% |
| fresh_paired_rust | no-live-subscriber | large | complete_harness_lifecycle_wall_ms | 1.126 | 0:+10.364%,1:+3.626%,2:+1.126% |
| fresh_paired_rust | no-live-subscriber | tool | mean_turn_ms | -1.829 | 2:+1.998%,4:+2.944% |
| fresh_paired_rust | no-live-subscriber | tool | turn_cpu_ms_per_turn | 0.000 | 0:+25.000%,2:+33.333% |
| fresh_paired_rust | no-live-subscriber | tool | through_cleanup_self_cpu_ms | 5.882 | 1:+5.882%,2:+6.667%,4:+5.882% |
| fresh_paired_rust | no-live-subscriber | tool | lifecycle_ms | 4.427 | 1:+5.153%,2:+4.427%,4:+8.681% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_anon_pss_mib | 0.035 | 0:+0.945%,1:+0.035%,2:+0.226%,4:+0.009% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_pss_mib | -0.118 | 0:+0.375%,1:+0.072% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_rss_mib | -0.111 | 0:+0.415%,1:+0.071% |
| fresh_paired_rust | no-live-subscriber | tool | median_measured_turn_ms | -1.829 | 2:+1.998%,4:+2.944% |
| fresh_paired_rust | no-live-subscriber | tool | lifecycle_self_cpu_ms | 5.882 | 1:+5.882%,2:+6.667%,4:+5.882% |
| fresh_paired_rust | no-live-subscriber | tool | measured_turn_cpu_ms | 0.000 | 0:+25.000%,2:+33.333% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_turn_rss_mib | -0.100 | 0:+0.584%,1:+0.258% |
| fresh_paired_rust | no-live-subscriber | tool | through_product_exit_wall_ms | 3.952 | 1:+3.952%,2:+5.960%,4:+8.869% |
| fresh_paired_rust | no-live-subscriber | tool | complete_harness_lifecycle_wall_ms | 3.184 | 1:+3.184%,2:+3.909%,4:+9.367% |
| fresh_paired_rust | no-live-subscriber | cancel | mean_turn_ms | 10.085 | 0:+13.659%,2:+13.098%,3:+7.577%,4:+10.085% |
| fresh_paired_rust | no-live-subscriber | cancel | turn_cpu_ms_per_turn | -25.000 | 0:+33.333% |
| fresh_paired_rust | no-live-subscriber | cancel | through_cleanup_self_cpu_ms | 0.000 | 0:+7.143% |
| fresh_paired_rust | no-live-subscriber | cancel | lifecycle_ms | -0.797 | 0:+6.012%,4:+5.070% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_anon_pss_mib | 0.633 | 0:+0.244%,1:+0.633%,2:+0.583%,3:+0.639%,4:+0.732% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_pss_mib | 0.039 | 0:+0.023%,1:+0.039%,2:+0.143%,3:+0.180% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_rss_mib | 0.072 | 0:+0.072%,2:+0.124%,3:+0.199% |
| fresh_paired_rust | no-live-subscriber | cancel | median_measured_turn_ms | 10.085 | 0:+13.659%,2:+13.098%,3:+7.577%,4:+10.085% |
| fresh_paired_rust | no-live-subscriber | cancel | lifecycle_self_cpu_ms | 0.000 | 0:+7.143% |
| fresh_paired_rust | no-live-subscriber | cancel | measured_turn_cpu_ms | -25.000 | 0:+33.333% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_turn_rss_mib | 0.172 | 0:+0.198%,1:+0.470%,2:+0.172%,3:+0.076% |
| fresh_paired_rust | no-live-subscriber | cancel | through_product_exit_wall_ms | 1.061 | 0:+5.419%,2:+1.061%,4:+3.113% |
| fresh_paired_rust | no-live-subscriber | cancel | complete_harness_lifecycle_wall_ms | -0.454 | 0:+5.786%,2:+0.241% |
| fresh_paired_rust | live-subscriber | short-small | mean_turn_ms | -2.375 | 0:+50.891%,3:+7.120% |
| fresh_paired_rust | live-subscriber | short-small | turn_cpu_ms_per_turn | 2.174 | 0:+58.929%,2:+2.174%,3:+13.793% |
| fresh_paired_rust | live-subscriber | short-small | through_cleanup_self_cpu_ms | 8.589 | 0:+28.125%,2:+8.589%,3:+12.422% |
| fresh_paired_rust | live-subscriber | short-small | through_cleanup_process_write_mib | 0.056 | 0:+0.019%,1:+0.009%,2:+0.056%,3:+0.056%,4:+0.056% |
| fresh_paired_rust | live-subscriber | short-small | lifecycle_ms | 4.153 | 0:+18.300%,2:+4.153%,3:+6.127% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_anon_pss_mib | -0.308 | 3:+0.741%,4:+0.660% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_pss_mib | -0.454 | 3:+0.075%,4:+0.540% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_rss_mib | -0.386 | 3:+0.062%,4:+0.554% |
| fresh_paired_rust | live-subscriber | short-small | median_measured_turn_ms | -5.377 | 0:+55.080% |
| fresh_paired_rust | live-subscriber | short-small | measured_turn_write_bytes | 0.071 | 0:+0.024%,1:+0.012%,2:+0.071%,3:+0.071%,4:+0.071% |
| fresh_paired_rust | live-subscriber | short-small | turn_write_bytes_per_turn | 0.071 | 0:+0.024%,1:+0.012%,2:+0.071%,3:+0.071%,4:+0.071% |
| fresh_paired_rust | live-subscriber | short-small | through_cleanup_process_write_bytes | 0.056 | 0:+0.019%,1:+0.009%,2:+0.056%,3:+0.056%,4:+0.056% |
| fresh_paired_rust | live-subscriber | short-small | lifecycle_self_cpu_ms | 8.589 | 0:+28.125%,2:+8.589%,3:+12.422% |
| fresh_paired_rust | live-subscriber | short-small | measured_turn_cpu_ms | 2.174 | 0:+58.929%,2:+2.174%,3:+13.793% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_turn_rss_mib | -0.645 | 4:+0.863% |
| fresh_paired_rust | live-subscriber | short-small | through_product_exit_wall_ms | 3.755 | 0:+17.525%,2:+3.755%,3:+6.391% |
| fresh_paired_rust | live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 2.258 | 0:+15.176%,2:+2.258%,3:+7.580% |
| fresh_paired_rust | live-subscriber | short-small | closed_logical_bytes | 0.110 | 1:+0.110%,2:+0.110%,4:+0.165% |
| fresh_paired_rust | live-subscriber | short-small | closed_allocated_bytes | 0.109 | 1:+0.109%,2:+0.109%,4:+0.163% |
| fresh_paired_rust | live-subscriber | short-large | mean_turn_ms | -7.699 | 1:+4.963%,2:+0.722% |
| fresh_paired_rust | live-subscriber | short-large | turn_cpu_ms_per_turn | -2.655 | 1:+10.465%,2:+5.263% |
| fresh_paired_rust | live-subscriber | short-large | through_cleanup_process_write_mib | -0.014 | 2:+0.007% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_anon_pss_mib | 0.000 | 2:+0.066%,4:+0.600% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_pss_mib | -0.212 | 4:+0.193% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_rss_mib | -0.225 | 4:+0.234% |
| fresh_paired_rust | live-subscriber | short-large | median_measured_turn_ms | -7.585 | 1:+5.701%,2:+1.951% |
| fresh_paired_rust | live-subscriber | short-large | measured_turn_write_bytes | -0.062 | 0:+0.052%,2:+0.031% |
| fresh_paired_rust | live-subscriber | short-large | turn_write_bytes_per_turn | -0.062 | 0:+0.052%,2:+0.031% |
| fresh_paired_rust | live-subscriber | short-large | through_cleanup_process_write_bytes | -0.014 | 2:+0.007% |
| fresh_paired_rust | live-subscriber | short-large | measured_turn_cpu_ms | -2.655 | 1:+10.465%,2:+5.263% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_turn_rss_mib | -0.159 | 2:+0.007%,4:+0.040% |
| fresh_paired_rust | live-subscriber | short-large | closed_logical_bytes | -1.202 | 0:+0.114% |
| fresh_paired_rust | live-subscriber | short-large | closed_allocated_bytes | -1.194 | 0:+0.076% |
| fresh_paired_rust | live-subscriber | stream | mean_turn_ms | 0.557 | 1:+0.488%,2:+0.557%,3:+1.875%,4:+1.220% |
| fresh_paired_rust | live-subscriber | stream | turn_cpu_ms_per_turn | 6.250 | 2:+6.250%,3:+18.750%,4:+14.286% |
| fresh_paired_rust | live-subscriber | stream | through_cleanup_self_cpu_ms | 10.000 | 1:+10.000%,3:+17.857%,4:+19.231% |
| fresh_paired_rust | live-subscriber | stream | lifecycle_ms | 0.929 | 1:+0.213%,2:+0.929%,3:+17.741%,4:+2.580% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_anon_pss_mib | 0.062 | 1:+1.511%,3:+0.533%,4:+0.062% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_pss_mib | -0.356 | 1:+0.542%,3:+0.161% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_rss_mib | -0.414 | 1:+0.452%,3:+0.156% |
| fresh_paired_rust | live-subscriber | stream | median_measured_turn_ms | 0.557 | 1:+0.488%,2:+0.557%,3:+1.875%,4:+1.220% |
| fresh_paired_rust | live-subscriber | stream | lifecycle_self_cpu_ms | 10.000 | 1:+10.000%,3:+17.857%,4:+19.231% |
| fresh_paired_rust | live-subscriber | stream | measured_turn_cpu_ms | 6.250 | 2:+6.250%,3:+18.750%,4:+14.286% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_turn_rss_mib | -0.226 | 1:+0.304%,3:+0.095% |
| fresh_paired_rust | live-subscriber | stream | through_product_exit_wall_ms | 1.239 | 1:+0.152%,2:+1.239%,3:+17.655%,4:+2.667% |
| fresh_paired_rust | live-subscriber | stream | complete_harness_lifecycle_wall_ms | 1.304 | 1:+0.145%,2:+1.304%,3:+17.485%,4:+2.780% |
| fresh_paired_rust | live-subscriber | large | mean_turn_ms | 8.848 | 0:+31.481%,1:+13.505%,2:+8.848%,4:+8.806% |
| fresh_paired_rust | live-subscriber | large | turn_cpu_ms_per_turn | 25.000 | 0:+50.000%,2:+25.000%,4:+25.000% |
| fresh_paired_rust | live-subscriber | large | through_cleanup_self_cpu_ms | 6.250 | 0:+20.000%,2:+6.250%,4:+6.250% |
| fresh_paired_rust | live-subscriber | large | lifecycle_ms | 0.322 | 0:+12.815%,3:+4.051%,4:+0.322% |
| fresh_paired_rust | live-subscriber | large | max_sampled_anon_pss_mib | 0.244 | 0:+0.244%,2:+0.547%,3:+0.329% |
| fresh_paired_rust | live-subscriber | large | max_sampled_pss_mib | -0.145 | 0:+0.202%,2:+0.348% |
| fresh_paired_rust | live-subscriber | large | max_sampled_rss_mib | -0.178 | 0:+0.174%,2:+0.353% |
| fresh_paired_rust | live-subscriber | large | median_measured_turn_ms | 8.848 | 0:+31.481%,1:+13.505%,2:+8.848%,4:+8.806% |
| fresh_paired_rust | live-subscriber | large | lifecycle_self_cpu_ms | 6.250 | 0:+20.000%,2:+6.250%,4:+6.250% |
| fresh_paired_rust | live-subscriber | large | measured_turn_cpu_ms | 25.000 | 0:+50.000%,2:+25.000%,4:+25.000% |
| fresh_paired_rust | live-subscriber | large | max_sampled_turn_rss_mib | -0.598 | 0:+0.357%,2:+0.351% |
| fresh_paired_rust | live-subscriber | large | through_product_exit_wall_ms | 0.068 | 0:+14.842%,3:+2.480%,4:+0.068% |
| fresh_paired_rust | live-subscriber | large | complete_harness_lifecycle_wall_ms | 2.907 | 0:+15.231%,2:+4.818%,3:+1.861%,4:+2.907% |
| fresh_paired_rust | live-subscriber | tool | mean_turn_ms | 6.081 | 0:+30.784%,1:+34.233%,3:+6.081% |
| fresh_paired_rust | live-subscriber | tool | turn_cpu_ms_per_turn | 0.000 | 0:+20.000%,1:+40.000% |
| fresh_paired_rust | live-subscriber | tool | through_cleanup_self_cpu_ms | 5.556 | 0:+16.667%,1:+27.778%,3:+5.556% |
| fresh_paired_rust | live-subscriber | tool | lifecycle_ms | 4.509 | 0:+4.509%,1:+13.943%,3:+10.753% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_anon_pss_mib | 0.018 | 1:+0.018%,2:+0.228%,3:+0.659% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_pss_mib | -0.157 | 2:+0.236% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_rss_mib | -0.092 | 2:+0.307% |
| fresh_paired_rust | live-subscriber | tool | median_measured_turn_ms | 6.081 | 0:+30.784%,1:+34.233%,3:+6.081% |
| fresh_paired_rust | live-subscriber | tool | lifecycle_self_cpu_ms | 5.556 | 0:+16.667%,1:+27.778%,3:+5.556% |
| fresh_paired_rust | live-subscriber | tool | measured_turn_cpu_ms | 0.000 | 0:+20.000%,1:+40.000% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_turn_rss_mib | -0.157 | 2:+0.262%,3:+0.083% |
| fresh_paired_rust | live-subscriber | tool | through_product_exit_wall_ms | 4.250 | 0:+4.250%,1:+13.479%,3:+10.182%,4:+0.756% |
| fresh_paired_rust | live-subscriber | tool | complete_harness_lifecycle_wall_ms | 4.192 | 0:+4.192%,1:+12.653%,3:+9.346%,4:+0.072% |
| fresh_paired_rust | live-subscriber | cancel | mean_turn_ms | -2.956 | 1:+2.008% |
| fresh_paired_rust | live-subscriber | cancel | turn_cpu_ms_per_turn | 0.000 | 0:+33.333% |
| fresh_paired_rust | live-subscriber | cancel | lifecycle_ms | -0.529 | 2:+0.613%,4:+3.393% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_anon_pss_mib | -0.121 | 1:+1.989%,2:+0.107% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_pss_mib | -0.649 | 1:+0.376% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_rss_mib | -0.645 | 1:+0.414% |
| fresh_paired_rust | live-subscriber | cancel | median_measured_turn_ms | -2.956 | 1:+2.008% |
| fresh_paired_rust | live-subscriber | cancel | measured_turn_cpu_ms | 0.000 | 0:+33.333% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_turn_rss_mib | -0.648 | 1:+0.387%,2:+0.215% |
| fresh_paired_rust | live-subscriber | cancel | through_product_exit_wall_ms | -1.553 | 2:+2.220%,4:+4.701% |
| fresh_paired_rust | live-subscriber | cancel | complete_harness_lifecycle_wall_ms | -1.962 | 2:+2.069%,4:+4.612% |
| prior_pi | no-live-subscriber | short-small | closed_allocated_bytes | 43.738 | cross-batch |
| prior_pi | no-live-subscriber | short-small | closed_logical_bytes | 43.645 | cross-batch |
| prior_pi | no-live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 2.017 | cross-batch |
| prior_pi | no-live-subscriber | short-small | lifecycle_ms | 3.090 | cross-batch |
| prior_pi | no-live-subscriber | short-small | lifecycle_self_cpu_ms | 2.627 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_anon_pss_mib | 1.115 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_pss_mib | 1.443 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_rss_mib | 1.054 | cross-batch |
| prior_pi | no-live-subscriber | short-small | mean_turn_ms | 4.748 | cross-batch |
| prior_pi | no-live-subscriber | short-small | measured_turn_cpu_ms | 2.739 | cross-batch |
| prior_pi | no-live-subscriber | short-small | measured_turn_write_bytes | 4.833 | cross-batch |
| prior_pi | no-live-subscriber | short-small | median_measured_turn_ms | 5.292 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_process_write_bytes | 4.744 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_process_write_mib | 4.744 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_self_cpu_ms | 1.426 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_product_exit_wall_ms | 2.024 | cross-batch |
| prior_pi | no-live-subscriber | short-small | turn_cpu_ms_per_turn | 2.739 | cross-batch |
| prior_pi | no-live-subscriber | short-small | turn_write_bytes_per_turn | 4.833 | cross-batch |
| prior_pi | no-live-subscriber | short-large | closed_allocated_bytes | 44.150 | cross-batch |
| prior_pi | no-live-subscriber | short-large | closed_logical_bytes | 44.069 | cross-batch |
| prior_pi | no-live-subscriber | short-large | complete_harness_lifecycle_wall_ms | 3.744 | cross-batch |
| prior_pi | no-live-subscriber | short-large | lifecycle_ms | 5.038 | cross-batch |
| prior_pi | no-live-subscriber | short-large | lifecycle_self_cpu_ms | 4.253 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_anon_pss_mib | 1.264 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_pss_mib | 1.488 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_rss_mib | 1.179 | cross-batch |
| prior_pi | no-live-subscriber | short-large | mean_turn_ms | 4.871 | cross-batch |
| prior_pi | no-live-subscriber | short-large | measured_turn_cpu_ms | 3.300 | cross-batch |
| prior_pi | no-live-subscriber | short-large | measured_turn_write_bytes | 5.537 | cross-batch |
| prior_pi | no-live-subscriber | short-large | median_measured_turn_ms | 5.738 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_process_write_bytes | 5.228 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_process_write_mib | 5.228 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_self_cpu_ms | 2.986 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_product_exit_wall_ms | 3.865 | cross-batch |
| prior_pi | no-live-subscriber | short-large | turn_cpu_ms_per_turn | 3.300 | cross-batch |
| prior_pi | no-live-subscriber | short-large | turn_write_bytes_per_turn | 5.537 | cross-batch |
| prior_pi | no-live-subscriber | stream | closed_allocated_bytes | 16.750 | cross-batch |
| prior_pi | no-live-subscriber | stream | closed_logical_bytes | 16.624 | cross-batch |
| prior_pi | no-live-subscriber | stream | max_sampled_pss_mib | 1.222 | cross-batch |
| prior_pi | no-live-subscriber | stream | measured_turn_write_bytes | 2.817 | cross-batch |
| prior_pi | no-live-subscriber | stream | through_cleanup_process_write_bytes | 4.009 | cross-batch |
| prior_pi | no-live-subscriber | stream | through_cleanup_process_write_mib | 4.009 | cross-batch |
| prior_pi | no-live-subscriber | stream | turn_write_bytes_per_turn | 2.817 | cross-batch |
| prior_pi | no-live-subscriber | large | closed_allocated_bytes | 11.237 | cross-batch |
| prior_pi | no-live-subscriber | large | closed_logical_bytes | 11.140 | cross-batch |
| prior_pi | no-live-subscriber | large | lifecycle_ms | 1.268 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_anon_pss_mib | 1.073 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_pss_mib | 1.504 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_rss_mib | 1.018 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_turn_rss_mib | 1.017 | cross-batch |
| prior_pi | no-live-subscriber | large | measured_turn_write_bytes | 3.417 | cross-batch |
| prior_pi | no-live-subscriber | large | through_cleanup_process_write_bytes | 4.541 | cross-batch |
| prior_pi | no-live-subscriber | large | through_cleanup_process_write_mib | 4.541 | cross-batch |
| prior_pi | no-live-subscriber | large | turn_write_bytes_per_turn | 3.417 | cross-batch |
| prior_pi | no-live-subscriber | tool | closed_allocated_bytes | 19.844 | cross-batch |
| prior_pi | no-live-subscriber | tool | closed_logical_bytes | 19.736 | cross-batch |
| prior_pi | no-live-subscriber | tool | lifecycle_ms | 1.219 | cross-batch |
| prior_pi | no-live-subscriber | tool | max_sampled_pss_mib | 1.336 | cross-batch |
| prior_pi | no-live-subscriber | tool | max_sampled_turn_rss_mib | 1.031 | cross-batch |
| prior_pi | no-live-subscriber | tool | measured_turn_write_bytes | 3.110 | cross-batch |
| prior_pi | no-live-subscriber | tool | through_cleanup_process_write_bytes | 4.171 | cross-batch |
| prior_pi | no-live-subscriber | tool | through_cleanup_process_write_mib | 4.171 | cross-batch |
| prior_pi | no-live-subscriber | tool | turn_write_bytes_per_turn | 3.110 | cross-batch |
| prior_pi | no-live-subscriber | cancel | closed_allocated_bytes | 13.900 | cross-batch |
| prior_pi | no-live-subscriber | cancel | closed_logical_bytes | 13.776 | cross-batch |
| prior_pi | no-live-subscriber | cancel | lifecycle_ms | 1.150 | cross-batch |
| prior_pi | no-live-subscriber | cancel | max_sampled_pss_mib | 1.361 | cross-batch |
| prior_pi | no-live-subscriber | cancel | max_sampled_turn_rss_mib | 1.014 | cross-batch |
| prior_pi | no-live-subscriber | cancel | measured_turn_write_bytes | 3.522 | cross-batch |
| prior_pi | no-live-subscriber | cancel | through_cleanup_process_write_bytes | 4.767 | cross-batch |
| prior_pi | no-live-subscriber | cancel | through_cleanup_process_write_mib | 4.767 | cross-batch |
| prior_pi | no-live-subscriber | cancel | turn_write_bytes_per_turn | 3.522 | cross-batch |
| prior_pi | live-subscriber | short-small | closed_allocated_bytes | 43.738 | cross-batch |
| prior_pi | live-subscriber | short-small | closed_logical_bytes | 43.645 | cross-batch |
| prior_pi | live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 1.995 | cross-batch |
| prior_pi | live-subscriber | short-small | lifecycle_ms | 3.041 | cross-batch |
| prior_pi | live-subscriber | short-small | lifecycle_self_cpu_ms | 3.037 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_anon_pss_mib | 1.190 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_pss_mib | 1.518 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_rss_mib | 1.104 | cross-batch |
| prior_pi | live-subscriber | short-small | mean_turn_ms | 4.627 | cross-batch |
| prior_pi | live-subscriber | short-small | measured_turn_cpu_ms | 3.708 | cross-batch |
| prior_pi | live-subscriber | short-small | measured_turn_write_bytes | 4.834 | cross-batch |
| prior_pi | live-subscriber | short-small | median_measured_turn_ms | 5.286 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_process_write_bytes | 4.745 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_process_write_mib | 4.745 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_self_cpu_ms | 1.691 | cross-batch |
| prior_pi | live-subscriber | short-small | through_product_exit_wall_ms | 2.002 | cross-batch |
| prior_pi | live-subscriber | short-small | turn_cpu_ms_per_turn | 3.708 | cross-batch |
| prior_pi | live-subscriber | short-small | turn_write_bytes_per_turn | 4.834 | cross-batch |
| prior_pi | live-subscriber | short-large | closed_allocated_bytes | 44.150 | cross-batch |
| prior_pi | live-subscriber | short-large | closed_logical_bytes | 44.086 | cross-batch |
| prior_pi | live-subscriber | short-large | complete_harness_lifecycle_wall_ms | 3.637 | cross-batch |
| prior_pi | live-subscriber | short-large | lifecycle_ms | 4.836 | cross-batch |
| prior_pi | live-subscriber | short-large | lifecycle_self_cpu_ms | 4.604 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_anon_pss_mib | 1.283 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_pss_mib | 1.502 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_rss_mib | 1.194 | cross-batch |
| prior_pi | live-subscriber | short-large | mean_turn_ms | 4.321 | cross-batch |
| prior_pi | live-subscriber | short-large | measured_turn_cpu_ms | 3.727 | cross-batch |
| prior_pi | live-subscriber | short-large | measured_turn_write_bytes | 5.539 | cross-batch |
| prior_pi | live-subscriber | short-large | median_measured_turn_ms | 4.811 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_process_write_bytes | 5.228 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_process_write_mib | 5.228 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_self_cpu_ms | 3.253 | cross-batch |
| prior_pi | live-subscriber | short-large | through_product_exit_wall_ms | 3.729 | cross-batch |
| prior_pi | live-subscriber | short-large | turn_cpu_ms_per_turn | 3.727 | cross-batch |
| prior_pi | live-subscriber | short-large | turn_write_bytes_per_turn | 5.539 | cross-batch |
| prior_pi | live-subscriber | stream | closed_allocated_bytes | 16.750 | cross-batch |
| prior_pi | live-subscriber | stream | closed_logical_bytes | 16.624 | cross-batch |
| prior_pi | live-subscriber | stream | max_sampled_pss_mib | 1.229 | cross-batch |
| prior_pi | live-subscriber | stream | measured_turn_write_bytes | 2.817 | cross-batch |
| prior_pi | live-subscriber | stream | through_cleanup_process_write_bytes | 4.009 | cross-batch |
| prior_pi | live-subscriber | stream | through_cleanup_process_write_mib | 4.009 | cross-batch |
| prior_pi | live-subscriber | stream | turn_write_bytes_per_turn | 2.817 | cross-batch |
| prior_pi | live-subscriber | large | closed_allocated_bytes | 11.237 | cross-batch |
| prior_pi | live-subscriber | large | closed_logical_bytes | 11.140 | cross-batch |
| prior_pi | live-subscriber | large | lifecycle_ms | 1.210 | cross-batch |
| prior_pi | live-subscriber | large | lifecycle_self_cpu_ms | 1.062 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_anon_pss_mib | 1.080 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_pss_mib | 1.512 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_rss_mib | 1.022 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_turn_rss_mib | 1.021 | cross-batch |
| prior_pi | live-subscriber | large | measured_turn_write_bytes | 3.417 | cross-batch |
| prior_pi | live-subscriber | large | through_cleanup_process_write_bytes | 4.541 | cross-batch |
| prior_pi | live-subscriber | large | through_cleanup_process_write_mib | 4.541 | cross-batch |
| prior_pi | live-subscriber | large | turn_write_bytes_per_turn | 3.417 | cross-batch |
| prior_pi | live-subscriber | tool | closed_allocated_bytes | 19.844 | cross-batch |
| prior_pi | live-subscriber | tool | closed_logical_bytes | 19.736 | cross-batch |
| prior_pi | live-subscriber | tool | lifecycle_ms | 1.273 | cross-batch |
| prior_pi | live-subscriber | tool | lifecycle_self_cpu_ms | 1.053 | cross-batch |
| prior_pi | live-subscriber | tool | max_sampled_pss_mib | 1.332 | cross-batch |
| prior_pi | live-subscriber | tool | max_sampled_turn_rss_mib | 1.030 | cross-batch |
| prior_pi | live-subscriber | tool | measured_turn_write_bytes | 3.110 | cross-batch |
| prior_pi | live-subscriber | tool | through_cleanup_process_write_bytes | 4.171 | cross-batch |
| prior_pi | live-subscriber | tool | through_cleanup_process_write_mib | 4.171 | cross-batch |
| prior_pi | live-subscriber | tool | turn_write_bytes_per_turn | 3.110 | cross-batch |
| prior_pi | live-subscriber | cancel | closed_allocated_bytes | 13.900 | cross-batch |
| prior_pi | live-subscriber | cancel | closed_logical_bytes | 13.776 | cross-batch |
| prior_pi | live-subscriber | cancel | lifecycle_ms | 1.120 | cross-batch |
| prior_pi | live-subscriber | cancel | max_sampled_pss_mib | 1.347 | cross-batch |
| prior_pi | live-subscriber | cancel | max_sampled_turn_rss_mib | 1.007 | cross-batch |
| prior_pi | live-subscriber | cancel | measured_turn_write_bytes | 3.522 | cross-batch |
| prior_pi | live-subscriber | cancel | through_cleanup_process_write_bytes | 4.767 | cross-batch |
| prior_pi | live-subscriber | cancel | through_cleanup_process_write_mib | 4.767 | cross-batch |
| prior_pi | live-subscriber | cancel | turn_write_bytes_per_turn | 3.522 | cross-batch |
| prior_deepseek | live-subscriber | short-small | mean_turn_ms | 1.171 | cross-batch |
| prior_deepseek | live-subscriber | short-small | median_measured_turn_ms | 1.224 | cross-batch |
| prior_deepseek | live-subscriber | short-small | turn_cpu_ms_per_turn | 1.534 | cross-batch |
| prior_deepseek | live-subscriber | short-small | turn_write_bytes_per_turn | 50.464 | cross-batch |
| prior_deepseek | live-subscriber | short-large | mean_turn_ms | 1.116 | cross-batch |
| prior_deepseek | live-subscriber | short-large | median_measured_turn_ms | 1.111 | cross-batch |
| prior_deepseek | live-subscriber | short-large | turn_cpu_ms_per_turn | 1.464 | cross-batch |
| prior_deepseek | live-subscriber | short-large | turn_write_bytes_per_turn | 58.144 | cross-batch |
| prior_deepseek | live-subscriber | stream | mean_turn_ms | 1.010 | cross-batch |
| prior_deepseek | live-subscriber | stream | median_measured_turn_ms | 1.010 | cross-batch |
| prior_deepseek | live-subscriber | stream | turn_write_bytes_per_turn | 50.714 | cross-batch |
| prior_deepseek | live-subscriber | large | turn_write_bytes_per_turn | 35.143 | cross-batch |

- Only the fresh old/new Rust products are interleaved pairs. Pi/DeepSeek use fixed previous batches and separate descriptive ratios of medians; no causal parity or paired confidence claim.
- /proc CPU counters use 100 ticks/s; each cumulative endpoint has 10 ms granularity. This is not profiler sampling.
- A product measured-turn median and a product measured-turn mean are different estimands. Across products we report median and range of those statistics, not pooled turns.
- DeepSeek SDK idle does not await flush/fsync. Native wait4 CPU covers exit/flush and verification separately; full process write_bytes is unavailable, not zero. No equivalent lifecycle ratio is constructed.
- All recorded adverse pairs and all unavailable ratios are retained, including reversals hidden by a favorable group median.

Unavailable ratio records, all per-product values, and reference hashes are retained in report-data.json.
