import gzip
import hashlib
import json
import pathlib
import shutil

root = pathlib.Path('/workspace/issue-481-evidence')
manifest_path = root / 'inactive-heaps-lossless-retention.jsonl'
paths = sorted(p for name in ['attr-heap-small', 'continued-profile']
               for p in (root / name).rglob('*.heap') if p.stat().st_size > 10_000_000)
with manifest_path.open('x') as manifest:
    for path in paths:
        encoded = path.with_suffix(path.suffix + '.gz')
        original_hash = hashlib.sha256()
        size = 0
        with path.open('rb') as source, encoded.open('xb') as output:
            with gzip.GzipFile(filename='', mode='wb', fileobj=output, compresslevel=1, mtime=0) as stream:
                while chunk := source.read(1024 * 1024):
                    original_hash.update(chunk)
                    size += len(chunk)
                    stream.write(chunk)
        restored_hash = hashlib.sha256()
        restored_size = 0
        with gzip.open(encoded, 'rb') as stream:
            while chunk := stream.read(1024 * 1024):
                restored_hash.update(chunk)
                restored_size += len(chunk)
        assert (restored_hash.hexdigest(), restored_size) == (original_hash.hexdigest(), size)
        row = dict(original=str(path), retained=str(encoded), original_bytes=size,
                   original_sha256=original_hash.hexdigest(), retained_bytes=encoded.stat().st_size,
                   retained_sha256=hashlib.file_digest(encoded.open('rb'), 'sha256').hexdigest(),
                   restoration='gzip.decompress; exact round-trip SHA-256 and length verified before raw release')
        manifest.write(json.dumps(row, sort_keys=True) + '\n')
        manifest.flush()
        path.unlink()
        print(json.dumps(row), flush=True)
