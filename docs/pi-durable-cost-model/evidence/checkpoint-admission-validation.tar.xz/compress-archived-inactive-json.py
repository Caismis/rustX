from pathlib import Path
import gzip
import hashlib
import json
import shutil

root = Path('/workspace/issue-481-evidence')
repo = Path('/workspace/rustX-pi-durable/docs/pi-durable-cost-model/evidence')
sources = {
    'native-statement-reuse-comparison': 'native-statement-reuse-results.tar.manifest.json',
    'native-statement-reuse-comparison-capacity-fixed': 'native-statement-reuse-results.tar.manifest.json',
    'observer-demand-v3-control': 'observer-demand-cancellation-v3.tar.manifest.json',
}
manifests = {name: json.loads((repo/manifest).read_text()) for name, manifest in sources.items()}
paths = sorted(path for name in sources for path in (root/name).rglob('*.json')
               if path.stat().st_size > 1024**2)
retention = root/'checkpoint-admission-validation/inactive-json-retention.jsonl'
with retention.open('x') as output:
    for path in paths:
        name = str(path.relative_to(root))
        original = manifests[path.relative_to(root).parts[0]][name]
        assert path.stat().st_size == original['bytes']
        assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == original['sha256'], name
        encoded = path.with_suffix(path.suffix + '.gz')
        with path.open('rb') as raw, encoded.open('xb') as destination:
            with gzip.GzipFile(filename='', mode='wb', fileobj=destination, compresslevel=1, mtime=0) as stream:
                shutil.copyfileobj(raw, stream, 1024*1024)
        restored = hashlib.sha256()
        size = 0
        with gzip.open(encoded, 'rb') as stream:
            while chunk := stream.read(1024*1024):
                restored.update(chunk)
                size += len(chunk)
        assert restored.hexdigest() == original['sha256'] and size == original['bytes']
        row = dict(original=str(path), retained=str(encoded), original_bytes=size,
                   original_sha256=original['sha256'], retained_bytes=encoded.stat().st_size,
                   retained_sha256=hashlib.file_digest(encoded.open('rb'), 'sha256').hexdigest(),
                   archive_manifest=sources[path.relative_to(root).parts[0]],
                   restoration='gzip -dc retained > original; original SHA-256/length verified against the already published archive before release')
        output.write(json.dumps(row, sort_keys=True)+'\n')
        output.flush()
        path.unlink()
print(json.dumps(dict(files=len(paths), original_bytes=sum(json.loads(x)['original_bytes'] for x in retention.read_text().splitlines()), retained_bytes=sum(json.loads(x)['retained_bytes'] for x in retention.read_text().splitlines()))))
