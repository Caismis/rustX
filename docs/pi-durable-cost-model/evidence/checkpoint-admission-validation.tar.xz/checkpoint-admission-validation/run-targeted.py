from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/workspace/rustX-pi-durable')
identity = json.loads((root/'source-identity.json').read_text())
assert all(hashlib.file_digest((repo/p).open('rb'), 'sha256').hexdigest() == expected for p, expected in identity['files'].items())
records = [json.loads(line) for line in (root/'freshness.stdout').read_text().splitlines() if line.startswith('{')]
assert records[-1]['reason'] == 'build-finished' and records[-1]['success']
artifact = next(r for r in records if r.get('reason') == 'compiler-artifact' and r['target']['name'] == 'rustx' and r.get('executable'))
binary = Path(artifact['executable'])
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN', 'SECRET', 'CREDENTIAL', 'API_KEY'])}
prefixes = ['runtime_client::preflight::tests::', 'runtime_client::checkpoint::',
            'runtime_client::structural_json::tests::', 'runtime_client::host::',
            'runtime_client::projection::', 'scripted_suites::runtime_client::',
            'runtime::read_layout::', 'durable::sqlite::indexed_fact_tests::']
passed = set()
for i, prefix in enumerate(prefixes):
    command = [str(binary), prefix, '--nocapture']
    with (root/f'tests-{i}.log').open('x') as log:
        result = subprocess.run(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT, check=False)
    assert result.returncode == 0, (prefix, result.returncode)
    names = re.findall(r'^test (\S+) \.\.\. ok$', (root/f'tests-{i}.log').read_text(), re.M)
    assert names, prefix
    passed.update(names)
    print(prefix, len(names), 'passed', flush=True)
assert all(hashlib.file_digest((repo/p).open('rb'), 'sha256').hexdigest() == expected for p, expected in identity['files'].items())
(root/'tests.json').write_text(json.dumps(dict(source=identity, binary=str(binary), binary_sha256=hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(), commands=[[str(binary), p, '--nocapture'] for p in prefixes], distinct_passed=len(passed), passed=sorted(passed)), indent=2)+'\n')
print('Distinct passed:', len(passed), flush=True)
