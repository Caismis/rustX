use rustx::durable::{ConversationStore,SqliteConversationStore};
use rustx::events::types::{RuntimeEvent,RuntimeEventEnvelope,EVENT_SCHEMA_VERSION};
use rustx::runtime::identity::{ConversationId,AttemptId,EventId};
use rustx::model::ModelFinishReason;
use serde_json::json;
use std::sync::{Arc,Barrier};
use std::time::Instant;
fn ns(t:Instant)->u64{t.elapsed().as_nanos().try_into().unwrap()}
fn io()->String{std::fs::read_to_string("/proc/self/io").unwrap()}
fn append(store:&SqliteConversationStore,i:usize,size:usize)->u64{
 let owner=AttemptId::new(format!("inspection-owner-{i}"));
 let event=if size==0{RuntimeEvent::AttemptStarted{attempt_id:owner.clone()}}else{
 RuntimeEvent::AttemptCompleted{attempt_id:owner.clone(),finish_reason:ModelFinishReason::Other{reason:"x".repeat(size)}}};
 store.append_event(RuntimeEventEnvelope{schema_version:EVENT_SCHEMA_VERSION,event_id:EventId::new(format!("inspection-event-{i}")),sequence:0,tool_occurrence:None,observation:None,conversation_id:store.conversation_id().clone(),attempt_id:Some(owner),turn_id:None,timestamp:chrono::DateTime::parse_from_rfc3339("2026-01-01T00:00:00Z").unwrap().with_timezone(&chrono::Utc),event}).unwrap().sequence
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let root=std::path::Path::new(&args[1]);let case=&args[2];std::fs::create_dir_all(root).unwrap();
 let size=match case.as_str(){"small"|"concurrent"=>0,"leaf-10k"=>10_000,"segmented-32k"=>32_000,_=>panic!("unknown case")};
 let started=Instant::now();let store=Arc::new(SqliteConversationStore::open(ConversationId::new("conv_36524fd8-f674-7fc2-8125-06d01fee0e18"),&root.join("conversation.sqlite")).unwrap());store.initialize(&[]).unwrap();
 let before=io();let at=Instant::now();let mut sequences=Vec::new();for i in 0..64{sequences.push(append(&store,i,size));}let append_ns=ns(at);let after_append=io();let through=*sequences.last().unwrap();let selected=sequences[0];
 let path:Vec<String>=if size==0{vec!["event".into(),"attempt_id".into()]}else{vec!["event".into(),"finish_reason".into(),"reason".into()]};
 let at=Instant::now();let original=store.event_value_read(selected,through,&path,0,65_536).unwrap();let first_read_ns=ns(at);
 let value:serde_json::Value=serde_json::from_slice(&original.bytes).unwrap();assert_eq!(value,if size==0{json!("inspection-owner-0")}else{json!("x".repeat(size))});assert!(original.next_offset.is_none());
 let mut reads=Vec::new();for _ in 0..32{let at=Instant::now();assert_eq!(store.event_value_read(selected,through,&path,0,65_536).unwrap(),original);reads.push(ns(at));}
 let at=Instant::now();let page=store.event_value_page(selected,through,&[],0,32).unwrap();let first_page_ns=ns(at);let expected=serde_json::to_value(page).unwrap();let mut pages=Vec::new();for _ in 0..32{let at=Instant::now();assert_eq!(serde_json::to_value(store.event_value_page(selected,through,&[],0,32).unwrap()).unwrap(),expected);pages.push(ns(at));}
 let after_inspection=io();let mut concurrent_reads=Vec::new();let mut concurrent_writer_ns=None;
 if case=="concurrent"{
  let barrier=Arc::new(Barrier::new(3));let writer=Arc::clone(&store);let sync=Arc::clone(&barrier);let handle=std::thread::spawn(move||{sync.wait();let at=Instant::now();for i in 1000..1032{append(&writer,i,0);}ns(at)});
  let reader=Arc::clone(&store);let sync=Arc::clone(&barrier);let p=path.clone();let expected=original.clone();let read=std::thread::spawn(move||{sync.wait();let mut times=Vec::new();for _ in 0..64{let at=Instant::now();assert_eq!(reader.event_value_read(selected,through,&p,0,65_536).unwrap(),expected);times.push(ns(at));}times});barrier.wait();concurrent_writer_ns=Some(handle.join().unwrap());concurrent_reads=read.join().unwrap();
 }
 drop(store);let reopened=SqliteConversationStore::open_existing(ConversationId::new("conv_36524fd8-f674-7fc2-8125-06d01fee0e18"),&root.join("conversation.sqlite")).unwrap();assert_eq!(reopened.event_value_read(selected,through,&path,0,65_536).unwrap(),original);drop(reopened);
 println!("{}",json!({"case":case,"events":64,"reason_bytes":size,"append_ns":append_ns,"first_read_ns":first_read_ns,"repeat_reads_ns":reads,"first_page_ns":first_page_ns,"repeat_pages_ns":pages,"concurrent_reads_ns":concurrent_reads,"concurrent_writer_ns":concurrent_writer_ns,"io_before":before,"io_after_append":after_append,"io_after_inspection":after_inspection,"io_after_close":io(),"elapsed_ns":ns(started),"exact_field_and_reopen_oracles_passed":true}));
}
