"""Render every retained formal metric, diagnostic delta and inspection pair."""
import collections,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;a=json.loads((r/'audit.json').read_text());assert a['accepted']
f=lambda x:'NA' if x is None else f'{x:.3f}'
pct=lambda x:'NA' if x is None else f'{x:+.3f}%'
lines=['# 观察层边界优化：全部测量单元','','数据来自同轮 Rust 基线与候选。每格四对，比例先逐对计算再取中位数。NA 保留缺失值或零分母；无置信区间或 Pi 倍数结论。','','## 正式矩阵摘要','','|订阅|情形|轮次中位耗时 ms，旧→新|配对变化|全程 CPU|全程进程写入|采样 RSS|','|---|---|---:|---:|---:|---:|---:|']
for cell in a['dataset']['table']:
 m=cell['metrics'];wall=m['median_measured_turn_ms'];p=lambda key:pct(m[key]['paired_percent_median'])
 lines.append(f"|{cell['mode']}|{cell['case']}|{f(wall['denominator_median'])}→{f(wall['numerator_median'])}|{p('median_measured_turn_ms')}|{p('through_cleanup_self_cpu_ms')}|{p('through_cleanup_process_write_mib')}|{p('max_sampled_rss_mib')}|")
lines+=['','全程 CPU 为产品进程累计 CPU 至清理后，写入为同一时点 /proc write_bytes；请求窗口和初始化前后的计数另列于下。CPU 端点为 10ms 粒度。采样 RSS 不是连续峰值。','','## 全部四对与反向结果','','|订阅|情形|metric|旧值四对|新值四对|配对百分比四对|中位数|范围|新值较低/相等/较高|','|---|---|---|---|---|---|---:|---|---|']
for g in a['dataset']['groups']:
 old=', '.join(f(x) for x in g['denominator_values']['values']);new=', '.join(f(x) for x in g['numerator_values']['values']);changes=', '.join(pct(x) for x in g['percent_change']['values']);s=g['percent_change']
 lines.append(f"|{g['mode']}|{g['case']}|{g['metric']}|{old}|{new}|{changes}|{pct(s['median'])}|{pct(s['minimum'])}…{pct(s['maximum'])}|{g['numerator_lower']}/{g['equal']}/{g['numerator_higher']}|")
lines+=['','## 有界历史检查','','首次指进程内首次 API 调用；未清内核页缓存。append 为 64 事件整体；repeat 为每个产品的 32 次调用中位数。并发为另写 32 事件/读旧 cut 64 次。完整 CPU 使用 /usr/bin/time（10ms 输出粒度），full_write_bytes 包含创建至 reopen 关闭。inspection_write_bytes 只覆盖首次/重复字段和分页，不含并发追加；并发产生的写入计入 full_write_bytes。','','|情形|metric|旧值四对|新值四对|配对百分比四对|中位变化|','|---|---|---|---|---|---:|']
inspection=[]
for case in ['small','leaf-10k','segmented-32k','concurrent']:
 rows=[x for x in a['inspection'] if x['case']==case]
 for metric in rows[0]['metrics']:
  old=[next(x['metrics'][metric] for x in rows if x['pair']==i and x['revision']=='baseline') for i in range(4)];new=[next(x['metrics'][metric] for x in rows if x['pair']==i and x['revision']=='candidate') for i in range(4)]
  changes=[None if b in (None,0) or c is None else 100*(c/b-1) for b,c in zip(old,new)];available=[v for v in changes if v is not None]
  item={'case':case,'metric':metric,'old':old,'new':new,'paired_percent':changes,'paired_percent_median':statistics.median(available) if available else None,'old_median':statistics.median([v for v in old if v is not None]) if any(v is not None for v in old) else None,'new_median':statistics.median([v for v in new if v is not None]) if any(v is not None for v in new) else None};inspection.append(item)
  lines.append('|'+case+'|'+metric+'|'+', '.join(f(v) for v in old)+'|'+', '.join(f(v) for v in new)+'|'+', '.join(pct(v) for v in changes)+'|'+pct(item['paired_percent_median'])+'|')
lines+=['','## 全部逻辑列差值','','每个产品 32 热轮。字节为 SQLite 各列值 cast 为 BLOB 后 length 的差；不含记录/页/索引开销，不是写入流量。','','|情形|revision|表|新增行|列值字节差|各列字节差|','|---|---|---|---:|---:|---|']
for d in a['columns']:
 for table,t in d['tables'].items():
  lines.append(f"|{d['case']}|{d['revision']}|{table}|{t['rows']}|{t['bytes']}|"+', '.join(f'{key}={n}' for key,n in t['columns'].items())+'|')
lines+=['','## WAL 独立诊断','','|revision|情形|热轮|提交|帧数|帧字节|','|---|---|---:|---:|---:|---:|']
for label,cases in a['wal'].items():
 for case,w in cases.items():lines.append(f"|{label}|{case}|{w['steady_turns']}|{w['wal_write_commits']}|{w['wal_frames']}|{w['wal_frame_bytes']}|")
lines+=['','端点页面归属的逐表帧数在原始 audit.json 中；它不构成逐次写入因果归属或可删除比例。','','## 固定的外部参考','','Pi 与 DeepSeek 均未执行；不为本轮生成跨批次新比值。此前结果、旧的不利批次和旧参考值未覆盖。']
assert not (r/'tables.md').exists();(r/'tables.md').write_text('\n'.join(lines)+'\n')
metrics=['median_measured_turn_ms','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib','max_sampled_rss_mib'];counts={}
for metric in metrics:
 groups=[g for g in a['dataset']['groups'] if g['metric']==metric];counts[metric]={k:sum(g[k] for g in groups) for k in ['numerator_lower','equal','numerator_higher']}
summary={'accepted':True,'formal_cells':a['dataset']['table'],'formal_counts':counts,'inspection':inspection}
(r/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n');print(json.dumps({'formal_counts':counts,'tables_lines':len(lines)}))
