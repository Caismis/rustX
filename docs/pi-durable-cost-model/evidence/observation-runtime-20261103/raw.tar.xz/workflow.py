import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
from fixture_binding import capture,affinity_snapshot,validate_affinity,FORMAL_PROTOCOL
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
write=lambda p,v:p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
os.sched_setaffinity(0,[2,8]);affinity=affinity_snapshot();validate_affinity(affinity)
def snapshot():
 assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime','test-support/fake-provider'],cwd=repo,text=True).strip()
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_files':{str(p.relative_to(repo)):sha(p) for d in ('src','tests') for p in sorted((repo/d).rglob('*')) if p.is_file()}|{p:sha(repo/p) for p in ['Cargo.toml','Cargo.lock']},'fixtures':capture(repo)}
before=snapshot();builds={label:json.loads((r/(label+'-build/identity.json')).read_text()) for label in ['baseline','candidate']}
for label,b in builds.items():
 assert b['verified'] and b['sha256']==sha(Path(b['binary'])) and all(c['exit']==0 for c in b['commands'])
 assert b['production_tree']==subprocess.check_output(['git','rev-parse',b['head']+':src'],cwd=repo,text=True).strip()
 probe=r/(label+'-build/probe-build.json');meta=json.loads(probe.read_text());assert meta['exit']==0 and meta['source_sha256']==sha(r/'inspect-probe.rs') and meta['binary_sha256']==sha(r/(label+'-build/inspect-probe'))
assert builds['candidate']['source_files']==before['source_files']
scripts={p.name:sha(p) for p in sorted(r.iterdir()) if p.is_file() and p.suffix in ['.py','.rs']}
pre={'utc':now(),'accepted':True,'protocol':FORMAL_PROTOCOL,'inspection_protocol':{'cases':['small','leaf-10k','segmented-32k','concurrent'],'pairs':4,'events_per_product':64,'repeat_reads':32,'repeat_pages':32,'concurrent_reader_operations':64,'concurrent_writer_events':32,'products':32,'cache':'No new inspection cache or background builder. Each operation owns bounded local material.'},'scripts':scripts,'source':before,'affinity':affinity,'builds':builds}
assert not (r/'premeasurement.json').exists();write(r/'premeasurement.json',pre)
steps=[]
def run(name,cmd):
 assert all(sha(r/n)==h for n,h in scripts.items());assert snapshot()==before
 item={'name':name,'command':cmd,'start_utc':now()};steps.append(item)
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 item.update(exit=done.returncode,end_utc=now());write(r/'workflow-commands.json',steps);print(name,done.returncode,flush=True)
 assert done.returncode==0,name
 assert all(sha(r/n)==h for n,h in scripts.items());assert snapshot()==before
base=r/'direct-cohorts';base.mkdir(exist_ok=False)
for label,mode in [('no-live','no-live-subscriber'),('live','live-subscriber')]:
 name='direct-'+label;cmd=['taskset','-c','2,8',sys.executable,'benchmarks/runtime/compare-revisions.py','--before',builds['baseline']['binary'],'--after',builds['candidate']['binary'],'--output',str(base/name),'--pairs','4','--observer-mode',mode]
 # Paired audit expects the unchanged controller stdout beside the cohort.
 run(name,cmd);(base/(name+'.stdout')).write_bytes((r/(name+'.stdout')).read_bytes())
run('inspection',[sys.executable,str(r/'run-inspection.py')])
for label,engine in [('baseline','baseline'),('candidate','complete')]:
 for kind,script in [('columns','columns-complete.py'),('wal','run-wal-rust.py')]:run(kind+'-'+engine,[sys.executable,str(r/script),'--binary',builds[label]['binary'],'--label',engine])
 run('wal-summary-'+engine,[sys.executable,str(r/'analyze-wal.py'),'--label',engine])
write(r/'source-after-measurement.json',snapshot());final=affinity_snapshot();validate_affinity(final);assert final['topology']==affinity['topology'];write(r/'affinity-after.json',final)
run('audit',[sys.executable,str(r/'audit-results.py')])
