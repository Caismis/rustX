import datetime,hashlib,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;label=sys.argv[1];build=r/(label+'-build');identity=json.loads((build/'identity.json').read_text());rows=[json.loads(l) for l in (build/'build.stdout').read_text().splitlines() if l.startswith('{')]
paths={}
for name in ['chrono','serde_json']:
 paths[name]=next(f for v in rows if v.get('reason')=='compiler-artifact' and v['target']['name']==name for f in v['filenames'] if f.endswith('.rlib'))
cmd=['rustc','--edition=2024','-O','-D','warnings',str(r/'inspect-probe.rs'),'--extern','rustx='+str(build/'librustx.rlib'),'-L','dependency=/home/capi/.cache/rustx-pr485-target/release/deps','-L','native=/home/capi/.cache/rustx-pr485-target/release/build']
# Native link search directories are emitted by dependency build scripts.
for d in Path('/home/capi/.cache/rustx-pr485-target/release/build').glob('*/out'):cmd+=['-L','native='+str(d)]
for name,path in paths.items():cmd+=['--extern',name+'='+path]
cmd+=['-o',str(build/'inspect-probe')]
with (build/'probe-build.stdout').open('x') as so,(build/'probe-build.stderr').open('x') as se:done=subprocess.run(cmd,stdout=so,stderr=se)
receipt={'command':cmd,'exit':done.returncode,'source_sha256':hashlib.sha256((r/'inspect-probe.rs').read_bytes()).hexdigest()}
if done.returncode==0:receipt['binary_sha256']=hashlib.sha256((build/'inspect-probe').read_bytes()).hexdigest()
(build/'probe-build.json').write_text(json.dumps(receipt,indent=2)+'\n');print('probe',label,done.returncode)
if done.returncode:print((build/'probe-build.stderr').read_text()[-5000:])
raise SystemExit(done.returncode)
