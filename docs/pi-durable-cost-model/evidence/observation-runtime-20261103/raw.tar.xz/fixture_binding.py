"""Read-only current measurement fixtures; never used to run a product.

The provider is a Python source project, separate from the Rust build inputs.
Keep its tracked inputs with the runtime harness without copying its venv or
bytecode caches. Raw-only auditors compare retained maps and never call here.
"""
import hashlib
from pathlib import Path
import subprocess
import datetime
import os

PROVIDER = 'test-support/fake-provider'
ROOTS = ('benchmarks/runtime', PROVIDER)
CPU_AFFINITY = [2, 8]
FORMAL_PROTOCOL = {
    'version': 1,
    'cases': ['short-small', 'short-large', 'stream', 'large', 'tool', 'cancel'],
    'observer_modes': ['no-live-subscriber', 'live-subscriber'],
    'pairs_per_cell': 4,
    'pair_ids': list(range(4)),
    'order': ['before_after' if pair % 2 == 0 else 'after_before' for pair in range(4)],
    'products': 96,
    'paired_comparisons': 48,
    'checked_request_pairs': 1128,
    'cpu_affinity': CPU_AFFINITY,
    'scope': 'Fresh interleaved Rust baseline/candidate only; no Pi/DeepSeek execution or cross-batch ratios.',
    'affinity_scope': 'Runner calling-thread affinity is observed before/after. taskset pins each controller to CPUs 2,8; product/provider descendants inherit that mask. Individual child threads are not independently sampled.',
    'topology_requirement': 'Distinct physical cores of the same observed CPU class; sibling masks do not overlap.',
    'statistics': 'All four paired values, missing counters, zeros and reversals retained; descriptive medians and ranges, no parity or confidence interval claim.',
}


def affinity_snapshot():
    def read(path):
        path = Path(path)
        return path.read_text().strip() if path.is_file() else None
    models = {}
    for block in Path('/proc/cpuinfo').read_text().split('\n\n'):
        fields = dict(line.split(':', 1) for line in block.splitlines() if ':' in line)
        fields = {key.strip(): value.strip() for key, value in fields.items()}
        if 'processor' in fields:
            models[int(fields['processor'])] = {key: fields.get(key) for key in ('vendor_id', 'cpu family', 'model', 'model name', 'stepping')}
    topology = {}
    for cpu in CPU_AFFINITY:
        base = Path('/sys/devices/system/cpu') / f'cpu{cpu}'
        topology[str(cpu)] = {key: read(base / path) for key, path in {
            'package_id': 'topology/physical_package_id', 'core_id': 'topology/core_id',
            'thread_siblings': 'topology/thread_siblings_list', 'core_type': 'topology/core_type',
            'capacity': 'cpu_capacity', 'max_frequency_khz': 'cpufreq/cpuinfo_max_freq',
            'base_frequency_khz': 'cpufreq/base_frequency',
        }.items()}
        topology[str(cpu)]['cpu_model'] = models[cpu]
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': os.getpid(),
            'actual_affinity': sorted(os.sched_getaffinity(0)),
            'online_cpus': read('/sys/devices/system/cpu/online'), 'topology': topology,
            'observed_scope': FORMAL_PROTOCOL['affinity_scope']}


def validate_affinity(snapshot, pinned=True):
    def cpus(value):
        result = set()
        for part in value.split(','):
            ends = [int(v) for v in part.split('-')]
            result.update(range(ends[0], ends[-1] + 1))
        return result
    actual = snapshot['actual_affinity']
    require(actual == CPU_AFFINITY if pinned else set(CPU_AFFINITY) <= set(actual), 'actual CPU affinity differs or requested CPUs unavailable')
    require(set(CPU_AFFINITY) <= cpus(snapshot['online_cpus']), 'requested CPU offline')
    require(snapshot['observed_scope'] == FORMAL_PROTOCOL['affinity_scope'], 'affinity observation scope differs')
    require(set(snapshot['topology']) == {'2', '8'}, 'CPU topology inventory differs')
    left, right = [snapshot['topology'][str(cpu)] for cpu in CPU_AFFINITY]
    require(all(row['package_id'] is not None and row['core_id'] is not None and row['thread_siblings'] for row in (left, right)), 'physical core evidence missing')
    require((left['package_id'], left['core_id']) != (right['package_id'], right['core_id']), 'requested CPUs share a physical core')
    require(not (cpus(left['thread_siblings']) & cpus(right['thread_siblings'])), 'requested CPU sibling groups overlap')
    require(left['cpu_model'] == right['cpu_model'], 'CPU models differ')
    require(all(left[k] == right[k] for k in ('core_type', 'capacity', 'max_frequency_khz', 'base_frequency_khz')), 'observed CPU class evidence differs')
    require(any(left[k] is not None for k in ('core_type', 'capacity', 'max_frequency_khz')), 'CPU class has no sysfs evidence')
    return {'verified': True, 'class_basis': {k: left[k] for k in ('core_type', 'capacity', 'max_frequency_khz', 'base_frequency_khz')},
            'limit': 'CPU class inferred from matching recorded model/sysfs evidence when core_type is unavailable; no per-thread affinity sampling.'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def capture(repo):
    repo = Path(repo)
    require(not git(repo, 'status', '--porcelain', '--untracked-files=all', '--', *ROOTS),
            'measurement fixture source is dirty or contains untracked inputs')
    provider = git(repo, 'ls-tree', '-r', '--name-only', 'HEAD', '--', PROVIDER).splitlines()
    require(len(provider) == len(set(provider)) and
            {PROVIDER + '/pyproject.toml', PROVIDER + '/uv.lock',
             PROVIDER + '/src/fake_provider/__main__.py'} <= set(provider),
            'provider tracked input inventory is incomplete')
    # Git intentionally ignores bytecode and environments. An extra importable
    # source/legacy .pyc under src must still not escape the measured inventory.
    actual_src = {p.relative_to(repo).as_posix()
                  for p in (repo / PROVIDER / 'src').rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts}
    require(actual_src == {p for p in provider if p.startswith(PROVIDER + '/src/')},
            'untracked or ignored importable provider input outside the tracked inventory')
    paths = sorted(p for p in (repo / 'benchmarks/runtime').rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts)
    paths += [repo / name for name in provider]
    require(all(not p.is_symlink() and p.resolve().is_relative_to(repo.resolve()) for p in paths),
            'measurement fixture input is a symlink or outside the repository')
    return {p.relative_to(repo).as_posix(): sha(p) for p in paths}


def provider_proof(repo, baseline_head, candidate_head, fixtures):
    """Bind this round's provider to both Rust commits, not an old Pi run."""
    repo = Path(repo)
    trees = {label: git(repo, 'rev-parse', head + ':' + PROVIDER)
             for label, head in (('baseline', baseline_head), ('candidate', candidate_head))}
    require(trees['baseline'] == trees['candidate'], 'provider differs across Rust source commits')
    names = git(repo, 'ls-tree', '-r', '--name-only', baseline_head, '--', PROVIDER).splitlines()
    values = {name: fixtures[name] for name in names}
    require(set(values) == {name for name in fixtures if name.startswith(PROVIDER + '/')},
            'provider recorded/tracked inventory differs')
    for name, digest in values.items():
        contents = subprocess.check_output(['git', 'show', baseline_head + ':' + name], cwd=repo)
        require(hashlib.sha256(contents).hexdigest() == digest,
                'provider working bytes differ from the fixed Rust baseline: ' + name)
    return {'baseline_head': baseline_head, 'candidate_head': candidate_head,
            'trees': trees, 'files': values,
            'scope': 'Provider bytes used by this round match both Rust commits. '
                     'This does not add a provider binding to prior Pi/DeepSeek measurements.'}
