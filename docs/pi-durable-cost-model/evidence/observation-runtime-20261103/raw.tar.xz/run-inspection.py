import datetime,hashlib,json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'inspection';out.mkdir(exist_ok=False);os.sched_setaffinity(0,[2,8]);records=[]
for pair in range(4):
 for case in ['small','leaf-10k','segmented-32k','concurrent']:
  for label in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):
   stem=f'{pair}-{case}-{label}';directory=out/stem;binary=r/(label+'-build/inspect-probe');cmd=['/usr/bin/time','-f','%U %S %M %e','-o',str(out/(stem+'.time')),str(binary),str(directory),case]
   row={'pair':pair,'case':case,'revision':label,'command':cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
   with (out/(stem+'.json')).open('x') as so,(out/(stem+'.stderr')).open('x') as se:done=subprocess.run(cmd,stdout=so,stderr=se)
   row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem,done.returncode,flush=True);assert done.returncode==0
