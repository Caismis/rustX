"""Archive retained evidence without private directions, checkouts or executables."""
import hashlib,json,sys,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
excluded={'user-directions.txt','conformance','inspect-probe','librustx.rlib'}
files=[p for p in sorted(r.rglob('*')) if p.is_file() and not p.is_symlink() and 'baseline-src' not in p.relative_to(r).parts and '__pycache__' not in p.relative_to(r).parts and p.name not in excluded]
assert all(p.read_bytes()[:4]!=b'\x7fELF' and p.suffix!='.rlib' for p in files)
entries=[{'path':str(p.relative_to(r)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
archive=out/'raw.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as t:
 for p in files:
  info=t.gettarinfo(str(p),arcname=str(p.relative_to(r)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with p.open('rb') as source:t.addfile(info,source)
manifest={'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'members':entries,'excluded':'Private user directions, baseline checkout, executables, rlibs, bytecode and parser-selftest symlinks. Failed checks and parser receipts retained.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'r:xz') as t:
 assert t.getnames()==[e['path'] for e in entries]
 for member,e in zip(t,entries):
  body=t.extractfile(member).read();assert member.isfile() and len(body)==e['bytes'] and hashlib.sha256(body).hexdigest()==e['sha256']
print(json.dumps({'members':len(entries),'archive':manifest['archive']}))
