from pathlib import Path
import hashlib,json,shutil,subprocess
repo=Path('/workspace/rustX-pi-durable');control=Path('/workspace/rustX-demand-control-v3');root=Path(__file__).resolve().parent
base='fbe6ae0ca05d4b11966efd0747f72b8a4ba63383';oldparent='44fff50b062688201e0301e89f0da319090bb46f'
clock=['src/runtime/conversation_runtime.rs','src/local_runtime/composition.rs','src/local_runtime/session_controller.rs','src/local_runtime/subagent_child.rs']
fixtures=['tests/conformance/agent_loop.rs','tests/common/launch.rs']
for path in clock+fixtures:
 a=subprocess.check_output(['git','show',base+':'+path],cwd=repo)
 b=subprocess.check_output(['git','show',oldparent+':'+path],cwd=repo)
 assert a==b, 'control would copy unrelated changes: '+path
 shutil.copy2(repo/path,control/path)
path=control/'src/runtime_client/host.rs';before=path.read_text();out=[];inserted=[]
for line in before.splitlines(keepends=True):
 out.append(line)
 if 'ConversationContextConfig {' in line and 'pub struct' not in line and 'pub fn' not in line:
  addition=line[:len(line)-len(line.lstrip())]+'    status_clock: std::sync::Arc::new(crate::context::SystemClock),\n'
  out.append(addition);inserted.append(addition)
after=''.join(out);restored=after
for line in inserted:restored=restored.replace(line,'',1)
assert restored==before
path.write_text(after)
identity=json.loads(Path('/workspace/issue-481-evidence/observer-oracle-v2-build/identity.json').read_text())
for path,expected in identity['harness'].items():
 source=repo/path;assert hashlib.sha256(source.read_bytes()).hexdigest()==expected
 (control/path).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,control/path)
(root/'preparation.json').write_text(json.dumps({'control_base':base,'reviewed_oracle_head':'ce3c3c6ac97112bc5b1e68e75f87b147e3b33cd3','clock_files_before_equal_to_oracle_parent':clock,'fixture_files_before_equal_to_oracle_parent':fixtures,'host_changes_only_test_literal_clock_fields':len(inserted),'harness':identity['harness'],'sparse_checkout':'root files plus src/tests/examples/.github/benchmarks; archived docs excluded; no product input removed'},indent=2)+'\n')
