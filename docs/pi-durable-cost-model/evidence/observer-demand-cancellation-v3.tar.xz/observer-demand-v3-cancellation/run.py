from pathlib import Path
import hashlib,json,subprocess,shutil
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
paths={'before':Path('/workspace/issue-481-evidence/observer-demand-v3-control-build/conformance'),'after':Path('/workspace/issue-481-evidence/observer-oracle-v2-build/conformance')}
ids={name:json.loads((p.parent/'identity.json').read_text()) for name,p in paths.items()}
assert ids['before']['head']=='29ca99808010e8c9e1d5dd551afc059f705dfde2' and ids['after']['head']=='b6c5b4a67775c4db36540e5ee840afcce9ccc45b'
assert ids['before']['harness']==ids['after']['harness'] and ids['before']['rustc']==ids['after']['rustc'] and ids['before']['build_environment']==ids['after']['build_environment']
for name,p in paths.items():assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==ids[name]['sha256']
assert shutil.disk_usage('/workspace').free>300*1024**2
procs=subprocess.check_output(['ps','-eo','stat=,comm='],text=True)
assert not [s for s in procs.splitlines() if not s.strip().startswith('Z') and s.split()[-1] in ['rustc','clippy-driver','cargo','xz','gzip','strace','perf']]
(root/'build-identities.json').write_text(json.dumps(ids,indent=2)+'\n')
for mode in ['no-live-subscriber','live-subscriber']:
 command=['python3','benchmarks/runtime/compare-revisions.py','--before',str(paths['before']),'--after',str(paths['after']),'--output',str(root/mode),'--pairs','3','--observer-mode',mode,'--case','cancel']
 with (root/f'{mode}.log').open('x') as log:subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (root/f'{mode}-summary.json').open('x') as out:subprocess.run(['python3','benchmarks/runtime/summarize-comparisons.py',str(root/mode)],cwd=repo,stdout=out,check=True)
 print(mode,'passed 3 strict cancellation pairs',flush=True)
