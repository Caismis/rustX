# Exact request occurrence width runs

Source scope: composed.rs, composed/nodes.rs, composed/record.rs and composed/width_table.rs. This is a static argument; correctness and measured benefits require the separately recorded checks/products.

The previous Augmentation stored a full 80-element array. Classes are the Cartesian product of 20 journal decimal widths and 4 rank widths. Each subtree contributes count * weights::delta(class), while its remaining body length can vary independently at any class because admission can change at a byte boundary. The new WidthTable stores count plus canonical changes in that remaining base. It does not assume every class has the same body, or collapse admission variants.

Leaf construction still obtains every class's exact native template base. Join merges the left/right run boundaries, adds the two bases plus the JSON comma, and adds their counts. Access chooses the current run base and adds count * delta. Same-class subtree lookup remains bounded; a query spanning coordinate classes follows the existing recursive geometry path. Tree hashes and native child/count authentication remain unchanged.

Validation checks the exact count against native geometry (1..8192), at most 80 runs, initial class zero, strictly ascending classes, distinct adjacent bases, bounded safe integers, and all per-run maxima. Because rank digits reset at each journal group, the maximum delta in a run is either its end or the prior complete journal group's last class. The stored record is closed MessagePack and its sequence deserializer rejects hostile counts before allocation. There is no dense-width legacy reader; schema increments to 81.

Four added regressions compare to the independent former 80-value algebra, including randomized joins and all 80 classes, native count 8192, every possible run interval, checked integer boundaries, malformed geometry, excessive declared runs and old dense records. Typical identical-body widths store one run, but the implementation deliberately permits up to 80 where exact admission requires it. It does not eliminate the original message body, tree geometry, history or raw request range index.
