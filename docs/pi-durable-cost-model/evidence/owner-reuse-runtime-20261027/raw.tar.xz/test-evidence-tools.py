#!/usr/bin/env python3
"""Pure parser/fixture checks. No product, build, source edit, or new timing sample."""
import copy, importlib.util, json, tempfile, types, unittest, sys, ast, struct
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
OLD=Path('/home/capi/.cache/rustx-pr485-pi-flow')
def module(name,file):
 s=importlib.util.spec_from_file_location(name,ROOT/file);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
D=module('owner_direct_test','direct-audit.py');G=module('owner_diag_test','diagnostic-audit.py');S=module('owner_summary_test','summarize-results.py');P=module('owner_preflight_test','premeasurement.py')
class EvidenceTests(unittest.TestCase):
 def test_all_scripts_parse_and_rust_only_entrypoints(self):
  for path in ROOT.glob('*.py'):ast.parse(path.read_text())
  self.assertEqual(set(P.script_inventory(ROOT)),set(P.PRODUCERS+P.AUDITORS))
 def test_retained_old_candidate_is_valid_new_baseline_snapshot(self):
  snapshot=D.load(OLD/'columns-complete-short-small/after_turns.json');G.validate_snapshot(snapshot,'baseline')
  for mutate in [lambda s:s['tables']['events']['column_value_bytes'].pop('observation_source_inline'),lambda s:s['tables'].update(event_observation_readiness={'rows':0,'column_value_bytes':{'ready':0}}),lambda s:s.update(scope='all memory'),lambda s:s['events_by_kind'][0].update(rows=99999)]:
   bad=copy.deepcopy(snapshot);mutate(bad)
   with self.assertRaises((ValueError,KeyError)):G.validate_snapshot(bad,'baseline')
 def test_candidate_overlay_inventory_is_explicit(self):
  snapshot=D.load(OLD/'columns-complete-short-small/after_turns.json')
  for row in [snapshot['tables']['events'],*snapshot['events_by_kind']]:
   cells=row['column_value_bytes'];cells['observation_source_overlay']=cells.pop('observation_source_inline');cells.pop('observation_source_inline_bytes')
  G.validate_snapshot(snapshot,'complete')
  snapshot['tables']['events']['column_value_bytes']['observation_source_inline']=0
  with self.assertRaises(ValueError):G.validate_snapshot(snapshot,'complete')
 def test_native_product_oracle_dimensions_and_failure_are_hard_gates(self):
  original=OLD/'profile-complete-live-large-control';build=D.load(OLD/'candidate-complete-build/identity.json');argv=D.load(original/'manifest.json')['argv']
  G.product(original,'baseline',build,'short-large','live-subscriber',argv)
  for file,mutate in [('sample.json',lambda r:r.update(schema=81)),('sample.json',lambda r:r.update(measured=31)),('sample.json',lambda r:r.update(oracle='failed')),('sample.process.json',lambda r:r.update(accepted=False)),('sample.process.json',lambda r:r.update(product_exit=1)),('sample.process.json',lambda r:r['provider_report'].update(complete=False))]:
   with tempfile.TemporaryDirectory() as directory:
    directory=Path(directory)
    for name in ('sample.json','sample.process.json'):
     row=D.load(original/name)
     if name==file:mutate(row)
     (directory/name).write_text(json.dumps(row))
    with self.assertRaises(ValueError):G.product(directory,'baseline',build,'short-large','live-subscriber',argv)
 def test_raw_only_output_binding_survives_relocation_but_not_command_changes(self):
  before=D.load(ROOT/'baseline-build/identity.json');after=copy.deepcopy(before);after.update(sha256='a'*64,binary='/original/archive/candidate-complete-build/conformance')
  with tempfile.TemporaryDirectory() as directory:
   root=Path(directory);(root/'direct-cohorts').mkdir()
   for label in ('baseline-build','candidate-complete-build'):
    (root/label).mkdir();(root/label/'build.stdout').write_bytes((ROOT/'baseline-build/build.stdout').read_bytes())
   source={'head':after['head'],'schema':81,'production_tree':after['production_tree'],'source_files':after['source_files'],'fixtures':{},'utc':'2026-10-27T01:00:00+00:00'}
   plan={'stage':'direct','identities':{'before':before,'after':after},'source_before':source,'source_after':dict(source,utc='2026-10-27T02:00:00+00:00'),'steps':[]}
   for index,(label,mode) in enumerate(D.MODES):
    row={'name':'direct-'+label,'status':'complete','exit':0,'start_utc':f'2026-10-27T01:{index*20+1:02}:00+00:00','end_utc':f'2026-10-27T01:{index*20+10:02}:00+00:00','command':['python3','benchmarks/runtime/compare-revisions.py','--before',before['binary'],'--after',after['binary'],'--output','/original/archive/direct-cohorts/direct-'+label,'--pairs','5','--observer-mode',mode]};plan['steps'].append(row)
    for suffix in ('.stdout','.stderr'):(root/'direct-cohorts'/(row['name']+suffix)).write_text('')
   args=types.SimpleNamespace(root=root,repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX'),raw_only=True)
   path=root/'direct-cohorts/commands.json';path.write_text(json.dumps(plan));self.assertTrue(D.identity_and_plan(args,before,after)['source_unchanged'])
   for mutation in [lambda p:p['steps'][0]['command'].__setitem__(1,'benchmarks/runtime/controller.py'),lambda p:p['steps'][0]['command'].__setitem__(7,'/another/output'),lambda p:p['steps'][0].update(exit=1),lambda p:p['source_after'].update(schema=82)]:
    bad=copy.deepcopy(plan);mutation(bad);path.write_text(json.dumps(bad))
    with self.assertRaises(ValueError):D.identity_and_plan(args,before,after)
 def test_wal_raw_header_payload_and_boundaries_are_recomputed(self):
  with tempfile.TemporaryDirectory() as directory:
   directory=Path(directory);snapshot={'path':'/tmp/conversation.db','counts':{'events':1},'tables':[['events','',1]],'pages':[['events',1,'leaf',1,10]]};lines=[]
   for phase in G.PHASES:
    lines.append(f'1 write(9<UNIX-STREAM:[control]>, "{phase}\\n", 1) = 1')
    if phase=='before_measured_turns':
     header=struct.pack('>II',1,1)+bytes(16);lines.extend([f'1 pwrite64(7</tmp/conversation.db-wal>, {repr(header)[1:]}, 24, 32) = 24','1 pwrite64(7</tmp/conversation.db-wal>, "payload"..., 4096, 56) = 4096'])
   path=directory/'calls.strace';path.write_text('\n'.join(lines));self.assertEqual(G.wal_frames(directory,snapshot,snapshot,G.PHASES)['wal_frame_bytes'],4120)
   for text in ['\n'.join(lines).replace('4096, 56','4096, 57'),'\n'.join(line for line in lines if 'after_turns' not in line),'\n'.join(lines).replace(' = 24',' = 23')]:
    path.write_text(text)
    with self.assertRaises(ValueError):G.wal_frames(directory,snapshot,snapshot,G.PHASES)
 def test_cross_batch_reference_is_never_pairwise_and_retains_unfavorable_pairs(self):
  old=D.load(OLD/'complete-all-audit.json');formal={'accepted':True,'errors':[],'datasets':{'direct':old['datasets']['direct']}}
  result=S.derive(formal,old)
  self.assertEqual((len(result['fresh_paired']),len(result['fixed_pi']),len(result['fixed_deepseek'])),(12,12,4))
  self.assertTrue(all(m['scope']=='cross_batch_descriptive_not_paired' and 'pairs' not in m for row in result['fixed_pi'] for m in row['metrics'].values()))
  self.assertTrue(any(row.get('adverse_count',0)>0 for row in result['all_adverse_metrics']))
  for row in result['fixed_deepseek']:
   self.assertIsNone(row['separate_deepseek_native_flush_exit_metrics']['through_cleanup_process_write_bytes']['median'])
  self.assertIn('All adverse metrics',S.markdown(result))
  bad=copy.deepcopy(formal);bad['datasets']['direct']['products'].pop()
  with self.assertRaises(ValueError):S.derive(bad,old)
  bad=copy.deepcopy(old);bad['datasets']['three-engine']['rows']=[r for r in bad['datasets']['three-engine']['rows'] if r['engine']!='deepseek']
  with self.assertRaises(ValueError):S.derive(formal,bad)
if __name__=='__main__':unittest.main()
