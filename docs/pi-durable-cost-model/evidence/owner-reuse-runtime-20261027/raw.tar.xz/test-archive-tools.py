#!/usr/bin/env python3
"""Pure synthetic archive/parser tests; never read measured products or run auditors."""
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile
import unittest
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def module(name):
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), HERE / (name + '.py'))
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


pack, verify = module('pack-evidence'), module('verify-archive')


def digest(value):
    return hashlib.sha256(value).hexdigest()


class ArchiveTools(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.counter = 0

    def tearDown(self):
        self.temp.cleanup()

    def archive(self, mutation=None, entries=None, member_extra=None):
        self.counter += 1
        folder = self.root / str(self.counter)
        folder.mkdir()
        payload = {'logs/failed.stdout': b'FAILED\n', 'data/snapshot.sqlite': b'SQLite format 3\x00\x00', 'profile.cpu': b'\x00' * 96}
        info = {name: {'bytes': len(value), 'sha256': digest(value)} for name, value in payload.items()}
        manifest = {'format': verify.FORMAT, 'files': info, 'phases': {}, 'reference_pins': {},
                    'strict_report_sha256': {}, 'replay_commands': verify.COMMANDS}
        if mutation:
            mutation(manifest)
        encoded = json.dumps(manifest).encode()
        summary = {key: manifest[key] for key in ('format', 'phases', 'reference_pins', 'strict_report_sha256', 'replay_commands')}
        summary.update(raw_files=len(info), raw_bytes=sum(len(v) for v in payload.values()),
                       manifest_bytes=len(encoded), manifest_sha256=digest(encoded))
        path = folder / 'raw.tar.xz'
        with tarfile.open(path, 'w:xz') as archive:
            for name, value in (entries or payload).items():
                item = tarfile.TarInfo(name); item.size = len(value)
                archive.addfile(item, io.BytesIO(value))
            if member_extra:
                item, value = member_extra
                archive.addfile(item, io.BytesIO(value) if value is not None else None)
            item = tarfile.TarInfo('MANIFEST.json'); item.size = len(encoded)
            archive.addfile(item, io.BytesIO(encoded))
        return path, summary, folder / 'raw', encoded, info

    def test_safety_names_and_json_duplicates(self):
        for name in ('', '/root', '../escape', 'dir/../escape', './a', 'a//b', 'a\\b', 'a/', 'a\x00b'):
            for fn in (pack.safe_name, verify.safe_name):
                with self.assertRaises(ValueError): fn(name)
        for name in ('logs/failed.stderr', 'snapshot.sqlite', 'raw/phase.cpu'):
            pack.safe_name(name); verify.safe_name(name)
        with self.assertRaises(ValueError): verify.unique_object([('x', 1), ('x', 2)])

    def test_inventory_keeps_binary_evidence_failed_logs_and_sources(self):
        (self.root / 'checks-failed').mkdir()
        values = {'snapshot.sqlite': b'SQLite format 3\0', 'sample.cpu': b'\0' * 64,
                  'trace.wal': b'\x37\x7f\x06\x82' + b'\0' * 60, 'profile.pb.gz': b'\x1f\x8b' + b'\0' * 80, 'trace.xz': b'\xfd7zXZ\0',
                  'checks-failed/log.stdout': b'FAILED', 'conformance-tests.md': b'source evidence',
                  'product': b'\x7fELF' + b'\0' * 60, 'conformance': b'executable placeholder',
                  'instrument.so': b'\x7fELF' + b'\0' * 60, 'old.tar.xz': b'archive',
                  'fat-macho': b'\xca\xfe\xba\xbf' + b'\0' * 60}
        for name, value in values.items(): (self.root / name).write_bytes(value)
        (self.root / '__pycache__').mkdir(); (self.root / '__pycache__/x.pyc').write_bytes(b'cache')
        (self.root / 'link').symlink_to(self.root / 'snapshot.sqlite')
        selected, excluded = pack.inventory(self.root, {})
        self.assertEqual(set(selected), {'snapshot.sqlite', 'sample.cpu', 'trace.wal', 'profile.pb.gz', 'trace.xz', 'checks-failed/log.stdout', 'conformance-tests.md'})
        self.assertTrue(any(row['path'] == 'link' for row in excluded))
        self.assertFalse(pack.compiled_format(self.root / 'sample.cpu'))

    def test_good_all_members_and_postaudit_hash(self):
        path, summary, root, encoded, entries = self.archive()
        pack.verify_archive(path, encoded, entries)
        _, expected = verify.extract_and_verify(path, summary, root)
        verify.verify_tree(root, expected)
        self.assertEqual(len(expected), 4)
        (root / 'logs/failed.stdout').write_bytes(b'changed')
        with self.assertRaises(ValueError): verify.verify_tree(root, expected)

    def test_postaudit_extra_file_directory_and_symlink(self):
        for mode in ('file', 'directory', 'symlink'):
            path, summary, root, _, _ = self.archive()
            _, expected = verify.extract_and_verify(path, summary, root)
            if mode == 'file': (root / 'extra').write_text('x')
            if mode == 'directory': (root / 'extra').mkdir()
            if mode == 'symlink': (root / 'extra').symlink_to(root / 'profile.cpu')
            with self.assertRaises(ValueError): verify.verify_tree(root, expected)

    def test_reject_unsafe_duplicate_and_nonregular_members(self):
        for name, kind, link in [('profile.cpu', tarfile.REGTYPE, ''), ('../escape', tarfile.REGTYPE, ''),
                                 ('link', tarfile.SYMTYPE, '../../escape'), ('hard', tarfile.LNKTYPE, 'profile.cpu'),
                                 ('directory', tarfile.DIRTYPE, ''), ('pipe', tarfile.FIFOTYPE, '')]:
            item = tarfile.TarInfo(name); item.type = kind; item.linkname = link
            path, summary, root, _, _ = self.archive(member_extra=(item, b'' if kind == tarfile.REGTYPE else None))
            with self.assertRaises((ValueError, FileExistsError, NotADirectoryError)):
                verify.extract_and_verify(path, summary, root)
            self.assertFalse((path.parent / 'escape').exists())

    def test_reject_missing_extra_changed_bytes_and_bad_manifest(self):
        cases = [lambda m: m['files']['profile.cpu'].update(sha256='0' * 64),
                 lambda m: m['files']['profile.cpu'].update(bytes=7),
                 lambda m: m['files'].update({'unexpected': {'bytes': 0, 'sha256': digest(b'')}}),
                 lambda m: m['files'].update({'../outside': m['files'].pop('profile.cpu')}),
                 lambda m: m['replay_commands']['formal'].append('--not-allowed')]
        for mutate in cases:
            # Fixture must not mutate the module allowlist through shared dicts.
            commands = copy.deepcopy(verify.COMMANDS)
            try:
                path, summary, root, _, _ = self.archive(mutation=mutate)
                verify.COMMANDS.clear(); verify.COMMANDS.update(commands)
                with self.assertRaises(ValueError): verify.extract_and_verify(path, summary, root)
            finally:
                verify.COMMANDS.clear(); verify.COMMANDS.update(commands)
        path, summary, root, _, _ = self.archive(entries={'missing-other-file': b'x'})
        with self.assertRaises(ValueError): verify.extract_and_verify(path, summary, root)

    def test_enforces_declared_payload_limits_and_fresh_extraction(self):
        for field in ('raw_bytes', 'raw_files'):
            path, summary, root, _, _ = self.archive(); summary[field] = 0
            with self.assertRaises(ValueError): verify.extract_and_verify(path, summary, root)
        path, summary, root, _, _ = self.archive(); root.mkdir()
        with self.assertRaises(FileExistsError): verify.extract_and_verify(path, summary, root)

    def test_formal_all_values_and_failure_history_compared(self):
        strict = {'accepted': True, 'errors': [], 'mode': 'strict', 'raw_only': False, 'strict_identity_verified': True,
                  'created_utc': 'old', 'datasets': {'direct': {'values': [1, None, 0, 7]}},
                  'validation': {'runs': [{'source_binding': 'actual', 'failed': ['real_failure'], 'hash': 'a'}]}}
        raw = copy.deepcopy(strict)
        raw.update(mode='raw-only', raw_only=True, strict_identity_verified=False, created_utc='new')
        raw['validation']['runs'][0]['source_binding'] = 'retained'
        verify.compare_formal(raw, strict)
        for field in ('metric', 'failure'):
            bad = copy.deepcopy(raw)
            if field == 'metric': bad['datasets']['direct']['values'][1] = 0
            else: bad['validation']['runs'][0]['failed'] = []
            with self.assertRaises(ValueError): verify.compare_formal(bad, strict)

    def test_diagnostic_fresh_formal_binding_and_complete_records(self):
        formal = self.root / 'fresh.json'; formal.write_text('fresh')
        strict = {'accepted': True, 'errors': [], 'mode': 'strict', 'strict_identity_verified': True,
                  'actual_binary_and_preload_verified': True, 'recorded_build_identity_verified': True,
                  'build_receipts': {'baseline': {'file': '/old', 'sha256': 'unchanged'}},
                  'formal_audit': {'file': '/old/direct', 'mode': 'strict', 'sha256': 'priorhash', 'products': 120},
                  'profiles': [{'count': 13}], 'columns': [{'bytes': 42}], 'wal': [{'frames': 7}]}
        raw = copy.deepcopy(strict); raw.update(mode='raw-only', strict_identity_verified=False, actual_binary_and_preload_verified=False)
        raw['build_receipts']['baseline']['file'] = 'relative'
        raw['formal_audit'].update(file='../fresh.json', mode='raw-only', sha256=verify.sha(formal))
        verify.compare_diagnostic(raw, strict, formal)
        for field in ('profiles', 'columns', 'wal', 'formal_audit'):
            bad = copy.deepcopy(raw)
            if field == 'formal_audit': bad[field]['sha256'] = 'priorhash'
            else: bad[field] = []
            with self.assertRaises(ValueError): verify.compare_diagnostic(bad, strict, formal)

    def test_summary_compares_adverse_missing_references_and_markdown(self):
        formal = self.root / 'fresh.json'; formal.write_text('fresh')
        md = self.root / 'report.md'; md.write_text('all rows\n')
        rawmd = self.root / 'replay.md'; rawmd.write_text('all rows\n')
        strict = {'accepted': True, 'current_audit_sha256': 'old', 'adverse': [2], 'missing': [None], 'refs': {'sha': 'pin'}}
        raw = copy.deepcopy(strict); raw['current_audit_sha256'] = verify.sha(formal)
        verify.compare_summary(raw, strict, formal, rawmd, md)
        for field in ('adverse', 'missing', 'refs'):
            bad = copy.deepcopy(raw); bad[field] = []
            with self.assertRaises(ValueError): verify.compare_summary(bad, strict, formal, rawmd, md)
        rawmd.write_text('different')
        with self.assertRaises(ValueError): verify.compare_summary(raw, strict, formal, rawmd, md)

    def test_three_allowlisted_commands_are_portable_and_bind_replay(self):
        self.assertEqual(pack.COMMANDS, verify.COMMANDS)
        for label in verify.COMMANDS:
            actual = verify.replay_command({'replay_commands': verify.COMMANDS}, {'replay_commands': verify.COMMANDS}, label)
            self.assertFalse(any(value.startswith('/home/') for value in actual))
        self.assertIn('../direct-raw-audit.json', verify.COMMANDS['diagnostic'])
        self.assertIn('../direct-raw-audit.json', verify.COMMANDS['summary'])
        bad = copy.deepcopy(verify.COMMANDS); bad['formal'][1] = '/historical/script.py'
        with self.assertRaises(ValueError): verify.replay_command({'replay_commands': bad}, {'replay_commands': bad}, 'formal')


if __name__ == '__main__':
    unittest.main(verbosity=2)
