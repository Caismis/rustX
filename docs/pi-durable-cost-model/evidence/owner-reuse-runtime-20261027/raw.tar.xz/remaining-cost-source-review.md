# 本轮之后仍存在的 response / event 派生成本

源码固定为 `459b1b6005bfbf7f0a1a1d52df5a6900b06c56c6`。以下是只读源码审查，没有运行产品或新测量；SQL 次数是明确分支的静态次数，不能当作实际 CPU/WAL 占比，也不能推断 wall time 贡献。全部位置相对仓库根目录；对应固定源码链接前缀为 `https://github.com/Caismis/rustX/blob/459b1b6005bfbf7f0a1a1d52df5a6900b06c56c6/`。

## 1. 完成 owner 命中之后，response 页仍不是零读取

`src/durable/sqlite/observation_response.rs:57` 的 `read_validated` 在非空、全部命中、已有本地 statistics row 的正常分支，仍执行：

| 工作 | 静态次数 / 内容 | 依赖与是否仍可减少 |
|---|---|---|
| 当前 J 前缀 member holes | 1 条 EXISTS | 新事件的缺失 member 证据会使历史响应不可用，不能仅凭旧 owner 不变省掉。可以与同事务的其他缺失证据查询合并，但必须保留错误优先级。 |
| cache capture | 3 个 PRAGMA + 1 条当前 J/L/T 查询 | `cache.rs:220`：data_version 保护外部写入，main/temp schema 保护布局/影子表，实际 Read 状态保护未提交写事务。J/L/T 在本页之前的原生 cut 校验中已经读取，因此**存在同事务重复读**；可让原验证返回带连接/事务作用域的事实，避免重新 SELECT，而不是信调用者给的 cut。 |
| 当前 J execution holes | 0 到若干条 EXISTS | `observation_response.rs:538`：每个已缓存 item 保留原 selected layout 的 owner-anchor→当前 J 区间；同页已经检查过的更早起点覆盖后续起点。测试的八个正常顺序 owner 是 1 条；任意输入顺序不能宣称固定 1 条。 |
| 当前 statistics | 通常 3 条 SQL + 1 次有界 JSON 解码 | `observation_statistics.rs:155,198,211`：重新读取当前 J、统计洞、最新非空统计 tuple。没有本地统计时还会读取 seed / bootstrap。这里的当前 J 又与 cut/capture 重复；统计内容和洞不能沿用旧响应结果。 |
| cache 对象操作 | 每个 item 一次有界查找/克隆 | `cache.rs:261`：最多 32 项，按完整 selection 和 cut 边界匹配并克隆 DTO；命中没有重新编码 item。冷准入还会做私有 16 KiB conservative walk。 |

所以不计外层 cut 验证，通常是 `8 + H` 条 SQL（H 是实际执行的 execution-hole 区间探测数）以及一次统计 tuple 解码；不是所有历史 owner 的 JSON/SQL 都被删除。这个公式只适用于上述完整命中分支，不适用于混合页、空页、seed 统计或错误路径。

外层工作也仍在：

- `observation.rs:29,49` 的 `validate` / `validate_canonical_provenance`，包括实际原生 cut、继承 T 边界、Ledger 末端 J/T 和 append revision 校验。`reading.rs:14` 已经 SELECT 了 J/L/T、Surface、pending 相关计数。当前实现先验证再丢弃实际 cut，后面的 cache/statistics 再读其子集，这是可明确指出的重复实现。
- `observation_checkpoint.rs:10` 已经共享 transcript→response 的同事务 cut 验证，但仍通过 `observation.rs:745` 读取最多一页 transcript headers：SQL `json_extract` 提取身份，再用 serde 解码 header；有 Tool 时还调用 `enrich_transcript_tools`。这些不是 response cache 的覆盖范围。
- 同一个 checkpoint 随后还执行 occupancy、trace_total、projection head。`observation_occupancy.rs:167` 固定做三种事件的最新值索引探测并解码选中值，必要时查 seed；`observation_statistics.rs:640` 读 trace holes+total；`observation_projection.rs:99,109` 选择 activation、校验有界 header witness 并解码。它们有独立当前 cut / 损坏合同，当前仍有 SQL/解析成本，并非理论上不能复用。

## 2. 仍然未准入或会保守失效的 response 路径

准入条件在 `observation_response.rs:492` / `cache.rs:284`，失效在 `cache.rs:190,220`。

- **运行中的 owner**：仍读取 Ledger→role→Tool alias→member anchor→最新 member，并读选中 execution。`Reader::owner:240`、`source_at_position:223`、`selected_layout_with_proof`（`observation_execution.rs:137`）仍有多次索引查找和 JSON 解码。它们确实会随新事件变化；可以做按 owner 版本的 typed 增量事实复用，但当前的“已完成”证书不能授权这种复用。
- **terminal-only 和继承 process 的委托路径**：`observation_response.rs:254,293` 继续调用 `observation_members::transcript_process:358`，明确 `fully_proven=false`。原因不是“有测试所以不能改”，而是委托函数没有返回所读取的 `MemberProcessHeader.native_terminal` 等依赖，特殊/损坏引用可能指向另一个 execution row。让该函数同时返回依赖事实即可建立新证明；本轮没有为较少见路径复制读取或引入无依据证书。结果和错误顺序不变。
- **首次访问的旧 cut、超大私有 item/selection、超过 32 项容量、主/临时 schema 改变、写事务**：按原有读取算法处理。后续合法 pending accept/adopt 不会仅因 pending mutation epoch 变化而清掉 native 完成 owner；外层验证仍拒绝过期旧 pending cut。
- **任意外部提交**会经 data_version 清缓存，即使修改与 response 无关；有 optional identity fields 的缓存遇到任意 content_frontiers 修改也会保守失效。可以缩小依赖范围，但须覆盖新增别名/新增字段等“原先不存在”的证据，不能只观察被读取过的旧 row。

这些是明确的覆盖边界，不是不可优化的功能下限。常见冷路径仍有可以同事务分享的 Ledger position、执行/成员 owner anchor、retry header 事实；实际收益需要后续诊断，不由函数数量决定。

## 3. 当前事件各层的功能不同，但字段仍有重叠

| 持久层 | 当前职责 | 仍存在的重叠 / 表示空间 |
|---|---|---|
| `events.event_json` 和原生列 | 原始 Journal 与恢复/原生引用验证；`sqlite.rs:11420` | 身份、时间、事件 kind 同时存在于原生列及若干派生 header。不能说每份都必须保持现有 JSON 形状。 |
| `observation_source_overlay` 或分段 source | 精确结构化字段字节、u64 引号处理、按字段/范围读取 | 本轮已把小 source 的第二份完整正文改为原生正文+认证 quote overlay（`observation_event/inline/overlay.rs:51`）；旧 observation_json 路径已删除。因此不能继续声称当前普遍持久化三份相同正文。写入仍需构造有限 structural source、比较差异并计算两个 digest；读取要恢复/验证。超出界限的 source 保留独立分段几何。 |
| `observation_witness` | 有限原生事件语义、deferred 字段引用、live receipt/replay，以及独立 unavailable/ready 信息 | `observation_event.rs:452`：sequence/time/event/attempt/turn/kind、terminal 字段与原事件/Trace 有重复；仍是描述性 JSON。source 索引失败时 `index_optional:373` 可保留自身 terminal 语义，这是功能上独立的失败域。 |
| `observation_trace_fact` | Trace 的 owner/location、请求/Tool/terminal 类型与时间轴查询、字段来源 | `observation_trace/event.rs:684,740`：sequence/time/kind/owner、部分身份/终态/usage 与 witness/execution 重叠。`observation_trace.rs:146` 的 reader 还将 header 中坐标与原生列核对；直接删重复坐标会删掉这项检查，需同时设计认证/校验表示，而非机械删字段。 |
| `observation_execution` | 某 Attempt 在各 J cut 的请求、usage、timing、models、closing/retry/failure 聚合 | 已是紧凑固定 tuple（`observation_execution/storage.rs:42`），但多个事件的版本仍重复未变的身份、request、model、timing 字段。历史 cut 需要可选定的版本，并不要求每次写一个完整重复快照；base+delta/共享不变 owner 是可选设计，但要保持有限读取和缺失证据检测。 |
| `observation_members` | canonical/Tool 成员、最终消息身份、process outcome/clock/owner 引用 | `observation_members.rs:45,149`：conversation/attempt、开始结束时间、terminal identity、closing identity 与 execution/witness 重叠；成员计数和 C/T 关系不能由 execution 角色猜出。当前仍编码完整有限 member JSON。 |
| `observation_statistics` | 每 cut 的整对话统计及 local-agent/继承差异 | `observation_statistics.rs:100,337` 已以 tuple 存储，并在没有 lineage 差异时合并 local/conversation 相同 totals；仍重复写累计值与时钟。它是整对话聚合，不等于某 Attempt 的 execution；可改变版本表示，不能直接复用后者当完整统计。 |

这几层“有不同用途”只能解释为什么不能无条件删除输出能力，不能证明所有重复字段、独立编码和宽行都不可消除。共享 immutable identity/base row、按域版本化或统一 append facts 都仍是实现选择；应保留各域自己的缺失/认证状态，不能让坏 source 自动抹掉原生 J 或另一有效 terminal 域。

## 4. append 仍有多阶段构造、查询和 UPDATE

`sqlite.rs:11334` 的 `persist_event_tx_with_requests` 当前流程仍是：

1. 原生身份/引用/lifecycle 校验和 lifecycle 写入，然后编码+INSERT 原始 event。
2. 共享 aggregate savepoint 中，`append_facts::aggregates:23` 把 trace_total/statistics/members 的 event 列合为一次 UPDATE。这项合并已经完成，不能再按旧三次写入报告。
3. Assistant/Tool 坐标独立 UPDATE；execution 读取上一个 layout、fold、编码并 UPDATE（`observation_execution.rs:155,253`）。
4. 需要时写 state、occupancy/request outcome；witness/source 独立构造并 UPDATE；Trace 独立构造并 UPDATE。
5. terminal/interaction T 坐标和 witness.transcript_cursor 还分别更新；`sqlite.rs:11636` 的 `enrich_event_transcript` 用三个独立 optional savepoint 写坐标、witness JSON 和 T header。turn header 再根据聚合/原生证据独立构造和 UPDATE。
6. 各必需派生阶段成功后才单独清 `observation_unavailable`；最后构造 receipt，读最终存储证据。

具体仍有的重复实现：

- 每个 event 的统计、execution、member、turn 都各自读取上一版本或 native owner；同一 family 内后续事件又会查刚写入的前一版本。已有 typed `Facts` 只延续 witness/execution，`Captured::reuse`（`append_facts.rs:11`）通过真实 stored bytes 相等避免部分解码；没有把所有 aggregate/owner 原生事实统一传遍整个 family。
- witness 构造、aggregate prepare、receipt `batch_with_summary` 均可能读取 trace_total；`observation_turn` 使用 prepared statistics 时仍会查询当前 stored cell 和 holes（`observation_statistics.rs:220`），这是防触发器改写的真实校验，不是“传了 typed 值就完全没有回读”。可合并最终所需证据查询，不可无条件跳过存储认证。
- `observation_receipt::stored_events:172` 已把最多四个 family 成员的最终 witness 和所选 execution 合为一条 SELECT；这项去重已完成。其后 `batch_with_summary:56` 仍独立读 unavailable、cut、J/T ready frontier 和 trace_total。
- `observation_trace/event.rs:949` 的 `refresh_raw_bindings` 会解码 canonical Trace summary 后再 UPDATE，即使 calls/fields 为空或最终值未变；对 proposals 同理。`settle_fields:993` 随后读 Trace fact、改 canonical_fields_ready 并再次保存。入口是 `sqlite.rs:6203` 的 `rebind_published_read_layouts`。**无变化 summary 的重写是具体可减少的重复**；而 readiness false→true 的更新是真实状态变化，不能一起删掉。需要保留原坏 header 检测和 raw 字段优先级；未测定它占整体 CPU/WAL 多大比例。

`optional_display_layout`（`sqlite.rs:21757`）成功路径每域还有 SAVEPOINT/RELEASE 的 SQLite 执行成本。它们在同一个原生事务内，**不等于每域一次 durable commit**。合并同一行多次 UPDATE 可能减少解释器/B-tree/索引维护工作，但脏页可在同一提交内合并，也可能受 spill 影响；不能把 UPDATE 数、逻辑 JSON 字节、索引声明数直接换算成 WAL frames/物理写入量。

## 5. 对本轮结论的限制

可以明确保留的结论是：历史完成 owner 的大量重复 SQL/解码已被针对性消除，小事件 source 的重复完整正文也已共享；**并未消除所有响应 SQL、所有派生字段重复、所有 append 多阶段写入**。仍有局部可行的事务事实传递、无变化重写省略、精确依赖扩展；也有需要改变私有持久表示才能明显减少的 execution/member/statistics 版本冗余。它们都不是理论不可优化，但收益顺序不能在本轮新 CPU/WAL 结果出来前凭源码行数确定。本记录没有把这些剩余点包装成已完成优化，也没有把当前结构当作追平 Pi 所需成本的下界。
