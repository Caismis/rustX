# Publication review of the first owner-reuse candidate

This is a read-only source/profile review of candidate `459b1b6005bfbf7f0a1a1d52df5a6900b06c56c6` against the fresh `d22ce66c5a1cda895cac382ce2c350f345933876` baseline. It neither changes the candidate nor reruns products, builds or tests. The initial 120-product formal result remains intact. The later seven-pair live/short-large confirmation is a separate post-hoc batch and is not pooled here.

**Conclusion:** the sampled stacks show the intended elimination of repeated whole-metadata wire-length traversal. They do not show an owner-lookup/OnceLock-hit/resolve-clone hotspot that explains the initial adverse formal cell. A concrete remaining bulk operation is transcript normalization owned by the entire page: changing one row discards the prepared capture of every row. This existed before this candidate. The current evidence warrants retaining this as a focused next design, not claiming either a measured regression cause or that publication work is finished.

## Independent collapsed-stack recount

Read `profile-{baseline,complete}-live-large-cpu/steady-collapsed.txt`, split each line at its final space, and add the integer weight once per predicate. Baseline SHA256: `0cee24567d30d83d01b0e5bd380908a479862790d2e73129c7da7f0a8df66461`; candidate SHA256: `e440498beb74ed7a57fb550093c95e62132bda76770c9893e6053f56ee3dc943`. Counts agree with the retained `cpu-counts.json` / accepted `diagnostic-audit.json`. They are 4 ms samples in the measured 32-turn interval, not invocation counters or speedup estimates.

| Mutually exclusive publication partition | Baseline samples | Candidate samples |
|---|---:|---:|
| Capture: transcript-entry prepared capture | 9 | 16 |
| Capture: attempt capture | 4 | 7 |
| Capture: first metadata-fragment size computation | 0 | 7 |
| Capture: all other work | 9 | 9 |
| Final transition/event exact-length probe, outside capture | 37 | 16 |
| Other inside `PublicationDraft::encode` | 2 | 3 |
| **Publication total** | **61 / 260** | **58 / 252** |

Classification precedence is `capture_checkpoint` first; within it metadata-fragment initialization, transcript prepared capture, attempt capture, then other capture. Outside capture, `bounded_structural_len_with_budget` is the final probe bucket. All other publication stacks form the last bucket. This prevents double-counting the candidate's six sampled fragment exact-length calculations as both capture and final probing.

Further inclusive details, **not additive** to the table:

- The baseline final whole-transition probe contains 17 samples traversing `ProjectionMetadata` (including 9 collection and 7 content-binding samples). The candidate's sampled final probe is the event-array encoder: 16 samples. It has no sampled whole `RuntimeClientEvent` exact-length fallback.
- Candidate `ProjectionMetadata::fragment_budget` has 8 samples. Seven enter a fragment's `Size` OnceLock initializer: 2 exact encodes of `ContentBinding`, 4 exact encodes of `CollectionFrontier`, and 1 other frontier initialization sample. The remaining sample visits the current read-cut preflight. These are cache misses/first computations, not evidence of an expensive OnceLock **hit**.
- `PreparedBindingHead`, `MetadataFrontiers`, and `MetadataFragment::resolve` have no separately visible sampled lookup/clone frames. Inlining and sampling mean zero visible samples is not proof of zero cost. It does mean this profile offers no basis to blame a mutex/Arc/OnceLock lookup for a large regression.
- `capture_working_seed` has 3 samples in each revision. The explicit `RuntimeClientSnapshot::clone` symbol has 2 baseline / 3 candidate samples. No sampled full `fit_checkpoint` traversal appears in either revision; `capture_checkpoint` must not be called “full snapshot rebuilding.” Its lazy closure still avoids ordinary materialization.
- Publisher call paths, classified with worker `commit_display` first, then native batch, then native actor, are baseline 35 / 8 / 8 / 10 other and candidate 31 / 11 / 8 / 8 other. These remain sample counts, not counts of publications.

## Actual diagnostic workload and timing limits

The CPU-profile runs used the same 64 history + 32 measured turns and each retained 96 completed attempts, 96 explicit settlements and 96 text outcomes. Both ended at late checkpoint cursor 1246. The retained `notification_records` field is a **cumulative** subscriber counter (`tests/conformance/agent_loop/runtime_benchmark/aligned.rs:691`); summing it over samples is invalid. Its measured-window endpoint deltas are baseline 416 and candidate 413. This is not an exact count of internal encode calls, cache hits, row rebuilds or read-domain refreshes, and it cannot prove identical scheduling/coalescing.

| Separate diagnostic product | Baseline | Candidate |
|---|---:|---:|
| CPU-profile mean measured turn, ms | 22.0560625 | 22.29553125 |
| CPU-profile measured self CPU, ms at 100 Hz | 1030 | 1020 |
| No-profiler control mean measured turn, ms | 20.13246875 | 23.737625 |
| No-profiler control measured self CPU, ms at 100 Hz | 910 | 1080 |
| Control measured notification delta | 414 | 416 |

The diagnostic CPU/control pair itself gives different directions/magnitudes. It is insufficient to establish whole-program regression or improvement. Root reported that the separate seven-pair confirmation reverses the initial live/short-large adverse median; its exact results belong to the independent supplemental audit. No profile fraction is converted to predicted latency savings, and neither batch establishes Pi parity.

## What the immutable metadata change is actually doing

`projection.rs:894` captures bounded domains and evidence; `projection.rs:1049` supplies frontier owners and calls `fragment_budget`. `metadata_fragment.rs:104` computes each immutable value's conservative admission and exact schema-aware length once. `metadata_fragment.rs:177` composes the closed transition envelope from current cut/event encoding and cached metadata lengths. The emitted event and eventual transport serialization remain typed and unchanged.

`PreparedBindingHead` (`projection/prepared_capture.rs:163`) owns native raw bindings; `prefixed` (`:196`) retains only the latest message-index/transcript mapping. It does not hash or deeply compare the page on each publication. `MetadataFragment::resolve` (`checkpoint/metadata_fragment.rs:77`) returns the same owner for an unchanged reference, retains one alternate resolved owner, and allocates a fresh owner only when a different authority cannot use either. Current reference resolution still makes two indexed `content_metadata` lookups per canonical binding (`projection.rs:1630`); these were already performed before the fragment change. A moving positional prefix or changed authority legitimately needs new encoded metadata.

Frontier inheritance (`prepared_capture.rs:253`) carries only the previous published finite map. `prepare` (`:265`) compares the domain name and fixed scalar fields, not arbitrary JSON. Changed domain revisions, loaded/total counts or next offset create a new owner and therefore a new first-size calculation. No evidence in this profile demonstrates that unchanged immutable metadata is being discarded wholesale. The first-size samples must not be interpreted as a cache-hit failure rate; no runtime hit/miss counter was recorded.

There is some real new work: Arc-owned fragments, first-size exact encoding at capture time, and a finite frontier map per published seed. It replaces old repeated metadata traversal rather than making metadata free. At a pressure/invalid-value boundary the original exact path still runs; that is intentional exact admission behavior. No sampled whole-fit recurrence supports blaming this boundary path here.

## The remaining transcript operation and a concrete safe next design

The ordinary live native head is eight rows (`projection.rs:2063`, `CHECKPOINT_NATIVE_HEAD_ITEMS`), independently of the generic 32-item capture cap. All four retained diagnostic late checkpoints contain eight message rows.

Current invalidation is explicit: `PreparedCaptures::inherit`, `prepared_capture.rs:82`, compares `encoding_equal` on the entire `transcript.entries` vector. Any appended/removed row or changed process/completion/tool decoration resets the **single** owner. `projection.rs:977` then invokes `Capture::transcript_page` (`checkpoint.rs:1175`) for every retained row. Each small row's `transcript_entry` (`checkpoint.rs:1348`) uses `bounded_clone`, which performs the existing bounded encode/decode normalization; `transcript_page` subsequently computes its bounded length, and the prepared result also computes a safe-integer budget. The candidate's 16 transcript samples enter the initializer and include this JSON work. The current feature only reuses all rows when the **entire row vector** remains unchanged; it does not reuse seven unchanged rows when the eighth changes.

A focused long-term design is possible, but it is not a safe one-line replacement of vector equality with cursor equality:

1. Give each fully authenticated **complete transcript row** an immutable native owner with a prepared-normalization slot. Carry that owner as an internal sidecar through the checkpoint-head/`ReadDomainValues` path to the seed; the public DTO and wire remain unchanged. Reuse by owner identity only. The owner must include both canonical/header body and response/process/tool decoration, not just transcript cursor, message ID or response-cache key. An absent completion may become present later; errors and schema/external-write invalidation must still be checked at the current read transaction.
2. Store the normalized row, its exact admission length/required budget and relative content/frontier evidence with that owner. Assemble the current page in the original order, charge the same shared optional-body budget and preserve the original stop/eviction behavior. Prefix relative evidence with the **current** row index, and resolve current content authority afterward. A shifted row position must never reuse old absolute `transcript.entries.N` paths.
3. Keep the cache bounded to the native head/retained owners. New rows and changed running rows get new owners; old seeds retain their exact old owners. Changed current cut/page envelope still emits current values. Where the original shared budget cannot admit a prepared row, execute the existing exact row admission; do not turn a failed admission into a partial or looser one.

The current durable response cache is useful proof infrastructure but insufficient by itself: `observation_response/cache.rs:42` owns `ResponsePageItem`, while `observation_checkpoint.rs:15` separately rereads and builds the transcript body before `response::apply_page_facts`. A response-owner token alone does **not** authenticate the canonical display body. Pure projection-local cursor lookup would guess identity and could suppress a coherently changed or corrupt body. Either the native bounded header reader must supply its own authenticated immutable body owner, or a complete-row owner must be produced at the point where both body and decoration are proven together. This is a focused cross-layer change (native head/read DTO, internal projection sidecar, row capture and tests), not a small OnceLock tweak. Moderate implementation/correctness risk is concentrated in corruption invalidation, inherited/deferred rows, positional bindings and exact shared-budget replay.

Minimum independent evidence for that iteration: a moving eight-row window proves unchanged rows avoid re-normalization; pending-to-complete and tool-result changes replace only affected owners; raw/opaque numbers, reordered JSON, signed zero and invalid quantities preserve original bytes/errors; every shared-budget boundary and shifted `$key`/content path matches the old algorithm; old-cut/replay results remain unchanged; same-connection mutation/rollback, external write and schema changes cannot admit stale body/decoration ownership. Current source tests and sampled work identify the opportunity, but do not prove this future implementation or its wall-clock gain.

The initial adverse cell is preserved, the supplemental reversal remains separate, and no production corrective patch is justified merely by the 9-to-16 transcript sample change. The appropriate closeout is honest split performance evidence for the current validated reductions, with this specific remaining work stated rather than an “all overhead removed” claim.
