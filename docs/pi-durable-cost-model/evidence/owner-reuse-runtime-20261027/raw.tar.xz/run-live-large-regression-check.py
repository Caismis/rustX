import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
ledger=root/'live-large-regression-command.json'
assert not ledger.exists()
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def source():
 assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime'],cwd=repo,text=True).strip()
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_files':{str(p.relative_to(repo)):sha(p) for folder in ('src','tests','benchmarks/runtime') for p in sorted((repo/folder).rglob('*')) if p.is_file() and '__pycache__' not in p.parts}|{p:sha(repo/p) for p in ('Cargo.toml','Cargo.lock')}}
old=Path('/home/capi/.cache/rustx-pr485-pi-flow/candidate-complete-build/conformance');new=root/'candidate-complete-build/conformance'
command=[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(old),'--after',str(new),'--output',str(root/'live-large-regression-check'),'--pairs','7','--observer-mode','live-subscriber','--case','short-large']
r={'purpose':'Independent follow-up to the adverse initial live/large median; not pooled with formal samples','command':command,'cwd':str(repo),'runner_sha256':sha(__file__),'source_before':source(),'binary_sha256':{'before':sha(old),'after':sha(new)},'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'}
ledger.write_text(json.dumps(r,indent=2)+'\n')
with (root/'live-large-regression-check.stdout').open('w') as out,(root/'live-large-regression-check.stderr').open('w') as err:
 p=subprocess.run(command,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
r.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),exit=p.returncode,status='complete' if p.returncode==0 else 'failed',source_after=source())
assert r['source_before']==r['source_after']
assert r['binary_sha256']=={'before':sha(old),'after':sha(new)}
ledger.write_text(json.dumps(r,indent=2)+'\n');print(r['status'],p.returncode);raise SystemExit(p.returncode)
