# Owner reuse evidence workflow

This round executes Rust only: 120 formal products (two revisions × six cases × two observer modes × five interleaved pairs) and twelve isolated diagnostics (four synchronized column products, four large/live CPU/control products, four Rust WAL products). Pi and DeepSeek are not executed. All runtime producers remain serial; do not overlap them with builds or tests.

The fixed old Rust is d22ce66c5a1cda895cac382ce2c350f345933876, SHA256 775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb, schema 80. Candidate identity is established by a successful explicit correctness directory and a new clean ordinary O3/default-feature build, schema 81. Correctness uses the existing O0/all-features queue and is distinct from the performance binary. Source, all tests, Cargo inputs and harness fixtures remain bound before/after each applicable stage. Failed queues and failed audit outputs remain in place.

After final checks and the source commit, run:

```text
python3 build-candidate.py --checks-dir checks-REPLACE_WITH_SUCCESSFUL_DIRECTORY
python3 premeasurement.py --output premeasurement.json
python3 run-diagnostics.py
python3 run-cohorts.py --stage direct
python3 direct-audit.py --output direct-audit.json
python3 diagnostic-audit.py --output diagnostic-audit.json
python3 summarize-results.py
```

Run from this evidence directory. `premeasurement.json` must precede all products. It verifies the exact source/check binding and actual binary bytes, and freezes producer/auditor scripts. Once it exists, do not change those scripts. Failed premeasurement/audit outputs require distinct names; retained failed product directories must never be overwritten. Direct and diagnostic order may be reversed, but their UTC windows must be disjoint. No performance claim is established until strict audits succeed.

The report uses all 60 candidate Rust samples, all 60 freshly paired old Rust samples, 60 fixed previous Pi samples (five per same case/mode cell), and 12 fixed previous DeepSeek samples (three per four live cases). The latter are separate batches, so ratios are **ratios of medians**, never new paired comparisons. DeepSeek idle does not await flush/fsync. Its native exit/verification `wait4` CPU is shown separately; its full process write counter is unavailable, not zero. Every adverse pair and unavailable ratio is retained in report-data.json.

`reference-pins/fixed-references.json` binds the copied previous strict audit and the already published prior raw archive by SHA256. It is an explicit reference dependency, not a new Pi/DS raw derivation. The prior archive's raw-only command and portable verification receipt are retained alongside this pin. No old samples validate the new candidate's tests or source.

New raw-only entry points are:

```text
python3 direct-audit.py --root EXTRACTED --raw-only --output OUTSIDE/direct-raw-audit.json
python3 diagnostic-audit.py --root EXTRACTED --raw-only --formal-audit OUTSIDE/direct-raw-audit.json --output OUTSIDE/diagnostic-raw-audit.json
python3 summarize-results.py --root EXTRACTED --audit OUTSIDE/direct-raw-audit.json --output OUTSIDE/report-data.json --markdown OUTSIDE/report-tables.md
```

Raw-only does not dereference recorded absolute binaries, source trees, profiler libraries or database paths. It verifies retained manifests, commands, logs, exact matrix/oracles, source/check hashes and independent raw arithmetic. For a portable archive retain every regular evidence file (including failed histories and reference pins), excluding compiled `conformance`, binaries, __pycache__, and the output archive itself; preserve all relative paths. Compare replayed direct datasets, diagnostic profiles/columns/WAL summaries, and report numerical data to the strict records. Hash every retained member and reject traversal, duplicate members, symlinks and unexpected files. Archive creation/replay has not yet occurred.

The new column layout has `observation_source_overlay` only on candidate; old inline columns exist only on baseline. Absence is never assigned a measured zero. Both revisions' readiness state is connection-local TEMP and outside these main-database snapshots. Logical retained column bytes are not WAL bytes, process write bytes or device traffic. Endpoint dbstat page labels are not exact per-write table attribution.

Validation so far: seven pure parser/fixture test groups passed; initial failure and three later successful logs are retained. No product/build was run to prepare these tools, and no uncompleted formal audit is marked accepted.
