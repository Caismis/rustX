#!/usr/bin/env python3
"""Replay the separate 14-product supplement after base archive verification.

Reuses the existing verified extraction; never modifies raw, runs a product or
reopens a historical source/binary. Original 120 products remain separate.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
DEFAULT_EVIDENCE = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/evidence/owner-reuse-runtime-20261027')
DEFAULT_WORK = Path('/home/capi/.cache/rustx-pr485-owner-reuse-portable-verification')
AUDITOR_SHA = '5620bcb7f0e485af5464ff354750574592b27cb0095529cc42818ef28ae5f16d'
COMMAND = ['python3', 'audit-live-large-regression.py', '--root', '.', '--raw-only',
           '--formal-audit', '../direct-raw-audit.json', '--output', '../live-large-regression-raw-audit.json']


def require(ok, message):
    if not ok:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def copied(value):
    return json.loads(json.dumps(value, allow_nan=False))


def compare(raw, strict, formal_path):
    require(strict['accepted'] is True and strict['errors'] == [] and strict['mode'] == 'strict'
            and strict['raw_only'] is False and strict['strict_identity_verified'] is True,
            'preserved supplemental strict audit is not accepted')
    require(raw['accepted'] is True and raw['errors'] == [] and raw['mode'] == 'raw-only'
            and raw['raw_only'] is True and raw['strict_identity_verified'] is False,
            'supplemental raw replay acceptance/identity mode differs')
    require(raw['formal_audit']['mode'] == 'raw-only' and raw['formal_audit']['sha256'] == sha(formal_path),
            'supplement does not bind freshly recomputed formal report')
    require((raw['dataset']['derived_products'], raw['dataset']['valid_comparisons'], raw['dataset']['checked_requests']) == (14, 7, 672),
            'supplement coverage differs')
    left, right = copied(raw), copied(strict)
    for report in (left, right):
        for key in ('mode', 'raw_only', 'strict_identity_verified', 'created_utc'):
            report.pop(key)
        for key in ('file', 'sha256', 'mode'):
            report['formal_audit'].pop(key)
    require(left == right, 'supplement complete data/identity/adverse/initial-formal records differ')
    return {'products': 14, 'comparisons': 7, 'checked_requests': 672,
            'all_metrics_adverse_missing_and_initial_formal_records_equal': True,
            'allowed_differences': 'Explicit raw-only mode, created timestamp and fresh formal report path/hash/mode only.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, default=DEFAULT_EVIDENCE)
    parser.add_argument('--work-dir', type=Path, default=DEFAULT_WORK)
    parser.add_argument('--base-receipt', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    evidence, work = args.evidence.resolve(), args.work_dir.resolve()
    root = work / 'raw'
    base_path = (args.base_receipt or evidence / 'portable-verification.json').resolve()
    output = (args.output or evidence / 'supplemental-portable-verification.json').resolve()
    raw_output = work / 'live-large-regression-raw-audit.json'
    require(work.is_dir() and root.is_dir(), 'base verifier must have completed fresh extraction first')
    require(not output.exists() and not output.is_relative_to(root) and not raw_output.exists(), 'new output outside extracted raw required')
    report = {'accepted': False, 'errors': [], 'started_utc': now(), 'verification_script_sha256': sha(__file__),
              'actual_host_binaries_reverified': False, 'actual_host_sources_reverified': False,
              'commands': [], 'formal_products': 120, 'separate_supplemental_products': 14,
              'new_pi_products': 0, 'new_deepseek_products': 0}
    try:
        base = load(base_path)
        require(base['accepted'] is True and base['errors'] == []
                and base['post_audit_raw_inventory_and_hashes_unchanged'] is True,
                'base portable verification not accepted')
        require(Path(base['external_verification_directory']).resolve() == work, 'base extraction directory differs')
        require(load(work / 'verification-result.json') == base, 'base sidecar and retained verification receipt differ')
        summary = load(evidence / 'summary.json')
        require(sha(evidence / 'summary.json') == base['summary_sha256'] and summary['archive_sha256'] == base['archive_sha256']
                and sha(evidence / 'raw.tar.xz') == base['archive_sha256'], 'base evidence archive/summary identity differs')
        require(sha(root / 'MANIFEST.json') == base['manifest_sha256'] == summary['manifest_sha256'], 'base manifest identity differs')
        manifest = load(root / 'MANIFEST.json')
        expected = {name: {key: value[key] for key in ('bytes', 'sha256')} for name, value in manifest['files'].items()}
        expected['MANIFEST.json'] = {'bytes': summary['manifest_bytes'], 'sha256': summary['manifest_sha256']}
        require(len(manifest['files']) == base['verified_payload_files'] == summary['raw_files']
                and sum(value['bytes'] for value in manifest['files'].values()) == base['verified_payload_bytes'] == summary['raw_bytes'],
                'base complete payload count/bytes differs')
        verifier_path = root / 'verify-archive.py'
        require(sha(verifier_path) == base['verification_script_sha256'] == expected['verify-archive.py']['sha256'],
                'base verifier differs from verified source')
        spec = importlib.util.spec_from_file_location('verified_base_archive', verifier_path)
        core = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(core)
        # Validate all raw bytes, including this extension and the supplemental
        # auditor/strict report, before executing any supplemental arithmetic.
        core.verify_tree(root, expected)
        require(sha(root / 'verify-live-large-regression.py') == report['verification_script_sha256'], 'extension differs from archived source')
        require(sha(root / 'audit-live-large-regression.py') == AUDITOR_SHA, 'supplemental auditor differs from reviewed version')
        formal_path = work / 'direct-raw-audit.json'
        require(sha(formal_path) == base['replayed_report_sha256']['direct-raw-audit.json'], 'fresh formal replay changed since base verification')
        strict_formal, _, _ = core.strict_reports(root)
        core.compare_formal(load(formal_path), strict_formal)
        strict_path = root / 'live-large-regression-audit.json'
        strict = load(strict_path)
        require(strict['accepted'] is True and strict['errors'] == [] and strict['mode'] == 'strict'
                and strict['raw_only'] is False and strict['strict_identity_verified'] is True, 'supplement strict audit not accepted')
        require(strict['script_sha256'] == AUDITOR_SHA and strict['formal_audit']['sha256'] == sha(root / 'direct-audit.json')
                and strict['formal_audit']['mode'] == 'strict' and strict['original_formal_sha256'] == sha(root / 'direct-audit.json'),
                'supplement strict report is not bound to original 120-product report')
        before = {name: core.fingerprint(path) for name, path in [('base', base_path), ('summary', evidence / 'summary.json'), ('archive', evidence / 'raw.tar.xz'), ('formal', formal_path)]}
        environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
        environment.pop('PYTHONPATH', None); environment.pop('PYTHONHOME', None)
        record = {'argv': COMMAND, 'cwd': str(root), 'start_utc': now()}
        report['commands'].append(record)
        outlog, errlog = work / 'supplemental-replay.stdout', work / 'supplemental-replay.stderr'
        with outlog.open('x') as stdout, errlog.open('x') as stderr:
            result = subprocess.run(COMMAND, cwd=root, env=environment, stdout=stdout, stderr=stderr)
        record.update(end_utc=now(), exit=result.returncode, stdout_sha256=sha(outlog), stderr_sha256=sha(errlog))
        require(result.returncode == 0, 'supplemental raw-only audit failed; retained external logs contain details')
        report['complete_supplemental_comparison'] = compare(load(raw_output), strict, formal_path)
        core.verify_tree(root, expected)
        require(all(core.fingerprint(path) == before[name] for name, path in [('base', base_path), ('summary', evidence / 'summary.json'), ('archive', evidence / 'raw.tar.xz'), ('formal', formal_path)]), 'base/archive/fresh formal evidence changed during supplemental replay')
        report.update(base_receipt_sha256=sha(base_path), archive_sha256=base['archive_sha256'],
                      manifest_sha256=base['manifest_sha256'], strict_supplement_sha256=sha(strict_path),
                      raw_supplement_sha256=sha(raw_output), fresh_formal_sha256=sha(formal_path),
                      verified_payload_files=summary['raw_files'], verified_payload_bytes=summary['raw_bytes'],
                      before_and_after_complete_raw_inventory_and_hashes_match=True, accepted=True)
    except Exception as error:
        report['errors'].append(f'{type(error).__name__}: {error}')
    report['finished_utc'] = now()
    report['scope'] = 'Independent retained-arithmetic replay of the separate post-hoc seven-pair Rust supplement after accepted base archive replay; no pooling, fresh historical host identity verification or parity claim.'
    encoded = json.dumps(report, indent=2, allow_nan=False) + '\n'
    with (work / 'supplemental-verification-result.json').open('x') as stream:
        stream.write(encoded)
    with output.open('x') as stream:
        stream.write(encoded)
    print(json.dumps({'accepted': report['accepted'], 'errors': report['errors'], 'output': str(output)}, indent=2))
    return int(not report['accepted'])


if __name__ == '__main__':
    raise SystemExit(main())
