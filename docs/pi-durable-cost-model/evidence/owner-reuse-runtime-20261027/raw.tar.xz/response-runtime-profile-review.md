# 响应 owner 缓存：真实运行采样复核

只读核对冻结源 `459b1b6005bfbf7f0a1a1d52df5a6900b06c56c6` 与本目录已完成的 CPU 诊断。未运行产品、测试或构建，未修改生产源和诊断脚本。后续配对实测决定总体收益；本说明不把采样方向当作因果解释，也不把不利结果称为噪声。

## 样本边界与准确计数

输入为 `profile-baseline-live-large-cpu` / `profile-complete-live-large-cpu` 的 `manifest.json`、`steady-cumulative.txt`、`steady-collapsed.txt`。两次均为 `short-large`、`live-subscriber`、250 Hz，64 个历史轮次之后测量 32 轮。按 `profile-reports.py`，steady 报告解码 `before_measured_turns.cpu`。基线 / 候选 binary SHA256 分别为 `775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb` / `21d50ee8ac86bb80a2132e6013ece360ae56944d311abbaf87c0576ef32c0e57`。

| 栈帧（inclusive） | 基线：260 samples | 候选：252 samples |
|---|---:|---:|
| `ReadDomainCut::read_with_trace` | 31（11.9%） | 40（15.9%） |
| `observation_checkpoint::read` | 31（11.9%） | 39（15.5%） |
| `observation_response::read_validated` | 22（8.5%） | 25（9.9%） |
| `Reader::item` | 20（7.7%） | 24（9.5%） |
| `Reader::members` | 6 | 3 |
| `Reader::execution` | 3 | 5 |
| `Reader::append_revision` | 3 | 4 |
| `Reader::retry` | 1 | 4 |
| `sqlite3VdbePreUpdateHook` | 1 | 1 |
| 新 `response::cache::Owner::observe` | 不存在 | 1 |
| 新 `response::cache::Owner::capture` | 不存在 | 1 |
| `PublicationDraft::encode` | 61（23.5%） | 58（23.0%） |

这些是含子调用的样本，父子项重叠，不能相加为独占 CPU。采样包含产品全部线程与 driver，含 profiler phase flush/dump/handshake 开销；不是 SQL 调用计数，也不是墙时或 CPU 改变量的因果分解。

在 collapsed 原始栈中，候选的 hook、`Owner::observe`、`get_new_column_value`、`sqlite3_preupdate_new` 都是**同一个**样本，来自 `commit_model_turn_start → persist_event_tx_with_requests → observation_event::index_with_paths` 的更新，落在 SQLite 为 preupdate 新值分配内存处。基线唯一 hook 样本来自既有 manifest observer。新增逐行扫描确实有工作量，现有一份低样本 profile 不支持“它已是主要瓶颈”的结论。

## 缓存是否被普通追加必然清空

没有在源码中找到普通 warm 新 attempt 必然清空所有历史 completed entries 的路径：

- `sqlite.rs:3205` 的 `presentation_reader` 共享同一 `ConnectionOwner`；不是每页新建 cache。主库同连接提交不会因外部 `data_version` 检查而必然失效。
- `cache.rs:190` 对新行检查 sequence、execution/member owner、Ledger/T 坐标。普通新 attempt 的这些坐标都超过旧完成 owner 的依赖上限。`append_facts.rs:23`、`observation_execution.rs:253`、`sqlite.rs:11434` 后续各派生 UPDATE 定位本次新 sequence，不是反复改写旧 execution summary 行。
- `sqlite.rs:6203` canonical rebind、`:10156` Surface 首次出现更新、`:7650` canonical receipt header 更新，在新 message 的 semantic transaction 内完成；之后才发布和读取。不能仅见到这些 UPDATE 就断言已缓存旧消息在每轮被重写。
- live checkpoint 头只有 8 项（`runtime_client/checkpoint.rs:15`），cache 上限 32 项（`cache.rs:15`）。普通短 ID 的 warm 页面不因容量就必然发生全页抖动。`Reader` 不准入正在运行的 execution，也不准入缺少 native Ledger authority 的 pending-only seat（`observation_response.rs:240,492`）。

不过失效仍有真实的保守性：任何命中累计前沿的旧行 UPDATE 都使整个 epoch 失效，即使只改了响应不读取的列或写回相同 bytes；各 entry 驱逐后累计前沿不缩小（`cache.rs:190,322`）。Deferred identity 条目还会因任意 `content_frontiers` 写入失效（`:209,328`）。这意味着某些负载可以产生多余冷读，但当前普通 warm 源路径与 profile 尚未证明这正是实测回退原因。

## 更需要核实的准入边界与仍然存在的工作

`ReadDomainCut` 捕获一个有限 cut，工作线程稍后才在 Store 上执行读取（`runtime_client/projection.rs:2052,7532,7552`）。`cache.rs:253` 只有当读取事务里的实际 J/L/T 恰好等于请求 cut 时才准入新 entry。若数据库已经推进，已有的兼容 entry 仍可命中，但这次冷读不能加入 cache；连续追赶可能使新 owner 多次走冷路径。**这是源码允许的具体假设，不是从现有样本得到的发生率。不得为提高命中率直接放宽历史证明。**

无论命中多少，非空页当前新增 3 个版本 PRAGMA + 1 个当前 head SELECT（`cache.rs:33,220`）；仍保留成员洞、所需 execution 区间洞与统计读取。cache miss 还要执行原 native owner/alias/header/execution/member/retry 查询，成功准入时做有界 preflight 与 clone；cache hit 也 clone 有界 item。现有候选 24 个 `Reader::item` 样本中仍清楚可见冷 owner SQL、execution hole/layout、member decode、retry MessageHeader decode、canonical locator/append revision 查询；不能把这些全称为缓存已消除的工作。当前未记录实际 hit/miss/admit-denied/epoch-reason 计数，profile 也不能区分冷的新 owner 与被失效的旧 owner。

有意义的后续验证应使用完整 native cycle，在 Pending 接受、adopt、AttemptFirstTurn、request、final publication 各阶段读取同样 8 项 checkpoint，分别记录 old completed hits、owner SQL、execution/member decode、准入拒绝原因和 epoch 失效表/坐标；另明确覆盖 worker 捕获旧 cut 后 native TX 推进的时序。已有 `observation_response_reuse_work_tests.rs:2` 证明 8 个 completed owner 跨新 J 与 accept/adopt 可保持 `(8 hits, 0 native-owner SQL, 1 execution-hole SQL)`，但不覆盖完整 live worker 调度。不要把这一局部工作量回归当作正式 live workload 命中率。

## Source 路径

本轮 event overlay 减少物理正文副本，但 `observation_event.rs:452` 仍构造 typed structural source 和 seekable layout。新增 `inline/overlay.rs:50` 对 native/source 字节做有界扫描、两个 SHA256、MessagePack 编码，`:542` UPDATE 另核对实际 `event_json` bytes。因此这项是存储表示取舍，不是删除全部 source 计算。候选 `SeekableObservationSource::from_layout` 有 5 个 inclusive samples，其中 event 路径 3、request 路径 2；基线 `SeekableObservationSource::new<RuntimeEventEnvelope>` 有 2 个。内联与符号归属不同、样本太少，而且 `read_layout.rs` 本轮未改，不能据此声称解析次数增加或定量解释 CPU 回退。

结论：现有证据支持“响应冷读和 source 构建仍占据可见工作，cache 新增固定检查与逐行 hook 成本”；不支持“普通 append 已被证明一直清空缓存”或“新增 hook 已被证明导致总体回退”。冻结源保持不变，完整配对结果及额外复验必须保留有利与不利方向。
