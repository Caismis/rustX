#!/usr/bin/env python3
"""Pure audit-result arithmetic. New Rust is paired only with freshly measured old Rust."""
import argparse, collections, hashlib, json, math, statistics, sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
CASES=['short-small','short-large','stream','large','tool','cancel']
MODES=['no-live-subscriber','live-subscriber']
PRIMARY=['median_measured_turn_ms','through_cleanup_self_cpu_ms','through_cleanup_process_write_bytes','max_sampled_anon_pss_mib','max_sampled_rss_mib']
def require(ok,message):
 if not ok:raise ValueError(message)
def load(p):return json.loads(Path(p).read_text())
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def distribution(values):
 require(all(v is None or type(v) in (int,float) and math.isfinite(v) and v>=0 for v in values),'invalid metric')
 valid=[v for v in values if v is not None]
 return {'values':values,'available':len(valid),'missing':len(values)-len(valid),'median':statistics.median(valid) if valid else None,'minimum':min(valid) if valid else None,'maximum':max(valid) if valid else None}
def ratio(numerator,denominator):
 if numerator is None or denominator is None:return None,'metric unavailable'
 if denominator==0:return None,'zero denominator; no invented ratio'
 return numerator/denominator,None

def compare(products,references,metric,reference_metric=None,scale=1):
 n=distribution([r['metrics'].get(metric) for r in products]);d=distribution([None if r['metrics'].get(reference_metric or metric) is None else r['metrics'][reference_metric or metric]*scale for r in references])
 r,reason=ratio(n['median'],d['median'])
 return {'current':n,'reference':d,'ratio_of_medians':r,'ratio_unavailable_reason':reason,'scope':'cross_batch_descriptive_not_paired'}

def derive(formal,previous):
 require(formal['accepted'] is True and formal['errors']==[] and formal['datasets']['direct']['derived_products']==120,'current direct audit incomplete')
 require(previous['accepted'] is True and previous['mode']=='strict' and previous['strict_identity_verified'] is True and not previous['errors'],'fixed reference was not strict accepted')
 require(len(formal['datasets']['direct']['products'])==120 and collections.Counter(r['engine'] for r in formal['datasets']['direct']['products'])=={'before':60,'after':60},'fresh direct product inventory differs')
 current=[r for r in formal['datasets']['direct']['products'] if r['engine']=='after']
 prior_pi=[r for r in previous['datasets']['final']['products'] if r['engine']=='pi']
 require(len(current)==len(prior_pi)==60,'current/Pi 60-product inventory differs')
 current_index=collections.defaultdict(list);pi_index=collections.defaultdict(list)
 for rows,index in [(current,current_index),(prior_pi,pi_index)]:
  for row in rows:index[(row['mode'],row['case'])].append(row)
  require(set(index)=={(m,c) for m in MODES for c in CASES},'twelve-cell matrix differs')
  require(all(len(v)==5 and {r['pair'] for r in v}==set(range(5)) for v in index.values()),'cell repetition inventory differs')
 groups=formal['datasets']['direct']['groups'];paired=[];pi=[];adverse=[];unavailable=[]
 for mode in MODES:
  for case in CASES:
   selected=[g for g in groups if g['mode']==mode and g['case']==case]
   require(selected and len({g['metric'] for g in selected})==len(selected),'duplicate or missing direct metrics')
   paired.append({'mode':mode,'case':case,'metrics':{g['metric']:{'fresh_before':g['denominator_values'],'fresh_after':g['numerator_values'],'paired_percent':g['percent_change'],'pairs':g['pairs']} for g in selected}})
   metrics=sorted(set.intersection(*(set(r['metrics']) for r in current_index[mode,case]+pi_index[mode,case])))
   pi.append({'mode':mode,'case':case,'metrics':{metric:compare(current_index[mode,case],pi_index[mode,case],metric) for metric in metrics}})
   for g in selected:
    bad=[r for r in g['pairs'] if r['percent_change'] is not None and r['percent_change']>0]
    if bad:adverse.append({'comparison':'fresh_paired_rust','mode':mode,'case':case,'metric':g['metric'],'paired_median_percent':g['percent_change']['median'],'adverse_pairs':bad,'adverse_count':len(bad),'all_pairs':len(g['pairs'])})
    for p in g['pairs']:
     if p['ratio'] is None:unavailable.append({'comparison':'fresh_paired_rust','mode':mode,'case':case,'metric':g['metric'],'pair':p['pair'],'reason':p['ratio_unavailable_reason']})
 ds=previous['datasets']['three-engine'];dsrows=[];supp={(r['case'],r['repetition']):r for r in ds['supplementary_products'] if r['engine']=='deepseek'}
 rawds=[r for r in ds['rows'] if r['engine']=='deepseek']
 require(len(rawds)==len(supp)==12 and {r['case'] for r in rawds}=={'short-small','short-large','stream','large'},'fixed DeepSeek inventory differs')
 for row in rawds:
  extra=supp[row['case'],row['repetition']]
  require(extra['raw_sha256']==row['raw_result_sha256'],'DeepSeek metric/source binding differs')
  dsrows.append({'case':row['case'],'repetition':row['repetition'],'metrics':dict(row,**extra['metrics']),'source':extra['file'],'raw_sha256':row['raw_result_sha256'],'limits':extra['limits']})
 dsout=[]
 for case in ['short-small','short-large','stream','large']:
  refs=[r for r in dsrows if r['case']==case];require(len(refs)==3 and {r['repetition'] for r in refs}==set(range(3)),'DeepSeek repetition differs')
  products=current_index['live-subscriber',case]
  metrics={key:compare(products,refs,key) for key in ('mean_turn_ms','median_measured_turn_ms','turn_cpu_ms_per_turn','max_sampled_turn_rss_mib')}
  metrics['turn_write_bytes_per_turn']=compare(products,refs,'turn_write_bytes_per_turn','turn_write_mib_per_turn',1048576)
  dsout.append({'mode':'live-subscriber','case':case,'metrics':metrics,'separate_deepseek_native_flush_exit_metrics':{key:distribution([r['metrics'].get(key) for r in refs]) for key in ('first_native_runtime_wait4_cpu_ms','verification_native_runtime_wait4_cpu_ms','both_native_runtimes_wait4_cpu_ms','through_cleanup_process_write_bytes','closed_logical_bytes','closed_allocated_bytes')},'limits':refs[0]['limits']})
 for label,rows in [('prior_pi',pi),('prior_deepseek',dsout)]:
  for row in rows:
   for metric,stats in row['metrics'].items():
    r=stats['ratio_of_medians']
    if r is None:unavailable.append({'comparison':label,'mode':row['mode'],'case':row['case'],'metric':metric,'reason':stats['ratio_unavailable_reason']})
    elif r>1:adverse.append({'comparison':label,'mode':row['mode'],'case':row['case'],'metric':metric,'ratio_of_medians':r,'scope':'fixed_prior_batch_reference_not_paired'})
 return {'accepted':True,'current_rust_products':60,'fresh_paired_products':120,'fixed_pi_products':60,'fixed_deepseek_products':12,'fresh_paired':paired,'fixed_pi':pi,'fixed_deepseek':dsout,'all_adverse_metrics':adverse,'all_unavailable_ratios':unavailable,
 'limits':['Only the fresh old/new Rust products are interleaved pairs. Pi/DeepSeek use fixed previous batches and separate descriptive ratios of medians; no causal parity or paired confidence claim.', '/proc CPU counters use 100 ticks/s; each cumulative endpoint has 10 ms granularity. This is not profiler sampling.', 'A product measured-turn median and a product measured-turn mean are different estimands. Across products we report median and range of those statistics, not pooled turns.', 'DeepSeek SDK idle does not await flush/fsync. Native wait4 CPU covers exit/flush and verification separately; full process write_bytes is unavailable, not zero. No equivalent lifecycle ratio is constructed.', 'All recorded adverse pairs and all unavailable ratios are retained, including reversals hidden by a favorable group median.']}

def fmt(value):return 'N/A' if value is None else f'{value:.3f}'
def markdown(data):
 lines=['# Owner reuse performance evidence','','Fresh Rust comparison: five interleaved pairs per cell. Historical Pi/DeepSeek rows are fixed, separate batches; their ratios are ratios of medians, not paired results.','','| Mode | Case | Paired median wall % [min,max] | Full CPU % | Full write bytes % | Sample anon PSS % | Sample RSS % |','|---|---|---:|---:|---:|---:|---:|']
 for row in data['fresh_paired']:
  cells=[]
  for metric in PRIMARY:
   p=row['metrics'][metric]['paired_percent'];text=fmt(p['median'])
   if metric==PRIMARY[0]:text+=f" [{fmt(p['minimum'])},{fmt(p['maximum'])}]"
   cells.append(text)
  lines.append('| '+' | '.join([row['mode'],row['case'],*cells])+' |')
 lines+=['','| Mode | Case | Mean wall / old Pi | Median wall / old Pi | Full CPU / old Pi | Full writes / old Pi |','|---|---|---:|---:|---:|---:|']
 for row in data['fixed_pi']:
  lines.append('| '+' | '.join([row['mode'],row['case'],*(fmt(row['metrics'][k]['ratio_of_medians']) for k in ('mean_turn_ms','median_measured_turn_ms','through_cleanup_self_cpu_ms','through_cleanup_process_write_bytes'))])+' |')
 lines+=['','Warm measured windows (per-product statistic, then median [minimum,maximum] across five Rust/Pi products; each has 32 measured turns):','','| Mode | History | Engine/batch | Mean ms/turn | Median ms/turn | CPU ms/turn | Write bytes/turn |','|---|---:|---|---:|---:|---:|---:|']
 for row in data['fixed_pi']:
  if row['case'] not in ('short-small','short-large'):continue
  for label,engine in [('current','current Rust'),('reference','fixed old Pi')]:
   cells=[]
   for key in ('mean_turn_ms','median_measured_turn_ms','turn_cpu_ms_per_turn','turn_write_bytes_per_turn'):
    d=row['metrics'][key][label];cells.append(f"{fmt(d['median'])} [{fmt(d['minimum'])},{fmt(d['maximum'])}]")
   lines.append('| '+' | '.join([row['mode'],str(8 if row['case']=='short-small' else 64),engine,*cells])+' |')
 lines+=['','| Live case | Current mean ms/turn | Fixed DS mean ms/turn | Wall ratio | CPU ratio | Measured write ratio |','|---|---:|---:|---:|---:|---:|']
 for row in data['fixed_deepseek']:
  wall=row['metrics']['mean_turn_ms'];lines.append('| '+' | '.join([row['case'],fmt(wall['current']['median']),fmt(wall['reference']['median']),fmt(wall['ratio_of_medians']),fmt(row['metrics']['turn_cpu_ms_per_turn']['ratio_of_medians']),fmt(row['metrics']['turn_write_bytes_per_turn']['ratio_of_medians'])])+' |')
 lines+=['','DeepSeek exit/flush CPU remains separate from measured turns and from Rust full-lifecycle CPU; full DeepSeek process write bytes remain unavailable. The JSON retains the exact wait4 metrics and source-specific limits.','','All adverse metrics (including individual fresh paired reversals):','','| Comparison | Mode | Case | Metric | Median % or cross-batch ratio | Adverse pairs |','|---|---|---|---|---:|---|']
 for row in data['all_adverse_metrics']:
  lines.append('| '+' | '.join([row['comparison'],row['mode'],row['case'],row['metric'],fmt(row.get('paired_median_percent',row.get('ratio_of_medians'))),','.join(f"{r['pair']}:{r['percent_change']:+.3f}%" for r in row.get('adverse_pairs',[])) or 'cross-batch'])+' |')
 lines+=['',*['- '+x for x in data['limits']],'','Unavailable ratio records, all per-product values, and reference hashes are retained in report-data.json.']
 return '\n'.join(lines)+'\n'

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=HERE);p.add_argument('--audit',type=Path);p.add_argument('--output',type=Path);p.add_argument('--markdown',type=Path);a=p.parse_args()
 audit=a.audit or a.root/'direct-audit.json';output=a.output or a.root/'report-data.json';md=a.markdown or a.root/'report-tables.md'
 require(not output.exists() and not md.exists(),'retain prior report attempt')
 pinpath=a.root/'reference-pins/fixed-references.json';pin=load(pinpath);ref=a.root/'reference-pins'/pin['reference_audit'];require(ref.parent==pinpath.parent and sha(ref)==pin['reference_audit_sha256'],'fixed prior reference audit changed')
 formal=load(audit);require(formal['script_sha256']==sha(a.root/'direct-audit.py'),'current formal auditor changed')
 previous=load(ref);require(previous['identities']['complete']['sha256']==pin['prior_rust_sha256'] and previous['identities']['complete']['head']==pin['prior_source'],'fixed reference source differs')
 data=derive(formal,previous);data.update(script_sha256=sha(__file__),current_audit_sha256=sha(audit),reference_pin_sha256=sha(pinpath),references=pin,current_identity=formal['identities'])
 output.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n');md.write_text(markdown(data));print(json.dumps({'accepted':True,'cells':len(data['fresh_paired']),'adverse_metrics':len(data['all_adverse_metrics']),'output':str(output)}))
if __name__=='__main__':main()
