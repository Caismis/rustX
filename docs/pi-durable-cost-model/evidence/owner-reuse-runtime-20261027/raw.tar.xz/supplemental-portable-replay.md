# Separate post-hoc portable verification

The original `pack-evidence.py` and `verify-archive.py` remain unchanged. Their full-root inventory naturally retains the 14 supplemental products, the supplemental strict audit and the scripts below. The original 120 formal products, 12 diagnostics and later 14 products are not pooled.

After pack finishes and the original verifier accepts its fresh extraction, run:

```sh
python3 /home/capi/.cache/rustx-pr485-owner-reuse/verify-live-large-regression.py \
  --evidence /home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/evidence/owner-reuse-runtime-20261027 \
  --work-dir /home/capi/.cache/rustx-pr485-owner-reuse-portable-verification
```

The extension validates the base accepted receipt, external summary/archive hashes, archived verifier identity and the full extracted manifest inventory. It then runs only:

```sh
python3 audit-live-large-regression.py --root . --raw-only \
  --formal-audit ../direct-raw-audit.json \
  --output ../live-large-regression-raw-audit.json
```

The newly computed formal report must match the base receipt hash. Supplemental raw and strict reports must match completely except explicit raw-only mode, timestamp, and fresh formal path/hash/mode. The original adverse five-pair cell, all 14 products, seven comparisons, 672 checked request correspondences, missing metrics and unfavorable samples remain equal. Full raw inventory and byte hashes are checked again afterward. Outputs/logs stay outside extracted `raw/`; actual host source/binary verification remains false.

Only an actual successful invocation produces the accepted `supplemental-portable-verification.json` sidecar. Development used one equal synthetic report and seven deliberately changed synthetic reports plus AST/help checks, recorded separately in `supplemental-verifier-tool-validation.json`. No measured archive/replay/product was executed during script preparation.
