# Publication immutable metadata owner review

记录时间：2026-10-27。本轮工作树基底为 `f2231b21391e8a7d6ca8fc40ea43b65f9f9bffe8`。下述引用针对当前冻结工作树，尚非新的已验证提交。文件路径相对于 rustX 根目录。本文只说明源码行为和待验证回归，**不代表测试已通过，也不宣称实际 CPU 或整体耗时收益**。

## 目标与实际调用链

上一轮 CPU 栈中 PublicationDraft 的 metadata 长度检查仍进入 ContentBinding 与 CollectionFrontier 的 schema-aware visitor。本轮把长度与 admission charge 绑定到确切的不可变值，而非按 revision 猜测可复用。

1. 原生 canonical head 安装时，`RuntimeClientProjection.head_bindings` 现在持有 `PreparedBindingHead`（`src/runtime_client/projection.rs:264`；写入入口约 `:3417`、`:5707`、`:6804`）。它拥有原始有限 ContentBinding 数组，clone 只共享 Arc。
2. transcript evidence 在 bootstrap（`:2599`）、descriptor 初始化（`:6825`）、hydrate seed（`:854`）与 read-domain 安装（`:7617`）同步建立或替换 owner。read-domain 更新保留原来的 transcript 值比较，并在此真实更新入口比较 evidence；**普通 delta 不为这套缓存比较整个 evidence 页**。
3. `capture_working_seed`（`:6660`）共享 canonical/transcript evidence owner，并继承上一有限集合 owner 表。既有 snapshot freeze 仍保留，未改为所有域零复制。
4. `CheckpointSeed::capture_checkpoint`（`:894`）保留原 domain capture 次序及共享入场预算；prepared Capture 的 `content` 已改为共享 fragment，重放时 clone Arc（`src/runtime_client/checkpoint.rs:636`、`:669`）。transcript 原始 content 的 admission charge 也属于相应 evidence owner（`projection.rs:984`）。
5. `capture_evidence`（`:1282`）向 metadata 合并消息与 transcript 引用。`PreparedBindingHead::prefixed`（`projection/prepared_capture.rs:196`）仅在 head 的位置前缀改变时复制并补路径。相同位置直接共享结果；原先按 path 排除重复的规则保留。
6. `capture_collection_frontiers`（`projection.rs:1328`）仍逐域确定当前 revision、total、loaded、next_offset。canonical 内容引用仍经 `resolve_captured_content`（`:1629`）按该 seed 的 content metadata 解析。完成这些步骤后才选择可复用的最终集合 fragment。
7. `PublicationDraft::encode`（`:513`）继续先更新 cursor/read cut，捕获 metadata，再决定是否需要完整 checkpoint fit/replacement。已获得完整 admission certificate 的 transition，通过 `metadata_fragment::transition_length`（`checkpoint/metadata_fragment.rs:177`）组合精确长度；事件数组和变化的 read_cut 仍交给原 schema-aware serializer。

## 精确长度与 wire 合同

`MetadataFragment<T>`（`checkpoint/metadata_fragment.rs:17`）透明转发 Serialize、Deserialize、schema_name、schema_id 和 json_schema；没有 DerefMut。公开 JSON 字段、类型 schema 和排序保持原形。checkpoint/page 的原始 owned DTO 在必要处通过 `into_owned` 恢复；durable `observation.rs` 的 Capture 使用点也已完成此类型整合。

每个 fragment 的 OnceLock 保存两项独立结果（`:104`）：

- 原 safe-integer preflight 的充分 admission charge；
- 原 schema-aware encoder 得到的实际字节长度，或原编码无法通过时的失败结果。

两者不可互换。metadata 数组的预算按原 visitor 的容器与元素收费组合（`:122`），超过原单次 budget 的数组仍无 certificate。精确数组长度则使用 `[]`、元素长度及实际逗号数量（`:134`）。外层 metadata/transition 使用现有闭合 wire 字段的固定标点长度，事件数组仍由原编码器完整测量。

只有整个 transition 的 certificate 在 limit 内时才使用组合路径。不确定数值、过大/缺失 certificate 与已发生裁剪的 metadata，仍调用原完整 structural admission/length 函数；这不是旧格式兼容层，而是同一个预算算法未获充分证明时的正常分支。完整 fit 的 eviction 次序与 replacement 事件语义未改变（`checkpoint.rs:109`、`projection.rs:557`）。实际 transport JSON 编码仍需序列化最终事件；此缓存主要消除 publication 内部为预算和精确长度重复遍历不变 metadata 的成本，**并未把整条 wire 输出缓存成字节块**。

## 复用、失效与历史 cut

- 原 native evidence owner 只在真正安装新 evidence 时替换。消息的位置改变只影响 prefixed fragment，不修改原始值。
- 一个 `PreparedBindingHead` 的 Mutex 只保留最近一个位置映射。它不执行 SQL、I/O 或 observer callback；读旧 cut 如需另一位置，可以替换这个缓存，但旧事件仍持有自己的 immutable Arc，字节不变。
- `MetadataFragment<ContentBinding>::resolve`（`:77`）保留原捕获引用及最多一个已解析 alternate。相同引用共享 owner；其他新引用产生新 owner，绝不覆写已有值，也不会通过不断追加 alternate 保存任意历史。
- `MetadataFrontiers`（`prepared_capture.rs:248`）按 domain 查找，只有 domain、revision、total、loaded、next_offset 全部相等才复用。比较只涉及该固定形状，不编码或哈希整页 JSON。当前表从最终捕获结果建立；未匹配项始终新建 owner。
- 历史 checkpoint/cursor 验证、native read-cut 失效规则和 replay 预算未删减。replay 使用的 `bytes` 仍为完整事件精确长度，不是共享内存大小或 admission 上界。

## 内存边界

这不是全局 registry，也不按历史 J 增长：

- 每个当前 native binding head 拥有原始有限数组和至多一个最新 prefixed 数组；每个 content fragment 最多一个 resolved alternate；长度 cache 只存两个 `Option<usize>`，不保存另一份 encoded JSON。
- 每个 seed 的 frontier cache 最多引用上一有限 map 与本 seed 的当前有限 map，不保留 CheckpointSeed 链。head 淘汰仍由既有 canonical/transcript 头部边界控制。
- 已发布事件和历史 seed 持有的旧 fragment，仍随原 replay/read-cut 生命周期回收；本轮没有新增长期历史保留策略。
- transcript 的原始 snapshot DTO 仍保留其 content 数组，新的 evidence owner 会额外保留该有限数组及最新路径映射。因此不能声称零副本、零内存开销或全局固定字节数。内存是当前有限头部加既有保留窗口的函数，需由后续 PSS/进程测量报告实际影响。

## 仍保留的 CPU 工作

- 事件主体及变化 read_cut 的 schema-aware 校验和精确编码长度计算。
- 原始 snapshot freeze、未迁移域的 deepcopy/equality/admission，及每次 metadata 合并、去重、排序与实际 frontier 更新。
- 当前 attempt/live 数据变化时的新引用与 fragment 建立；native head 更新或位置变化时的一次前缀构造。
- canonical reference 的当前 seed 查找与引用比较。旧 alternate 不匹配时会重新构造，不把旧引用当作当前 authority。
- 不确定 schema、预算边界、强制 replacement 与实际 eviction 的完整 checkpoint 构造/fit；这些路径保留功能并不说明其代价永远不可优化。
- 最终 transport 序列化。不能把 fragment counter 为零解读为整条 publication 零计算，也不能由采样份额直接推算速度收益。

## 待验证差分和 work-count 回归

新增精确叶名：

1. `immutable_metadata_fragments_preserve_schema_wire_and_exact_budget_boundaries`：wrapper/base schema 与编码字节，空/单/多元素、source_path 省略、转义字符、cursor 位数增长、实际长度及 admission 两侧。
2. `immutable_metadata_fragments_preserve_invalid_and_oversized_admission`：受限 u64 边界/非法值与巨大 path，组合路径和原 encoder 的成功/失败一致。
3. `immutable_metadata_resolution_keeps_old_owner_and_measures_each_value_once`：引用更新、重复命中、非法新引用，原 owner 和旧 alternate 字节不变。
4. `prepared_capture_reuses_metadata_value_and_exact_length_without_deep_copy`：实际 Capture 重放共享 owner，32 次重放只测量一个值。
5. `metadata_frontier_owners_reuse_only_identical_fixed_fields`：五个 frontier 字段分别变化必须换 owner，原值不变。
6. `native_metadata_heads_reuse_fragments_across_publication_and_keep_old_paths`：publication 真实调用链中两次 native evidence 发布的复用计数、replay 精确长度、旧事件字节、位置变化后的独立前缀 oracle。

原 `assembled_publication_budget_is_conservative_at_all_admission_boundaries` 增加了组合长度与完整原编码器的差分，包括强制 replacement。原 metadata ownership、incremental checkpoint、历史 cut、压力裁剪及 opaque JSON/number 相关回归继续由统一队列执行，不降低原预期。

## 当前验证状态

- 已定向格式化并检查 diff 空白。
- native_snapshot_share 已独立只读复核新 fragment/owner 代码，未报告阻断。
- 初轮统一编译发现 durable `observation.rs` 的 Capture 类型调用点遗漏；已完成 5 处 push 包装、3 处 owned DTO 转换和 1 处 immutable resolve 修正。
- 根代理正在统一构建/测试。本文没有自行运行 cargo、产品或基准；所有新测试仍须以最终统一队列结果为准。
- 本轮 Pi/DeepSeek 不重新测量，publication 实测判断应来自新 rustX 对照与诊断，不能把上一轮其他引擎数据重标为本轮新跑结果。
