#!/usr/bin/env python3
"""Independently audit the separate post-hoc live/large Rust-only supplement.

This does not execute products, change the original 120-product dataset, pool
samples, or convert a favorable follow-up into a parity/no-regression claim.
"""
import argparse
import collections
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
DIRECT_SHA = '76798955886f8f4a7966f444332c6be75f9fe29fd070dcb47cbdc410a286b8fd'
MATH_SHA = 'e2879454bd2c6ed1add046dd55d6ceaa3c7451087ee92e6e008afcbf7a7e1ac3'
NAME = 'live-large-regression-check'
CASE, MODE, PAIRS = 'short-large', 'live-subscriber', 7
PURPOSE = 'Independent follow-up to the adverse initial live/large median; not pooled with formal samples'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def module(name, path, digest):
    require(sha(path) == digest, 'frozen independent primitive changed: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def instant(value):
    parsed = datetime.datetime.fromisoformat(value)
    require(parsed.tzinfo is not None and parsed.utcoffset() == datetime.timedelta(0), 'timestamp must be UTC')
    return parsed


def validate_command(record, before, after, original_plan, runner_sha, diagnostic_end):
    expected = ['benchmarks/runtime/compare-revisions.py', '--before', before['binary'],
                '--after', after['binary'], '--output', str(Path(after['binary']).parent.parent / NAME),
                '--pairs', '7', '--observer-mode', MODE, '--case', CASE]
    require(Path(record['command'][0]).name.startswith('python') and record['command'][1:] == expected,
            'supplement command/case/mode/pair count differs')
    require(record['purpose'] == PURPOSE and record['status'] == 'complete' and record['exit'] == 0,
            'supplement incomplete or lacks explicit post-hoc scope')
    require(record['runner_sha256'] == runner_sha and record['binary_sha256'] ==
            {name: build['sha256'] for name, build in [('before', before), ('after', after)]},
            'supplement producer/binary identity differs')
    require(record['source_before'] == record['source_after'], 'supplement source changed')
    initial = original_plan['source_before']
    require(initial['source_files'] == after['source_files'], 'formal/candidate source differs')
    require(all(name not in initial['fixtures'] or initial['fixtures'][name] == digest
                for name, digest in after['source_files'].items()), 'source/fixture hashes conflict')
    expected_source = {'head': after['head'], 'source_files': {**after['source_files'], **initial['fixtures']}}
    require(record['source_before'] == expected_source, 'supplement full source/fixture identity differs')
    start, end = instant(record['start_utc']), instant(record['end_utc'])
    require(start < end and instant(original_plan['source_after']['utc']) <= start
            and instant(diagnostic_end) <= start, 'supplement overlaps or precedes original products')
    return {'start_utc': record['start_utc'], 'end_utc': record['end_utc'],
            'source_unchanged': True, 'formal_and_diagnostic_precede_supplement': True}


def validate_manifest(manifest, before, after):
    require(manifest['cases'] == [CASE] and manifest['pairs'] == PAIRS
            and manifest['pair_offset'] == 0 and manifest['observer_mode'] == MODE
            and type(manifest['clock_ticks']) is int and manifest['clock_ticks'] == 100,
            'supplement matrix/clock differs')
    require(manifest['head'] == after['head'] and manifest['comparison_kind'] == 'production-revision',
            'supplement source/comparison kind differs')
    require(manifest['executables'] == {name: {'path': build['binary'], 'sha256': build['sha256']}
            for name, build in [('before', before), ('after', after)]}, 'supplement executable differs')


def distribution(values):
    valid = [value for value in values if value is not None]
    return {'values': values, 'n': len(values), 'available': len(valid),
            'median': statistics.median(valid) if valid else None,
            'minimum': min(valid) if valid else None, 'maximum': max(valid) if valid else None,
            'interval': None, 'scope': 'Separate post-hoc sample; descriptive values only, no pooled or parity estimate.'}


def metric_groups(products, math):
    indexed = {(row['pair'], row['engine']): row for row in products}
    require(len(products) == len(indexed) == 14 and set(indexed) ==
            {(pair, engine) for pair in range(PAIRS) for engine in ('before', 'after')},
            'supplement product inventory differs')
    names = set(products[0]['metrics'])
    require(names and all(set(row['metrics']) == names for row in products), 'metric inventory differs')
    groups, adverse, missing = [], [], []
    for metric in sorted(names):
        rows = []
        for pair in range(PAIRS):
            a, b = (indexed[pair, engine]['metrics'][metric] for engine in ('after', 'before'))
            ratio, reason = math.paired_ratio(a, b)
            row = {'pair': pair, 'numerator': a, 'denominator': b, 'ratio': ratio,
                   'ratio_unavailable_reason': reason, 'percent_change': None if ratio is None else 100 * (ratio - 1),
                   'difference': None if a is None or b is None else a - b}
            rows.append(row)
            if row['percent_change'] is not None and row['percent_change'] > 0:
                adverse.append({'metric': metric, **row})
            if ratio is None:
                missing.append({'metric': metric, **row})
        groups.append({'metric': metric, 'pairs': rows,
                       'numerator_values': distribution([r['numerator'] for r in rows]),
                       'denominator_values': distribution([r['denominator'] for r in rows]),
                       'ratios': distribution([r['ratio'] for r in rows]),
                       'percent_change': distribution([r['percent_change'] for r in rows]),
                       'adverse_pairs': sum(r['percent_change'] is not None and r['percent_change'] > 0 for r in rows)})
    return groups, adverse, missing


def dataset(root, direct, before, after):
    directory = root / NAME
    manifest = load(directory / 'manifest.json')
    validate_manifest(manifest, before, after)
    stems = {f'{pair}-{CASE}-{engine}' for pair in range(PAIRS) for engine in ('before', 'after')}
    require({p.name[:-13] for p in directory.glob('*.process.json')} == stems, 'missing/extra process records')
    require({p.stem for engine in ('before', 'after') for p in directory.glob(f'*-{engine}.json')} == stems,
            'missing/extra raw products')
    require({p.name for p in directory.glob('*-comparison.json')} ==
            {f'{pair}-{CASE}-comparison.json' for pair in range(PAIRS)}
            and not list(directory.glob('*-comparison-error.log')), 'missing/extra/failed comparisons')
    order = [(pair, engine) for pair in range(PAIRS)
             for engine in (('before', 'after') if pair % 2 == 0 else ('after', 'before'))]
    stdout = root / (NAME + '.stdout')
    require((root / (NAME + '.stderr')).is_file(), 'missing supplement stderr')
    logged = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
    require(len(logged) == len(order), 'supplement execution log count differs')
    for row, (pair, engine) in zip(logged, order):
        proc = load(directory / f'{pair}-{CASE}-{engine}.process.json')
        require(row['case'] == CASE and row['observer_mode'] == MODE and row['accepted'] is True
                and row['argv'] == proc['argv'] and all(key in proc and value == proc[key] for key, value in row.items()),
                'supplement logged order/admission/argv differs')
    products, comparisons = [], []
    for pair in range(PAIRS):
        for engine in ('before', 'after'):
            path = directory / f'{pair}-{CASE}-{engine}.json'
            process = path.with_name(path.stem + '.process.json')
            raw, proc = load(path), load(process)
            require(raw['schema'] == (80 if engine == 'before' else 81), 'actual supplement schema differs')
            derived = direct.derived_product(raw, proc, CASE, MODE, engine, manifest)
            products.append({'file': path.relative_to(root).as_posix(), 'raw_sha256': sha(path),
                             'process_sha256': sha(process), 'case': CASE, 'mode': MODE,
                             'pair': pair, 'engine': engine, **derived})
        path = directory / f'{pair}-{CASE}-comparison.json'
        comparisons.append({'file': path.relative_to(root).as_posix(), 'sha256': sha(path),
                            'requests': direct.comparison(path, CASE, MODE, True)})
    groups, adverse, missing = metric_groups(products, direct.MATH)
    require(sum(row['requests'] for row in comparisons) == 672, 'supplement request coverage differs')
    return {'derived_products': 14, 'valid_comparisons': 7, 'checked_requests': 672,
            'product_provider_requests': 1344, 'products': products, 'comparisons': comparisons,
            'manifest_sha256': sha(directory / 'manifest.json'),
            'stdout_sha256': sha(stdout), 'stderr_sha256': sha(root / (NAME + '.stderr')),
            'execution_order': [{'pair': pair, 'engine': engine} for pair, engine in order],
            'groups': groups, 'all_adverse_pairs': adverse, 'all_unavailable_ratios': missing}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--raw-only', action='store_true')
    parser.add_argument('--formal-audit', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'retain previous audit attempt; choose another output')
    args.formal_audit = args.formal_audit or args.root / 'direct-audit.json'
    report = {'accepted': False, 'errors': [], 'mode': 'raw-only' if args.raw_only else 'strict',
              'raw_only': args.raw_only, 'strict_identity_verified': False,
              'script_sha256': sha(__file__), 'independent_primitives': {'direct-audit.py': DIRECT_SHA, 'recompute-pi.py': MATH_SHA},
              'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Post-hoc short-large/live supplement: 14 new Rust products, separate from original 120; zero new Pi/DeepSeek products. No pooling, parity claim, or automatic dismissal of the original regression.'}
    try:
        direct = module('supplement_direct', args.root / 'direct-audit.py', DIRECT_SHA)
        direct.MATH = module('supplement_math', args.root / 'recompute-pi.py', MATH_SHA)
        before, after = (load(args.root / folder / 'identity.json') for folder in ('baseline-build', 'candidate-complete-build'))
        report['identities'] = direct.identity_and_plan(args, before, after)
        report['premeasurement'] = direct.premeasurement_binding(args, before, after)
        formal, original = load(args.formal_audit), load(args.root / 'direct-audit.json')
        for row in (formal, original):
            require(row['accepted'] is True and row['errors'] == [] and row['script_sha256'] == DIRECT_SHA
                    and row['identities'] == report['identities'] and row['datasets']['direct']['derived_products'] == 120,
                    'bound original formal report differs')
        require(original['mode'] == 'strict' and original['strict_identity_verified'] is True,
                'original strict admission missing')
        require(formal['mode'] == ('raw-only' if args.raw_only else 'strict')
                and formal['datasets'] == original['datasets'] and formal['validation']['successful_complete_queues'] ==
                original['validation']['successful_complete_queues'], 'fresh formal mode/data/check binding differs')
        report['formal_audit'] = {'file': str(args.formal_audit), 'sha256': sha(args.formal_audit), 'mode': formal['mode']}
        report['original_formal_sha256'] = sha(args.root / 'direct-audit.json')
        report['initial_adverse_cell'] = [g for g in original['datasets']['direct']['groups'] if g['case'] == CASE and g['mode'] == MODE]
        record = load(args.root / 'live-large-regression-command.json')
        plan = load(args.root / 'direct-cohorts/commands.json')
        require(record['cwd'] == str(args.repo), 'supplement original working directory differs')
        report['command_binding'] = validate_command(record, before, after, plan,
            sha(args.root / 'run-live-large-regression-check.py'), load(args.root / 'diagnostic-source-after.json')['utc'])
        require(instant(original['created_utc']) <= instant(record['start_utc']), 'supplement predates original adverse audit')
        if not args.raw_only:
            require(all(sha(args.repo / name) == digest for name, digest in record['source_before']['source_files'].items()),
                    'current supplement source/fixture bytes changed')
        report['command_sha256'] = sha(args.root / 'live-large-regression-command.json')
        report['producer_sha256'] = record['runner_sha256']
        report['dataset'] = dataset(args.root, direct, before, after)
        report['accepted'] = True
        report['strict_identity_verified'] = not args.raw_only
    except Exception as error:
        report['errors'].append(f'{type(error).__name__}: {error}')
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'accepted': report['accepted'], 'errors': report['errors'], 'output': str(args.output)}))
    return int(not report['accepted'])


if __name__ == '__main__':
    raise SystemExit(main())
