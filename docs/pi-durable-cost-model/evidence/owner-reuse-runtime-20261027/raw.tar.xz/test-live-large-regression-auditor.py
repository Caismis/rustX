#!/usr/bin/env python3
"""Small synthetic parser tests; no product, profiler, build or formal audit."""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import types
import unittest

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('supplement', ROOT / 'audit-live-large-regression.py')
A = importlib.util.module_from_spec(spec)
spec.loader.exec_module(A)


class SupplementTests(unittest.TestCase):
    def setUp(self):
        self.before = {'binary': '/old/conformance', 'sha256': 'a' * 64}
        self.after = {'binary': '/original/evidence/candidate-complete-build/conformance', 'sha256': 'b' * 64,
                      'head': 'candidate', 'source_files': {'src/a.rs': 'c' * 64}}
        self.plan = {'source_before': {'source_files': self.after['source_files'], 'fixtures': {'benchmarks/runtime/a.py': 'd' * 64}},
                     'source_after': {'utc': '2026-10-27T00:00:00+00:00'}}
        self.record = {'purpose': A.PURPOSE, 'status': 'complete', 'exit': 0, 'runner_sha256': 'e' * 64,
            'binary_sha256': {'before': self.before['sha256'], 'after': self.after['sha256']},
            'command': ['python3', 'benchmarks/runtime/compare-revisions.py', '--before', self.before['binary'],
                        '--after', self.after['binary'], '--output', '/original/evidence/' + A.NAME,
                        '--pairs', '7', '--observer-mode', A.MODE, '--case', A.CASE],
            'source_before': {'head': self.after['head'], 'source_files': {**self.after['source_files'], **self.plan['source_before']['fixtures']}},
            'start_utc': '2026-10-27T02:00:00+00:00', 'end_utc': '2026-10-27T03:00:00+00:00'}
        self.record['source_after'] = copy.deepcopy(self.record['source_before'])
        self.manifest = {'cases': [A.CASE], 'pairs': 7, 'pair_offset': 0, 'observer_mode': A.MODE,
                         'clock_ticks': 100, 'head': self.after['head'], 'comparison_kind': 'production-revision',
                         'executables': {name: {'path': build['binary'], 'sha256': build['sha256']}
                                         for name, build in [('before', self.before), ('after', self.after)]}}

    def command(self, record):
        return A.validate_command(record, self.before, self.after, self.plan, 'e' * 64, '2026-10-27T01:00:00+00:00')

    def test_command_source_scope_binary_and_disjoint_windows(self):
        self.command(self.record)
        for change in [lambda r: r['command'].__setitem__(-1, 'short-small'), lambda r: r.update(exit=1),
                       lambda r: r.update(purpose='pooled'), lambda r: r['source_after']['source_files'].update(extra='changed'),
                       lambda r: r['binary_sha256'].update(after='0' * 64),
                       lambda r: r.update(start_utc='2026-10-27T00:00:00+00:00'),
                       lambda r: r.update(end_utc='2026-10-27T01:00:00+00:00')]:
            bad = copy.deepcopy(self.record); change(bad)
            with self.assertRaises(ValueError): self.command(bad)

    def test_manifest_exact_inventory_and_identity(self):
        A.validate_manifest(self.manifest, self.before, self.after)
        for field, value in [('pairs', 5), ('pair_offset', 1), ('cases', ['short-small']),
                             ('observer_mode', 'no-live-subscriber'), ('clock_ticks', 100.0), ('head', 'other')]:
            bad = copy.deepcopy(self.manifest); bad[field] = value
            with self.assertRaises(ValueError): A.validate_manifest(bad, self.before, self.after)

    def test_all_pairs_adverse_and_missing_values_are_retained(self):
        math = types.SimpleNamespace(paired_ratio=lambda a, b: (None, 'missing') if a is None or b in (None, 0) else (a / b, None))
        products = [{'pair': pair, 'engine': engine, 'metrics': {'wall': 10 if engine == 'before' else pair + 6,
                                                               'missing': None, 'zero': 0}}
                    for pair in range(7) for engine in ('before', 'after')]
        groups, adverse, missing = A.metric_groups(products, math)
        self.assertEqual(len(groups), 3)
        self.assertEqual([r['pair'] for r in adverse], [5, 6])
        self.assertEqual(len(missing), 14)
        self.assertEqual(next(r for r in groups if r['metric'] == 'wall')['percent_change']['median'], -9.999999999999998)
        with self.assertRaises(ValueError): A.metric_groups(products[:-1], math)
        with self.assertRaises(ValueError): A.metric_groups(products[:-1] + [products[0]], math)

    def test_complete_structural_dataset_and_rejected_order_or_missing_raw(self):
        math = types.SimpleNamespace(paired_ratio=lambda a, b: (a / b, None))
        direct = types.SimpleNamespace(MATH=math,
            derived_product=lambda *args: {'metrics': {'wall': 1}, 'arithmetic': {}},
            comparison=lambda *args: 96)
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); directory = root / A.NAME; directory.mkdir()
            (directory / 'manifest.json').write_text(json.dumps(self.manifest))
            logged = []
            for pair in range(7):
                for engine in (('before', 'after') if pair % 2 == 0 else ('after', 'before')):
                    raw = directory / f'{pair}-{A.CASE}-{engine}.json'
                    raw.write_text(json.dumps({'schema': 80 if engine == 'before' else 81}))
                    proc = {'argv': [engine, str(pair)], 'case': A.CASE, 'observer_mode': A.MODE, 'accepted': True}
                    raw.with_name(raw.stem + '.process.json').write_text(json.dumps(proc)); logged.append(proc)
                (directory / f'{pair}-{A.CASE}-comparison.json').write_text('{}')
            stdout = root / (A.NAME + '.stdout')
            stdout.write_text('\n'.join(map(json.dumps, logged)))
            (root / (A.NAME + '.stderr')).write_text('')
            report = A.dataset(root, direct, self.before, self.after)
            self.assertEqual((report['derived_products'], report['valid_comparisons'], report['checked_requests']), (14, 7, 672))
            logged[0], logged[1] = logged[1], logged[0]
            stdout.write_text('\n'.join(map(json.dumps, logged)))
            with self.assertRaises(ValueError): A.dataset(root, direct, self.before, self.after)
            (directory / f'0-{A.CASE}-after.json').unlink()
            with self.assertRaises(ValueError): A.dataset(root, direct, self.before, self.after)


if __name__ == '__main__':
    unittest.main()
