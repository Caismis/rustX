# Completed native response reuse: dependency and invalidation proof

Implementation at `src/durable/sqlite/observation_response.rs`, `observation_response/cache.rs`, `observation_execution.rs`; connection dispatch is the existing single preupdate hook in `manifest.rs`. This note describes source behavior, not a measured performance claim. The parent runs compilation/tests/benchmarks separately.

## Admission and storage bound

- A certificate is made only after the original native read path succeeds in an actual SQLite **main Read** transaction. Write transactions never consume or admit cross-refresh entries. Read-only rollback does not destroy a valid committed snapshot certificate; preupdate invalidates relevant writes, even if those writes later roll back.
- New certificates require the requested J, Ledger frontier and native T to equal the pinned snapshot's current frontiers. An old-cut read after newer events therefore cannot certify absence of those newer events.
- Eligible results are completed/non-running native process owners read through the local typed member path, or a native Ledger-authorized row whose original header role is user and whose response source lookup returns none. Pending-only rows lacking a Ledger owner cannot qualify as user seats. Delegated terminal-only/inherited process readers do not expose their native-terminal dependency facts and therefore do not enter this cache; their complete existing reads remain unchanged. Every consulted selected execution summary must also be terminal.
- Keys include the exact selection kind/cursor/identity/locator. Forward reuse requires same conversation/inherited boundary and nondecreasing J/L/T/Surface coordinates. Pending mutation epochs are deliberately not owner dependencies: no pending body/count is cached. The public native cut validator remains mandatory and still rejects stale pending cuts.
- At most 32 entries. Each item must pass a conservative 16 KiB private admission walk; selection <=512 conservative encoded bytes (ordinary ID <=256 bytes), conversation ID <=512 bytes. Private admission rejection only skips caching and cannot reject otherwise valid public output. Epoch saturation permanently disables reuse.

## Reads retained at each call

1. Original native cut/canonical provenance validation, selection bounds, and current-J prefix member-hole check.
2. Pinned `main.data_version`, main/temp schema cookies. A version/epoch change clears entries; any schema cookie differing from installation disables reuse for that connection (also prevents TEMP shadow/obsolete column-ordinal proofs).
3. On a cached execution-dependent item, the original selected layout's exact owner-anchor-to-current-J execution-hole check. The earliest verified interval is shared only within the current page; a later unrelated execution hole still rejects a cached historical owner. A hole before the selected anchor is not incorrectly promoted to a global failure.
4. Original current-cut statistics. Checkpoint occupancy, trace total, and projection reads preserve their original order after response decoration.

## Same-connection preupdate dependencies

The cache tracks upper frontiers of the actual bounded page's native dependency reads, not the full current J for ordinary responses. Frontiers can conservatively include previous cold items in the same <=32-row page; the per-item execution-hole anchor is kept separate. Fields referring to another native event/row extend the tracked frontier. Local execution/member/response maps retain these dependencies when they avoid repeated SQL in the current transaction.

| Native source | Invalidation condition (old and new values for UPDATE) | Why ordinary append survives |
|---|---|---|
| events | sequence, execution owner anchor or member anchor <= tracked J; assistant Ledger <= tracked L; observation T <= tracked T; accessor/type failure invalidates | A new event and all of its owners/relationships are strictly beyond the old completed-owner frontiers. Trigger rewrites of old rows or new rows pointing at old owners invalidate. |
| message_ledger | position <= tracked L or native T <= tracked T | New canonical rows and T positions are beyond retained owners. A new position reusing an old T is caught. |
| observation_headers | Ledger <= tracked L or T <= tracked T | New ordinary header rows do not overlap. Header JSON/role/retry identity changes on an old owner are caught regardless of which cell changed. |
| canonical_tool_calls | proposal observation Ledger or result Ledger <= tracked L | Both existing-alias changes and new aliases targeting an old cached seat invalidate, including ordinary user and assistant seats. |
| request_snapshots | started_sequence <= tracked J | Completed owner retry/native request checks retain their request start dependency; a new request start is beyond it. |
| transcript_order | position <= tracked T | Old transcript authority changes invalidate; new positions do not. |
| inherited_* tables | every mutation | These are initialized frozen provenance; their relation/identity validation is retained on initial reads. |
| content_frontiers | every mutation while a cached item consulted optional response identity fields | Conservative invalidation for deferred identity descriptors. Ordinary cached responses have no content-frontier dependency. This is intentionally not claimed as maximal reuse for deferred identities. |

The existing hook dispatches independently to append validation, response reuse and native manifest owners. The response cache does not infer native owner authority from display DTOs, roles alone, hash equality, or a prepared statement.

## External writes, recovery, and errors

- `main.data_version` is sampled after native reads have pinned the snapshot, matching the existing manifest discipline. An external commit cannot leak into the current snapshot and invalidates at the next snapshot. All external writes conservatively invalidate, including unrelated ones.
- No cache is persisted or shared across independently opened connections. A presentation reader sharing the connection owner shares its proof owner. Reopen starts empty.
- Main/temp DDL invalidates and disables reuse; no compatibility schema, migration or replacement authority was added.
- Cache misses follow the original native algorithm. Errors in the current cut, holes, source reads or statistics propagate. Failure tests compare hot reads with forced-cold reads, including exact error discriminant/text when malformed SQL is outside the older name-based test oracle's authority.

## Targeted regression coverage (authored, execution owned by parent)

Four work/boundary tests cover eight completed owners across new J **and pending adoption epochs**, zero repeated execution/member decodes, zero original native-owner SELECTs on hit, one retained execution-hole SELECT, authenticated user seats, fixed 32-entry capacity, missing native authority no admission from a successful provisional write-transaction read, and unchanged terminal-only output without uncertified reuse.

Six additional tests supplied by the parent cover same-connection execution/member/header/native-T/append-revision changes and rollback; external writes/restoration/reopen; new unrelated execution/member holes and old cuts; new event member aliases to an old owner; tool result aliases distinct from process ownership; inherited corruption and TEMP DDL. Existing cold-map count tests still force a cold cache to retain their original one-owner and 32-owner decode assertions. Existing checkpoint snapshot-concurrency tests remain in scope.

Limits: this is not a universal query-result cache. Running or delegated terminal-only/inherited owners, historical snapshots first read after later native growth, oversized private entries, changed schemas, and externally modified connections use native reads. The four bounded snapshot/version SQL operations and current-prefix/statistics reads remain. No measured speedup, eliminated total SQL count, or equivalence beyond the tested/source-defined contract is asserted here.
