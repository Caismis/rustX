from pathlib import Path
root=Path('/workspace/rustX-pi-durable');out=Path(__file__).resolve().parent/'candidate'
p=(root/'src/runtime_client/projection.rs').read_text()
p=p.replace('    read_domains_dirty: bool,','    read_domains_dirty: bool,\n    /// One explicit checkpoint demand, coalesced until its bounded read completes.\n    read_domains_requested: bool,',1)
pos=p.index('            read_domains_dirty:')
end=p.index('\n',pos)
p=p[:end]+ '\n            read_domains_requested: false,'+p[end:]
p=p.replace('    pub(crate) fn read_domain_candidate(&self) -> Option<ReadDomainCut> {\n        self.read_domain_cut()\n    }','''    pub(crate) fn read_domain_candidate(&self) -> Option<ReadDomainCut> {
        if self.subscribers.is_empty() && !self.read_domains_requested {
            return None;
        }
        self.read_domain_cut()
    }

    /// Request hydration for an explicit checkpoint even without subscribers.
    /// The worker still owns physical reads and their publication fence.
    pub(crate) fn request_read_domains(&mut self) -> Option<(ReadDomainCut, bool)> {
        if self.exhausted
            || (!self.read_domains_dirty && self.read_failure.is_none())
            || self.validate_source_prefix().is_err()
        {
            return None;
        }
        let newly_requested = !self.read_domains_requested;
        self.read_domains_requested = true;
        self.read_domains_dirty = true;
        self.read_domain_cut().map(|cut| (cut, newly_requested))
    }''',1)
# Test-only explicit requests continue to exercise the production worker.
p=p.replace('    pub(crate) fn request_read_domains_for_test(&mut self) {\n        self.read_domains_dirty = true;','    pub(crate) fn request_read_domains_for_test(&mut self) {\n        self.read_domains_requested = true;\n        self.read_domains_dirty = true;',1)
# Existing failure-only helper is now test-only: all production checkpoints use demand.
p=p.replace('    pub(crate) fn request_failed_read_repair(&mut self)', '    #[cfg(test)]\n    pub(crate) fn request_failed_read_repair(&mut self)',1)
p=p.replace('        let newly_requested = !self.read_domains_dirty;\n        self.read_domains_dirty = true;', '        let newly_requested = !self.read_domains_dirty;\n        self.read_domains_requested = true;\n        self.read_domains_dirty = true;',1)
needle='''        let ReadDomainValues {
            projection_head,
            transcript,
            occupancy,
            mut trace,
            trace_total,
        } = match read {'''
assert needle in p
p=p.replace(needle,'        self.read_domains_requested = false;\n'+needle,1)
(out/'projection.rs').write_text(p)
h=(root/'src/runtime_client/host.rs').read_text()
h=h.replace('state.projection.request_failed_read_repair()','state.projection.request_read_domains()',1)
needle='''        drop(state);
        Ok((
            EventSubscription {'''
assert needle in h
h=h.replace(needle,'''        drop(state);
        // Registration creates display demand without doing Store I/O under
        // the attachment lock. Retained semantic replay is unchanged.
        self.pending.push(ConversationObservation::JournalSourceReady);
        Ok((
            EventSubscription {''',1)
# Settlement is an explicit test read and renews demand if a native cut advances.
needle = """        let mut turns = self.worker_turns.subscribe();
        loop {
            let worker_turn = *turns.borrow_and_update();"""
assert needle in h
h=h.replace(needle,"""        let mut turns = self.worker_turns.subscribe();
        loop {
            let requested = self.lock_published_state().projection.request_read_domains();
            if requested.is_some_and(|(_, new)| new) {
                self.pending.push(ConversationObservation::JournalSourceReady);
            }
            let worker_turn = *turns.borrow_and_update();""",1)
(out/'host.rs').write_text(h)
