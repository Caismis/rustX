from pathlib import Path
import subprocess,os,json,time,datetime
root=Path('/workspace/issue-481-evidence/pi-observed-views');repo=Path('/workspace/rustX-observed-views')
log=Path('/workspace/issue-481-evidence/pi-parity-small-nav-stage.log')
while True:
 text=log.read_text()
 if 'Source stage complete' in text:break
 if 'Traceback (most recent call last)' in text:raise SystemExit('Source stage failed; validation not started')
 time.sleep(10)
(root/'validation-start.txt').write_text(datetime.datetime.now(datetime.timezone.utc).isoformat()+'\nSource formal measurements completed before compilation.\n')
env=os.environ|{'CARGO_TARGET_DIR':'/workspace/issue-481-target','CARGO_BUILD_JOBS':'2'}
commands=[('cache-clean',['cargo','clean','--release','--package','rustx']),('test-build',['cargo','test','--release','--config','profile.release.package.rustx.opt-level=0','--locked','--offline','--lib','--no-run','--message-format=json'])]
for name,command in commands:
 with (root/(name+'.stdout')).open('w') as stdout,(root/(name+'.stderr')).open('w') as stderr:
  subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr,check=True)
rows=[json.loads(s) for s in (root/'test-build.stdout').read_text().splitlines() if s.startswith('{')]
binary=next(x['executable'] for x in rows if x.get('executable') and x.get('target',{}).get('name')=='rustx')
for test in ['display_reads_follow_observers_and_explicit_checkpoint_demand','dormant_display_preserves_serviceable_semantic_replay','dormant_display_waits_for_checkpoint_demand_and_preserves_replay','runtime_client::projection::tests::','runtime_client::host::tests::source_recovery_tests::']:
 with (root/(test.strip(':').replace('::','-')+'.log')).open('w') as out:
  result=subprocess.run([binary,test,'--test-threads=2'],cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 print(test,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
print('Observer targeted validation complete',flush=True)
