import subprocess,json,os,datetime,hashlib
from pathlib import Path
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-pi-durable');pi=Path('/workspace/pi-481')
def git(path,*args):return subprocess.check_output(['git',*args],cwd=path,text=True).strip()
assert git(pi,'rev-parse','HEAD')=='90d863f7c1183b965f099855715d6e88c7b8a52c';assert not git(pi,'status','--porcelain','--untracked-files=no')
identities={name:json.loads((root/name/'identity.json').read_text()) for name in ['compact-verified-build','origin-verified-build','pi-partial-build']}
for n,v in identities.items():
 assert v['verified'];assert hashlib.file_digest((root/n/'conformance').open('rb'),'sha256').hexdigest()==v['sha256']
 for k in ['harness','rustc','cargo','build_environment']:assert v[k]==identities['pi-partial-build'][k],(n,k)
(root/'pi-final-comparison-identity.json').write_text(json.dumps({'identities':identities,'pi_head':git(pi,'rev-parse','HEAD'),'pi_tracked_clean':True,'node':subprocess.check_output(['node','--version'],text=True).strip(),'host':subprocess.check_output(['uname','-a'],text=True).strip(),'cpu_affinity':sorted(os.sched_getaffinity(0)),'cpu_max':Path('/sys/fs/cgroup/cpu.max').read_text(),'memory_max':Path('/sys/fs/cgroup/memory.max').read_text(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
def run(label,command,json_output=False):
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,'START',flush=True)
 with (root/(label+('.json' if json_output else '.log'))).open('w') as log:r=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'UV_CACHE_DIR':'/workspace/.uv-cache'})
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),label,'EXIT',r.returncode,flush=True);r.check_returncode()
final=str(root/'pi-partial-build/conformance')
run('pi-combined-stage',['python3',str(root/'run-cost-stage.py'),'pi-combined','compact-verified-build','pi-partial-build'])
run('pi-final-pi-formal',['python3','benchmarks/runtime/controller.py','--rust',final,'--pi',str(pi),'--output',str(root/'pi-final-pi-matrix')])
run('pi-final-pi-summary',['python3','benchmarks/runtime/summarize-http.py',str(root/'pi-final-pi-matrix')],True)
run('pi-final-main-formal',['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/'origin-verified-build/conformance'),'--after',final,'--output',str(root/'pi-final-main-matrix')])
run('pi-final-main-summary',['python3','benchmarks/runtime/summarize-comparisons.py',str(root/'pi-final-main-matrix')],True)
for base,build in [('base','compact-verified-build'),('main','origin-verified-build')]:
 for mode in ['warm','cold']:
  stage='pi-final-'+base+'-'+mode
  run(stage+'-formal',['python3','benchmarks/runtime/compare-append.py','--before',str(root/build/'conformance'),'--after',final,'--output',str(root/(stage+'-matrix')),*(['--cold'] if mode=='cold' else [])])
  run(stage+'-summary',['python3','benchmarks/runtime/summarize-comparisons.py','--append',str(root/(stage+'-matrix'))],True)
