import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();rows=[];symbols=[]
bins={'previous':Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build/rustx'),'before':Path('/home/capi/.cache/rustx-pr485-idle-retention-20261103/refinement/final-build/rustx'),'after':r/'candidate-build/rustx'};base=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked');pprof=base/'usr/bin/google-pprof';cpu=base/'usr/lib/x86_64-linux-gnu/libprofiler.so.0.5.11';tc=base/'usr/lib/x86_64-linux-gnu/libtcmalloc.so.4.5.16';helper=Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/heap-sample.so');(r/'profiler-identity.json').write_text(json.dumps({k:{'path':str(p),'sha256':sha(p)} for k,p in [('pprof',pprof),('cpu',cpu),('tcmalloc',tc),('heap_helper',helper)]},indent=2)+'\n')
# These two completed diagnostics preceded changes/builds. Their original raw
# identity/profiler/phases records bind them; no controller start/end was captured.
for side in ['previous','before']:
 d=r/('profile-'+side);assert load(d/'completed.json')['accepted'];assert load(d/'identity.json')['sha256']==sha(bins[side]);rows.append({'family':'cpu','side':side,'directory':d.name,'exit':0,'actual_native_sha256':sha(bins[side]),'scope':'Completed pre-change diagnostic; raw identity/profiler/phases retained, no new controller timing reconstructed.'})
(r/'diagnostic-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
while not(r/'functional-completed.json').exists():time.sleep(2)
def run(row):
 while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(1)
 row['start_utc']=now()
 with(r/(row['directory']+'.stdout')).open('x') as so,(r/(row['directory']+'.stderr')).open('x') as se:p=subprocess.run(row['command'],cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 row.update(exit=p.returncode,end_utc=now());rows.append(row);(r/'diagnostic-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(row['directory'],p.returncode,flush=True);assert p.returncode==0 and load(r/row['directory']/'completed.json')['accepted']
run({'family':'cpu','side':'after','directory':'profile-after','actual_native_sha256':sha(bins['after']),'command':[sys.executable,str(r/'capacity-rotating.py'),'--binary',str(bins['after']),'--output',str(r/'profile-after'),'--sessions','128','--history','8','--widths','4','--rounds','128','--cpu-profiler',str(cpu)]})
def symbolize(name,bin,profile,flags,target):
 cmd=[str(pprof),*flags,'--no_strip_temp',str(bin),str(profile)]
 if not target.exists():
  with target.open('x') as so,target.with_suffix('.stderr').open('x') as se:subprocess.run(cmd,stdout=so,stderr=se,check=True)
 symbols.append({'directory':name,'command':cmd,'output':str(target.relative_to(r)),'native_sha256':sha(bin),'profile_sha256':sha(profile),'output_sha256':sha(target)});(r/'symbol-commands.json').write_text(json.dumps(symbols,indent=2)+'\n')
for side in ['previous','before','after']:
 name='profile-'+side;d=r/name;symbolize(name,bins[side],d/'active.cpu.0',['--collapsed'],d/'stacks.txt');symbolize(name,bins[side],d/'active.cpu.0',['--text','--nodecount=3000','--nodefraction=0','--edgefraction=0'],d/'flat.txt')
for side in ['before','after']:
 name='heap-'+side;d=r/name;wrapper=r/(name+'.sh');wrapper.write_text('#!/bin/sh\nexport LD_PRELOAD='+str(tc)+':'+str(helper)+'\nexport TCMALLOC_SAMPLE_PARAMETER=65536\nexport RUSTX_SAMPLE_PREFIX='+str(d/'native-sample')+'\nunset HEAPPROFILE HEAPPROFILESIGNAL\nexec '+str(bins[side])+' "$@"\n');wrapper.chmod(0o755)
 run({'family':'heap','side':side,'directory':name,'actual_native_sha256':sha(bins[side]),'wrapper_sha256':sha(wrapper),'command':[sys.executable,str(r/'sampling-capacity.py'),'--binary',str(wrapper),'--output',str(d),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16','--cache-probes']})
 for i in range(1,13):
  profile=d/f'native-sample-{i}.heap';assert profile.exists();symbolize(name,bins[side],profile,['--collapsed'],d/f'sample-{i}-collapsed.txt');symbolize(name,bins[side],profile,['--text','--cum','--nodecount=3000','--nodefraction=0','--edgefraction=0'],d/f'sample-{i}-cum.txt')
(r/'diagnostics-completed.json').write_text('{"accepted":true}\n')
