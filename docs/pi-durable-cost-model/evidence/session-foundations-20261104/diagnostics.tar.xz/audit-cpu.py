"""Reparse gperftools native CPU samples, with exact denominators and overlapping groups."""
import hashlib,json,re,struct
from pathlib import Path
r=Path(__file__).resolve().parent;rows=[]
for side in ['previous','before','after']:
 d=r/('profile-'+side);p=d/'active.cpu.0';raw=p.read_bytes();assert struct.unpack_from('<5Q',raw)==(0,3,0,4000,0);i=40;total=records=0
 while True:
  n,depth=struct.unpack_from('<2Q',raw,i);i+=16;assert depth<4096;pcs=struct.unpack_from('<'+'Q'*depth,raw,i);i+=8*depth
  if n==0 and depth==1 and pcs[0]==0:break
  assert n>0;total+=n;records+=1
 assert b'r-xp' in raw[i:];stacks=[]
 for line in(d/'stacks.txt').read_text().splitlines():
  if line.strip():s,n=line.rsplit(' ',1);stacks.append((s,int(n)))
 assert sum(n for _,n in stacks)==total;assert int(re.search(r'Total: (\d+) samples',(d/'flat.txt').read_text())[1])==total
 groups={k:sum(n for s,n in stacks if token in s) for k,token in [('sqlite','sqlite3'),('observation','runtime_client'),('serde','serde_json'),('structural_codec','structural_json'),('public_native_budget','serialize::Budget'),('checkpoint','capture_checkpoint'),('schema_compile','jsonschema'),('catalog_activity','session_activity')]}
 rows.append({'side':side,'samples':total,'records':records,'period_us':4000,'sample_cpu_ms':total*4,'raw_sha256':hashlib.sha256(raw).hexdigest(),'inclusive_groups':groups,'inclusive_percent':{k:n/total*100 for k,n in groups.items()}})
(r/'cpu-audit.json').write_text(json.dumps({'accepted':True,'profiles':rows,'scope':'Three separate native rotating-width4 diagnostic products,512 active requests each, histories8→12. Parent e1d4 is a historical ownership comparison; before is current d501; after is this production candidate. Signal profiler only in native child. Groups overlap and are not additive; finite/optimized symbolization does not prove a precise explanation of the earlier fixed64-request +4.13% cell. No diagnostic timing is pooled with ordinary products.'},indent=2)+'\n');print(json.dumps({'accepted':True,'samples':[v['samples'] for v in rows]}))
