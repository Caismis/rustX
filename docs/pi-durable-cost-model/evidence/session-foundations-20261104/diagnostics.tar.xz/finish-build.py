import hashlib,json,re,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=r/'checks-final'
while not(d/'source-after.json').exists():
 if(d/'commands.json').exists():assert all(v['exit']==0 for v in load(d/'commands.json'))
 time.sleep(2)
cmds=load(d/'commands.json');assert len(cmds)==22 and all(v['exit']==0 for v in cmds);s=load(d/'source-after.json');assert s==load(d/'source-before.json');assert all(sha(repo/p)==v for p,v in(s['files']|s['helpers']).items());counts={};duplicates=[]
for row in cmds:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in(d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    k=(row['command'][0],m[1]);assert k not in counts or counts[k]==m[2]
    if k in counts:duplicates.append(m[1])
    counts[k]=m[2]
(r/'checks-summary.json').write_text(json.dumps({'accepted':True,'commands':22,'source_inputs':len(s['files']),'helpers':s['helpers'],'tests':{k:sum(v==k for v in counts.values()) for k in ['ok','ignored']},'duplicates':duplicates},indent=2)+'\n')
owned=load(r/'owned-files.json');subprocess.run(['git','add',*owned],cwd=repo,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True);subprocess.run(['git','commit','-m','Share immutable tool schemas and provider transport; encode bounded records once'],cwd=repo,check=True)
with(r/'candidate-build.stdout').open('x') as so,(r/'candidate-build.stderr').open('x') as se:subprocess.run([sys.executable,str(r/'build.py'),'candidate',str(repo)],stdout=so,stderr=se,check=True)
b=load(r/'candidate-build/identity.json');assert b['source_files']==s['files'];assert all(sha(repo/p)==v for p,v in(s['files']|s['helpers']).items());artifacts=[json.loads(v) for v in(r/'candidate-build/build.stdout').read_text().splitlines() if v.startswith('{')];a=next(v for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['kind']==['bin'] and v.get('executable'));(r/'candidate-build/app-server-identity.json').write_text(json.dumps({'head':b['head'],'binary':str(r/'candidate-build/rustx'),'sha256':sha(r/'candidate-build/rustx'),'artifact':a},indent=2)+'\n');(r/'ready.json').write_text(json.dumps({'accepted':True,'head':b['head'],'native_sha256':sha(r/'candidate-build/rustx'),'conformance_sha256':b['sha256']},indent=2)+'\n');print('Ready',flush=True)
