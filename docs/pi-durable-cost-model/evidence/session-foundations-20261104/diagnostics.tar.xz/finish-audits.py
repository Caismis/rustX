import json,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent
while not(r/'diagnostics-completed.json').exists():time.sleep(2)
rows=[]
for script in ['prepare-bindings.py','audit-native.py','audit-requests.py','audit-cache.py','audit-functional.py','audit-source.py','audit-host.py','audit-cpu.py','audit-heap.py','summarize.py','make-tables.py','prepare-proof.py']:
 p=subprocess.run([sys.executable,str(r/script)],capture_output=True,text=True)
 (r/(script.removesuffix('.py')+'.stdout')).write_text(p.stdout);(r/(script.removesuffix('.py')+'.stderr')).write_text(p.stderr)
 rows.append({'script':script,'exit':p.returncode});(r/'audit-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(script,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.stderr)
(r/'audits-completed.json').write_text('{"accepted":true}\n')
