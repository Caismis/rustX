import json,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent
while not(r/'audits-completed.json').exists():time.sleep(2)
base=Path('/home/capi/.cache/rustx-pr485-session-foundations-publish-20261104')
commands=[[sys.executable,str(r/'pack.py')],[sys.executable,str(base/'replay.py'),'--directory',str(base),'--output',str(base/'replay-result.json')]]
for i,cmd in enumerate(commands):
 with Path(str(base)+f'-step{i}.stdout').open('x') as so,Path(str(base)+f'-step{i}.stderr').open('x') as se:p=subprocess.run(cmd,stdout=so,stderr=se)
 print(i,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(r/'publication-completed.json').write_text(json.dumps({'accepted':True,'directory':str(base)})+'\n')
