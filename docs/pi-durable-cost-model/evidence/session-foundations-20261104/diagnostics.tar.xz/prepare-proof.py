"""Verify intentionally omitted executables and current source before packaging."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

r = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
load = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
source = load(r / 'source-audit.json')
identity = load(r / 'candidate-build/identity.json')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == source['head']
for name, digest in identity['source_files'].items():
    assert sha(repo / name) == digest
    assert hashlib.sha256(subprocess.check_output(['git', 'show', source['head'] + ':' + name], cwd=repo)).hexdigest() == digest
for name, digest in source['helpers'].items():
    assert sha(repo / name) == digest
old = Path('/home/capi/.cache/rustx-pr485-idle-retention-20261103/refinement/final-build')
previous = Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build')
executables = []
for label, directory, names in [('before', old, ['rustx', 'conformance']),
                                ('after', r / 'candidate-build', ['rustx', 'conformance']),
                                ('previous-cpu-only', previous, ['rustx'])]:
    for name in names:
        p = directory / name
        executables.append({'side': label, 'path': str(p), 'sha256': sha(p), 'bytes': p.stat().st_size})
    dest = r / ('before-build-records' if label == 'before' else 'previous-build-records')
    if label != 'after':
        dest.mkdir(exist_ok=True)
        for p in directory.iterdir():
            if p.is_file() and (p.suffix in ['.json', '.stdout', '.stderr']):
                shutil.copyfile(p, dest / p.name)
for row in load(r / 'product-commands.json'):
    expected = next(v['sha256'] for v in executables if v['side'] == row['side'] and v['path'].endswith('/rustx'))
    assert load(r / row['directory'] / 'identity.json')['sha256'] == expected
for row in load(r / 'diagnostic-commands.json'):
    label = 'previous-cpu-only' if row['side'] == 'previous' else row['side']
    expected = next(v['sha256'] for v in executables if v['side'] == label and v['path'].endswith('/rustx'))
    assert row['actual_native_sha256'] == expected
libraries = [{'side': side, 'path': str(p), 'bytes': p.stat().st_size, 'sha256': sha(p)}
             for side, directory in [('before', old), ('after', r / 'candidate-build')]
             for p in [directory / 'librustx.rlib']]
wrappers = [{'path': p.name, 'sha256': sha(p)} for p in [r / 'heap-before.sh', r / 'heap-after.sh']]
for row in load(r / 'symbol-commands.json'):
    assert sha(r / row['output']) == row['output_sha256']
    assert sha(Path(row['command'][-1])) == row['profile_sha256']
    assert sha(Path(row['command'][-2])) == row['native_sha256']
for row in load(r / 'profiler-identity.json').values():
    assert sha(Path(row['path'])) == row['sha256']
pi = Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/pi-memory-audit.json')
reference = load(r / 'prior-pi-memory-reference.json')
assert sha(pi) == reference['original_audit_sha256']
assert load(pi)['points'] == reference['points']
(r / 'source.patch').write_bytes(subprocess.check_output(
    ['git', 'diff', '--binary', '71278408e7ee71c43f6eff462c69d03396a9494b', source['head'], '--', 'src', 'tests', 'Cargo.toml', 'Cargo.lock'], cwd=repo))
proof = {'accepted': True, 'source_head': source['head'], 'source_inputs': source['source_inputs'],
         'source_map_sha256': source['source_map_sha256'], 'executables': executables, 'libraries': libraries, 'wrappers': wrappers,
         'profiler_identity_sha256': sha(r / 'profiler-identity.json'),
         'heap_helper_source_sha256': sha(r / 'heap-sample.cc'),
         'prior_pi_reference_sha256': sha(r / 'prior-pi-memory-reference.json'),
         'source_patch_sha256': sha(r / 'source.patch'), 'symbol_commands': len(load(r / 'symbol-commands.json')),
         'new_pi_deepseek_products': 0,
         'scope': 'Actual source/committed bytes, preserved executable/library/helper/wrapper and symbol-input bytes checked before exclusion. Offline replay rechecks stored proof and raw arithmetic; it does not rebuild or rehash omitted binaries. No Pi/DeepSeek product was run.'}
(r / 'prearchive-proof.json').write_text(json.dumps(proof, indent=2) + '\n')
print(json.dumps({'accepted': True, 'executables': len(executables)}))
