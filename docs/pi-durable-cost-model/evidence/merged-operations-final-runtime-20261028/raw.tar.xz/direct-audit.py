#!/usr/bin/env python3
"""Read-only direct Rust revision audit; Pi/DSH are never executed."""
import argparse, collections, datetime, hashlib, importlib.util, json, math, re, statistics, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent


CASES = ['short-small', 'short-large', 'stream', 'large', 'tool', 'cancel']

RUST_TOOLS = ['read', 'write', 'edit', 'glob', 'grep', 'bash', 'todo']

PI_TOOLS = ['read', 'write', 'edit', 'bash']

JOINT_REQUIRED_TESTS = {
    'native_configuration': {
        'durable::sqlite::tests::native_request_tests::' + name for name in (
            'shared_native_configuration_reuses_exact_bytes_and_preserves_scalar_validation',
            'shared_native_configuration_changed_prompt_and_order_remain_exact_after_reopen',
            'shared_native_configuration_corruption_is_rejected_by_scalar_full_and_retry_reads',
            'shared_native_configuration_fresh_trigger_mutation_rolls_back_the_configuration_and_start',
            'shared_native_configuration_materialization_charges_full_payload_before_allocating_metadata',
            'shared_native_configuration_coherently_rehashed_invalid_types_still_fail_native_validation',
        )
    },
    'incremental_capture': {
        'runtime_client::checkpoint::incremental_capture_tests::incremental_capture_replays_the_exact_shared_budget_at_every_item_boundary',
        'runtime_client::checkpoint::incremental_capture_tests::incremental_capture_keeps_invalid_rows_and_optional_body_eviction_exact',
        'runtime_client::projection::tests::incremental_checkpoint_tests::incremental_checkpoint_reuses_unchanged_domains_without_capture_or_whole_fit',
        'runtime_client::projection::tests::incremental_checkpoint_tests::incremental_checkpoint_changed_domains_and_cursor_widths_match_original_bytes',
        'runtime_client::projection::tests::incremental_checkpoint_tests::incremental_checkpoint_budget_pressure_and_unsafe_quantities_match_original',
        'runtime_client::projection::prepared_capture::tests::incremental_checkpoint_reuse_rejects_signed_zero_nan_and_reordered_maps',
    },
    'compact_headers': {
        'durable::sqlite::observation_execution::storage::tests::compact_execution_preserves_every_field_and_rejects_missing_positions',
        'durable::sqlite::observation_execution::storage::tests::compact_execution_keeps_original_bounded_admission',
        'durable::sqlite::observation_statistics::compact_tests::compact_statistics_shared_and_inherited_round_trip_and_shape',
        'durable::sqlite::tests::compact_statistics_preserve_every_historical_cut_and_lineage_after_reopen',
    },
}

JOINT_TEST_NAMES = set().union(*JOINT_REQUIRED_TESTS.values())

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

def same(left, right):
    if left is None or right is None:
        return left is right
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(same(left[k], right[k]) for k in left)
    if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    if type(left) in (int, float) and type(right) in (int, float):
        return math.isfinite(left) and math.isfinite(right) and math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12)
    return type(left) is type(right) and left == right

class Audit:
    def __init__(self):
        self.errors = []

    def attempt(self, label, fn):
        try:
            return fn()
        except Exception as error:
            self.errors.append(f'{label}: {type(error).__name__}: {error}')
            return None

def module(name, path, digest):
    require(sha(path) == digest, f'independent auditor changed: {path}')
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

PAIRS = 5

MODES = [('no-live', 'no-live-subscriber'), ('live', 'live-subscriber')]

COMPLETE_REQUIRED_TESTS = {
    'attempt_first_turn_family_preserves_ordered_facts_old_cut_and_single_publication',
    'attempt_first_turn_callbacks_install_only_at_final_member_and_require_evidence',
    'attempt_first_turn_commits_once_with_one_authenticated_observation_family',
    'attempt_first_turn_rejects_foreign_or_nonfirst_members_without_writes',
    'attempt_first_turn_second_member_failure_rolls_back_all_admission_evidence',
    'attempt_first_turn_corrupt_member_fences_both_receipts_without_losing_native_events',
    'first_turn_admission_preserves_precancel_and_committed_observer_order',
    'first_turn_admission_failure_never_publishes_a_partial_start_or_calls_provider',
    'first_turn_admission_is_all_or_nothing_across_process_death',
    'native_preupdate_identity_uses_logical_ordinals_across_virtual_columns',
    'native_readiness_commits_all_members_once_before_waking_readers',
    'immutable_capability_owner_is_shared_across_unrelated_publications',
    'immutable_capability_owner_preserves_raw_pages_and_historical_cut_on_replacement',
    'immutable_capability_owner_keeps_schema_wire_and_snapshot_copy_independent',

    'first_publication_frame_failure_rolls_back_admission_and_all_partial_sources',
    'every_first_publication_write_rejects_foreign_generation_without_admission',
    'first_audit_failure_rolls_back_admission_and_explicit_retry_settles_once',
    'an_unpublished_request_does_not_recover_as_an_empty_stream_audit',
    'first_publication_write_killed_before_commit_leaves_no_empty_audit',
    'native_readiness_reopen_uses_committed_baseline_without_history_rows_or_writes',
    'native_readiness_source_deletion_and_rollback_share_the_connection_transaction',

    'native_request_transaction_validation_reuses_exact_typed_ownership_and_live_sequences',
    'native_request_transaction_validation_rechecks_direct_sql_bytes_and_storage_type',
    'native_request_transaction_validation_rejects_coherently_rehashed_invalid_configuration',
    'native_request_transaction_validation_refreshes_valid_changed_configuration_and_new_transactions',
    'native_request_fresh_configuration_checks_exact_bytes_without_payload_materialization',
    'final_model_settlement_reads_and_decodes_one_configuration_with_or_without_live_prefix',
    'final_model_settlement_configuration_trigger_rejects_even_coherent_corruption_and_rolls_back',
    'masks_preserve_each_native_hole_predicate_at_every_historical_cut',
    'optional_failure_updates_and_rollback_recalculate_holes_without_a_mirror',
    'unrelated_hole_history_does_not_expand_a_bounded_negative_probe',
    'changed_hole_schema_is_rejected_instead_of_silently_widening_queries',
    'primary_and_unique_keys_replace_duplicate_btrees_for_bounded_seeks',

    'geometry_only_headers_authenticate_raw_chunks_without_changing_native_history_or_old_cuts',
    'geometry_capture_preserves_eager_headers_and_raw_chunks_without_preview_mirrors',
    'range_filter_skips_preview_work_but_keeps_selected_facts',
    'compact_request_fact_contains_only_geometry_and_omits_preview_mirrors',
    'compact_request_records_reject_trailing_missing_named_and_legacy_encodings',
    'compact_request_metadata_declared_lengths_fail_before_element_allocation',
    'compact_request_metadata_exact_byte_bound_is_enforced',
    'compact_request_nodes_roots_and_templates_keep_every_native_coordinate',
    'checkpoint_head_keeps_one_wal_snapshot_across_concurrent_source_changes',
    'checkpoint_head_preserves_cut_bound_and_source_error_order',
    'checkpoint_head_keeps_projection_and_occupancy_at_the_same_historical_cut',
    'final_model_shared_family_retains_terminal_and_tool_boundaries',
    'final_model_adoption_family_keeps_assistant_when_more_than_eight_users_replace_head',
    'final_model_missing_or_corrupt_family_witness_never_restores_partial_receipts',
    'final_model_missing_pending_receipt_marks_the_entire_adoption_family_unavailable',
    'final_model_family_release_is_one_transaction_and_failure_rolls_back_every_flag',
    'model_turn_family_matches_ordered_native_members_and_keeps_assistant_before_large_adoption',
    'append_facts_materialize_each_existing_atomic_group_once',
    'append_facts_reuse_observes_changed_and_corrupt_stored_cells',
    'metadata_first_publication_skips_snapshot_copies_and_repeated_preflight',
    'assembled_publication_budget_is_conservative_at_all_admission_boundaries',
    'append_aggregate_failure_keeps_other_event_evidence_independent',
    'append_statistics_reuse_keeps_actual_cut_and_hole_checks',
    'missing_native_event_receipt_never_releases_individual_sources',
    't08_t15_t20_scalar_capture_scopes_span_io_without_changing_any_original_field_or_bytes',
    't08_t12_t19_request_shape_anchor_and_metadata_corruption_never_rebases_original_authority',
    'app_server_stdio_protocol_errors_are_records_but_framing_is_terminal',
    'native_metadata_cached_statements_keep_historical_cuts_and_readiness_errors',
    't10_t14_t19_event_witness_failure_keeps_original_terminal_and_lifecycle',
    't15_t20_journal_witness_and_statistics_use_bounded_native_evidence',
    'incremental_transcript_cut_changes_reuse_rows_and_keep_current_envelope',
    'incremental_transcript_statistics_and_deferred_rows_have_independent_admission',
    'incremental_transcript_split_capture_keeps_shared_budget_pressure_exact',
    'incremental_transcript_row_ownership_keeps_opaque_json_encoding_exact',
}

def instant(value):
    parsed = datetime.datetime.fromisoformat(value)
    require(parsed.tzinfo is not None, 'timestamp lacks timezone')
    return parsed

def finite_nonnegative(value):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0,
            f'invalid nonnegative metric {value!r}')
    return value

def source_hashes(files):
    require(isinstance(files, dict) and files and {'Cargo.toml', 'Cargo.lock'} <= files.keys(), 'missing source/Cargo hashes')
    require(all(isinstance(p, str) and not Path(p).is_absolute() and '..' not in Path(p).parts and re.fullmatch('[0-9a-f]{64}', h) for p, h in files.items()), 'malformed source hash manifest')

def counter_identity(data):
    identities = set()
    for point in data['samples'] + data['lifecycle']:
        stat = point['process']['stat']
        if stat is not None:
            tail = stat.rsplit(')', 1)[1].split()
            identities.add((int(stat.split('(', 1)[0]), int(tail[19])))
    require(len(identities) <= 1, 'PID/start-time changed across self-counter endpoints')
    for series in (data['samples'], data['lifecycle']):
        for key in ('cpu_ticks', 'write_bytes'):
            available = [v for p in series if (v := MATH.counters(p)[key]) is not None]
            require(available == sorted(available), f'{key} decreased in retained samples')

def comparison(path, case, mode, direct):
    data = load(path)
    require(data['case'] == case and data['observer_mode'] == mode and data['workload_version'] == 3 and data['model_time'] == MATH.MODEL_TIME, 'comparison fixture identity')
    rows = data['checked']
    count = {'short-small': 40, 'short-large': 96, 'tool': 2}.get(case, 1)
    require(len(rows) == count and [r['index'] for r in rows] == list(range(count)), 'comparison request coverage')
    for row in rows:
        require(row['coreSemanticEqual'] is True and row['fullSemanticRequestEqual'] is direct, 'request equivalence boundary changed')
        require(row['rustToolNames'] == RUST_TOOLS and row['piToolNames'] == (RUST_TOOLS if direct else PI_TOOLS), 'native tool roster differs')
        require((row['rustToolsSha256'] == row['piToolsSha256']) is direct, 'native schema equivalence changed')
        require(all(re.fullmatch('[0-9a-f]{64}', row[k]) for k in ('rustToolsSha256', 'piToolsSha256')), 'invalid native tool schema digest')
    return count

def observer_check(raw, engine, mode):
    live = mode == 'live-subscriber'
    turns = raw['history'] + raw['measured']
    if engine != 'pi':
        require(raw['oracle_version'] == 2 and isinstance(raw['canonical'], list) and isinstance(raw['late_snapshot'], dict), 'missing native persistence/snapshot oracle')
        observed = raw['observer_validation']
        if live:
            require(observed['oracle_version'] == 2 and observed['completed_attempts'] == turns and len(observed['explicit_settlements']) == turns, 'native subscriber settlement count')
            expected = 'cancelled' if raw['case'] == 'cancel' else 'completed'
            require(all(r['outcome']['type'] == expected for r in observed['explicit_settlements']), 'native subscriber terminal outcome')
        else:
            require(observed is None, 'unexpected live observer in no-live cohort')
    else:
        require(raw['observer_oracle_version'] == 2 and raw['observer_failure'] is None and isinstance(raw['entries'], list) and isinstance(raw['lateSnapshot'], dict), 'Pi observer/persistence oracle')
        require(len(raw['observer_explicit_run_ends']) == (turns if live else 0), 'Pi subscriber end count')
        require(all(v['valid'] is True for v in raw['observer_versions']), 'Pi observer invalid checkpoint')
    require(raw['closed_footprint'], 'missing closed footprint')
    for sample in raw['samples']:
        require(MATH.integer(sample['accepted_us']) <= sample['settled_us'], 'accepted later than settled')
        first = sample['first_consumed_publication_us']
        if live:
            # Pi records first content, not first notification; cancellation can
            # complete with explicit run_end and no consumed content timestamp.
            if first is not None:
                require(MATH.integer(first) <= sample['settled_us'], 'publication after settlement')
        else:
            require(first is None and sample.get('notification_records', 0) == 0, 'no-live cohort consumed publications')

def derived_product(raw, proc, case, mode, engine, manifest):
    result = MATH.derive(raw, proc, case, mode, engine, manifest)
    counter_identity(raw)
    observer_check(raw, engine, mode)
    provider = proc['provider_report']
    require(provider['complete'] is True and not provider['failures'] and provider['stepsMatched'] == provider['stepsSettled'] == provider['stepsTotal'] == provider['requestCount'] and provider['stepStates'] == ['settled'] * provider['requestCount'], 'provider did not finish every step')
    history, turns = raw['history'], raw['measured']
    measured = raw['samples'][history:]
    life = {p['phase']: MATH.counters(p) for p in raw['lifecycle']}
    start = MATH.counters(raw['samples'][history - 1]) if history else life['after_initialization']
    end, final = MATH.counters(measured[-1]), life['after_cleanup']
    metrics, arithmetic = result['metrics'], result['arithmetic']
    measured_write = MATH.difference(end['write_bytes'], start['write_bytes'])
    lifecycle_ticks = MATH.difference(final['cpu_ticks'], life['before_initialization']['cpu_ticks'])
    metrics.update(median_measured_turn_ms=statistics.median(p['settled_us'] for p in measured) / 1000,
                   measured_turn_write_bytes=measured_write,
                   turn_write_bytes_per_turn=MATH.scale(measured_write, turns),
                   through_cleanup_process_write_bytes=final['write_bytes'],
                   lifecycle_self_cpu_ms=None if lifecycle_ticks is None else lifecycle_ticks * 10,
                   measured_turn_cpu_ms=None if arithmetic['start_cpu_ticks'] is None or arithmetic['end_cpu_ticks'] is None else (arithmetic['end_cpu_ticks'] - arithmetic['start_cpu_ticks']) * 10)
    rss = [MATH.counters(p)['Rss'] for p in measured]
    metrics['max_sampled_turn_rss_mib'] = None if any(v is None for v in rss) else max(rss) / 1024
    for name in ('product_startup_ns', 'provider_startup_ns', 'through_product_exit_ns', 'provider_teardown_ns', 'complete_lifecycle_ns'):
        finite_nonnegative(proc[name])
    require(proc['through_product_exit_ns'] <= proc['complete_lifecycle_ns'], 'process exit after complete lifecycle')
    metrics['through_product_exit_wall_ms'] = proc['through_product_exit_ns'] / 1e6
    metrics['complete_harness_lifecycle_wall_ms'] = proc['complete_lifecycle_ns'] / 1e6
    metrics['closed_logical_bytes'] = sum(MATH.integer(row['logical']) for row in raw['closed_footprint'])
    metrics['closed_allocated_bytes'] = sum(MATH.integer(row['allocated']) for row in raw['closed_footprint'])
    arithmetic.update(start_write_bytes=start['write_bytes'], end_write_bytes=end['write_bytes'], lifecycle_start_cpu_ticks=life['before_initialization']['cpu_ticks'], warm_history_turns=history, raw_process_times_ns={name: proc[name] for name in ('product_startup_ns', 'provider_startup_ns', 'through_product_exit_ns', 'provider_teardown_ns', 'complete_lifecycle_ns')})
    require(all(v is None or (type(v) in (int, float) and math.isfinite(v) and v >= 0) for v in metrics.values()), 'nonfinite/negative derived metric')
    return result

def descriptive(values):
    available = [v for v in values if v is not None]
    return {'state': 'complete' if len(available) == len(values) else 'missing_values_retained', 'n': len(values), 'values': values, 'available': len(available), 'median': statistics.median(available) if available else None, 'minimum': min(available) if available else None, 'maximum': max(available) if available else None, 'interval': None, 'interval_unavailable_reason': 'Retained values reported descriptively; no fixed-three interval or full >=7-pair parity claim.'}

def paired_dataset(args, audit, stage, before, after):
    direct = stage == 'direct'
    prefix = 'direct' if direct else 'pi'
    base = args.root / (stage + '-cohorts')
    numerator, denominator = ('after', 'before') if direct else ('rust', 'pi')
    products, groups, comparisons, inventory, manifests = [], [], [], [], []
    table = []
    for label, mode in MODES:
        cohort = prefix + '-' + label
        directory = base / cohort
        manifest = audit.attempt(cohort + '/manifest', lambda: load(directory / 'manifest.json'))
        if manifest is None:
            continue
        def verify_manifest():
            require(manifest['cases'] == CASES and manifest['pairs'] == PAIRS and manifest.get('pair_offset', 0) == 0 and type(manifest['clock_ticks']) is int and manifest['clock_ticks'] == 100 and manifest['observer_mode'] == mode, 'matrix/mode/clock differs')
            if direct:
                require(manifest['head'] == args.expected_harness_revision and manifest['comparison_kind'] == 'production-revision', 'direct measurement identity differs')
                require(manifest['executables'] == {engine: {'path': identity['binary'], 'sha256': identity['sha256']} for engine, identity in [('before', before), ('after', after)]}, 'direct executable differs')
            else:
                require(manifest['rust'] == after['binary'] and manifest['rust_sha256'] == after['sha256'], 'Pi candidate executable differs')
                if not args.raw_only:
                    require(git(manifest['pi'], 'rev-parse', 'HEAD') == MATH.PI_REVISION and not git(manifest['pi'], 'diff', '--name-only', 'HEAD'), 'Pi source changed')
        audit.attempt(cohort + '/manifest identity', verify_manifest)
        manifests.append({'file': str((directory / 'manifest.json').relative_to(args.root)), 'sha256': sha(directory / 'manifest.json')})
        expected = {f'{pair}-{case}-{engine}' for pair in range(PAIRS) for case in CASES for engine in (numerator, denominator)}
        observed = {p.name[:-len('.process.json')] for p in directory.glob('*.process.json')}
        audit.attempt(cohort + '/process matrix', lambda: require(observed == expected, f'missing={sorted(expected-observed)} extras={sorted(observed-expected)}'))
        raw_names = {p.stem for engine in (numerator, denominator) for p in directory.glob(f'*-{engine}.json')}
        audit.attempt(cohort + '/raw matrix', lambda: require(raw_names == expected, f'missing={sorted(expected-raw_names)} extras={sorted(raw_names-expected)}'))
        expected_comp = {f'{pair}-{case}-comparison.json' for pair in range(PAIRS) for case in CASES}
        audit.attempt(cohort + '/comparisons', lambda: require({p.name for p in directory.glob('*-comparison.json')} == expected_comp and not list(directory.glob('*-comparison-error.log')), 'missing/extra comparisons or recorded failures'))
        for stem in sorted(expected | observed):
            proc_path, raw_path = directory / (stem + '.process.json'), directory / (stem + '.json')
            proc = audit.attempt(str(proc_path), lambda: load(proc_path))
            inventory.append({'file': str(proc_path.relative_to(args.root)), 'sha256': sha(proc_path) if proc_path.exists() else None, 'raw_exists': raw_path.exists(), 'accepted': None if proc is None else proc.get('accepted'), 'product_exit': None if proc is None else proc.get('product_exit'), 'provider_exit': None if proc is None else proc.get('provider_exit'), 'expected': stem in expected})
        def verify_order():
            logs = [json.loads(line) for line in (base / (cohort + '.stdout')).read_text().splitlines() if line.startswith('{')]
            order = [(pair, case, engine) for pair in range(PAIRS) for case in CASES for engine in ((denominator, numerator) if direct and pair % 2 == 0 else (numerator, denominator) if direct else ('rust', 'pi') if pair % 2 == 0 else ('pi', 'rust'))]
            require(len(logs) == len(order), 'execution log count differs')
            for row, (pair, case, engine) in zip(logs, order):
                proc = load(directory / f'{pair}-{case}-{engine}.process.json')
                require(row['case'] == case and row['accepted'] is True and row['observer_mode'] == mode and row['argv'] == proc['argv'], 'recorded order/admission/argv differs')
                # Stdout omits bulky provider bodies; every retained field must still agree.
                require(all(key in proc and value == proc[key] for key, value in row.items()), 'stdout process record differs')
        audit.attempt(cohort + '/execution order', verify_order)
        by_group = collections.defaultdict(list)
        for case in CASES:
            for pair in range(PAIRS):
                values = {}
                for engine in (numerator, denominator):
                    stem = f'{pair}-{case}-{engine}'
                    raw_path, proc_path = directory / (stem + '.json'), directory / (stem + '.process.json')
                    def derive():
                        raw, proc = load(raw_path), load(proc_path)
                        if engine != 'pi':
                            require(raw['schema'] == (81), 'actual database schema differs')
                        else:
                            require(Path(proc['argv'][-1]).name == raw_path.name, 'Pi output identity differs')
                        return derived_product(raw, proc, case, mode, engine, manifest)
                    result = audit.attempt(f'{cohort}/{stem}', derive)
                    if result is not None:
                        values[engine] = result['metrics']
                        products.append({'file': str(raw_path.relative_to(args.root)), 'raw_sha256': sha(raw_path), 'process_sha256': sha(proc_path), 'cohort': cohort, 'mode': mode, 'case': case, 'pair': pair, 'engine': engine, **result})
                cp = directory / f'{pair}-{case}-comparison.json'
                count = audit.attempt(str(cp), lambda: comparison(cp, case, mode, direct))
                if count is not None:
                    comparisons.append({'file': str(cp.relative_to(args.root)), 'sha256': sha(cp), 'requests': count})
                for metric in next(iter(values.values())).keys() if values else []:
                    a, b = values.get(numerator, {}).get(metric), values.get(denominator, {}).get(metric)
                    ratio, reason = MATH.paired_ratio(a, b)
                    by_group[(case, metric)].append({'pair': pair, 'numerator': a, 'denominator': b, 'ratio': ratio, 'percent_change': None if ratio is None else 100 * (ratio - 1), 'ratio_unavailable_reason': reason, 'difference': None if a is None or b is None else a - b})
        for (case, metric), rows in by_group.items():
            audit.attempt(cohort + '/' + case + '/' + metric, lambda: require(len(rows) == PAIRS, 'incomplete paired group'))
            differences = [r['difference'] for r in rows]
            group = {'cohort': cohort, 'mode': mode, 'case': case, 'metric': metric, 'numerator_engine': numerator, 'denominator_engine': denominator, 'pairs': rows, 'summary': descriptive([r['ratio'] for r in rows]), 'percent_change': descriptive([r['percent_change'] for r in rows]), 'numerator_values': descriptive([r['numerator'] for r in rows]), 'denominator_values': descriptive([r['denominator'] for r in rows]), 'numerator_lower': sum(v is not None and v < 0 for v in differences), 'equal': sum(v == 0 for v in differences), 'numerator_higher': sum(v is not None and v > 0 for v in differences), 'all_five_higher': len(differences) == PAIRS and all(v is not None and v > 0 for v in differences)}
            groups.append(group)
        for case in CASES:
            table.append({'cohort': cohort, 'mode': mode, 'case': case, 'numerator_engine': numerator, 'denominator_engine': denominator, 'warm_history_turns': {'short-small': 8, 'short-large': 64}.get(case, 0), 'metrics': {g['metric']: {'numerator_median': g['numerator_values']['median'], 'denominator_median': g['denominator_values']['median'], 'paired_ratio_median': g['summary']['median'], 'paired_percent_median': g['percent_change']['median'], 'paired_percent_range': [g['percent_change']['minimum'], g['percent_change']['maximum']], 'available_pairs': g['summary']['available']} for g in groups if g['cohort'] == cohort and g['case'] == case}})
    audit.attempt(stage + '/total coverage', lambda: require(len(products) == 120 and len(comparisons) == 60 and sum(r['requests'] for r in comparisons) == 1410, 'expected 120 products, 60 comparisons, 1410 requests'))
    return {'derived_products': len(products), 'valid_comparisons': len(comparisons), 'checked_requests': sum(r['requests'] for r in comparisons), 'product_inventory': inventory, 'products': products, 'comparisons': comparisons, 'manifests': manifests, 'groups': groups, 'table': table, 'arithmetic_scope': 'Independent retained raw counters. All five paired values, missing counters, arithmetic zero and unfavorable outcomes preserved; no producer statistics imported. Table wall medians are median of each product measured-turn median, not a pooled sample.'}

def correctness_commands(rows, artifacts):
    binaries = {row['name']: row['executable'] for row in artifacts if row['executable'] and (row['kind'] == ['lib'] or row['name'] in ('durable', 'process'))}
    require({'rustx', 'durable', 'process'} <= binaries.keys(), 'missing correctness artifact executable identities')
    expected = {'fmt': ['cargo', 'fmt', '--all', '--', '--check'],
                'clippy': ['cargo', 'clippy', '--release', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings']}
    for label, selector in [('sqlite', 'durable::sqlite::'), ('client', 'runtime_client::'), ('conversation-runtime', 'runtime::conversation_runtime::'), ('read-layout', 'runtime::read_layout::'), ('content', 'boundary_suites::durable::content::'), ('agent', 'agent::'), ('tool-registry', 'tools::executor::'), ('recovery', 'runtime::recovery::'), ('process-death', 'boundary_suites::durable::process_death::')]:
        expected['tests-' + label] = [binaries['rustx'], selector, '--skip', '::scale::', '--test-threads=2']
    for name in ('durable', 'process'):
        expected['tests-' + name] = [binaries[name], '--test-threads=2']
    require(len({row['label'] for row in rows}) == len(rows), 'duplicate correctness labels')
    for row in rows:
        if row['label'] in expected:
            require(row['command'] == expected[row['label']], 'correctness command/built executable differs: ' + row['label'])
        require(instant(row['start_utc']) <= instant(row['end_utc']), 'negative correctness step duration')
    require(all(instant(a['end_utc']) <= instant(b['start_utc']) for a, b in zip(rows, rows[1:])), 'overlapping correctness commands')

def diagnostic_continuations(args, audit):
    results = []
    for path in sorted(args.root.glob('check*/**/commands.json')):
        def retain():
            rows = load(path)
            require(isinstance(rows, list), 'diagnostic continuation ledger is not a command list')
            steps = []
            for row in rows:
                label = row['label']
                require(Path(label).name == label, 'invalid diagnostic log label')
                out, err = path.parent / (label + '.stdout'), path.parent / (label + '.stderr')
                require(out.is_file() and err.is_file(), 'diagnostic continuation log missing')
                text = out.read_text()
                tests = re.findall(r'^test (\S+) \.\.\. (ok|ignored|FAILED)', text, re.M)
                summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
                source = None
                if row.get('source_identity'):
                    source_path = (path.parent / row['source_identity']).resolve()
                    require(source_path.is_relative_to(args.root.resolve()) and source_path.is_file(), 'diagnostic source snapshot missing or outside evidence root')
                    source = {'file': str(source_path.relative_to(args.root.resolve())), 'sha256': sha(source_path)}
                steps.append({'record': row, 'stdout_sha256': sha(out), 'stderr_sha256': sha(err), 'test_status_counts': dict(collections.Counter(v for _, v in tests)), 'failed': [n for n, v in tests if v == 'FAILED'], 'ignored': [n for n, v in tests if v == 'ignored'], 'summary': summaries, 'source_identity': source})
            return {'file': str(path.relative_to(args.root)), 'sha256': sha(path), 'scope': 'Historical diagnostic continuation only; never counted as final candidate correctness validation.', 'steps': steps}
        value = audit.attempt(str(path) + ' retained diagnostic continuation', retain)
        if value is not None:
            results.append(value)
    return results

def diagnostic_probes(args, audit):
    results = []
    # Optional historical diagnostics retain failures and exact retries alike.
    # None has the frozen complete-suite source binding needed for validation.
    paths = sorted(set(args.root.glob('process-repro*/command.json')) | set(args.root.glob('lint-probe*/command.json')))
    for path in paths:
        def retain():
            row = load(path)
            require(isinstance(row, dict) and isinstance(row['command'], list) and row['command'], 'invalid diagnostic command record')
            require(type(row['exit']) is int and instant(row['start_utc']) <= instant(row['end_utc']), 'incomplete diagnostic command result')
            out, err = path.parent / 'stdout', path.parent / 'stderr'
            require(out.is_file() and err.is_file(), 'diagnostic stdout/stderr missing')
            text = out.read_text()
            tests = re.findall(r'^test (\S+) \.\.\. (ok|ignored|FAILED)', text, re.M)
            summaries = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
            return {'file': str(path.relative_to(args.root)), 'sha256': sha(path), 'record': row, 'stdout_sha256': sha(out), 'stderr_sha256': sha(err), 'test_status_counts': dict(collections.Counter(v for _, v in tests)), 'failed': [n for n, v in tests if v == 'FAILED'], 'ignored': [n for n, v in tests if v == 'ignored'], 'summary': summaries, 'source_binding': 'No complete frozen before/after source snapshots in this command record; no historical identity invented.', 'scope': 'Historical diagnostic probe or exact reproduction only; never counted as final candidate correctness validation.'}
        value = audit.attempt(str(path) + ' retained diagnostic probe', retain)
        if value is not None:
            results.append(value)
    return results

def validation(args, audit, candidate):
    results = []
    binding = None if candidate is None else candidate.get('validation')
    def exact_validation_binding():
        require(isinstance(binding, dict) and isinstance(binding.get('directory'), str), 'O3 identity lacks explicit validation directory')
        relative = Path(binding['directory'])
        require(not relative.is_absolute() and len(relative.parts) == 1 and relative.name.startswith('checks'), 'unsafe validation directory')
        require(set(binding['files']) == {'check-build-commands.json', 'source-before.json', 'source-after.json'}, 'validation binding inventory differs')
        require(all(sha(args.root / relative / name) == digest for name, digest in binding['files'].items()), 'bound validation artifacts changed')
        return relative.as_posix()
    bound_directory = audit.attempt('explicit O3 validation binding', exact_validation_binding)
    for commands_path in sorted(args.root.glob('check*/check-build-commands.json')):
        rows = load(commands_path)
        directory = commands_path.parent
        result = {'directory': str(directory.relative_to(args.root)), 'commands_sha256': sha(commands_path), 'steps': [], 'source_snapshots': {}}
        snapshots = {}
        for name in ('source-before.json', 'source-after.json'):
            path = directory / name
            if path.exists():
                snapshot = load(path)
                snapshots[name] = snapshot
                result['source_snapshots'][name] = {'sha256': sha(path), 'utc': snapshot.get('utc'), 'head': snapshot.get('head'), 'files': len(snapshot.get('files', {})), 'scope': snapshot.get('scope')}
            else:
                result['source_snapshots'][name] = None
        result['source_binding'] = 'unavailable; no historical identity invented'
        result['matches_candidate_source'] = False
        if len(snapshots) == 2:
            source_before, source_after = snapshots['source-before.json'], snapshots['source-after.json']
            if source_before.get('files') == source_after.get('files') and source_before.get('files'):
                result['source_binding'] = 'recorded before/after file hashes equal'
        for row in rows:
            label = row['label']
            out = directory / (label + '.stdout')
            entry = {'label': label, 'status': row['status'], 'exit': row.get('exit'), 'stdout_sha256': sha(out) if out.exists() else None, 'stderr_sha256': sha(directory / (label + '.stderr')) if (directory / (label + '.stderr')).exists() else None}
            if row.get('exit') == 0:
                audit.attempt(str(directory) + '/' + label + ' success logs', lambda: require(out.is_file() and (directory / (label + '.stderr')).is_file(), 'successful check is missing stdout/stderr evidence'))
            if label == 'tests-build' and row.get('exit') == 0:
                def check_artifacts():
                    require(row['command'] == ['cargo', 'test', '--release', '--config', 'profile.release.package.rustx.opt-level=0', '--locked', '--all-features', '--lib', '--test', 'durable', '--test', 'process', '--no-run', '--message-format=json'], 'correctness build command differs')
                    build = [json.loads(line) for line in out.read_text().splitlines() if line.startswith('{')]
                    require([r for r in build if r.get('reason') == 'build-finished'] == [{'reason': 'build-finished', 'success': True}], 'no successful correctness build marker')
                    artifacts = [r for r in build if r.get('reason') == 'compiler-artifact' and r['target']['name'] in ('rustx', 'durable', 'process', 'bash-supervisor', 'interactive-supervisor')]
                    require(artifacts and all(r['profile']['opt_level'] == '0' and r['features'] == ['issue-387-profile', 'mcp-fixture'] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts), 'correctness root O0/all-feature profile differs')
                    return [{'name': r['target']['name'], 'kind': r['target']['kind'], 'executable': r['executable'], 'fresh': r['fresh']} for r in artifacts]
                entry['root_artifacts'] = audit.attempt(str(out) + ' artifact identity', check_artifacts)
            if label.startswith('tests-') and label != 'tests-build' and out.exists():
                text = out.read_text()
                tests = re.findall(r'^test (\S+) \.\.\. (ok|ignored|FAILED)', text, re.M)
                summary = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
                entry.update(test_status_counts=dict(collections.Counter(v for _, v in tests)), failed=[n for n, v in tests if v == 'FAILED'], ignored=[n for n, v in tests if v == 'ignored'], summary=summary)
                if summary:
                    last = summary[-1]
                    audit.attempt(str(out), lambda: require(len(summary) == 1 and len({n for n, _ in tests}) == len(tests) and collections.Counter(v for _, v in tests) == collections.Counter({'ok': int(last[1]), 'FAILED': int(last[2]), 'ignored': int(last[3])}), 'test names and summary disagree'))
                    if row.get('exit') == 0:
                        audit.attempt(str(out) + ' success status', lambda: require(last[0] == 'ok' and int(last[2]) == 0 and int(last[4]) == 0, 'exit-zero test output reports failure/measured tests'))
                elif row.get('exit') == 0:
                    audit.errors.append(f'{out}: exit-zero test queue has no libtest summary')
                entry['gh_tests'] = [n for n, status in tests if status == 'ok' and ('::shared_scalar_' in n or '::bounded_response_page_' in n)]
                entry['joint_tests'] = [n for n, status in tests if status == 'ok' and n in JOINT_TEST_NAMES]
                entry['complete_tests'] = [n for n, status in tests if status == 'ok' and n.rsplit('::', 1)[-1] in COMPLETE_REQUIRED_TESTS]
            result['steps'].append(entry)
        if rows and all(row.get('exit') == 0 for row in rows) and rows[-1]['label'] == 'clippy':
            def source_binding():
                artifacts = next((r.get('root_artifacts') for r in result['steps'] if r['label'] == 'tests-build'), None)
                require(artifacts is not None, 'successful checks lack build artifact proof')
                correctness_commands(rows, artifacts)
                require(len(snapshots) == 2, 'successful check queue has no complete source snapshots')
                left, right = snapshots['source-before.json'], snapshots['source-after.json']
                require(left['files'] == right['files'] and {'Cargo.toml', 'Cargo.lock'} <= left['files'].keys(), 'test source changed or missing Cargo inputs during correctness queue')
                source_hashes(left['files'])
                result['matches_candidate_source'] = candidate is not None and left['files'] == candidate['source_files']
                require(left['utc'] <= rows[0]['start_utc'] and rows[-1]['end_utc'] <= right['utc'], 'test source snapshots do not bracket checks')
                if not args.raw_only and result['matches_candidate_source']:
                    require(all(sha(args.repo / path) == digest for path, digest in left['files'].items()), 'tested source file differs from current committed candidate source')
                    expected_inputs = set(git(args.repo, 'ls-tree', '-r', '--name-only', 'HEAD', '--', 'src', 'tests').splitlines())
                    require({p for p in left['files'] if p.startswith(('src/', 'tests/'))} == expected_inputs, 'src/tests source snapshot file set is incomplete')
                if not result['matches_candidate_source']:
                    return 'historical successful queue; identical before/after hashes differ from candidate; not current validation'
                return 'before/after identical; candidate build inputs and current committed bytes verified' if not args.raw_only else 'before/after identical and equal to retained candidate build input hashes; current/source commit bytes not checked'
            result['source_binding'] = audit.attempt(str(directory) + ' test source binding', source_binding)
        results.append(result)
    required = {'fmt', 'tests-build', 'tests-sqlite', 'tests-client', 'tests-conversation-runtime', 'tests-read-layout', 'tests-content', 'tests-durable', 'tests-process', 'tests-agent', 'tests-tool-registry', 'tests-recovery', 'tests-process-death', 'clippy'}
    complete = [r for r in results if r['directory'] == bound_directory and r['matches_candidate_source'] and {s['label'] for s in r['steps']} >= required and all(s['status'] == 'complete' and s['exit'] == 0 for s in r['steps'])]
    audit.attempt('correctness checks', lambda: require(complete, 'no complete successful recorded correctness/fmt/Clippy queue with source hashes equal to candidate O3 build inputs'))
    if complete:
        tested = [name for step in complete[-1]['steps'] for name in step.get('gh_tests', [])]
        audit.attempt('new differential test coverage', lambda: require(sum('::shared_scalar_' in n for n in tested) >= 7 and sum('::bounded_response_page_' in n for n in tested) >= 9, 'G/H differential tests missing from successful selected suite'))
        complete_tested = {name.rsplit('::', 1)[-1] for step in complete[-1]['steps'] for name in step.get('complete_tests', [])}
        audit.attempt('complete-cost exact passing test coverage', lambda: require(COMPLETE_REQUIRED_TESTS <= complete_tested, 'required passing tests missing: ' + ', '.join(sorted(COMPLETE_REQUIRED_TESTS - complete_tested))))
        joint_tested = {name for step in complete[-1]['steps'] for name in step.get('joint_tests', [])}
        for group, required_tests in JOINT_REQUIRED_TESTS.items():
            audit.attempt(group + ' exact passing test coverage', lambda required_tests=required_tests: require(required_tests <= joint_tested, 'required passing tests missing: ' + ', '.join(sorted(required_tests - joint_tested))))
    return {'bound_directory': bound_directory, 'runs': results, 'diagnostic_continuations': diagnostic_continuations(args, audit), 'diagnostic_probes': diagnostic_probes(args, audit), 'successful_complete_queues': [r['directory'] for r in complete], 'source_binding_limit': 'Initial failed runs without source snapshots are retained and explicitly unbound. Successful final checks require before/after src/tests/Cargo file hashes equal to candidate build inputs; strict mode verifies the tracked src/tests file set and matches those bytes to the clean current candidate source. This is evidence consistency, not a reproducible-build proof.'}

COMPLETE_REQUIRED_TESTS |= {
 'immutable_metadata_fragments_preserve_schema_wire_and_exact_budget_boundaries',
 'immutable_metadata_fragments_preserve_invalid_and_oversized_admission',
 'immutable_metadata_resolution_keeps_old_owner_and_measures_each_value_once',
 'prepared_capture_reuses_metadata_value_and_exact_length_without_deep_copy',
 'metadata_frontier_owners_reuse_only_identical_fixed_fields',
 'native_metadata_heads_reuse_fragments_across_publication_and_keep_old_paths',
 'completed_response_reuse_skips_native_owner_queries_and_decodes_across_new_journal',
 'response_reuse_authenticates_user_seats_and_keeps_a_fixed_capacity',
 'response_reuse_never_admits_provisional_write_transaction_results',
 'response_cache_revalidates_same_connection_sources_and_survives_rollback',
 'response_cache_external_write_invalidates_and_reopen_has_no_stale_owner',
 'response_cache_keeps_old_cut_and_checks_new_unrelated_execution_and_member_holes',
 'response_cache_new_member_alias_cannot_reuse_an_old_completed_owner',
 'response_cache_new_tool_result_alias_rechecks_source_without_changing_process_owner',
 'response_cache_inherited_rewrites_and_schema_changes_keep_native_failure_order',
 'response_reuse_keeps_terminal_only_delegated_proofs_uncached',
}

COMPLETE_REQUIRED_TESTS |= {
 'quote_overlay_authenticates_every_byte_and_retains_exact_scalar_distinctions',
 'quote_overlay_rejects_noncanonical_positions_lengths_trailing_and_hostile_counts',
 'quote_overlay_storage_choice_preserves_exact_byte_boundary_and_rejects_other_edits',
 'quote_overlay_shares_native_body_and_fences_changed_or_coherently_malformed_sources',
 'quote_overlay_trigger_changed_native_bytes_fail_only_the_derived_source',
 'quote_overlay_reads_share_one_snapshot_across_external_body_changes',
 't08_t12_t14_t19_headless_request_keeps_real_giant_owner_fields_without_native_start_facts',
}

COMPLETE_REQUIRED_TESTS |= {
 'constant_bodies_store_one_run_without_losing_any_occurrence_width',
 'independently_changing_admission_bodies_join_exactly_for_all_eighty_classes',
 'run_validation_checks_interior_rank_maxima_and_rehashed_geometry',
 'obsolete_dense_widths_and_hostile_run_counts_are_not_decoded',
}

COMPLETE_REQUIRED_TESTS |= {
 'immutable_registry_selection_preserves_bindings_without_registration',
 'transcript_row_owners_moving_eight_row_head_prepares_only_new_row',
 'transcript_row_owners_replay_shared_budget_and_failed_admission_exactly',
 'transcript_row_owners_reindex_deferred_bindings_without_changing_old_cut',
 'transcript_row_owners_keep_opaque_numbers_order_and_current_decoration',
}

COMPLETE_REQUIRED_TESTS |= {'lifecycle_probes_reuse_existence_until_the_first_write', 'lifecycle_first_write_rechecks_trigger_changed_later_keys', 'trace_unchanged_bindings_do_not_rewrite_summaries_or_proposals', 'checkpoint_shared_cut_preserves_order_when_multiple_native_domains_are_corrupt', 'transaction_cut_proof_rejects_writes_and_savepoint_rollback_without_reusing_facts', 'checkpoint_complete_rows_reuse_only_verified_body_and_response_owners', 'turn_start_materializes_ordinal_header_once_and_reads_empty_prompt_once', 'trace_unchanged_bindings_keep_typed_encoding_admission', 'checkpoint_tool_rows_share_cut_proof_but_keep_each_native_tool_validation', 'turn_start_ordinal_and_header_failure_keeps_native_and_other_layouts', 'checkpoint_read_reuses_one_actual_native_head_for_response_and_statistics'}

COMPLETE_REQUIRED_TESTS |= {'response_owner_admission_bounds_do_not_allocate_or_clone_rejected_native_facts', 'transcript_page_capture_preserves_empty_and_truncated_cardinality', 'transcript_page_capture_reuses_same_owners_without_row_reindex_or_rebuild', 'transient_response_facts_move_without_sharing_and_completed_owners_stay_identical', 'transcript_page_capture_budget_boundary_preserves_oracle_and_warm_certificate'}

def identity_and_plan(args, before, after):
    require((before['head'],before['sha256'],before['production_tree']) == (
        '459b1b6005bfbf7f0a1a1d52df5a6900b06c56c6',
        '21d50ee8ac86bb80a2132e6013ece360ae56944d311abbaf87c0576ef32c0e57',
        '955c5220e821babe9ece0cdb4791164056a3056f'), 'fixed prior Rust identity differs')
    require(before['harness']==after['harness'] and before['rustc']==after['rustc'] and before['cargo']==after['cargo'], 'harness/toolchain differs')
    require(before['sha256']!=after['sha256'], 'identical revisions')
    for name, identity in [('baseline',before),('candidate',after)]:
        require(identity['verified'] and identity['build_exit']==identity['clean_exit']==0, name+' build failed')
        build=args.root/('baseline-build' if name=='baseline' else 'candidate-complete-build')
        rows=[json.loads(line) for line in (build/'build.stdout').read_text().splitlines() if line.startswith('{')]
        artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['src_path'].startswith(str(args.repo))]
        require(artifacts and all(not r['fresh'] and r['profile']['opt_level']=='3' and r['features']==[] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts),name+' ordinary O3/default build differs')
        require([r for r in rows if r.get('reason')=='build-finished']==[{'reason':'build-finished','success':True}],name+' build-finished missing')
        require(identity['commands']==[['cargo','clean','--release','--package','rustx'],['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json']],name+' build commands differ')
        source_hashes(identity['source_files'])
        if not args.raw_only:
            require(sha(identity['binary'])==identity['sha256'],name+' executable bytes differ')
            require(git(args.repo,'rev-parse',identity['head']+':src')==identity['production_tree'],name+' source commit differs')
    if not args.raw_only:
        require(git(args.repo,'rev-parse','HEAD:src')==after['production_tree'],'production tree changed')
        require(not git(args.repo,'status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime'),'source/harness dirty')
        require(all(sha(args.repo/path)==digest for path,digest in after['source_files'].items()),'source bytes changed')
        require(all(sha(args.repo/path)==digest for path,digest in after['harness'].items()),'harness bytes changed')
    plan=load(args.root/'direct-cohorts/commands.json')
    require(plan['stage']=='direct' and plan['identities']=={'before':before,'after':after},'runner identities differ')
    start,end=plan['source_before'],plan['source_after']
    require(start['head']==after['head'] and start['schema']==81 and start['production_tree']==after['production_tree'] and start['source_files']==after['source_files'],'runner source before differs')
    require({k:v for k,v in start.items() if k!='utc'}=={k:v for k,v in end.items() if k!='utc'},'runner source changed')
    require(len(plan['steps'])==2,'unexpected runner stage')
    for row,(label,mode) in zip(plan['steps'],MODES):
        require(row['name']=='direct-'+label and row['status']=='complete' and row['exit']==0,'incomplete direct step')
        require(row['command'][1:]==['benchmarks/runtime/compare-revisions.py','--before',before['binary'],'--after',after['binary'],'--output',str(Path(after['binary']).parent.parent/'direct-cohorts'/('direct-'+label)),'--pairs','5','--observer-mode',mode],'direct command differs or executes another engine')
        require(start['utc']<=row['start_utc']<=row['end_utc']<=end['utc'],'product timestamps outside source freeze')
    require(plan['steps'][0]['end_utc']<=plan['steps'][1]['start_utc'],'cohorts overlap')
    require(all((args.root/'direct-cohorts'/(row['name']+suffix)).is_file() for row in plan['steps'] for suffix in ('.stdout','.stderr')), 'direct command logs missing')
    return {'before':{k:before[k] for k in ('head','production_tree','sha256')},'after':{k:after[k] for k in ('head','production_tree','sha256')},'commands_sha256':sha(args.root/'direct-cohorts/commands.json'),'source_unchanged':True}

def premeasurement_binding(args, before, after):
    path=args.root/'premeasurement.json';receipt=load(path)
    require(receipt['accepted'] is True and receipt['errors']==[], 'premeasurement did not pass')
    require(receipt['identities']=={name:{key:build[key] for key in ('head','production_tree','sha256')} for name,build in [('baseline-build',before),('candidate-complete-build',after)]}, 'premeasurement identities differ')
    required={'build-candidate.py','run-cohorts.py','run-diagnostics.py','columns-complete.py','run-profiles.py','profile-reports.py','run-wal-rust.py','analyze-wal-verified.py','direct-audit.py','diagnostic-audit.py','recompute-pi.py','premeasurement.py','summarize-results.py'}
    require(set(receipt['scripts'])==required and all(sha(args.root/name)==digest for name,digest in receipt['scripts'].items()), 'frozen measurement/audit scripts changed')
    plan=load(args.root/'direct-cohorts/commands.json')
    require(instant(receipt['completed_utc'])<=instant(plan['source_before']['utc']), 'measurement predates premeasurement checks')
    return {'file':path.name,'sha256':sha(path),'completed_utc':receipt['completed_utc'],'verified':True}

def main():
    global MATH
    parser=argparse.ArgumentParser()
    parser.add_argument('--root',type=Path,default=HERE)
    parser.add_argument('--repo',type=Path,default=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX'))
    parser.add_argument('--raw-only',action='store_true')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    require(not args.output.exists(),'retain previous audit; choose another output')
    MATH=module('independent_pi_math',HERE/'recompute-pi.py','e2879454bd2c6ed1add046dd55d6ceaa3c7451087ee92e6e008afcbf7a7e1ac3')
    before=load(args.root/'baseline-build/identity.json');after=load(args.root/'candidate-complete-build/identity.json')
    args.expected_harness_revision=after['head']
    audit=Audit()
    ids=audit.attempt('source/build/runner binding',lambda:identity_and_plan(args,before,after))
    preflight=audit.attempt('premeasurement binding',lambda:premeasurement_binding(args,before,after))
    checks=validation(args,audit,after)
    data=paired_dataset(args,audit,'direct',before,after)
    report={'accepted':not audit.errors,'raw_only':args.raw_only,'mode':'raw-only' if args.raw_only else 'strict','strict_identity_verified':not audit.errors and not args.raw_only,'errors':audit.errors,'identities':ids,'validation':checks,'premeasurement':preflight,'datasets':{'direct':data},'script_sha256':sha(__file__),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reference_policy':'Only before/after Rust executes. Prior Pi/DSH references are separate cross-batch descriptive ratios, never paired to this batch.'}
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'accepted':report['accepted'],'errors':report['errors'],'products':data['derived_products'],'comparisons':data['valid_comparisons'],'requests':data['checked_requests']}))
    raise SystemExit(int(bool(audit.errors)))

if __name__=='__main__':main()
