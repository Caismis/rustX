#!/usr/bin/env python3
"""Strict Rust-only diagnostics: 4 columns, 4 CPU/control, 4 WAL. No products run."""
import argparse, ast, collections, datetime, hashlib, json, math, re, struct, subprocess, sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=Path("/home/capi/.codex/worktrees/pr485-pi-performance/rustX")
BASELINE_HEAD="459b1b6005bfbf7f0a1a1d52df5a6900b06c56c6"
BASELINE_TREE="955c5220e821babe9ece0cdb4791164056a3056f"
BASELINE_SHA="21d50ee8ac86bb80a2132e6013ece360ae56944d311abbaf87c0576ef32c0e57"

TEST = 'agent_loop::runtime_benchmark::measure_runtime'

PHASES = ['before_initialization', 'after_provider_start', 'after_initialization',
          'before_measured_turns', 'after_turns', 'after_late_snapshot',
          'after_verification', 'after_shutdown', 'after_driver_drop',
          'after_final_writer_close', 'after_reopen_verification', 'after_cleanup']

LIFECYCLE = [phase for phase in PHASES if phase != 'before_measured_turns']

PROFILE_NAMES = [f'profile-{revision}-live-large-{mode}'
                 for revision in ('baseline', 'complete') for mode in ('control', 'cpu')]

NEEDLES = {
    'read_with_trace': 'ReadDomainCut>::read_with_trace',
    'index_request_read_layouts': 'index_request_read_layouts',
    'sqlite_prepare': 'sqlite3LockAndPrepare',
    'publication_encode': 'PublicationDraft>::encode',
    'checkpoint_unfitted': 'CheckpointSeed>::checkpoint_unfitted',
    'checkpoint_prepared': 'CheckpointSeed>::checkpoint_prepared',
    'prepared_domain_inherit': 'PreparedCaptures>::inherit',
    'prepared_capture': 'Capture>::prepared',
    'capture_evidence': 'capture_evidence',
    'fit_checkpoint': 'fit_checkpoint',
    'native_request_persist': 'native_request::persist',
    'native_request_read': 'native_request::read',
    'native_request_full': 'native_request::full',
    'statistics_prepare': 'observation_statistics::prepare',
    'append_aggregates': 'append_facts::aggregates',
    'model_turn_receipt': 'observation_receipt::model_turn_settlement',
    'final_stored_evidence': 'observation_receipt::stored_events',
    'execution_seal': 'seal_execution',
    'content_persist_part': 'persist_part',
    'transcript_row_capture': 'PreparedTranscriptRow>::capture',
    'transcript_head_capture': 'PreparedTranscriptHead>::capture',
    'capture_certificate_replay': 'Capture>::try_replay',
    'registry_for_model': 'ToolRegistry>::for_model',
    'registry_registration': 'register_with_execution_metadata',
    'canonical_schema_validation': 'validate_canonical_schema',
}

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, f'invalid {label}')
    return value

def utc(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None and result.utcoffset() == datetime.timedelta(0),
            'timestamp is not explicitly UTC')
    return result

def window(start, end):
    begin, finish = utc(start), utc(end)
    require(begin < finish, 'empty/reversed command window')
    return begin, finish

def disjoint(left, right):
    return left[1] <= right[0] or right[1] <= left[0]

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

def verify_build(args, label):
    path = args.baseline_identity if label == 'baseline' else args.candidate_identity
    build = load(path)
    require(all(re.fullmatch('[0-9a-f]{40}', build[key]) for key in ('head', 'production_tree'))
            and re.fullmatch('[0-9a-f]{64}', build['sha256']), f'{label} malformed identity')
    require(build['verified'] is True and build['build_exit'] == build['clean_exit'] == 0, 'ordinary build failed')
    require(build['commands'] == [['cargo','clean','--release','--package','rustx'],
        ['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json']], 'build commands differ')
    require(build['harness'] and build['rustc'] and build['cargo'], 'missing toolchain/harness')
    require(all(re.fullmatch('[0-9a-f]{64}', v) for v in build['harness'].values()), 'bad harness hash')
    stdout = path.parent / 'build.stdout'
    rows = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
    require([r for r in rows if r.get('reason') == 'build-finished'] == [{'reason':'build-finished','success':True}], 'Cargo success missing')
    artifacts = [r for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] in ('rustx','conformance')]
    require(any(r['target']['name'] == 'conformance' and r['executable'] for r in artifacts), 'conformance missing')
    require(all(r['profile']['opt_level']=='3' and r['features']==[] and not r['fresh'] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts), 'ordinary O3 artifacts differ')
    if label == 'baseline':
        require((build['head'],build['production_tree'],build['sha256']) == (BASELINE_HEAD,BASELINE_TREE,BASELINE_SHA), 'pinned baseline differs')
    if label == 'complete' and args.expect_rust_sha256:
        require(build['sha256'] == args.expect_rust_sha256, 'candidate SHA differs')
    if not args.raw_only:
        require(sha(build['binary']) == build['sha256'], 'actual binary differs')
        require(git(args.repo,'rev-parse',build['head']+':src') == build['production_tree'], 'source tree differs')
        for source,digest in build['harness'].items():
            require(sha(args.repo/source)==digest, 'current harness differs: '+source)
        schema=81
        require(f'pub const SQLITE_SCHEMA_VERSION: i64 = {schema};' in git(args.repo,'show',build['head']+':src/durable/sqlite.rs'), 'schema differs')
    return build, {'file':str(path),'sha256':sha(path),'cargo_stdout_sha256':sha(stdout)}

def counters(point):
    process = point['process']
    stat = process['stat']
    tail = stat.rsplit(')', 1)[1].split()
    io = {key: int(value.strip()) for key, value in
          (line.split(':', 1) for line in process['io'].splitlines())}
    return {'identity': (int(stat.split('(', 1)[0]), int(tail[19])),
            'cpu_ticks': int(tail[11]) + int(tail[12]), 'write_bytes': io['write_bytes']}

def product(directory, revision, build, case, observer, argv):
    raw, proc = load(directory / 'sample.json'), load(directory / 'sample.process.json')
    require(proc['argv'] == argv and proc['accepted'] is True and
            proc['product_exit'] == proc['provider_exit'] == 0, 'product argv/admission differs')
    require(proc['case'] == raw['case'] == case and proc['observer_mode'] ==
            raw['observer_mode'] == observer, 'product case/observer differs')
    require(raw['schema'] == (81), 'product schema differs')
    require(raw['oracle'] == 'passed' and raw['workload_version'] == 3
            and raw['measurement_version'] == 4, 'product oracle/version differs')
    history = 8 if case == 'short-small' else 64
    count = history + 32
    require(raw['history'] == history and raw['measured'] == 32 and len(raw['samples']) == count,
            'product turn dimensions differ')
    require(all(s['turn'] == i and s['measured'] is (i >= history)
                and s['observer_mode'] == observer for i, s in enumerate(raw['samples'])),
            'product measured phase identities differ')
    require([point['phase'] for point in raw['lifecycle']] == LIFECYCLE, 'product lifecycle differs')
    elapsed = [point['elapsed_us'] for point in raw['lifecycle']]
    require(all(type(value) is int and value >= 0 for value in elapsed) and elapsed == sorted(elapsed),
            'lifecycle times invalid/decreased')
    provider = proc['provider_report']
    require(provider['complete'] is True and provider['ok'] is True and not provider['failures']
            and provider['requestCount'] == provider['stepsTotal'] == provider['stepsMatched'] ==
            provider['stepsSettled'] == count and provider['stepStates'] == ['settled'] * count,
            'provider completion differs')
    require(raw['wire_requests'] == provider['requests'] and raw['live_requests'] == raw['reopened_requests']
            and raw['verified_live_requests'] == raw['verified_reopened_requests'] == count,
            'persisted/reopened request admission differs')
    points = raw['samples'] + raw['lifecycle']
    require(len({counters(point)['identity'] for point in points}) == 1,
            'self PID/start-time changed between counters')
    for series in (raw['samples'], raw['lifecycle']):
        for key in ('cpu_ticks', 'write_bytes'):
            values = [counters(point)[key] for point in series]
            require(min(values) >= 0 and values == sorted(values), f'{key} invalid/decreased')
    begin, end, final = (counters(raw['samples'][history - 1]),
                         counters(raw['samples'][-1]), counters(raw['lifecycle'][-1]))
    settled = [sample['settled_us'] for sample in raw['samples'][history:]]
    require(all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in settled),
            'invalid settled counter')
    return {'accepted': True, 'schema': raw['schema'], 'history_turns': history,
            'measured_turns': 32, 'request_count': count,
            'sample_sha256': sha(directory / 'sample.json'),
            'process_sha256': sha(directory / 'sample.process.json'),
            'mean_measured_turn_ms': sum(settled) / 32000,
            'measured_phase_self_cpu_ticks': end['cpu_ticks'] - begin['cpu_ticks'],
            'measured_phase_self_cpu_ms_at_100hz': (end['cpu_ticks'] - begin['cpu_ticks']) * 10,
            'measured_phase_process_write_bytes': end['write_bytes'] - begin['write_bytes'],
            'full_self_cpu_ticks': final['cpu_ticks'], 'full_self_cpu_ms_at_100hz': final['cpu_ticks'] * 10,
            'full_process_write_bytes': final['write_bytes'],
            'clock_ticks_note': 'Raw ticks are primary; milliseconds use the formal cohort 100 Hz clock convention.'}

def raw_cpu(path, binary):
    raw = path.read_bytes()
    require(len(raw) >= 64 and struct.unpack_from('<5Q', raw) == (0, 3, 0, 4000, 0),
            f'{path.name}: invalid 250 Hz CPU header')
    offset, total, records = 40, 0, 0
    while True:
        require(offset + 16 <= len(raw), f'{path.name}: truncated raw count')
        count, depth = struct.unpack_from('<2Q', raw, offset)
        offset += 16
        require(0 < depth < 10000 and offset + depth * 8 <= len(raw),
                f'{path.name}: invalid/truncated raw stack')
        pcs = struct.unpack_from(f'<{depth}Q', raw, offset)
        offset += depth * 8
        if count == 0 and pcs == (0,):
            break
        require(count > 0, f'{path.name}: invalid raw sample count')
        total += count
        records += 1
    maps = raw[offset:].decode()
    require(binary in maps, f'{path.name}: maps lack recorded measured binary')
    return {'total_samples': total, 'sample_records': records,
            'interval_us': 4000, 'raw_sha256': sha(path)}, maps

def cpu_profile(directory, build, command, counts, raw_only):
    require({path.name for path in directory.glob('*.cpu')} ==
            {phase + '.cpu' for phase in PHASES[:-1]}, 'CPU phase file inventory differs')
    inventory = {}
    for phase in PHASES[:-1]:
        info, maps = raw_cpu(directory / (phase + '.cpu'), build['binary'])
        inventory[phase] = info
        if not raw_only:
            require(all(str(Path(path).resolve()) in maps for path in command['preload_sha256']),
                    f'{phase}: raw maps lack actual preload')
    steady = inventory['before_measured_turns']
    total = steady['total_samples']
    require(total > 0, 'measured CPU interval has no samples')
    stacks = []
    for line in (directory / 'steady-collapsed.txt').read_text().splitlines():
        stack, value = line.rsplit(' ', 1)
        require(stack and value.isdigit() and int(value) > 0, 'invalid collapsed stack/count')
        stacks.append((stack, int(value)))
    require(sum(count for _, count in stacks) == total, 'raw and collapsed totals differ')
    cumulative = (directory / 'steady-cumulative.txt').read_text().splitlines()
    require(cumulative and cumulative[0] == f'Total: {total} samples', 'cumulative total differs')
    rows = []
    for line in cumulative[1:]:
        if not line.strip():
            continue
        match = re.fullmatch(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)', line)
        require(match is not None, 'unrecognized cumulative row')
        row = {'symbol': match[3], 'flat': int(match[1]), 'inclusive': int(match[2])}
        require(0 <= row['flat'] <= row['inclusive'] <= total, 'invalid cumulative counts')
        rows.append(row)
    require(rows and len({row['symbol'] for row in rows}) == len(rows), 'empty/duplicate cumulative symbols')
    require(sum(row['flat'] for row in rows) <= total, 'cumulative flat counts exceed raw samples')
    record = counts[command['name']]
    require(record['samples'] == total and record['interval_us'] == 4000 and
            record['raw_sha256'] == steady['raw_sha256'] and record['rows'] == rows,
            'cpu-counts summary differs from independently parsed evidence')
    inclusive = {}
    for label, needle in NEEDLES.items():
        value = sum(count for stack, count in stacks if needle in stack)
        matches = [row for row in rows if needle in row['symbol']]
        # pprof text shortens Rust generics and truncates at 200 nodes. Only a
        # unique text match supports a direct equality check. Multiple matches
        # are retained individually, never added as independent costs.
        agreement = None
        if len(matches) == 1:
            require(matches[0]['inclusive'] == value, f'inclusive raw-stack/text counts differ: {label}')
            agreement = True
        inclusive[label] = {'needle': needle, 'samples': value, 'share_percent': 100 * value / total,
                            'cumulative_matches': matches, 'unique_cumulative_agreement': agreement}
    return {**steady, 'raw_header': [0, 3, 0, 4000, 0], 'collapsed_total': total,
            'collapsed_sha256': sha(directory / 'steady-collapsed.txt'),
            'cumulative_sha256': sha(directory / 'steady-cumulative.txt'),
            'phase_inventory': inventory, 'inclusive': inclusive,
            'phase': 'before_measured_turns starts this file; after_turns stops it. All product threads, '
                     '32 measured turns plus between-turn counters/footprints and control overhead.',
            'symbol_binding': 'Retained symbolized reports are bound by raw SHA and count consistency; '
                              'this read-only audit does not independently symbolize program counters.'}

def profile(args, command, identities, counts):
    name = command['name']
    revision, mode = name.split('-')[1], name.split('-')[-1]
    directory, build = args.root / name, identities[revision]
    require(command['build_identity'] == build, 'profile build differs from archived identity')
    require(command['status'] == 'complete' and command['exit'] == 0, 'profile command failed')
    window(command['start_utc'], command['end_utc'])
    argv_command = command['command']
    require(argv_command[:2] == ['python3', 'benchmarks/runtime/profiling/run.py'], 'profile runner differs')
    for flag, expected in [('--binary', build['binary']), ('--mode', mode), ('--case', 'short-large'),
                           ('--observer-mode', 'live-subscriber')]:
        require(argv_command.count(flag) == 1 and argv_command[argv_command.index(flag) + 1] == expected,
                f'profile command {flag} differs')
    require(argv_command.count('--output') == 1 and
            Path(argv_command[argv_command.index('--output') + 1]).name == name, 'profile output identity differs')
    manifest = load(directory / 'manifest.json')
    require(manifest['mode'] == mode and manifest['binary_sha256'] == build['sha256'] and
            manifest['case'] == 'short-large' and manifest['observer_mode'] == 'live-subscriber',
            'profile manifest identity differs')
    argv = manifest['argv']
    require(argv[-5:] == [build['binary'], TEST, '--exact', '--ignored', '--nocapture'], 'profile target differs')
    if mode == 'cpu':
        require(argv[0] == 'env' and len(argv) == 10 and argv[4] == 'CPUPROFILE_FREQUENCY=250',
                'CPU environment/frequency differs')
        env = dict(value.split('=', 1) for value in argv[1:5])
        require(set(env) == {'LD_PRELOAD', 'RUSTX_BENCH_PROFILE_SOCKET', 'RUSTX_BENCH_PROFILE_DIR',
                             'CPUPROFILE_FREQUENCY'}, 'CPU env keys differ')
        preload = command['preload_sha256']
        require(len(preload) == 2 and set(env['LD_PRELOAD'].split(':')) == set(preload), 'preload identity differs')
        require({Path(path).name for path in preload} == {'bridge.so', 'libprofiler.so.0'} and
                all(re.fullmatch('[0-9a-f]{64}', digest) for digest in preload.values()), 'preload hashes malformed')
        require(Path(env['RUSTX_BENCH_PROFILE_DIR']).name == name and
                Path(env['RUSTX_BENCH_PROFILE_SOCKET']).parent == Path(env['RUSTX_BENCH_PROFILE_DIR']),
                'CPU phase output/socket identity differs')
        if not args.raw_only:
            require(all(sha(path) == digest for path, digest in preload.items()), 'actual preload differs')
    else:
        require(len(argv) == 5 and not command['preload_sha256'] and not list(directory.glob('*.cpu')),
                'control unexpectedly preloaded/profiled')
    result = {'name': name, 'revision': revision, 'mode': mode,
              'window': {key: command[key] for key in ('start_utc', 'end_utc')},
              'build_head': build['head'], 'binary_sha256': build['sha256'],
              'manifest_sha256': sha(directory / 'manifest.json'), 'preload_sha256': command['preload_sha256'],
              'product': product(directory, revision, build, 'short-large', 'live-subscriber', argv)}
    if mode == 'cpu':
        result['cpu'] = cpu_profile(directory, build, command, counts, args.raw_only)
    return result

def validate_snapshot(snapshot, revision):
    tables = snapshot['tables']
    require(tables and 'request_configurations' in tables,
            'schema-specific request_configurations presence differs')
    for name, table in tables.items():
        integer(table['rows'], name + ' rows')
        require(table['column_value_bytes'], name + ' has no column values')
        for column, value in table['column_value_bytes'].items():
            integer(value, name + '.' + column + ' bytes')
    require(not any(name in tables for name in ('event_observation_readiness', 'transcript_observation_readiness')), 'connection-local readiness must not appear in main storage')
    event_columns = tables['events']['column_value_bytes']
    require({'observation_statistics', 'observation_execution', 'event_json'} <=
            event_columns.keys(), 'missing native/derived event columns')
    require('observation_json' not in event_columns,
            'retired event observation layout differs from the recorded revision')
    require('observation_source_overlay' in event_columns and not any(name in event_columns for name in ('observation_source_inline', 'observation_source_inline_bytes')), 'native-body overlay schema differs')
    require('snapshot_json' in tables['request_snapshots']['column_value_bytes'], 'missing native snapshot column')
    if 'request_configurations' in tables:
        require(set(tables['request_configurations']['column_value_bytes']) == {'digest', 'configuration_json'},
                'request_configurations column shape differs')
    kinds = snapshot['events_by_kind']
    require(len({row['kind'] for row in kinds}) == len(kinds), 'duplicate event kind')
    require(all(row['column_value_bytes'].keys() == tables['events']['column_value_bytes'].keys()
                for row in kinds), 'event kind column shape differs')
    for row in kinds:
        integer(row['rows'], 'event kind rows')
        for column, value in row['column_value_bytes'].items():
            integer(value, 'event kind ' + column)
    require(sum(row['rows'] for row in kinds) == tables['events']['rows'], 'event kind rows do not sum')
    require(all(sum(row['column_value_bytes'][column] for row in kinds) == value
                for column, value in tables['events']['column_value_bytes'].items()),
            'event kind byte values do not sum')
    duplicate = snapshot['equal_event_observation_json']
    require(duplicate == {'status': 'retired_layout_absent', 'table': 'events',
                          'column': 'observation_json', 'rows': None, 'native_bytes': None},
            'retired event observation column must be absent, not reported as a measured zero')
    require(snapshot.get('scope') == 'main_database_only; connection-local TEMP owner state and virtual generated columns are outside this read-only connection measurement',
            'column snapshot must declare main-only storage scope')
    names = []
    for name, pages, payload, count in snapshot['dbstat']:
        names.append(name)
        integer(pages, 'dbstat page bytes')
        integer(payload, 'dbstat payload bytes')
        integer(count, 'dbstat page count')
        require(payload <= pages, 'dbstat payload exceeds allocated page bytes')
    require(len(set(names)) == len(names), 'duplicate dbstat object')

def row_delta(before, after):
    require(before['column_value_bytes'].keys() == after['column_value_bytes'].keys(), 'column identity changed')
    values = {column: after['column_value_bytes'][column] - value
              for column, value in before['column_value_bytes'].items()}
    return {'rows': after['rows'] - before['rows'], 'column_value_bytes': values,
            'total_column_value_bytes': sum(values.values())}

def columns(args, revision, case, identities):
    directory = args.root / f'columns-{revision}-{case}'
    build = identities[revision]
    require(load(directory / 'identity-before.json')['build'] == build, 'column build identity differs')
    require(load(directory / 'phases.json') == PHASES, 'column synchronous phase sequence differs')
    argv = [build['binary'], TEST, '--exact', '--ignored', '--nocapture']
    prod = product(directory, revision, build, case, 'no-live-subscriber', argv)
    before, after = load(directory / 'before_measured_turns.json'), load(directory / 'after_turns.json')
    for snapshot in (before, after):
        validate_snapshot(snapshot, revision)
    require(before['path'] == after['path'] and before['tables'].keys() == after['tables'].keys(),
            'column database/table identity changed during measured phase')
    delta = {name: row_delta(table, after['tables'][name]) for name, table in before['tables'].items()}
    require(delta['events']['rows'] == 256 and delta['request_snapshots']['rows'] == 32,
            'measured native event/request count differs')
    before_kinds, after_kinds = ({row['kind']: row for row in snapshot['events_by_kind']}
                                for snapshot in (before, after))
    kinds = {}
    empty = {'rows': 0, 'column_value_bytes': dict.fromkeys(before['tables']['events']['column_value_bytes'], 0)}
    for name in sorted(before_kinds.keys() | after_kinds.keys(), key=str):
        kinds[str(name)] = row_delta(before_kinds.get(name, empty), after_kinds.get(name, empty))
    totals = {label: sum(sum(table['column_value_bytes'].values()) for table in snapshot['tables'].values())
              for label, snapshot in [('before', before), ('after', after)]}
    total_delta = sum(row['total_column_value_bytes'] for row in delta.values())
    require(total_delta == totals['after'] - totals['before'], 'logical total arithmetic differs')
    configurations = {label: snapshot['tables'].get('request_configurations')
                      for label, snapshot in [('before', before), ('after', after)]}
    return {'revision': revision, 'case': case, 'build_head': build['head'], 'binary_sha256': build['sha256'],
            'product': prod, 'before_sha256': sha(directory / 'before_measured_turns.json'),
            'after_sha256': sha(directory / 'after_turns.json'), 'phases_sha256': sha(directory / 'phases.json'),
            'logical_totals': totals, 'total_logical_delta': total_delta, 'table_deltas': delta,
            'event_kind_deltas': kinds, 'request_configurations_retained': configurations,
            'equal_event_observation_json': {label: snapshot['equal_event_observation_json']
                                            for label, snapshot in [('before', before), ('after', after)]},
            'timing_isolation': 'Synchronous phase acknowledgments and exact phase order verified. '
                                'The separately audited serial wrapper brackets this column producer with UTC timestamps; no timing values are mixed with formal products.'}

def comparison(before, after):
    return {'baseline': before, 'complete': after, 'difference': after - before,
            'complete_over_baseline': None if before == 0 else after / before}

def column_comparisons(rows):
    result = []
    for case in ('short-small', 'short-large'):
        pair = {row['revision']: row for row in rows if row['case'] == case}
        if pair.keys() != {'baseline', 'complete'}:
            continue
        before, after = pair['baseline'], pair['complete']
        fields = {'all_logical': comparison(before['total_logical_delta'], after['total_logical_delta'])}
        selected = [('request_snapshots_all', 'request_snapshots', None),
                    ('request_source_pages', 'request_source_pages', None),
                    ('native_snapshot_json', 'request_snapshots', 'snapshot_json'),
                    ('native_event_json', 'events', 'event_json'),
                    ('observation_event_json', 'events', 'observation_json'),
                    ('event_statistics', 'events', 'observation_statistics'),
                    ('event_execution', 'events', 'observation_execution')]
        for label, table, column in selected:
            def value(row):
                data = row['table_deltas'][table]
                return data['total_column_value_bytes'] if column is None else data['column_value_bytes'][column]
            if column is not None and column not in after['table_deltas'][table]['column_value_bytes']:
                require((table, column) == ('events', 'observation_json'),
                        'unexpected missing comparison column')
                fields[label] = {'baseline': (value(before) if column in before['table_deltas'][table]['column_value_bytes'] else None), 'complete': None, 'difference': None,
                                 'complete_over_baseline': None, 'status': 'retired_layout_absent',
                                 'note': 'Final events schema omits this former column; absence is not a measured zero. Total logical bytes include only actual stored columns.'}
            else:
                fields[label] = comparison(value(before), value(after))
        # Both schemas retain shared configuration. Include each revision's
        # actual measured configuration delta in its native snapshot total.
        config = after['table_deltas']['request_configurations']['total_column_value_bytes']
        fields['native_snapshot_and_configuration'] = comparison(
            before['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + before['table_deltas']['request_configurations']['total_column_value_bytes'],
            after['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + config)
        all_tables = {}
        for table in sorted(before['table_deltas'].keys() | after['table_deltas'].keys()):
            b, a = before['table_deltas'].get(table), after['table_deltas'].get(table)
            values = (comparison(b['total_column_value_bytes'], a['total_column_value_bytes']) if b is not None and a is not None else
                      {'baseline': None if b is None else b['total_column_value_bytes'], 'complete': None if a is None else a['total_column_value_bytes'],
                       'difference': None, 'complete_over_baseline': None, 'status': 'outside_measured_main_layout',
                       'note': 'Table absence from main is explicit. Connection-local TEMP memory/state is not observable from this collector and is not assigned zero.'})
            all_tables[table] = {'present_in_baseline': b is not None, 'present_in_complete': a is not None, **values}
        result.append({'case': case, 'logical_bytes': fields, 'all_table_logical_bytes': all_tables,
                       'shared_configuration_measured_delta': {'baseline': before['table_deltas']['request_configurations']['total_column_value_bytes'], 'complete': config},
                       'shared_configuration_note': 'Both revision retained totals are in columns; '
                                                    'seeded shared payload is not charged again as a measured-turn insertion; both schemas retain it.'})
    return result

def phase_points(path, expected=PHASES):
    points = load(path)
    require([p['phase'] for p in points] == expected, 'synchronous phase inventory differs')
    ticks = [integer(p['monotonic_ns'], 'phase time', 1) for p in points]
    require(all(a < b for a,b in zip(ticks,ticks[1:])), 'phase times not strictly increasing')
    return points, {p['phase']:p['monotonic_ns'] for p in points}

def wal_frames(directory, before, after, expected_phases):
    owners=collections.defaultdict(set)
    for snapshot in (before,after):
        require(snapshot['counts'] and snapshot['pages'] and snapshot['tables'],'empty database snapshot')
        for name,page,kind,cells,payload in snapshot['pages']:
            integer(page,'page',1);integer(cells,'cells');integer(payload,'payload');owners[page].add(name)
    require(before['path']==after['path'],'WAL target database changed')
    frames=collections.Counter();commits=0;pending={};phase='startup';allcommits=collections.Counter();txpages=[];tx=collections.Counter();active=False;seen=[];payloads=0;frame_bytes=0
    with (directory/'calls.strace').open() as stream:
        for line in stream:
            m=re.match(r'(\d+)\s+(.*)',line)
            if not m:continue
            pid,call=m.groups()
            if '<unfinished ...>' in call:
                require(pid not in pending,'duplicate unfinished syscall');pending[pid]=call.split('<unfinished ...>')[0];continue
            m=re.match(r'<\.\.\. \w+ resumed>(.*)',call)
            if m:
                require(pid in pending,'resumed syscall has no start');call=pending.pop(pid)+m[1]
            if 'UNIX-STREAM' in call:
                for boundary in expected_phases:
                    if '"'+boundary+'"' in call or '"'+boundary+'\\n"' in call:
                        seen.append(boundary)
                        if boundary=='before_measured_turns':phase='steady';active=True
                        elif boundary=='after_turns':phase='after_turns';active=False
                        break
            m=re.match(r'pwrite64\(\d+<([^>]+-wal)>, (.*), (\d+), (\d+)\) = (\d+)$',call)
            if not m:continue
            target,quoted,n,offset,ret=m.groups();n,offset,ret=map(int,(n,offset,ret));require(ret==n,'short WAL write')
            if active:
                require(target==before['path']+'-wal','unexpected measured WAL target')
                require(n in (24,32,4096),'unsupported measured WAL write shape')
                if n==4096:payloads+=1;require((offset-56)%4120==0,'WAL payload misaligned')
            if n!=24:continue
            data=ast.literal_eval('b'+quoted);require(len(data)==24,'bad frame header bytes')
            page,size=struct.unpack('>II',data[:8]);require(page>0 and (offset-32)%4120==0,'bad WAL frame geometry')
            if active:frames[page]+=1;tx[page]+=1;frame_bytes+=4120
            if size:
                allcommits[phase]+=1
                if active:commits+=1;txpages.append(sum(tx.values()));tx.clear()
    require(not pending and not tx and phase=='after_turns' and commits>0,'unclosed trace/transaction or missing measured commits')
    require(seen==expected_phases,'strace boundary phase inventory differs')
    require(payloads==sum(frames.values()),'WAL frame headers and page payload counts differ')
    bytable=collections.Counter()
    for page,n in frames.items():bytable['|'.join(sorted(owners[page])) or '<unmapped>']+=n
    delta={k:after['counts'][k]-before['counts'].get(k,0) for k in after['counts'] if after['counts'][k]!=before['counts'].get(k,0)}
    return {'steady_turns':32,'wal_write_commits':commits,'wal_frames':sum(frames.values()),'wal_frame_bytes':frame_bytes,
            'commits_by_phase':dict(allcommits),'wal_frames_by_snapshot_page_owner':dict(bytable.most_common()),
            'net_row_count_changes':delta,'transaction_page_counts':txpages,
            'raw_sha256':sha(directory/'calls.strace'),'matched_page_payloads':payloads,
            'limits':'WAL commit markers exclude read-only commits. Snapshot page owners are endpoint classifications, not exact ownership at each write; mixed and unmapped owners remain explicit. WAL bytes are not process write_bytes/device traffic and are not attributed CPU time.'}

def wal_diagnostic(args, label, build, case):
    directory=args.root/f'wal-{label}-{case}-rust'
    identity=load(directory/'identity-before.json');whole=load(args.root/f'wal-identity-{label}.json')
    require(identity['build']==build and identity['binary_sha256']==build['sha256'], 'WAL identity differs')
    require(whole['rust_sha256']==build['sha256'] and whole['rust_source']==build['head'], 'WAL whole-run identity differs')
    require(identity['runner_sha256']==sha(args.root/'run-wal-rust.py'), 'WAL producer changed')
    argv=[build['binary'],TEST,'--exact','--ignored','--nocapture']
    require(identity['argv']==argv, 'WAL executes an unexpected product')
    prod=product(directory,label,build,case,'no-live-subscriber',argv)
    points,_=phase_points(directory/'phases.json')
    records=load(args.root/f'wal-records-{label}.json')
    require([(r['case'],r['engine']) for r in records]==[(case,'rust') for case in ('short-small','short-large')], 'WAL product inventory differs')
    require(all(r['accepted'] is True and r['error'] is None and r['diagnostic_error']==[] and 0<r['start_ns']<r['end_ns'] for r in records), 'WAL product failed')
    require(records[0]['end_ns']<=records[1]['start_ns'], 'WAL products overlap')
    record=next(r for r in records if r['case']==case)
    require(record['start_ns']<=points[0]['monotonic_ns']<points[-1]['monotonic_ns']<=record['end_ns'], 'WAL boundaries outside product')
    before=load(directory/'before_measured_turns-database.json');after=load(directory/'after_turns-database.json')
    require(len(before)==len(after)==1, 'WAL database inventory differs')
    derived=wal_frames(directory,before[0],after[0],PHASES)
    retained=load(args.root/f'wal-summary-{label}.json')[case+'-rust']
    require(all(k in derived and retained[k]==derived[k] for k in retained if k!='limitations'), 'WAL summary arithmetic differs')
    return {'label':label,'case':case,'engine':'rust','product':prod,'summary':derived,'identity':identity,
            'phases':points,'command':record,'identity_sha256':sha(directory/'identity-before.json'),
            'before_sha256':sha(directory/'before_measured_turns-database.json'),'after_sha256':sha(directory/'after_turns-database.json'),
            'phases_sha256':sha(directory/'phases.json'),'whole_identity_sha256':sha(args.root/f'wal-identity-{label}.json')}

def producer_windows(args, identities):
    rows=load(args.root/'diagnostic-commands.json')
    expected=['columns-baseline','columns-complete','profiles','profile-reports','wal-baseline','wal-summary-baseline','wal-complete','wal-summary-complete']
    require([r['name'] for r in rows]==expected, 'diagnostic producer inventory/order differs')
    commands={'profiles':('run-profiles.py',[]),'profile-reports':('profile-reports.py',[])}
    for label,build in identities.items():
        commands['columns-'+label]=('columns-complete.py',['--binary',build['binary'],'--label',label])
        commands['wal-'+label]=('run-wal-rust.py',['--binary',build['binary'],'--label',label])
        commands['wal-summary-'+label]=('analyze-wal-verified.py',['--label',label])
    for row in rows:
        require(row['status']=='complete' and row['exit']==0, 'diagnostic producer failed')
        command=row['command'];require(len(command)>=2 and Path(command[0]).name.startswith('python'), 'invalid diagnostic interpreter')
        name=Path(command[1]).name
        require((name,command[2:])==commands[row['name']], 'unexpected diagnostic producer/arguments')
        require(row['producer_sha256']==sha(args.root/name), 'diagnostic producer hash differs')
        require(all((args.root/(row['name']+suffix)).is_file() for suffix in ('.stdout','.stderr')), 'missing diagnostic command logs')
    spans=[window(r['start_utc'],r['end_utc']) for r in rows]
    require(all(a[1]<=b[0] for a,b in zip(spans,spans[1:])), 'diagnostic producers overlap')
    left,right=(load(args.root/f'diagnostic-source-{side}.json') for side in ('before','after'))
    require({k:v for k,v in left.items() if k!='utc'}=={k:v for k,v in right.items() if k!='utc'}, 'diagnostic sources changed')
    require(left['files']==identities['complete']['source_files'] and left['head']==identities['complete']['head'], 'diagnostic source identity differs')
    require(left['runner_sha256']==sha(args.root/'run-diagnostics.py'), 'diagnostic wrapper changed')
    require(utc(left['utc'])<=spans[0][0] and spans[-1][1]<=utc(right['utc']), 'diagnostic source snapshots do not bracket products')
    preflight=load(args.root/'premeasurement.json')
    require(preflight['accepted'] is True and utc(preflight['completed_utc'])<=utc(left['utc']), 'diagnostics predate successful premeasurement')
    formal=load(args.root/'direct-cohorts/commands.json')
    require(left['fixtures']==formal['source_before']['fixtures'], 'formal/diagnostic fixtures differ')
    if not args.raw_only:
        require(all(sha(args.repo/path)==value for path,value in left['files'].items()), 'diagnostic current source differs')
        actual={str(p.relative_to(args.repo)):sha(p) for p in sorted((args.repo/'benchmarks/runtime').rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
        require(actual==left['fixtures'], 'diagnostic current fixtures differ')
    return {'verified':True,'wrappers':rows,'sha256':sha(args.root/'diagnostic-commands.json'),
            'source_before_sha256':sha(args.root/'diagnostic-source-before.json'),'source_after_sha256':sha(args.root/'diagnostic-source-after.json')}

def formal_binding(args, identities, producers, profiles):
    formal=load(args.formal_audit)
    require(formal['accepted'] is True and formal['errors']==[] and formal['datasets']['direct']['derived_products']==120, 'direct formal audit incomplete')
    require(formal['script_sha256']==sha(args.root/'direct-audit.py'), 'formal auditor identity differs')
    require(formal['mode'] in ('strict','raw-only'), 'unknown formal audit mode')
    if not args.raw_only:require(formal['mode']=='strict' and formal['strict_identity_verified'] is True, 'formal strict identity missing')
    for key,label in [('before','baseline'),('after','complete')]:
        require(formal['identities'][key]=={k:identities[label][k] for k in ('head','production_tree','sha256')}, 'formal diagnostic build differs')
    plan=load(args.root/'direct-cohorts/commands.json')
    require(formal['identities']['commands_sha256']==sha(args.root/'direct-cohorts/commands.json'), 'formal queue changed')
    span=window(plan['source_before']['utc'],plan['source_after']['utc'])
    require(all(disjoint(span,window(r['start_utc'],r['end_utc'])) for r in producers['wrappers']), 'formal and diagnostic products overlap')
    profile_span=next(window(r['start_utc'],r['end_utc']) for r in producers['wrappers'] if r['name']=='profiles')
    spans=[window(r['window']['start_utc'],r['window']['end_utc']) for r in profiles]
    require(all(profile_span[0]<=p[0]<p[1]<=profile_span[1] for p in spans), 'profile interval outside producer window')
    require(all(a[1]<=b[0] for a,b in zip(spans,spans[1:])), 'profile products overlap')
    return {'file':str(args.formal_audit),'sha256':sha(args.formal_audit),'mode':formal['mode'],'products':120,
            'scope':'Fresh paired Rust-only formal products; twelve diagnostic products remain separate. All producer UTC windows are disjoint from the formal source window.'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=HERE);parser.add_argument('--repo',type=Path,default=REPO)
    parser.add_argument('--raw-only',action='store_true');parser.add_argument('--expect-rust-sha256');parser.add_argument('--formal-audit',type=Path)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    require(not args.output.exists(), 'retain previous audit; choose another output')
    args.baseline_identity=args.root/'baseline-build/identity.json';args.candidate_identity=args.root/'candidate-complete-build/identity.json'
    args.formal_audit=args.formal_audit or args.root/'direct-audit.json'
    report={'accepted':False,'mode':'raw-only' if args.raw_only else 'strict','errors':[],'profiles':[],'columns':[],'wal':[],'identities':{},'build_receipts':{},'script_sha256':sha(__file__)}
    def check(name,fn):
        try:return fn()
        except Exception as error:report['errors'].append(f'{name}: {type(error).__name__}: {error}');return None
    identities={}
    for label in ('baseline','complete'):
        result=check(label+' build',lambda label=label:verify_build(args,label))
        if result:
            build,receipt=result;identities[label]=build;report['build_receipts'][label]=receipt
            report['identities'][label]={k:build[k] for k in ('head','production_tree','sha256','harness','rustc','cargo')}
    if len(identities)==2:
        check('same build harness/toolchain',lambda:require(all(identities['baseline'][k]==identities['complete'][k] for k in ('harness','rustc','cargo')) and identities['baseline']['sha256']!=identities['complete']['sha256'], 'build pair differs'))
        report['producer_windows']=check('producer windows',lambda:producer_windows(args,identities))
    for label,build in identities.items():
        for case in ('short-small','short-large'):
            row=check(f'columns-{label}-{case}',lambda label=label,case=case:columns(args,label,case,identities))
            if row:report['columns'].append(row)
            row=check(f'wal-{label}-{case}',lambda label=label,build=build,case=case:wal_diagnostic(args,label,build,case))
            if row:report['wal'].append(row)
    commands=check('profile commands',lambda:load(args.root/'profile-commands.json'))
    counts=check('CPU counts',lambda:load(args.root/'cpu-counts.json'))
    if commands is not None and counts is not None:
        check('profile inventory',lambda:require([r['name'] for r in commands]==PROFILE_NAMES and len(counts)==2 and {r['name'] for r in counts}=={n for n in PROFILE_NAMES if n.endswith('-cpu')} and commands[1]['preload_sha256']==commands[3]['preload_sha256'], 'profile/count/preload inventory differs'))
        for command in commands:
            label=command['name'].split('-')[1]
            if label in identities:
                row=check(command['name'],lambda command=command:profile(args,command,identities,{r['name']:r for r in counts}))
                if row:report['profiles'].append(row)
    report['column_comparison']=check('column arithmetic',lambda:column_comparisons(report['columns']))
    report['overlay_comparison']=[]
    for case in ('short-small','short-large'):
        pair={r['revision']:r for r in report['columns'] if r['case']==case}
        if pair.keys()=={'baseline','complete'}:
            old=pair['baseline']['table_deltas']['events']['column_value_bytes'];new=pair['complete']['table_deltas']['events']['column_value_bytes']
            report['overlay_comparison'].append({'case':case,'stored_derived_source_bytes':comparison(old['observation_source_overlay'],new['observation_source_overlay']), 'scope':'Both revisions retain the same native-body overlay representation; values are independently measured in each product.'})
    if report.get('producer_windows') and len(identities)==2:
        report['formal_audit']=check('formal binding',lambda:formal_binding(args,identities,report['producer_windows'],report['profiles']))
    report['accepted']=not report['errors'] and all(len(report[k])==4 for k in ('profiles','columns','wal')) and report.get('formal_audit') is not None
    report['recorded_build_identity_verified']=len(identities)==2 and report['accepted']
    report['strict_identity_verified']=report['actual_binary_and_preload_verified']=report['accepted'] and not args.raw_only
    report['product_count']=sum(len(report[k]) for k in ('profiles','columns','wal'))
    report['limits']=['Diagnostics are isolated from formal products, not pooled into timing statistics.', 'Endpoint dbstat page ownership is not exact per-write table attribution.', 'Main-only logical values exclude TEMP and transient/deleted values and are not WAL or process write bytes.', 'Inclusive CPU buckets overlap; zero sampled frames do not prove absence.', 'Raw-only follows only selected retained paths, never embedded absolute binary, preload or database paths.', 'No Pi or DeepSeek product executes in this round.']
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'accepted':report['accepted'],'product_count':report['product_count'],'errors':report['errors']},indent=2))
    return int(not report['accepted'])

if __name__=='__main__':raise SystemExit(main())
