from pathlib import Path
import re
r=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
p=r/'src/runtime_client/checkpoint/prepared_transcript.rs';s=p.read_text();s=s.replace('native: OnceLock<Arc<RuntimeClientTranscriptEntry>>,','native: Arc<RuntimeClientTranscriptEntry>,');s=s.replace('pub(crate) fn new(conversation: ConversationId, value: RuntimeClientTranscriptEntry)', 'pub(crate) fn new(conversation: ConversationId, value: Arc<RuntimeClientTranscriptEntry>)');s=s.replace('let (body, decoration) = body::Owner::new(conversation, value);','let (body, decoration) = body::Owner::new(conversation, Arc::clone(&value));');s=s.replace('            native: OnceLock::new(),','            native: value,',1)
s=re.sub(r'    pub\(crate\) fn native_entry\(&self\) -> Arc<RuntimeClientTranscriptEntry> \{.*?\n    \}', '    pub(crate) fn native_entry(&self) -> Arc<RuntimeClientTranscriptEntry> {\n        Arc::clone(&self.0.native)\n    }', s, count=1, flags=re.S);s=s.replace('pub(crate) fn with_decoration(&self, value: &RuntimeClientTranscriptEntry)', 'pub(crate) fn with_decoration(&self, value: &Arc<RuntimeClientTranscriptEntry>)');s=s.replace('            native: OnceLock::new(),','            native: Arc::clone(value),');s=s.replace('PreparedTranscriptRow::new(conversation.clone(), entry.as_ref().clone())','PreparedTranscriptRow::new(conversation.clone(), Arc::clone(entry))');p.write_text(s)
p=r/'src/runtime_client/checkpoint/prepared_transcript/body.rs';s=p.read_text();a=s.index('fn inline<');z=s.index('    // The body',a);s=s[:a]+'''fn inline<S: Serialize, T: Serialize + serde::de::DeserializeOwned>(
    value: &S,
    raw_limit: usize,
) -> Option<Inline<T>> {
'''+s[z:];s=s.replace('    value: Value,\n    inline:', '    value: Arc<RuntimeClientTranscriptEntry>,\n    inline:')
a=s.index('    pub(super) fn new(\n',s.index('impl Owner {'));z=s.index('    fn inline(&self)',a);s=s[:a]+'''    pub(super) fn new(
        conversation: ConversationId,
        value: Arc<RuntimeClientTranscriptEntry>,
    ) -> (Arc<Self>, Decoration) {
        let decoration = Decoration::from_entry(&value);
        (Arc::new(Self {
            conversation, value,
            inline: OnceLock::new(), fallback: OnceLock::new(),
        }), decoration)
    }
'''+s[z:]
s=s.replace('inline(&self.value, super::super::CHECKPOINT_ITEM_BYTES).map(|part| Inline {','inline(&BodyFields::from(self.value.as_ref()), super::super::CHECKPOINT_ITEM_BYTES).map(|part: Inline<Value>| Inline {')
s=s.replace('    pub(super) fn entry(&self, decoration: &Decoration) -> RuntimeClientTranscriptEntry {\n        self.value.entry(decoration)\n    }','''    #[cfg(test)]
    pub(super) fn entry(&self, decoration: &Decoration) -> RuntimeClientTranscriptEntry {
        let mut value = self.value.as_ref().clone();
        value.turn_process = decoration.turn_process.clone();
        value.response_pending = decoration.response_pending;
        value.completed_response = decoration.completed_response.clone();
        value
    }''')
s=s.replace('self.conversation == other.conversation && self.value == other.value','self.conversation == other.conversation\n            && self.value.cursor == other.value.cursor\n            && self.value.tool_calls == other.value.tool_calls\n            && self.value.item == other.value.item')
anchor='#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]\npub(super) struct Decoration'
insert='''/// Serialize the three immutable body fields without copying the native row.
#[derive(Serialize)]
struct BodyFields<'a> {
    tool_calls: &'a [ForegroundToolExecution],
    cursor: RuntimeClientTranscriptCursor,
    item: &'a RuntimeClientTranscriptItem,
}
impl<'a> From<&'a RuntimeClientTranscriptEntry> for BodyFields<'a> {
    fn from(value: &'a RuntimeClientTranscriptEntry) -> Self {
        Self { tool_calls: &value.tool_calls, cursor: value.cursor, item: &value.item }
    }
}

''';assert anchor in s;s=s.replace(anchor,insert+anchor);p.write_text(s)
p=r/'src/durable/sqlite/observation_response/cache.rs';s=p.read_text().replace('value: &crate::runtime_client::snapshot::RuntimeClientTranscriptEntry,','value: &Arc<crate::runtime_client::snapshot::RuntimeClientTranscriptEntry>,');p.write_text(s)
p=r/'src/durable/sqlite/observation_checkpoint_tests.rs';s=p.read_text().replace('PreparedTranscriptRow::new(cut.read.conversation_id.clone(), entry.as_ref().clone())','PreparedTranscriptRow::new(cut.read.conversation_id.clone(), entry)');p.write_text(s)
