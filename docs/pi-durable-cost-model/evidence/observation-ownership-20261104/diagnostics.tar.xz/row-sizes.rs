fn main(){
 macro_rules! s{($($t:ty),*)=>{$(println!("{} {}",stringify!($t),std::mem::size_of::<$t>());)*}}
 use rustx::runtime_client::{snapshot::*,response::*};
 s!(RuntimeClientTranscriptEntry,RuntimeClientTranscriptItem,Option<TurnProcessView>,Option<CompletedResponseView>,ForegroundToolExecution);
}
