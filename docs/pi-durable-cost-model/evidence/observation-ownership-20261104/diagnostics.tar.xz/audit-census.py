"""Reparse exact native Drop owner addresses/counts and retained-vector storage."""
import hashlib,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());median=statistics.median;products=[]
def parse(name,side):
 d=r/name;identity=load(d/'identity.json');n=identity['sessions'];assert identity['history_turns']==8 and identity['widths']==[1] and identity['rounds']==1
 complete=load(d/'completed.json');assert complete['accepted'];routing=load(d/'routing.json');ids={v['conversation_id']:i for i,v in enumerate(routing)}
 rows=[json.loads(v.removeprefix('OWNER_CENSUS ')) for v in (d/'server.stderr').read_text().splitlines() if v.startswith('OWNER_CENSUS ')]
 assert len(rows)==n and len({v['conversation'] for v in rows})==n
 kept=[v for v in rows if complete['turn_counts'][str(ids[v['conversation']])]==8];assert len(kept)==n-2
 for row in kept:
  assert row['replacements']==8 and row['replay']>=80
  for value in row['census'].values():assert value['references']>=value['unique']>0 and sum(value['roles'].values())==value['references']
  for value in row.get('storage',{}).values():assert value['cap']>=value['len'] and value['bytes']>=value['unused_bytes']>=0
 keys=sorted({key for v in kept for key in v['census']});summary={}
 for key in keys:
  xs=[v['census'][key] for v in kept if key in v['census']]
  summary[key]={'sessions':len(xs),'median_references':median(v['references'] for v in xs),'median_unique':median(v['unique'] for v in xs),'inline_total_bytes':sum(v['inline_bytes'] for v in xs),'native_json_total_bytes':sum(v['native_json_bytes'] for v in xs)}
 slots={}
 for key in sorted({key for v in kept for key in v.get('storage',{})}):
  xs=[v['storage'][key] for v in kept if key in v.get('storage',{})];slots[key]={k:median(v[k] for v in xs) for k in ['len','cap','bytes','unused_bytes']}
 return {'directory':name,'side':side,'sessions':n,'exact8_sessions':len(kept),'sha256':hashlib.sha256((d/'server.stderr').read_bytes()).hexdigest(),'replacement_counts':[v['replacements'] for v in kept],'replay_counts':[v['replay'] for v in kept],'owners':summary,'storage_medians':slots,'records':kept}
products=[parse('census-before-drop','before'),parse('capacity-before','before-capacity'),parse('census-after-drop','after')]
a,b=products[0],products[2];assert a['exact8_sessions']==b['exact8_sessions']==126
assert b['owners']['transcript_rows']['median_unique']<a['owners']['transcript_rows']['median_unique']
for key in ['events','metadata_frontiers','metadata_bindings']:assert b['storage_medians'][key]['unused_bytes']==0
out={'accepted':True,'products':products,'scope':'Private intrusive rootO0/default diagnostics only. Exact8subset selected using completed native session/turn binding; independently reparsed canonical images are in native-audit. Pointer census traverses current/replay bodies and current prepared head; it is not an exhaustive allocator inventory. Unique inline sizes and JSON representations are not PSS/live-heap partitions and overlap container bodies. Extra capacity-before has6eligible sessions, before/after owner cohorts126each; capacity samples are descriptive, not paired PSS estimates. No event/window/budget reduction; all selected sessions retain8replacement checkpoints. Normalized and native rows remain distinct when admission/normalization requires it.'}
(r/'census-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'accepted':True,'exact8':[v['exact8_sessions'] for v in products],'transcript_unique_before_after':[a['owners']['transcript_rows']['median_unique'],b['owners']['transcript_rows']['median_unique']]}))
