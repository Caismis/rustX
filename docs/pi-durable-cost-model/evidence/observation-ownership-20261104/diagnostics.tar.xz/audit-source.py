"""Recheck the final source-identical22command validation and fresh ordinary artifacts."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());d=r/'checks-final';before=load(d/'source-before.json');after=load(d/'source-after.json');build=load(r/'candidate-build/identity.json');cmds=load(d/'commands.json');assert before==after;assert len(cmds)==22 and all(v['exit']==0 for v in cmds);assert before['files']==build['source_files'] and len(before['files'])==974;assert build['verified'] and all(v['exit']==0 for v in build['commands']);counts={};dups=[]
for row in cmds:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in counts or counts[key]==m[2]
    if key in counts:dups.append(m[1])
    counts[key]=m[2]
summary=load(r/'checks-summary.json');assert summary['tests']=={s:sum(v==s for v in counts.values()) for s in ['ok','ignored']};assert dups==summary['duplicates'];assert summary['helpers']==before['helpers']
rootartifacts=[json.loads(v) for v in (r/'candidate-build/build.stdout').read_text().splitlines() if v.startswith('{')];rootartifacts=[v for v in rootartifacts if v.get('reason')=='compiler-artifact' and v['target']['src_path'].startswith('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/')];assert rootartifacts and all(v['profile']['opt_level']=='3' and v['features']==[] and not v['fresh'] for v in rootartifacts)
dependency_artifacts={}
for side,directory in [('before','before-build-records'),('after','candidate-build')]:
 artifacts=[json.loads(line) for line in(r/directory/'build.stdout').read_text().splitlines() if line.startswith('{')]
 dependency_artifacts[side]=[{key:v[key] for key in ['package_id','features','profile','filenames']} for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name']=='serde_json']
 target_json={side:[v for v in values if v['profile']['opt_level']=='3'] for side,values in dependency_artifacts.items()}
assert len(target_json['before'])==len(target_json['after'])==1
assert target_json['before'][0]['package_id']==target_json['after'][0]['package_id']
assert target_json['before'][0]['features']==target_json['after'][0]['features']
result={'accepted':True,'head':build['head'],'source_inputs':974,'helpers':before['helpers'],'commands':22,'tests':summary['tests'],'duplicates':len(dups),'serde_json_artifacts':dependency_artifacts,'ordinary_root_artifacts':len(rootartifacts),'source_map_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'scope':'All22commands passed against exactly the same974source/test/Cargo inputs and2capacity helpers. Overlapping broad/focused test filters and artifact-lineage cases are deduplicated. Ordinary root artifacts are freshO3/default; correctness is separate rootO0/all-features. Committed v52 schema/fixtures test passes without artifact regeneration. Failed/partial development attempts remain; focused development pretests are not added again to the final unique test count.'}
(r/'source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'tests':summary['tests']}))
