"""Rust-only streamed/large/tool/cancel functional and reopen comparisons; one pair per case."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run,TEST
while not (r/'products-completed.json').exists():time.sleep(2)
while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(2)
os.sched_setaffinity(0,[2,8]);out=r/'functional-products';out.mkdir(exist_ok=False);rows=[];binaries={'before':Path('/home/capi/.cache/rustx-pr485-empty-session-20261103/candidate-build/conformance'),'after':r/'candidate-build/conformance'}
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])}
for i,case in enumerate(['stream','large','tool','cancel']):
 for side in (['before','after'] if i%2==0 else ['after','before']):
  stem=out/f'{case}-{side}';at=datetime.datetime.now(datetime.timezone.utc).isoformat();result=run([str(binaries[side]),TEST,'--exact','--ignored','--nocapture'],stem,case,env|{'UV_OFFLINE':'1','RUSTX_BENCH_CASE':case,'RUSTX_BENCH_OBSERVER_MODE':'no-live-subscriber','RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json'))},repo/'test-support/fake-provider');row={'side':side,'case':case,'accepted':result['accepted'],'start_utc':at,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':hashlib.sha256(binaries[side].read_bytes()).hexdigest()};rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(case,side,result['accepted'],flush=True);assert result['accepted'],result.get('error')
 p=subprocess.run(['node','benchmarks/runtime/compare-http.mjs',str(out/f'{case}-before.json'),str(out/f'{case}-after.json'),str(out/f'{case}-comparison.json')],cwd=repo,capture_output=True,text=True);(out/f'{case}-comparison.stderr').write_text(p.stderr);assert p.returncode==0,p.stderr
(out/'completed.json').write_text(json.dumps({'accepted':True,'products':8,'scope':'Functional/reopen/request comparisons only; a single pair is not a performance confidence claim.'})+'\n')

(r/'functional-completed.json').write_text('{"accepted":true}\n')
