"""Package only immutable evidence from this turn; exclude live/secret/build payloads."""
import hashlib
import json
import shutil
import tarfile
from pathlib import Path

r = Path(__file__).resolve().parent
out = Path('/home/capi/.cache/rustx-pr485-observation-ownership-publish-20261104')
assert not out.exists()
out.mkdir()
assert json.loads((r / 'audits-completed.json').read_text())['accepted']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
groups = {'ordinary-fixed.tar.xz': [], 'ordinary-rotating.tar.xz': [], 'diagnostics.tar.xz': []}
excluded = {'runtime', 'workspaces', 'node_modules', '.git', '__pycache__', 'target', '.env', 'token', 'probe-worktree', 'integration-worktree'}
for p in sorted(r.rglob('*')):
    rel = p.relative_to(r)
    if not p.is_file() or p.is_symlink() or any(part in excluded for part in rel.parts):
        continue
    if p.name in ['rustx', 'conformance', 'provider.stdout', 'WORK-IN-PROGRESS.txt', 'report-draft.md']:
        continue
    if p.name in ['sizes', 'row-sizes', 'vector-capacity'] or p.name.startswith('probe-') and p.name.endswith('-rustx'):
        continue
    if p.suffix in ['.rlib', '.rmeta', '.so', '.o', '.pyc'] or '.so.' in p.name:
        continue
    top = rel.parts[0]
    archive = ('ordinary-fixed.tar.xz' if top.startswith('ordinary-') else
               'ordinary-rotating.tar.xz' if top.startswith('rotating-') else 'diagnostics.tar.xz')
    groups[archive].append(p)
manifest = {'archives': [], 'members': [],
            'scope': 'New turn only. Full structured provider reports, complete closed consistent images and wire checks, all raw native owner/vector diagnostics and heap profiles/symbolization, frozen inputs/check/build maps/logs/failures. Excludes mutable workspaces, live databases, dependencies, authentication, duplicated provider stdout and actual native/compiler/library artifacts; stored prearchive proofs cover omitted bytes.'}
for name, paths in groups.items():
    dest = out / name
    with tarfile.open(dest, 'w:xz', preset=6) as archive:
        for p in paths:
            rel = str(p.relative_to(r))
            record = {'archive': name, 'path': rel, 'bytes': p.stat().st_size, 'sha256': sha(p)}
            info = archive.gettarinfo(str(p), arcname=rel)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with p.open('rb') as source:
                archive.addfile(info, source)
            manifest['members'].append(record)
    assert dest.stat().st_size < 95_000_000, (name, dest.stat().st_size)
    manifest['archives'].append({'name': name, 'bytes': dest.stat().st_size, 'sha256': sha(dest)})
    print(name, dest.stat().st_size, flush=True)
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
shutil.copyfile(r / 'replay.py', out / 'replay.py')
print(json.dumps({'members': len(manifest['members'])}), flush=True)
