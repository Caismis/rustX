import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');probe=r/'probe-worktree'
while True:
 rows=[json.loads(v) for v in (r/'probe-drop-o0-build.stdout').read_text().splitlines() if v.startswith('{')]
 if any(v.get('reason')=='build-finished' for v in rows):break
 time.sleep(2)
assert rows[-1]['reason']=='build-finished' and rows[-1]['success']
shutil.copy2(Path('/home/capi/.cache/rustx-pr485-target/release/rustx'),r/'probe-before-drop-rustx')
root=[v for v in rows if v.get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['src_path'].startswith(str(probe))];assert root and all(v['profile']['opt_level']=='0' for v in root)
(r/'probe-before-drop.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=probe));shutil.copyfile(probe/'src/runtime_client/projection/ownership_probe.rs',r/'ownership-probe-before-drop.rs')
(r/'probe-before-drop-identity.json').write_text(json.dumps({'sha256':hashlib.sha256((r/'probe-before-drop-rustx').read_bytes()).hexdigest(),'source':{str(p.relative_to(probe)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (probe/'src').rglob('*') if p.is_file()},'root_artifacts':root,'scope':'Intrusive per-Projection Drop census only, rootO0/default, dependenciesoptimized. No ordinary memory/CPU/latency claim; full native protocol/HTTP/history/cancel/reopen workload preserved. Exact8turn subset excludes two additional-active sessions and empty reloads.'},indent=2)+'\n')
while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(2)
cmd=['python3',str(repo/'benchmarks/runtime/app-server-capacity.py'),'--binary',str(r/'probe-before-drop-rustx'),'--output',str(r/'census-before-drop'),'--sessions','128','--history','8','--widths','1','--rounds','1']
with (r/'census-before-drop.stdout').open('x') as so,(r/'census-before-drop.stderr').open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
print(p.returncode,flush=True);assert p.returncode==0
