"""Bind intentionally excluded live artifacts and committed source before packaging."""
import hashlib,json,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=load(r/'source-audit.json');identity=load(r/'candidate-build/identity.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==source['head']
for name,digest in identity['source_files'].items():
 assert sha(repo/name)==digest
 assert hashlib.sha256(subprocess.check_output(['git','show',source['head']+':'+name],cwd=repo)).hexdigest()==digest
for name,digest in source['helpers'].items():assert sha(repo/name)==digest
before=Path('/home/capi/.cache/rustx-pr485-empty-session-20261103/candidate-build');executables=[]
for side,d,names in [('before',before,['rustx','conformance']),('after',r/'candidate-build',['rustx','conformance']),('development',r,['probe-before-rustx']),('census-before',r,['probe-before-drop-rustx']),('capacity-before',r,['probe-before-capacity-rustx']),('census-after',r,['probe-after-rustx'])]:
 for name in names:
  p=d/name;executables.append({'side':side,'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
libraries=[{'side':side,'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for side,d in [('before',before),('after',r/'candidate-build')] for p in [d/'librustx.rlib']]
for row in load(r/'product-commands.json'):
 expected=next(v['sha256'] for v in executables if v['side']==row['side'] and v['path'].endswith('/rustx'));assert load(r/row['directory']/'identity.json')['sha256']==expected
for row in load(r/'diagnostic-commands.json'):
 assert row['actual_native_sha256'] in {v['sha256'] for v in executables}
for row in load(r/'profiler-identity.json').values():assert sha(Path(row['path']))==row['sha256']
for row in load(r/'symbol-commands.json'):
 assert sha(r/row['output'])==row['output_sha256'] and sha(Path(row['command'][-1]))==row['profile_sha256'] and sha(Path(row['command'][-2]))==row['native_sha256']
pi=Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/pi-memory-audit.json');ref=load(r/'prior-pi-memory-reference.json');assert sha(pi)==ref['original_audit_sha256'] and load(pi)['points']==ref['points']
(r/'source.patch').write_bytes(subprocess.check_output(['git','diff','--binary','659023375651c8494de9af9636acb9684c3f2162',source['head'],'--','src','tests','Cargo.toml','Cargo.lock'],cwd=repo))
artifacts=[json.loads(v) for v in (r/'probe-after-build.stdout').read_text().splitlines() if v.startswith('{')];roots=[v for v in artifacts if v.get('reason')=='compiler-artifact' and '/probe-worktree/' in v['target']['src_path']];assert roots and all(v['profile']['opt_level']=='0' and v['features']==[] for v in roots)
wrappers=[{'path':p.name,'sha256':sha(p)} for p in [r/'heap-before.sh',r/'heap-after.sh']]
proof={'accepted':True,'source_head':source['head'],'source_inputs':source['source_inputs'],'source_map_sha256':source['source_map_sha256'],'executables':executables,'private_census_root_artifacts':roots,'libraries':libraries,'wrappers':wrappers,'profiler_identity_sha256':sha(r/'profiler-identity.json'),'heap_helper_source_sha256':sha(r/'heap-sample.cc'),'prior_pi_reference_sha256':sha(r/'prior-pi-memory-reference.json'),'source_patch_sha256':sha(r/'source.patch'),'symbol_commands':len(load(r/'symbol-commands.json')),'new_pi_deepseek_products':0,'scope':'Current committed source and actual preserved binary/library/wrapper/symbol-input bytes checked before exclusion. Private census builds carry their separate source patches and added module, rootO0/default except the unused-developmentO3probe. Offline replay checks stored byte proofs rather than rehashing absent binaries.'}
(r/'prearchive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'accepted':True,'executables':len(executables)}))
