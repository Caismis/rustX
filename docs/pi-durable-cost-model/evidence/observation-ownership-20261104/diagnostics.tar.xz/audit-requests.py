"""Compare complete provider request bodies by native session/turn, including tool schemas."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());cmds=load(r/'product-commands.json');groups={};rows=[]
for v in cmds:assert v['exit']==0;groups.setdefault((v['family'],v['pair']),{})[v['side']]=v['directory']
def corpus(name):
 result={}
 for row in load(r/name/'provider-report.json')['requests']:
  body=row['body'];body=json.loads(body) if isinstance(body,str) else body;markers=re.findall(r'capacity turn session=(\d{4}) turn=(\d{4})',json.dumps(body['messages']));assert markers;key=tuple(map(int,markers[-1]));assert key not in result;result[key]=json.dumps(body,ensure_ascii=False,separators=(',',':')).encode()
 return result
for (family,pair),sides in groups.items():
 a,b=corpus(sides['before']),corpus(sides['after']);assert a.keys()==b.keys(),(family,pair,'native request binding');assert all(a[k]==b[k] for k in a),(family,pair,'full body or field-order difference');digest=hashlib.sha256()
 for k in sorted(a):digest.update(json.dumps(k).encode());digest.update(b'\0');digest.update(a[k]);digest.update(b'\n')
 rows.append({'family':family,'pair':pair,'before':sides['before'],'after':sides['after'],'requests_per_side':len(a),'complete_body_corpus_sha256':digest.hexdigest()})
(r/'requests-audit.json').write_text(json.dumps({'accepted':True,'pairs':rows,'scope':'Every complete provider request body, including tools/schemas/nulls/field order, matches by session/turn. No body field, path, time or identity is normalized or ignored. Scheduling order is represented by native request binding, not arrival order.'},indent=2)+'\n');print(json.dumps({'accepted':True,'pairs':len(rows),'requests_per_side':sum(v['requests_per_side'] for v in rows)}))
