use rustx::runtime_client::checkpoint::{CollectionFrontier, MetadataFragment};
fn main(){
 let raw:Vec<_>=(0..36).map(|i|CollectionFrontier{domain:format!("domain-{i}"),revision:1,total:1,loaded:1,next_offset:None}).collect();
 let old_bytes=raw.capacity()*std::mem::size_of::<CollectionFrontier>();
 let values:Vec<_>=raw.into_iter().map(MetadataFragment::from).collect();
 println!("source-allocation={old_bytes} mapped-len={} mapped-capacity={} mapped-allocation={} actual-pointer-bytes={}",values.len(),values.capacity(),values.capacity()*std::mem::size_of::<MetadataFragment<CollectionFrontier>>(),values.len()*std::mem::size_of::<MetadataFragment<CollectionFrontier>>());
}
