from pathlib import Path
r=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
def edit(name,a,b):
 p=r/name;s=p.read_text();assert a in s,(name,a);p.write_text(s.replace(a,b))
edit('src/runtime_client/checkpoint/prepared_transcript/body.rs','    #[cfg(test)]\n    pub(super) fn entry(&self, decoration:', '    pub(super) fn entry(&self, decoration:')
edit('src/runtime_client/projection/shared_snapshot.rs','.eq(other.message_descriptors.iter().map(Arc::as_ref))','.eq(other.message_descriptors.iter())')
edit('src/runtime_client/projection.rs','|entry: &super::snapshot::RuntimeClientTranscriptEntry| entry','|entry: &Arc<super::snapshot::RuntimeClientTranscriptEntry>| entry')
edit('src/runtime_client/projection.rs','.flat_map(|entry| &mut entry.tool_calls)','.flat_map(|entry| &mut Arc::make_mut(entry).tool_calls)')
edit('src/runtime_client/response.rs','    for entry in &mut page.entries {\n        let facts =','    for entry in &mut page.entries {\n        let entry = std::sync::Arc::make_mut(entry);\n        let facts =')
edit('src/runtime_client/checkpoint.rs','                next_offset: Some(0),\n            });','                next_offset: Some(0),\n            }.into());')
p=r/'src/runtime_client/host.rs';s=p.read_text();start=s.index('    fn materialize_content_bindings(');end=s.index('    /// Read a bounded checkpoint',start)
s=s[:start]+'''    fn materialize_content_bindings(
        &self,
        bindings: &mut [super::checkpoint::ContentBinding],
    ) -> Result<(), RuntimeClientError> {
        for binding in bindings {
            if let Some(reference) = self.materialize_content_binding(binding)? {
                binding.content_ref = reference;
            }
        }
        Ok(())
    }

    /// Always validate the current store before sharing a resolved display owner.
    fn materialize_content_binding(
        &self,
        binding: &super::checkpoint::ContentBinding,
    ) -> Result<Option<super::content::ContentRef>, RuntimeClientError> {
        if matches!(binding.content_ref.source, super::content::ContentSource::LivePublicationPrefix { .. }) {
            return Ok(None);
        }
        let raw = if matches!(binding.content_ref.source, super::content::ContentSource::CanonicalMessageBlock { .. })
            && binding.path.last().is_some_and(|field| field == "arguments") {
            self.store.content_descriptor(&binding.content_ref.source, super::content::ContentRepresentation::RawJsonUtf8)
                .map_err(|_| RuntimeClientError::ContentSourceUnavailable)?
        } else { None };
        Ok(Some(match raw {
            Some(reference) => reference,
            None => self.store.content_descriptor(&binding.content_ref.source, binding.content_ref.representation)
                .map_err(|_| RuntimeClientError::ContentSourceUnavailable)?
                .ok_or(RuntimeClientError::ContentSourceUnavailable)?,
        }))
    }

'''+s[end:]
s=s.replace('        self.materialize_content_bindings(&mut checkpoint.content)?;','''        for binding in &mut checkpoint.content {
            if let Some(reference) = self.materialize_content_binding(binding)? {
                *binding = binding.resolve(&reference);
            }
        }''')
s=s.replace('                    total: checkpoint.snapshot.trace_updates.len() as u64,\n                    loaded: checkpoint.snapshot.trace_updates.len() as u64,\n                    next_offset: None,\n                });','                    total: checkpoint.snapshot.trace_updates.len() as u64,\n                    loaded: checkpoint.snapshot.trace_updates.len() as u64,\n                    next_offset: None,\n                }.into());')
p.write_text(s)
