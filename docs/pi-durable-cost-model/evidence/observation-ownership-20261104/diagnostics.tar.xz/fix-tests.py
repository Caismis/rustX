from pathlib import Path
r=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
def edit(n,changes):
 p=r/n;s=p.read_text()
 for a,b in changes:
  assert a in s,(n,a);s=s.replace(a,b)
 p.write_text(s)
edit('src/durable/sqlite/observation_checkpoint_tests.rs',[
 ('PreparedTranscriptRow::new(cut.read.conversation_id.clone(), entry)','PreparedTranscriptRow::new(cut.read.conversation_id.clone(), entry.as_ref().clone())'),
 ('original.transcript_rows[0].value(), original.transcript.entries[0]','original.transcript_rows[0].value(), *original.transcript.entries[0]'),
 ('        running.transcript.entries[0]\n','        *running.transcript.entries[0]\n')])
edit('src/runtime_client/checkpoint/prepared_transcript_tests.rs',[
 ('std::slice::from_ref(&wide)','std::slice::from_ref(&Arc::new(wide.clone()))'),
 ('PreparedTranscriptHead::from_entries(&conversation(), &entries)','PreparedTranscriptHead::from_entries(&conversation(), &entries.iter().cloned().map(Arc::new).collect::<Vec<_>>())')])
edit('src/runtime_client/host/trace_demand_recovery_tests.rs',[( '.content\n        .iter()\n        .chain(','.content\n        .iter()\n        .map(std::ops::Deref::deref)\n        .chain(')])
edit('src/runtime_client/host.rs', [('head.iter().map(|row| row.as_ref().clone()).collect()', 'head.iter().cloned().collect()')])
edit('src/durable/sqlite/observation_owner_tests.rs',[('.find_map(|entry| entry.completed_response)','.find_map(|entry| entry.completed_response.clone())')])
edit('src/runtime_client/response.rs', [('    for entry in &mut page.entries {\n','    for entry in &mut page.entries {\n        let entry = std::sync::Arc::make_mut(entry);\n')])
p=r/'src/runtime_client/response.rs';s=p.read_text().replace('        let entry = std::sync::Arc::make_mut(entry);\n        let entry = std::sync::Arc::make_mut(entry);','        let entry = std::sync::Arc::make_mut(entry);');p.write_text(s)
edit('src/runtime_client/response/tests.rs',[('        entry.completed_response = None;','        std::sync::Arc::make_mut(entry).completed_response = None;')])
edit('src/runtime_client/projection/shared_domain_detach_tests.rs', [('    }]\n    .into();','    }.into()]\n    .into();')])
p=r/'src/runtime_client/projection/incremental_checkpoint_tests.rs';s=p.read_text();s=s.replace('.collect::<Vec<_>>().into();','.map(std::sync::Arc::new).collect::<Vec<_>>().into();')
for scope in ['seed','original']:
 for f in ['response_pending','item']:s=s.replace(f'{scope}.snapshot.transcript.entries[0].{f} =',f'std::sync::Arc::make_mut(&mut {scope}.snapshot.transcript.entries[0]).{f} =')
p.write_text(s)
p=r/'src/runtime_client/projection.rs';s=p.read_text();s=s.replace('            .map(super::super::checkpoint::MetadataFragment::into_owned)\n','')
s=s.replace('.transcript_page(&source.transcript.entries, &source.conversation_id)\n                .into()', '.transcript_page(&source.transcript.entries.iter().map(|row| row.as_ref().clone()).collect::<Vec<_>>(), &source.conversation_id)\n                .into_iter().map(Arc::new).collect::<Vec<_>>().into()')
p.write_text(s)
