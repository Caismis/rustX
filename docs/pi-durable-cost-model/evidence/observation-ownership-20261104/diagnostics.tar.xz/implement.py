from pathlib import Path
r=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
def edit(name,changes):
 p=r/name;s=p.read_text()
 for a,b in changes:
  if a not in s and b in s:continue
  assert a in s,(name,a);s=s.replace(a,b)
 p.write_text(s)
edit('src/runtime_client/snapshot.rs',[
 ('pub message_descriptors: Vec<RuntimeClientMessageDescriptor>,','pub message_descriptors: Vec<std::sync::Arc<RuntimeClientMessageDescriptor>>,'),
 ('MetadataFragment<Vec<RuntimeClientTranscriptEntry>>','MetadataFragment<Vec<std::sync::Arc<RuntimeClientTranscriptEntry>>>'),
 ('entries: entries.into(),','entries: entries.into_iter().map(std::sync::Arc::new).collect::<Vec<_>>().into(),'),
 ('result.entries.push(display);','result.entries.push(std::sync::Arc::new(display));'),
])
edit('src/runtime_client/projection/shared_snapshot.rs',[
 ('.map(Arc::new)\n                .collect::<RuntimeClientMessageDescriptorHead>()','.collect::<RuntimeClientMessageDescriptorHead>()'),
 ('MetadataFragment<Vec<RuntimeClientTranscriptEntry>>','MetadataFragment<Vec<Arc<RuntimeClientTranscriptEntry>>>'),
 ('.map(|row| row.as_ref().clone())','.cloned()'),
])
edit('src/runtime_client/checkpoint.rs',[
 ('pub content: Vec<ContentBinding>,\n    pub collections: Vec<CollectionFrontier>,','pub content: Vec<MetadataFragment<ContentBinding>>,\n    pub collections: Vec<MetadataFragment<CollectionFrontier>>,'),
 ('collections: &mut [CollectionFrontier],\n    content: &mut [ContentBinding],','collections: &mut [MetadataFragment<CollectionFrontier>],\n    content: &mut [MetadataFragment<ContentBinding>],'),
])
edit('src/runtime_client/projection.rs',[
 ('entries: transcript_entries.into_owned().into(),','entries: transcript_entries.into_entries().into(),'),
 ('content: metadata\n                        .content\n                        .into_iter()\n                        .map(super::checkpoint::MetadataFragment::into_owned)\n                        .collect(),','content: metadata.content,'),
 ('collections: metadata\n                        .collections\n                        .into_iter()\n                        .map(super::checkpoint::MetadataFragment::into_owned)\n                        .collect(),','collections: metadata.collections,'),
 ('content: std::mem::take(&mut owned.content)\n                        .into_iter()\n                        .map(Into::into)\n                        .collect(),','content: std::mem::take(&mut owned.content),'),
 ('collections: std::mem::take(&mut owned.collections)\n                        .into_iter()\n                        .map(Into::into)\n                        .collect(),','collections: std::mem::take(&mut owned.collections),'),
 ('content: capture\n                    .content\n                    .into_iter()\n                    .map(super::checkpoint::MetadataFragment::into_owned)\n                    .collect(),','content: capture.content,'),
 ('collections: capture.collections,','collections: capture.collections.into_iter().map(Into::into).collect(),'),
 (') -> Vec<super::snapshot::RuntimeClientMessageDescriptor> {',') -> Vec<Arc<super::snapshot::RuntimeClientMessageDescriptor>> {'),
 ('let mut descriptor = source.as_ref().clone();','let mut descriptor = Arc::clone(source);'),
 ('let Some(removed) = descriptor.tool_calls.pop() else {','let Some(removed) = Arc::make_mut(&mut descriptor).tool_calls.pop() else {'),
 ('descriptor.content.retain(|binding| {','Arc::make_mut(&mut descriptor).content.retain(|binding| {'),
 ('if let Some(frontier) = descriptor\n                        .collections','if let Some(frontier) = Arc::make_mut(&mut descriptor)\n                        .collections'),
])
edit('src/runtime_client/projection/prepared_capture.rs',[
 ('content: self\n                .metadata\n                .content\n                .into_iter()\n                .map(checkpoint::MetadataFragment::into_owned)\n                .collect(),','content: self.metadata.content,'),
 ('collections: self\n                .metadata\n                .collections\n                .into_iter()\n                .map(checkpoint::MetadataFragment::into_owned)\n                .collect(),','collections: self.metadata.collections,'),
])
edit('src/runtime_client/checkpoint/prepared_transcript.rs',[
 ('prepared: OnceLock<PreparedCapture<Option<CapturedRow>>>,','prepared: OnceLock<PreparedCapture<Option<CapturedRow>>>,\n    native: OnceLock<Arc<RuntimeClientTranscriptEntry>>,'),
 ('prepared: OnceLock::new(),','prepared: OnceLock::new(),\n            native: OnceLock::new(),'),
 ('entries: &[RuntimeClientTranscriptEntry],','entries: &[Arc<RuntimeClientTranscriptEntry>],'),
 ('.cloned()\n                .map(|entry| PreparedTranscriptRow::new(conversation.clone(), entry))','.map(|entry| PreparedTranscriptRow::new(conversation.clone(), entry.as_ref().clone()))'),
 ('pub(crate) fn into_owned(self) -> Vec<RuntimeClientTranscriptEntry> {','pub(crate) fn into_entries(self) -> Vec<Arc<RuntimeClientTranscriptEntry>> {'),
])
# The Head also has a different `prepared` field; no native cache belongs there.
p=r/'src/runtime_client/checkpoint/prepared_transcript.rs';s=p.read_text().replace('            prepared: OnceLock::new(),\n            native: OnceLock::new(),\n        }))\n    }\n    pub(crate) fn from_entries','            prepared: OnceLock::new(),\n        }))\n    }\n    pub(crate) fn from_entries')
s=s.replace('    #[cfg(test)]\n    pub(crate) fn value(&self)', '''    /// Called after the native reader has revalidated body and response proof.
    /// This exact immutable row is shared with current and retained read pages.
    pub(crate) fn native_entry(&self) -> Arc<RuntimeClientTranscriptEntry> {
        Arc::clone(self.0.native.get_or_init(|| Arc::new(self.0.body.entry(&self.0.decoration))))
    }
    #[cfg(test)]
    pub(crate) fn value(&self)''');p.write_text(s)
edit('src/runtime_client/checkpoint/prepared_transcript/body.rs',[
 ('    decoration: Decoration,\n}\nimpl Serialize for Captured','    decoration: Decoration,\n    entry: OnceLock<Arc<RuntimeClientTranscriptEntry>>,\n}\nimpl Serialize for Captured'),
 ('pub(super) fn entry(&self) -> RuntimeClientTranscriptEntry {\n        self.body.value.entry(&self.decoration)\n    }','pub(super) fn entry(&self) -> Arc<RuntimeClientTranscriptEntry> {\n        Arc::clone(self.entry.get_or_init(|| Arc::new(self.body.value.entry(&self.decoration))))\n    }'),
 ('pub(super) fn into_entry(self) -> RuntimeClientTranscriptEntry {\n        Arc::unwrap_or_clone(self.body)\n            .value\n            .into_entry(self.decoration)\n    }','pub(super) fn into_entry(self) -> Arc<RuntimeClientTranscriptEntry> {\n        self.entry.into_inner().unwrap_or_else(|| Arc::new(Arc::unwrap_or_clone(self.body).value.into_entry(self.decoration)))\n    }'),
 ('decoration: decoration.value,','decoration: decoration.value,\n                entry: OnceLock::new(),'),
 ('let projected = Captured { body, decoration };','let projected = Captured { body, decoration, entry: OnceLock::new() };'),
])
# Reuse is selected only AFTER current native descriptor/tool/response authorization.
edit('src/durable/sqlite/observation_checkpoint.rs',[
 ('let transcript_rows = transcript','let transcript_rows: Vec<_> = transcript'),
 ('    Ok(CheckpointHead {','    transcript.entries = transcript_rows.iter().map(|row| row.native_entry()).collect::<Vec<_>>().into();\n    Ok(CheckpointHead {'),
])
