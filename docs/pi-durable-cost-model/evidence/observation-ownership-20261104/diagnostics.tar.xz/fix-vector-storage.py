from pathlib import Path
r=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
p=r/'src/runtime_client/projection/prepared_capture.rs';s=p.read_text();a=s.index('        let result: Vec<_> = values\n');z=s.index('        let _ = self.current.get_or_init',a);s=s[:a]+'''        // Collecting owned64-byte frontiers into8-byte owners can reuse the
        // source allocation and retain its much larger byte capacity. This is
        // the immutable pointer array: allocate only its own finite slots.
        let mut result = Vec::with_capacity(values.len());
        for value in values {
            result.push(
                owners.get(&value.domain)
                    .filter(|owner| ***owner == value)
                    .cloned()
                    .unwrap_or_else(|| value.into()),
            );
        }
'''+s[z:]
# Place the regression inside the existing private tests module.
a=s.rfind('\n}');s=s[:a]+'''
    #[test]
    fn frontier_pointer_array_does_not_retain_larger_value_allocation() {
        let mut values = Vec::with_capacity(128);
        for index in 0..37 {
            values.push(checkpoint::CollectionFrontier {
                domain: format!("domain-{index}"), revision:9, total:1, loaded:1, next_offset:None,
            });
        }
        let wanted = serde_json::to_vec(&values).unwrap();
        let prepared = MetadataFrontiers::default().prepare(values);
        assert!(prepared.capacity() <= prepared.len()*2,
            "a pointer array must not keep the wider input's byte allocation");
        assert_eq!(serde_json::to_vec(&prepared).unwrap(), wanted);
    }
'''+s[a:];p.write_text(s)
p=r/'src/runtime_client/snapshot.rs';s=p.read_text();a=s.index('    let entries = page\n',s.index('pub(crate) fn transcript_page_view'));z=s.index('    Ok(RuntimeClientTranscriptPage {',a);s=s[:a]+'''    let mut entries = Vec::with_capacity(page.entries.len());
    for entry in page.entries {
        entries.push(std::sync::Arc::new(transcript_entry_view(entry)?));
    }
'''+s[z:];a=s.index('        entries: entries\n',s.index('pub(crate) fn transcript_page_view'));z=s.index('        next_cursor:',a);s=s[:a]+'        entries: entries.into(),\n'+s[z:];p.write_text(s)
p=r/'src/runtime_client/projection.rs';s=p.read_text();anchor='fn stamp_trace_cut(';i=s.index(anchor);s=s[:i]+'''/// Freeze only owned vector storage. Shared row bodies and every encoded
/// value/cut/budget remain unchanged; no published owner is mutated.
fn compact_replay_storage(event: &mut RuntimeClientEvent) {
    match event {
        RuntimeClientEvent::ProjectionTransition { events, metadata } => {
            for event in events.iter_mut() { compact_replay_storage(event); }
            events.shrink_to_fit();
            metadata.content.shrink_to_fit();
            metadata.collections.shrink_to_fit();
        }
        RuntimeClientEvent::CheckpointAdvanced { checkpoint, .. } => {
            checkpoint.content.shrink_to_fit();
            checkpoint.collections.shrink_to_fit();
        }
        _ => {}
    }
}

'''+s[i:];s=s.replace('fn retain_replay(&mut self, event: RuntimeClientEvent, bytes: usize) {','fn retain_replay(&mut self, mut event: RuntimeClientEvent, bytes: usize) {\n        compact_replay_storage(&mut event);');p.write_text(s)
p=r/'src/runtime_client/projection/incremental_checkpoint_tests.rs';s=p.read_text();s+='''

#[test]
fn retained_vector_compaction_preserves_exact_event_bytes_and_rows() {
    let (projection, _store) = initialized_source_projection();
    let mut metadata = projection.checkpoint_seed().capture_checkpoint().unwrap().metadata;
    metadata.content.reserve(1024);
    metadata.collections.reserve(1024);
    let mut events = Vec::with_capacity(128);
    events.push(RuntimeClientEvent::TraceChanged);
    let mut event = RuntimeClientEvent::ProjectionTransition { events, metadata };
    let before = encoded_event_bytes(&event, checkpoint::CHECKPOINT_TARGET_BYTES).unwrap();
    compact_replay_storage(&mut event);
    assert_eq!(encoded_event_bytes(&event, checkpoint::CHECKPOINT_TARGET_BYTES).unwrap(), before);
    let RuntimeClientEvent::ProjectionTransition { events, metadata } = &event else { unreachable!() };
    assert!(events.capacity() <= events.len()*2);
    assert!(metadata.content.capacity() <= metadata.content.len().max(1)*2);
    assert!(metadata.collections.capacity() <= metadata.collections.len()*2);
}
''';p.write_text(s)
