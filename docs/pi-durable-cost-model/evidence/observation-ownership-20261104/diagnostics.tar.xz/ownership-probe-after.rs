//! Private diagnostic patch; never part of the delivered production binary.
use super::*;
use crate::runtime_client::{snapshot::*, trace::*};
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet};
#[derive(Default,Serialize)]
struct Group { references: usize, unique: usize, inline_bytes: usize, native_json_bytes: usize, roles: BTreeMap<&'static str,usize>, #[serde(skip)] ids: BTreeSet<usize> }
#[derive(Default,Serialize)]
pub(crate) struct Census(BTreeMap<&'static str,Group>);
impl Census {
 pub(crate) fn row<T:Serialize>(&mut self, group:&'static str, role:&'static str, value:&T) {
  struct Length(usize); impl std::io::Write for Length {fn write(&mut self,b:&[u8])->std::io::Result<usize>{self.0+=b.len();Ok(b.len())}fn flush(&mut self)->std::io::Result<()>{Ok(())}}
  let g=self.0.entry(group).or_default();g.references+=1;*g.roles.entry(role).or_default()+=1;
  if g.ids.insert(std::ptr::from_ref(value) as usize) {g.unique+=1;g.inline_bytes+=std::mem::size_of_val(value);let mut len=Length(0);serde_json::to_writer(&mut len,value).unwrap();g.native_json_bytes+=len.0;}
 }
 fn transcript(&mut self,page:&RuntimeClientTranscriptPage,role:&'static str) {
  self.row("transcript_arrays",role,&*page.entries);
  for row in &page.entries {self.row("transcript_rows",role,row.as_ref());}
  for value in &page.content {self.row("binding_rows",role,value);}
  for value in &page.collections {self.row("frontier_rows",role,value);}
 }
 fn trace(&mut self,page:&TracePage,role:&'static str){for row in &page.records{self.row("trace_rows",role,row);}}
 fn snapshot(&mut self,s:&RuntimeClientSnapshot,role:&'static str){
  self.row("snapshots",role,s);for row in &s.message_descriptors{self.row("descriptor_rows",role,row.as_ref());}
  self.transcript(&s.transcript,role);self.trace(&s.trace,role);
 }
 fn event(&mut self,event:&RuntimeClientEvent, replacements:&mut usize){match event {
  RuntimeClientEvent::CheckpointAdvanced{checkpoint,..}=>{*replacements+=1;self.snapshot(&checkpoint.snapshot,"checkpoint");for row in &checkpoint.content{self.row("binding_rows","checkpoint",&**row);}for row in &checkpoint.collections{self.row("frontier_rows","checkpoint",&**row);}},
  RuntimeClientEvent::ReadDomainsUpdated{transcript,trace,..}=>{self.transcript(transcript,"read_domain");if let Some(trace)=trace{self.trace(trace,"read_domain");}},
  RuntimeClientEvent::MessageDescriptorCommitted{descriptor,head,..}=>{self.row("descriptor_rows","event",descriptor.as_ref());for row in head{self.row("descriptor_rows","event",row.as_ref());}},
  RuntimeClientEvent::ProjectionTransition{events,metadata}=>{for row in &metadata.content{self.row("binding_rows","metadata",&**row);}for row in &metadata.collections{self.row("frontier_rows","metadata",&**row);}for event in events{self.event(event,replacements);}},
  _=>{}
 }}
}

#[derive(Default,Serialize)]
struct Slots(BTreeMap<&'static str,Slot>);
#[derive(Default,Serialize)]
struct Slot { len:usize,cap:usize,bytes:usize,unused_bytes:usize,#[serde(skip)] ids:BTreeSet<usize> }
impl Slots {
 fn add<T>(&mut self,key:&'static str,values:&Vec<T>){
  if values.capacity()==0{return;}
  let s=self.0.entry(key).or_default();
  if s.ids.insert(values.as_ptr() as usize){s.len+=values.len();s.cap+=values.capacity();s.bytes+=values.capacity()*std::mem::size_of::<T>();s.unused_bytes+=(values.capacity()-values.len())*std::mem::size_of::<T>();}
 }
 fn transcript(&mut self,p:&RuntimeClientTranscriptPage){self.add("transcript_rows",&p.entries);}
 fn event(&mut self,e:&RuntimeClientEvent){match e {
 RuntimeClientEvent::ProjectionTransition{events,metadata}=>{self.add("events",events);self.add("metadata_frontiers",&metadata.collections);self.add("metadata_bindings",&metadata.content);for e in events{self.event(e);}},
 RuntimeClientEvent::CheckpointAdvanced{checkpoint,..}=>{self.add("checkpoint_frontiers",&checkpoint.collections);self.add("checkpoint_bindings",&checkpoint.content);self.add("descriptors",&checkpoint.snapshot.message_descriptors);self.transcript(&checkpoint.snapshot.transcript);},
 RuntimeClientEvent::ReadDomainsUpdated{transcript,..}=>self.transcript(transcript),
 _=>{}
 }}
}

impl RuntimeClientProjection {
 pub(super) fn record_ownership_probe(&self) {
  let assistant=self.snapshot.messages.iter().filter(|v|matches!(v,MessageBlock::Assistant(_))).count();
  if self.replay.len()<80{return;}
  let mut census=Census::default();let mut replacements=0;
  for (_,event) in &self.replay{census.event(event,&mut replacements);}
  for row in &self.snapshot.message_descriptors{census.row("descriptor_rows","current",row.as_ref());}
  for row in &self.snapshot.transcript.entries{census.row("transcript_rows","current",row.as_ref());}
  for row in &self.snapshot.trace.records{census.row("trace_rows","current",row);}
  if let Some(seed)=&self.published_seed{seed.transcript_head.probe(&mut census);seed.trace_head.probe(&mut census);}
  let mut slots=Slots::default();for (_,event) in &self.replay{slots.event(event);}
  let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_micros();
  eprintln!("OWNER_CENSUS {}",serde_json::json!({"unix_us":now,"conversation":self.snapshot.conversation_id,"cursor":self.cursor.get(),"assistant":assistant,"replay":self.replay.len(),"replacements":replacements,"census":census,"storage":slots}).to_string());
 }
}

impl Drop for RuntimeClientProjection { fn drop(&mut self) { self.record_ownership_probe(); } }
