import hashlib,json,re,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text())
while not(r/'final-checks-completed.json').exists():time.sleep(2)
d=r/'checks-final';commands=load(d/'commands.json');assert len(commands)==22 and all(v['exit']==0 for v in commands);before=load(d/'source-before.json');assert before==load(d/'source-after.json');assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==v for n,v in before['files'].items());counts={};duplicates=[]
for row in commands:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in counts or counts[key]==m[2]
    if key in counts:duplicates.append(m[1])
    counts[key]=m[2]
summary={'accepted':True,'commands':22,'source_inputs':len(before['files']),'helpers':before['helpers'],'tests':{s:sum(v==s for v in counts.values()) for s in ['ok','ignored']},'duplicates':duplicates};(r/'checks-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary['tests'],flush=True)
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert changed and all(v.startswith('src/') for v in changed);subprocess.run(['git','diff','--check'],cwd=repo,check=True);subprocess.run(['git','add','--',*changed],cwd=repo,check=True);subprocess.run(['git','commit','-m','Freeze observation vectors without retaining unused source capacity'],cwd=repo,check=True)
p=subprocess.run(['python3',str(r/'build.py'),'candidate',str(repo)],cwd=repo,stdout=(r/'candidate-build.stdout').open('x'),stderr=(r/'candidate-build.stderr').open('x'));assert p.returncode==0
build=load(r/'candidate-build/identity.json');assert build['source_files']==before['files'] and build['verified'];rows=[json.loads(v) for v in (r/'candidate-build/build.stdout').read_text().splitlines() if v.startswith('{')];artifact=next(v for v in rows if v.get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['kind']==['bin']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();(r/'candidate-build/app-server-identity.json').write_text(json.dumps({'head':build['head'],'binary':str(r/'candidate-build/rustx'),'sha256':sha(r/'candidate-build/rustx'),'artifact':artifact},indent=2)+'\n');(r/'ready.json').write_text(json.dumps({'accepted':True,'head':build['head'],'native_sha256':sha(r/'candidate-build/rustx'),'conformance_sha256':sha(r/'candidate-build/conformance')},indent=2)+'\n')
