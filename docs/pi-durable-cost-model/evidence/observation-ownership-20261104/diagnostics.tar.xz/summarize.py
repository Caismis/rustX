"""Arithmetic only: keep fixed/rotating/cache and profiler cohorts distinct."""
import json
import statistics
from pathlib import Path

r = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
native = {v['directory']: v for v in load(r / 'native-audit.json')['products']}
commands = load(r / 'product-commands.json')


def series(values):
    return {'values': values, 'median': statistics.median(values)}


def paired(before, after):
    return {'before': series(before), 'after': series(after),
            'paired_changes_percent': series([(b / a - 1) * 100 for a, b in zip(before, after)])}


def compare(getter, pairs=4):
    return paired([getter(i, 'before') for i in range(pairs)],
                  [getter(i, 'after') for i in range(pairs)])


families = {}
for family, widths in [('ordinary', [1, 4, 8]), ('rotating', [4]), ('deep', [4])]:
    index = {(v['pair'], v['side']): native[v['directory']]
             for v in commands if v['family'] == family}
    activity = []
    for width in widths:
        def metric(pair, side, key):
            v = next(x for x in index[pair, side]['activity'] if x['width'] == width)
            return {'settled_ms': v['latency']['settled_us']['median_ms'],
                    'accepted_ms': v['latency']['accepted_us']['median_ms'],
                    'p95_ms': v['latency']['settled_us']['p95_ms'],
                    'p99_ms': v['latency']['settled_us']['p99_ms'],
                    'cpu_ms_per_turn': v['server_cpu_ms_per_all_turns'],
                    'write_kib_per_turn': v['server_write_bytes_per_all_turns'] / 1024}[key]
        activity.append({'width': width, 'metrics': {
            key: compare(lambda i, s: metric(i, s, key), 2 if family=='deep' else 4) for key in
            ['settled_ms', 'accepted_ms', 'p95_ms', 'p99_ms', 'cpu_ms_per_turn', 'write_kib_per_turn']}})
    families[family] = activity

index = {(v['pair'], v['side']): native[v['directory']]
         for v in commands if v['family'] == 'ordinary'}
phases = ['empty_server', 'metadata_only', 'empty_attached_1', 'empty_attached_8',
          'empty_attached_32', 'empty_attached_64', 'empty_attached_128',
          'all_subscribed_empty', 'seeded_history_8', 'all_unloaded', 'reload_unload_cycle_2']
memory = []
for phase in phases:
    memory.append({'phase': phase, 'metrics': {key: compare(
        lambda i, s: next(v for v in index[i, s]['points'] if v['phase'] == phase)['counters'][key])
        for key in ['anon_pss_mib', 'rss_mib']}})

growth = {}
for label, start, end, count in [('first_session', 'metadata_only', 'empty_attached_1', 1),
                                 ('remaining127_per_session', 'empty_attached_1', 'empty_attached_128', 127),
                                 ('eight_turns_per_session', 'all_subscribed_empty', 'seeded_history_8', 128)]:
    def delta(i, s):
        points = {v['phase']: v['counters'] for v in index[i, s]['points']}
        return (points[end]['anon_pss_mib'] - points[start]['anon_pss_mib']) / count
    growth[label] = compare(delta)

cache = {v['side']: v['metrics'] for v in load(r / 'cache-audit.json')['products']}
cache_memory = []
for phase in ['all_subscribed_empty', 'seeded_history_8', 'cache_pages_idle',
              'cache_statements_idle', 'cache_rotation_cold', 'cache_rotation_warm', 'all_unloaded']:
    cache_memory.append({'phase': phase, 'metrics': {
        key: paired([cache['before']['memory'][phase][key]], [cache['after']['memory'][phase][key]])
        for key in ['anon_pss_mib', 'rss_mib']}})
rotation = []
for label in ['cold', 'warm']:
    metrics = {key: paired([cache['before'][label]['cold_eligible'][key]],
                          [cache['after'][label]['cold_eligible'][key]])
               for key in ['settled_median_ms', 'accepted_median_ms', 'settled_p95_ms']}
    metrics.update({key: paired([cache['before'][label]['window'][key]],
                               [cache['after'][label]['window'][key]])
                    for key in ['cpu_ms_per_turn', 'write_kib_per_turn']})
    rotation.append({'label': label, 'metrics': metrics})

deep_index = {(v['pair'],v['side']):native[v['directory']] for v in commands if v['family']=='deep'}
deep_memory=[]
for phase in ['all_subscribed_empty','seeded_history_8','seeded_history_16','seeded_history_32','seeded_history_64']:
    deep_memory.append({'phase':phase,'metrics':{key:compare(
        lambda i,s:next(v for v in deep_index[i,s]['points'] if v['phase']==phase)['counters'][key],2)
        for key in ['anon_pss_mib','rss_mib']}})

pi = load(r / 'prior-pi-memory-reference.json')
ratios = {}
for phase in ['all_subscribed_empty', 'seeded_history_8']:
    point = next(v for v in pi['points'] if v['phase'] == phase)
    here = next(v['metrics'] for v in memory if v['phase'] == phase)
    ratios[phase] = {key: {'prior_pi': point[key],
                          'before_ratio': here[key]['before']['median'] / point[key],
                          'after_ratio': here[key]['after']['median'] / point[key]}
                     for key in ['anon_pss_mib', 'rss_mib']}

out = {'accepted': True, 'activity': families, 'memory': memory, 'memory_growth_mib': growth,
       'cache_memory': cache_memory, 'rotation': rotation, 'deep_memory': deep_memory,
       'prior_pi_memory_reference': pi, 'prior_pi_ratios': ratios,
       'scope': 'Four balanced pairs each for ordinary fixed/rotating; two separate pairs with8sessions64turns/deep1/8/16/32/64memorypoints; one separate extended cache pair. Latency excludes held first round; CPU/write windows include it. Process memory endpoints are sampled values, not exact peak/live heap. Paired changes are medians of per-pair ratios. Pi is the unchanged prior single memory sample with different service/feature/tool surface; no new Pi/DeepSeek products or CPU comparison. Diagnostic CPU/heap runs are separate.'}
(r / 'summary.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'accepted': True, 'ratios': ratios}))
