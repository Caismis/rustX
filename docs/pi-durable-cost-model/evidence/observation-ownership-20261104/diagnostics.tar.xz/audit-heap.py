"""Verify complete raw sampled exports and independently correct64KiBPoisson weighting."""
import hashlib,json,math,re
from pathlib import Path
r=Path(__file__).resolve().parent;products=[]
for side in ['before','after']:
 d=r/('heap-'+side)
 for i in range(1,13):
  raw=d/f'native-sample-{i}.heap';lines=raw.read_text().splitlines();m=re.match(r'heap profile:\s+(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\] @ heap_v2/(\d+)',lines[0]);assert m;head=list(map(int,m.groups()));assert head[4]==65536;sums=[0]*4;weighted=0.;records=0
  for line in lines[1:]:
   m=re.match(r'\s*(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\]\s+@',line)
   if not m:continue
   v=list(map(int,m.groups()));records+=1;sums=[a+b for a,b in zip(sums,v)];assert v[0]>0;weighted+=v[1]/(-math.expm1(-v[1]/v[0]/head[4]))
  assert sums==head[:4];stacks=[]
  for line in (d/f'sample-{i}-collapsed.txt').read_text().splitlines():
   if line.strip():s,n=line.rsplit(' ',1);stacks.append((s,int(n)))
  collapsed=sum(n for _,n in stacks);assert abs(collapsed-weighted)<len(stacks)+1;total=float(re.search(r'Total: ([\d.]+) MB',(d/f'sample-{i}-cum.txt').read_text())[1]);assert abs(total-weighted/1048576)<=.051
  presence={label:sum(n for s,n in stacks if token in s) for label,token in [('sqlite_malloc','sqlite3MemMalloc'),('sqlite_page_cache','pcache1Alloc'),('sqlite_prepare','sqlite3Prepare'),('schema_compilation','jsonschema::compiler::compile'),('checkpoint_materialization','capture_checkpoint'),('publication_encoding','PublicationDraft>::encode')]}
  exclusive={}
  for stack,amount in stacks:
   category=next((name for name,tokens in [
    ('schema_validation',('jsonschema::',)),('sqlite',('sqlite3MemMalloc',)),
    ('http_tls',('reqwest::','rustls::','rustls_platform_verifier')),
    ('capability_preparation',('capability_source::prepared',)),
    ('tool_catalog',('capabilities::tools','tools::native::registration','ToolRegistry')),
    ('checkpoint_capture',('capture_checkpoint',)),('publication',('PublicationDraft',)),
    ('other_observation',('runtime_client::',)),('model_binding',('rustx::model::',)),
    ('other_session',('local_runtime::',))] if any(token in stack for token in tokens)), 'other')
   exclusive[category]=exclusive.get(category,0)+amount
  assert sum(exclusive.values())==collapsed
  binding=json.loads((d/f'sample-{i}-binding.json').read_text());products.append({'side':side,'index':i,'phase':binding['phase'],'pid':binding['pid'],'profile_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'raw_records':records,'raw_header':head,'raw_sums':sums,'weighted_requested_bytes':weighted,'collapsed_weighted_requested_bytes':collapsed,'overlapping_stack_presence_bytes':presence,'disjoint_priority_stack_bytes':exclusive,'allocator_numeric_properties':binding['stats']})
assert len(products)==24
result={'accepted':True,'products':products,'scope':'NativeO3/default executable with replacement tcmalloc allocator and existing complete64KiBsampler, one diagnostic product per side with12phases. Raw records exactly cover headers and independent Poisson weights match archived symbolization within integer rounding. Requested estimates, allocator class-charged live/free totals and ordinary glibc PSS are different denominators. Inclusive stack groups overlap and must not be added; the separate priority partition assigns each symbolized sampled allocation to exactly one first-matching stack group, not to a PSS component; sqlite_prepare includes initialization work. Mixed130s point has4sessions14turns/124sessions8turns. No ordinary latency/CPU or device-write claim from profiler products.'}
(r/'heap-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'profiles':24}))
