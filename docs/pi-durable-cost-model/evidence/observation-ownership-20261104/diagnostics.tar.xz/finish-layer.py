import hashlib,json,re,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');d=r/'checks-final';load=lambda p:json.loads(p.read_text())
while not(d/'source-after.json').exists():time.sleep(2)
commands=load(d/'commands.json');assert len(commands)==22 and all(v['exit']==0 for v in commands);before=load(d/'source-before.json');assert before==load(d/'source-after.json');assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==v for n,v in before['files'].items());counts={}
for row in commands:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:counts[row['command'][0],m[1]]=m[2]
summary={'accepted':True,'commands':22,'source_inputs':len(before['files']),'tests':{s:sum(v==s for v in counts.values()) for s in ['ok','ignored']},'scope':'Verified row-sharing layer before the separately attributed retained-vector capacity repair.'};(r/'layer-a-checks-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=repo,text=True).splitlines();assert changed and all(v.startswith('src/') for v in changed);subprocess.run(['git','diff','--check'],cwd=repo,check=True);subprocess.run(['git','add','--',*changed],cwd=repo,check=True);subprocess.run(['git','commit','-m','Share proven transcript rows and checkpoint metadata across historical views'],cwd=repo,check=True);summary['head']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();(r/'layer-a-checks-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
(d).rename(r/'checks-layer-a')
for suffix in ['stdout','stderr']:(r/f'checks-final.{suffix}').rename(r/f'checks-layer-a.{suffix}')
subprocess.run(['python3',str(r/'fix-vector-storage.py')],cwd=repo,check=True);subprocess.run(['cargo','fmt','--all'],cwd=repo,check=True)
with (r/'checks-final.stdout').open('x') as so,(r/'checks-final.stderr').open('x') as se:p=subprocess.run(['python3',str(r/'check.py'),'checks-final'],cwd=repo,stdout=so,stderr=se)
assert p.returncode==0
(r/'final-checks-completed.json').write_text('{"accepted":true}\n')
