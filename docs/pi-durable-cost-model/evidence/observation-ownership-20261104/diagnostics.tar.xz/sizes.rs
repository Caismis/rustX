fn main() {
 macro_rules! size { ($($ty:ty),* $(,)?) => {$(println!("{} {}",stringify!($ty),std::mem::size_of::<$ty>());)*} }
 use rustx::runtime_client::{snapshot::*,checkpoint::*,trace::*};
 size!(RuntimeClientSnapshot,RuntimeClientCheckpoint,RuntimeClientTranscriptPage,RuntimeClientTranscriptEntry,RuntimeClientMessageDescriptor,RuntimeClientAttempt,RuntimeClientContextView,ProjectionMetadata,TracePage,TraceRecord,ContentBinding,CollectionFrontier,Option<rustx::runtime_client::goal::RuntimeClientGoalView>,Option<rustx::model::session::SessionModelView>);
}
