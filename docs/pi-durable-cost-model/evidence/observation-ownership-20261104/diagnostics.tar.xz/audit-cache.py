"""Independent raw checks and counter arithmetic for the bounded cold/rotation products."""
import base64,hashlib,json,math,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();native={p['directory']:p for p in load(r/'native-audit.json')['products']};results=[]
def counter(raw):
 tail=raw['stat'].rsplit(')',1)[1].split();io=dict(v.split(':',1) for v in raw['io'].splitlines());return {'pid':int(raw['stat'].split('(',1)[0]),'start':int(tail[19]),'ticks':int(tail[11])+int(tail[12]),'writes':int(io['write_bytes'])}
def elapsed(data,n):
 a,b=counter(data['before']),counter(data['after']);assert a['pid']==b['pid'] and a['start']==b['start'];assert b['ticks']>=a['ticks'] and b['writes']>=a['writes'];return {'cpu_ms':(b['ticks']-a['ticks'])*10,'write_bytes':b['writes']-a['writes'],'cpu_ms_per_turn':(b['ticks']-a['ticks'])*10/n,'write_kib_per_turn':(b['writes']-a['writes'])/1024/n}
def metrics(rows):
 assert rows
 for t in rows:assert t['terminal']['outcome']['type']=='completed' and 0<=t['accepted_us']<=t['settled_us'];assert math.isclose(t['settled_monotonic_ns']-t['began_monotonic_ns'],t['settled_us']*1000,rel_tol=1e-12,abs_tol=1e-3)
 return {'n':len(rows),'accepted_median_ms':statistics.median(t['accepted_us'] for t in rows)/1000,'settled_median_ms':statistics.median(t['settled_us'] for t in rows)/1000,'settled_p95_ms':sorted(t['settled_us'] for t in rows)[math.ceil(.95*len(rows))-1]/1000,'settled_values_ms':[t['settled_us']/1000 for t in rows]}
for cmd in load(r/'product-commands.json'):
 if cmd['family']!='cache' or cmd['exit']!=0:continue
 name=cmd['directory'];d=r/name;p=native[name];identity=load(d/'identity.json');n=identity['sessions'];assert n==128 and identity['cache_probes'];phases={v['phase']:v for v in p['points']}
 assert phases['cache_pages_idle']['monotonic_ns']-phases['seeded_history_8']['monotonic_ns']>=32e9
 assert phases['cache_statements_idle']['monotonic_ns']-phases['seeded_history_8']['monotonic_ns']>=130e9
 for phase in ['cache_pages_idle','cache_statements_idle','cache_rotation_cold','cache_rotation_warm']:assert phases[phase]['loaded']==128 and phases[phase]['loading']==phases[phase]['unloading']==0
 kept=load(d/'cache-kept-warm.json');assert len(kept['rows'])==24
 for j,t in enumerate(kept['rows']):assert t['session']==j%4 and t['turn']==8+j//4
 gaps=[(kept['rows'][j]['began_monotonic_ns']-kept['rows'][j-4]['settled_monotonic_ns'])/1e9 for j in range(4,24)]
 cold=load(d/'cache-rotation-cold.json');warm=load(d/'cache-rotation-warm.json');assert len(cold['rows'])==len(warm['rows'])==128
 for i,(a,b) in enumerate(zip(cold['rows'],warm['rows'])):assert a['session']==b['session']==i and a['turn']==8+6*int(i<4) and b['turn']==a['turn']+1 and b['began_monotonic_ns']>=a['settled_monotonic_ns']
 eligible=[i for i in range(128) if i>=4 and i not in [n-3,n-2]];assert len(eligible)==122
 inspector=load(d/'cache-inspector.json');chunks=inspector['chunks'];assert len(chunks)==2 and chunks[0]==chunks[1];chunk=chunks[0]['chunk'];assert chunk['content_ref']['conversation_id']==load(d/'routing.json')[n-2]['conversation_id'];assert chunk['offset']==0 and chunk['end_offset']==len(base64.b64decode(chunk['data_base64'],validate=True)) and chunk['readable_end']==chunk['content_ref']['readable_end'];assert 0<chunk['end_offset']<=4096 and chunk['end_offset']<=chunk['readable_end'];assert inspector['elapsed_ms']>=0
 rows={label:{'all':metrics(data['rows']),'cold_eligible':metrics([data['rows'][i] for i in eligible]),'window':elapsed(data,128)} for label,data in [('cold',cold),('warm',warm)]}
 warm_gaps=[(b['began_monotonic_ns']-a['settled_monotonic_ns'])/1e9 for a,b in zip(cold['rows'],warm['rows'])];rows['warm']['maximum_same_session_idle_seconds']=max(warm_gaps);rows['warm']['gaps_over30seconds']=sum(v>=30 for v in warm_gaps)
 rows['kept_warm']={'all':metrics(kept['rows']),'after_first4':metrics(kept['rows'][4:]),'mixed_window':elapsed(kept,24),'maximum_same_session_db_idle_seconds':max(gaps),'gaps_over30seconds':sum(v>=30 for v in gaps)};rows['inspector']={'elapsed_ms':inspector['elapsed_ms'],'window':elapsed(inspector,1),'sha256':sha(d/'cache-inspector.json')}
 rows['memory']={k:phases[k]['counters'] for k in ['all_subscribed_empty','seeded_history_8','cache_pages_idle','cache_statements_idle','cache_rotation_cold','cache_rotation_warm','all_unloaded']};results.append({'directory':name,'pair':cmd['pair'],'side':cmd['side'],'metrics':rows})
assert len(results)==2
(r/'cache-audit.json').write_text(json.dumps({'accepted':True,'products':results,'scope':'Cold eligible122exclude4kept-active and2Inspector-primed sessions; every cold/warm call is preserved. Kept-warm CPU/write includes98seconds of idle maintenance and is not pure active-turn CPU. PID counters have10msCPU granularity. Native/fullHTTP/integrity checks are independently reparsed by audit-native. Process memory is not an exact SQLite/replay/live-object partition.'},indent=2)+'\n');print(json.dumps({'accepted':True,'products':len(results)}))
