"""Render tables from audited arithmetic only, with exactly one final LF."""
import json
from pathlib import Path

r = Path(__file__).resolve().parent
load = lambda p: json.loads(p.read_text())
s = load(r / 'summary.json')
lines = ['# Observation ownership: complete measurements', '',
         'Four balanced pairs each for fixed/rotating, two separate pairs for deeper history. Before: 57c7082ea; final head in source-audit.json. '
         'Pi and DeepSeek were not run. MiB = 2^20 bytes, KiB = 2^10 bytes. '
         'Changes are medians of paired percentages, not ratios of displayed medians.', '']


def table(header, rows):
    lines.append('| ' + ' | '.join(header) + ' |')
    lines.append('| ' + ' | '.join(['---'] * len(header)) + ' |')
    lines.extend('| ' + ' | '.join(map(str, row)) + ' |' for row in rows)
    lines.append('')


def vals(v):
    return ', '.join(f'{x:.3f}' for x in v)


def metrics(m):
    return [f"{m['before']['median']:.3f}", f"{m['after']['median']:.3f}",
            f"{m['paired_changes_percent']['median']:+.3f}%"]


lines += ['## Ordinary process memory', '',
          'Sampled endpoints, not exact peaks. Anonymous PSS is not live heap or SQLite/replay allocation ownership.', '']
for key in ['anon_pss_mib', 'rss_mib']:
    lines += [f'### {key}', '']
    table(['Endpoint', 'Before MiB', 'After MiB', 'Paired change'],
          [[v['phase'], *metrics(v['metrics'][key])] for v in s['memory']])
lines += ['### Anonymous-PSS growth within each product', '']
table(['Increment', 'Before MiB', 'After MiB', 'Paired change'],
      [[key, *metrics(v)] for key, v in s['memory_growth_mib'].items()])
lines += ['### All memory pairs', '']
table(['Endpoint / measure', 'Before pairs', 'After pairs', 'Paired changes %'],
      [[v['phase'] + ' / ' + key, vals(m['before']['values']), vals(m['after']['values']),
        vals(m['paired_changes_percent']['values'])]
       for v in s['memory'] for key, m in v['metrics'].items()])

for family, activity in s['activity'].items():
    lines += [f'## {family} requests', '',
              ('Fixed active sessions, 16 rounds per width; 128×8 seeding precedes active work.' if family=='ordinary' else 'Four active sessions rotate through all128,128rounds/512calls,histories8→12.' if family=='rotating' else 'Eight sessions64turns,two separate pairs; fixed width4/32rounds; memory points8/16/32/64.'), '',
              'Latency excludes the deliberately held first round; native PID CPU/write counters include it. '
              'P95/P99 are finite sample summaries, not production-tail guarantees.', '']
    table(['Width / metric', 'Before', 'After', 'Paired change'],
          [[f"{v['width']} / {key}", *metrics(m)] for v in activity for key, m in v['metrics'].items()])
    table(['Width / metric', 'Before pairs', 'After pairs', 'Paired changes %'],
          [[f"{v['width']} / {key}", vals(m['before']['values']), vals(m['after']['values']),
            vals(m['paired_changes_percent']['values'])] for v in activity for key, m in v['metrics'].items()])

lines += ['## Deeper history:8sessions,64turns,two balanced pairs', '', 'Not pooled with the128×8cohort. Immediate seeding endpoints; actual process counters retained.', '']
table(['Endpoint / measure','Before MiB','After MiB','Paired change'],[[v['phase']+' / '+key,*metrics(m)] for v in s['deep_memory'] for key,m in v['metrics'].items()])
lines += ['## Concrete native owner census', '', 'Private intrusive rootO0/default diagnostics;126exact8turns per side. Counts address identities in current/replay and current prepared head. Inline sizes and serialized representations are not a live-heap/PSS partition or an exhaustive store-cache inventory.', '']
census=load(r/'census-audit.json')['products'];left,right=census[0],census[2]
table(['Representation','Before refs/unique median','After refs/unique median','Before inline total MiB','After inline total MiB'],[[key, f"{left['owners'].get(key,{}).get('median_references',0):.1f}/{left['owners'].get(key,{}).get('median_unique',0):.1f}",f"{right['owners'].get(key,{}).get('median_references',0):.1f}/{right['owners'].get(key,{}).get('median_unique',0):.1f}",f"{left['owners'].get(key,{}).get('inline_total_bytes',0)/1048576:.3f}",f"{right['owners'].get(key,{}).get('inline_total_bytes',0)/1048576:.3f}"] for key in sorted(set(left['owners'])|set(right['owners']))])
lines += ['### Retained vector capacity', '', 'Before capacity diagnostic has6eligible8turn sessions; candidate census126. This describes actual buffers, not a paired PSS cohort; backing capacity can overlap the inline rows above.', '']
table(['Side / vector','Median length','Median capacity','Requested bytes','Unused bytes'],[[v['side']+' / '+key,*[f'{values[k]:.1f}' for k in ['len','cap','bytes','unused_bytes']]] for v in [census[1],census[2]] for key,values in v['storage_medians'].items()])

lines += ['## Extended ordinary cache pair', '',
          'One before/after product per side: diagnostic and functional coverage, not a timing confidence cohort. '
          '32 s is all128×8; 130 s is four14-turn +1248-turn sessions. '
          'Cold/warm latency uses122 predefined eligible sessions; CPU/write windows include all128.', '']
table(['Endpoint / measure', 'Before MiB', 'After MiB', 'Change'],
      [[v['phase'] + ' / ' + key, *metrics(m)] for v in s['cache_memory'] for key, m in v['metrics'].items()])
table(['Rotation / metric', 'Before', 'After', 'Change'],
      [[v['label'] + ' / ' + key, *metrics(m)] for v in s['rotation'] for key, m in v['metrics'].items()])
cache = load(r / 'cache-audit.json')['products']
table(['Side', 'Kept-warm max gap s', 'Warm-rotation max gap s', 'Warm gaps ≥30 s',
       'Inspector/history/2 Source reads ms', 'Mixed98 s CPU ms'],
      [[v['side'], f"{v['metrics']['kept_warm']['maximum_same_session_db_idle_seconds']:.3f}",
        f"{v['metrics']['warm']['maximum_same_session_idle_seconds']:.3f}",
        v['metrics']['warm']['gaps_over30seconds'], f"{v['metrics']['inspector']['elapsed_ms']:.3f}",
        v['metrics']['kept_warm']['mixed_window']['cpu_ms']] for v in cache])

lines += ['## Complete sampled heap diagnostics', '',
          'One fresh native product per side,12 phases each. Replacement tcmalloc,64KiB Poisson samples. '
          'These are allocator-class live totals and estimated requested bytes, not ordinary-glibc PSS. '
          'Priority groups assign each weighted sampled allocation once by first matching stack; '
          'the grouping is hierarchy-dependent and does not partition PSS. Inclusive groups remain in heap-audit.json.', '']
heap = load(r / 'heap-audit.json')['products']
table(['Side / phase', 'Class-charged live MiB', 'Estimated requested MiB', 'Heap profiles'],
      [[v['side'] + ' / ' + v['phase'],
        f"{v['allocator_numeric_properties']['allocated']/1048576:.3f}",
        f"{v['weighted_requested_bytes']/1048576:.3f}", v['index']] for v in heap])
selected = [v for v in heap if v['phase'] in ['empty_attached_1', 'all_subscribed_empty', 'seeded_history_8', 'cache_pages_idle', 'cache_statements_idle']]
keys = ['schema_validation', 'sqlite', 'http_tls', 'capability_preparation', 'tool_catalog',
        'checkpoint_capture', 'publication', 'other_observation', 'model_binding', 'other_session', 'other']
table(['Side / phase', *keys],
      [[v['side'] + ' / ' + v['phase'],
        *[f"{v['disjoint_priority_stack_bytes'].get(key,0)/1048576:.3f}" for key in keys]] for v in selected])

lines += ['## Unchanged prior Pi memory reference', '',
          'One previously authorized Pi128 sample; no execution this round. Different service/tool/inspection '
          'surface, so the residual gap is not an estimate of removable work.', '']
table(['Phase / measure', 'Prior Pi MiB', 'Before / Pi', 'After / Pi'],
      [[phase + ' / ' + key, f"{v['prior_pi']:.3f}", f"{v['before_ratio']:.3f}×", f"{v['after_ratio']:.3f}×"]
       for phase, m in s['prior_pi_ratios'].items() for key, v in m.items()])

source = load(r / 'source-audit.json')
native = load(r / 'native-audit.json')
requests = load(r / 'requests-audit.json')
lines += ['## Acceptance counts', '']
table(['Check', 'Result'], [
    ['Source / helpers / command groups', f"{source['source_inputs']} /2 /{source['commands']}"],
    ['Unique tests passed / existing ignored', f"{source['tests']['ok']} /{source['tests']['ignored']}"],
    ['Native products / consistent SQLite images', f"{len(native['products'])} /{sum(v['sessions'] for v in native['products'])}"],
    ['Complete matching HTTP body pairs / requests per side', f"{len(requests['pairs'])} /{sum(v['requests_per_side'] for v in requests['pairs'])}"],
    ['Separate stream/large/tool/cancel products', len(load(r / 'functional-audit.json')['products'])],
    ['New Pi / DeepSeek products', '0 /0'],
])
(r / 'observation-ownership-tables.md').write_text('\n'.join(lines).rstrip() + '\n')
print('tables rendered')
