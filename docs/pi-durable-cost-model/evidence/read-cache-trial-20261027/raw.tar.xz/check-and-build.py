import datetime,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
target=Path('/home/capi/.cache/rustx-pr485-target')
env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'}
records=[]
def run(label,command,log_json=False):
 record=dict(label=label,command=command,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');records.append(record)
 (root/'check-build-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
 record.update(exit=result.returncode,status='complete',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/'check-build-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
run('fmt',['cargo','fmt','--all','--','--check'])
run('tests-build',['cargo','test','--release','--config','profile.release.package.rustx.opt-level=0','--locked','--all-features','--lib','--test','durable','--test','process','--no-run','--message-format=json'])
rows=[json.loads(line) for line in (root/'tests-build.stdout').read_text().splitlines() if line.startswith('{')]
artifacts={r['target']['name']:r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable')}
for label,selector in [('sqlite','durable::sqlite::'),('client','runtime_client::'),('read-layout','runtime::read_layout::'),('content','boundary_suites::durable::content::')]:
 run('tests-'+label,[artifacts['rustx'],selector,'--skip','::scale::','--test-threads=2'])
for name in ['durable','process']:
 run('tests-'+name,[artifacts[name],'--test-threads=2'])
run('clippy',['cargo','clippy','--release','--locked','--all-targets','--all-features','--','-D','warnings'])
run('optimized-build',['python3','benchmarks/runtime/build-revision.py','--repo',str(repo),'--target',str(target),'--output',str(root/'candidate-build')])
