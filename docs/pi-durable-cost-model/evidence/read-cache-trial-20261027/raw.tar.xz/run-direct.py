import datetime,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
before=Path('/home/capi/.cache/rustx-pr485-evidence/candidate-final-build/conformance')
after=root/'candidate-build/conformance'
records=[]
for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
 name='direct-'+label
 command=['python3','benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(root/name),'--pairs','3','--observer-mode',mode]
 record=dict(name=name,command=command,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');records.append(record)
 (root/'direct-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(name+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'UV_OFFLINE':'1'})
 record.update(exit=result.returncode,status='complete',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/'direct-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
