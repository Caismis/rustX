Parent independent review of b42faa94 found a shutdown regression: a dirty unobserved derived head cannot refresh after shutdown closes the worker reader. Existing post-shutdown checkpoints can silently expose bootstrap transcript/occupancy.

Targeted regressions added (test-only before fix):
- Two actual unobserved turns, native shutdown and worker drain, then first checkpoint and reattachment. Compare transcript/occupancy/projection head with the exact frozen native cut; append a later canonical message to prove it cannot enter the shutdown view; cursor/read cut must stay identical.
- One actual unobserved turn, direct subscription without any prior checkpoint, gated physical read, published ReadDomainsUpdated then current head.

Planned correction (not applied until red run): carry dirty status in immutable CheckpointSeed; on explicit closed-host checkpoint read, hydrate a request-owned copy at that seed's frozen native cut using the existing ordinary Store read surface. Do not reopen/cancel-change/restart projection reader, install a live repair, or publish a cursor. Rebuild finite Trace capture metadata for the copied head. Normal live demand remains worker-owned. Native generic transcript/trace/context observation methods read their original cut independently of the seed cache.

Prototype patch preparation script: /tmp/issue481-closed-checkpoint-fix.py. Harness work is paused and remains uncommitted, excluded from production fix commit.
