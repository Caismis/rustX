from pathlib import Path
import gzip
import hashlib
import json
import shutil

root = Path('/workspace/issue-481-evidence')
repo = Path('/workspace/rustX-pi-durable')
names = ['source-paired', 'whole-issue-runtime-paired', 'selected-source-paired',
         'selected-baseline-paired', 'selected-continued-paired',
         'selected-sql-removal-paired', 'statement-reuse-paired', 'reservations-paired',
         'sql-removal-confirmation', 'pi-parity-qpsg', 'pi-resident16-matrix',
         'pi-observer-demand-comparison']
paths = sorted(p for name in names for p in (root/name).rglob('*.json')
               if p.stat().st_size > 1024**2)
wanted = {str(p.relative_to(root)) for p in paths}
published = {}
for manifest in (repo/'docs').rglob('*.tar.manifest.json'):
    entries = json.loads(manifest.read_text())
    for name in wanted & entries.keys():
        published.setdefault(name, (str(manifest), entries[name]))
out = root/'historical-sample-json-retention.jsonl'
with out.open('x') as log:
    for path in paths:
        name = str(path.relative_to(root))
        digest = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
        size = path.stat().st_size
        if name in published:
            _, expected = published[name]
            assert digest == expected['sha256'] and size == expected['bytes'], name
        encoded = path.with_suffix(path.suffix+'.gz')
        with path.open('rb') as source, encoded.open('xb') as destination:
            with gzip.GzipFile(filename='', mode='wb', fileobj=destination, compresslevel=1, mtime=0) as stream:
                shutil.copyfileobj(source, stream, 1024*1024)
        restored = hashlib.sha256()
        count = 0
        with gzip.open(encoded, 'rb') as stream:
            while chunk := stream.read(1024*1024):
                restored.update(chunk)
                count += len(chunk)
        assert restored.hexdigest() == digest and count == size
        row = dict(original=str(path), retained=str(encoded), original_bytes=size,
                   original_sha256=digest, retained_bytes=encoded.stat().st_size,
                   retained_sha256=hashlib.file_digest(encoded.open('rb'),'sha256').hexdigest(),
                   published_manifest=published.get(name, (None,))[0],
                   restoration='gzip -dc retained > original; exact round-trip SHA-256 and byte length verified; published archive hash checked when available')
        log.write(json.dumps(row, sort_keys=True)+'\n');log.flush()
        path.unlink()
print(json.dumps(dict(files=len(paths), published_matches=len(published),
                      original_bytes=sum(json.loads(x)['original_bytes'] for x in out.read_text().splitlines()),
                      retained_bytes=sum(json.loads(x)['retained_bytes'] for x in out.read_text().splitlines()),
                      workspace_free_bytes=shutil.disk_usage('/workspace').free)))
