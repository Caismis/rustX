from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
paths={'before':Path('/workspace/issue-481-evidence/native-statement-reuse-build/conformance'),'after':Path('/workspace/issue-481-evidence/checkpoint-admission-build-2/conformance')}
expected={'before':'b87ae908b17dc9b63c2e6993a0c81d10c0960177','after':json.loads((paths['after'].parent/'identity.json').read_text())['head']}
gate=json.loads((root/'reviewed-oracle-full-gate.json').read_text())
assert gate['head']=='ce3c3c6ac97112bc5b1e68e75f87b147e3b33cd3' and gate['profile']=='full' and gate['conclusion']=='success' and gate['merge_verification']=='success'
identities={}
for name,binary in paths.items():
 identity=json.loads((binary.parent/'identity.json').read_text());assert identity['verified'] and identity['head']==expected[name]
 assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==identity['sha256'];identities[name]=identity
assert identities['before']['harness']==identities['after']['harness']
assert identities['before']['rustc']==identities['after']['rustc'] and identities['before']['cargo']==identities['after']['cargo']
assert identities['before']['build_environment']==identities['after']['build_environment']
assert all(hashlib.file_digest((repo/path).open('rb'),'sha256').hexdigest()==expected for path,expected in identities['after']['harness'].items())
git=lambda value:subprocess.check_output(['git','rev-parse',value],cwd=repo,text=True).strip()
assert git('HEAD:src')==identities['after']['production_tree']
assert git('HEAD:tests')==git(expected['after']+':tests')
assert git('HEAD:benchmarks')==git('ce3c3c6ac97112bc5b1e68e75f87b147e3b33cd3:benchmarks')
assert __import__('shutil').disk_usage('/workspace').free>1_800*1024**2
(root/'reporting-head.json').write_text(json.dumps({'reporting_head':git('HEAD'),'measured_source_head':expected['after'],'production_tree':git('HEAD:src'),'tests_tree':git('HEAD:tests'),'latest_main':git('origin/main')},indent=2)+'\n')
assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock'],cwd=repo)
processes=subprocess.check_output(['ps','-eo','stat=,comm='],text=True)
blocked=[line for line in processes.splitlines() if not line.strip().startswith('Z') and line.split()[-1] in ['rustc','clippy-driver','cargo','xz','gzip','strace','perf']]
assert not blocked,blocked
(root/'build-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
commands=[];failed=False
for mode in ['no-live-subscriber','live-subscriber']:
 command=['python3','benchmarks/runtime/compare-revisions.py','--before',str(paths['before']),'--after',str(paths['after']),'--output',str(root/mode),'--pairs','3','--observer-mode',mode]
 commands.append(command)
 with (root/f'{mode}.log').open('w') as log:
  result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=False)
 failed|=result.returncode!=0;print(mode,'exit',result.returncode,flush=True)
 if result.returncode==0:
  command=['python3','benchmarks/runtime/summarize-comparisons.py',str(root/mode)];commands.append(command)
  with (root/f'{mode}-summary.json').open('w') as summary,(root/f'{mode}-summary.stderr').open('w') as err:
   result=subprocess.run(command,cwd=repo,stdout=summary,stderr=err,check=False)
  failed|=result.returncode!=0
for kind in ['warm','cold']:
 command=['python3','benchmarks/runtime/compare-append.py','--before',str(paths['before']),'--after',str(paths['after']),'--output',str(root/f'{kind}-append'),'--pairs','3']
 if kind=='cold':command.append('--cold')
 commands.append(command)
 with (root/f'{kind}-append.log').open('w') as log:
  result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=False)
 failed|=result.returncode!=0;print(kind,'append exit',result.returncode,flush=True)
 if result.returncode==0:
  command=['python3','benchmarks/runtime/summarize-comparisons.py','--append',str(root/f'{kind}-append')];commands.append(command)
  with (root/f'{kind}-append-summary.json').open('w') as summary,(root/f'{kind}-append-summary.stderr').open('w') as err:
   result=subprocess.run(command,cwd=repo,stdout=summary,stderr=err,check=False)
  failed|=result.returncode!=0
(root/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
raise SystemExit(int(failed))
