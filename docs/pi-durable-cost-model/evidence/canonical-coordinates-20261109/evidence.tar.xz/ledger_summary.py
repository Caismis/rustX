"""Summarize authenticated WAL replay; preserve SQL bytes and OS counters separately."""
from collections import Counter,defaultdict
import json
import sys
from pathlib import Path

def load(p):
    return json.loads(p.read_text())

HOT='before_measured_turns'
GROUPS={
    'events and native/observation indexes': lambda n: n=='events' or n.startswith(('events_','sqlite_autoindex_events_')),
    'content frontiers and segment layout': lambda n: n.startswith(('content_','sqlite_autoindex_content_')),
    'request manifest and Source': lambda n: n.startswith(('native_input_nodes','request_source_','sqlite_autoindex_request_source_','sqlite_autoindex_native_input_nodes_')),
    'canonical and transcript rows': lambda n: n.startswith(('message_ledger','observation_header','observation_block_header','observation_block_','transcript_','surface_','pending_inbound','sqlite_autoindex_message_ledger_','sqlite_autoindex_observation_header','sqlite_autoindex_observation_block','sqlite_autoindex_transcript_','sqlite_autoindex_pending_inbound_','sqlite_autoindex_surface_')),
    'request owner/snapshot/model': lambda n: n.startswith(('request_snapshots','request_owners','observation_models','observation_model','sqlite_autoindex_request_snapshots_','sqlite_autoindex_request_owners_','sqlite_autoindex_observation_model','request_trace_retry_idx')),
    'request Trace catalog': lambda n: n.startswith(('request_trace_catalog','request_trace_definition','sqlite_autoindex_request_trace_catalog','sqlite_autoindex_request_trace_definition')),
    'unattributed': lambda n: n in ('unattributed_or_free','bootstrap_unattributed'),
}
def group(name):
    return next((k for k,matcher in GROUPS.items() if matcher(name)),'other btrees / page 1')

def summarize(path):
    v=load(path/'write-replay.json')
    before=load(path/'before_measured_turns-layout.json')
    after=load(path/'after_turns-layout.json')
    init=load(path/'after_initialization-layout.json')
    closed=load(path/'after_final_writer_close-layout.json')
    sample=load(path/'sample.json')
    ops=dict((tuple(k),n) for *k,n in v['totals'][HOT])
    commits=[c for c in v['commits'] if c['phase']==HOT]
    proc={p['phase']:dict(line.split(': ') for line in p['io'].splitlines()) for p in load(path/'phases.json')}
    delta=lambda start,end,k:int(proc[end][k])-int(proc[start][k])
    ledger=defaultdict(lambda:dict(wal_frames=0,main_bytes=0,retained_page_growth=0,net_logical_column_bytes=0))
    for name,n in v['wal_owners'][HOT].items(): ledger[group(name)]['wal_frames']+=n
    for name,n in v['main_owners'][HOT].items(): ledger[group(name)]['main_bytes']+=n
    for p,sign in ((after,1),(before,-1)):
        for name,*_ in p['dbstat']:
            ledger[group(name)]['retained_page_growth']+=sign
        for name,table in p['tables'].items():
            ledger[group(name)]['net_logical_column_bytes']+=sign*sum(table['column_bytes'].values())
    changes=defaultdict(Counter)
    phases=defaultdict(Counter)
    for c in commits:
        phases[c['semantic_phase']].update({'commits':1,'wal_frames':c['frames']})
        for table,change in c.get('committed_row_changes',{}).items(): changes[table].update(change)
    assert sum(c['frames'] for c in commits)==sum(v['wal_owners'][HOT].values())
    def col(name,col):
        return after['tables'][name]['column_bytes'][col]-before['tables'][name]['column_bytes'][col]
    def rows(name):
        return after['tables'][name]['rows']-before['tables'][name]['rows']
    def inventory(s):
        return {'page_count':s['pragma']['page_count'],'freelist':s['pragma']['freelist_count'],
                'useful_payload':sum(r[5] for r in s['dbstat']),'unused':sum(r[6] for r in s['dbstat']),
                'overflow_pages':sum(r[3]=='overflow' for r in s['dbstat'])}
    return {
        'history':sample['history'],'measured':sample['measured'],'schema':sample['schema'],
        'wal_bytes':ops[('wal','pwrite64','bytes')],'wal_frames':sum(c['frames'] for c in commits),
        'main_bytes':ops.get(('main','pwrite64','bytes'),0),'wal_epochs':ops.get(('wal','epochs','calls'),0),
        'checkpoint_main_syncs':ops.get(('main','fsync','calls'),0),'wal_syncs':ops.get(('wal','fsync','calls'),0),
        'distinct_wal_pages':v['unique_wal_pages'][HOT],'phase_writes':v['totals'],
        'phase_commits':phases,'group_ledger':ledger,
        'process_hot':{k:delta(HOT,'after_turns',k) for k in ('write_bytes','wchar','syscw','cancelled_write_bytes')},
        'process_through_close':{k:delta('before_initialization','after_final_writer_close',k)
                                 for k in ('write_bytes','wchar','syscw','cancelled_write_bytes')},
        'mutations_at_commits':changes,
        'native_nodes':rows('native_input_nodes'),'source_nodes':rows('request_source_nodes'),
        'source_metadata_bytes':col('request_source_nodes','metadata'),
        'source_pages':rows('request_source_pages'),'source_page_bytes':col('request_source_pages','bytes'),
        'request_catalogs':rows('request_trace_catalogs'),'request_catalog_definitions':rows('request_trace_definitions'),
        'native_events':rows('events'),'event_json_bytes':col('events','event_json'),
        'event_domain_bytes':{k:col('events',k) for k in after['tables']['events']['column_bytes'] if k.startswith('observation_')},
        'event_kinds':after['event_kinds'],
        'empty_opened_conversation':inventory(init),'pre_hot':inventory(before),
        'post_hot':inventory(after),'after_writer_close':inventory(closed),
        'authenticated_wal_owners':v['wal_owners'][HOT],'authenticated_main_owners':v['main_owners'][HOT],
    }

if __name__=='__main__':
    result=[summarize(Path(arg)) for arg in sys.argv[1:]]
    print(json.dumps(result,indent=2))
