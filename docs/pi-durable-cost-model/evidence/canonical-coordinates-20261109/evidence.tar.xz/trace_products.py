"""Trace SQLite syscalls and read-only checkpoints using the conformance profile boundary."""
import argparse
import contextlib
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import traceback

sys.path.insert(0,str(Path.cwd()/'benchmarks/runtime'))
from controller import TEST, run

def dump(path, value):
    path.write_text(json.dumps(value,indent=2)+'\n')

def quote(name):
    return '"'+name.replace('"','""')+'"'

def layout(db, *, immutable=False, columns=True):
    uri=db.as_uri()+('?immutable=1' if immutable else '?mode=ro')
    with contextlib.closing(sqlite3.connect(uri,uri=True,timeout=10)) as c:
        c.execute('PRAGMA query_only=ON')
        rows=c.execute("SELECT name,sql,rootpage FROM sqlite_schema WHERE type='table'").fetchall()
        if not any(name=='events' for name,_,_ in rows):
            return None
        result={'path':str(db),'reader_version':sqlite3.sqlite_version,
                'pragma':{key:c.execute(f'PRAGMA {key}').fetchone()[0] for key in
                          ('page_size','page_count','freelist_count','journal_mode','user_version','auto_vacuum')},
                'dbstat':c.execute('SELECT name,path,pageno,pagetype,ncell,payload,unused,pgsize FROM dbstat').fetchall()}
        if columns:
            result['tables']={}
            for name,ddl,root in rows:
                fields=[row for row in c.execute(f'PRAGMA table_xinfo({quote(name)})') if row[-1] in (0,3)]
                names=[row[1] for row in fields]
                expr=[f'coalesce(sum(length(cast({quote(col)} AS BLOB))),0)' for col in names]
                totals=c.execute(f'SELECT count(*),{",".join(expr)} FROM {quote(name)}').fetchone()
                result['tables'][name]={'ddl':ddl,'root':root,'rows':totals[0],'column_bytes':dict(zip(names,totals[1:]))}
            names=result['tables']['events']['column_bytes']
            fields=[f'coalesce(sum(length(cast({quote(col)} AS BLOB))),0)' for col in names]
            result['event_kinds']=[{'kind':kind,'rows':count,'column_bytes':dict(zip(names,totals))}
                                    for kind,count,*totals in c.execute("SELECT json_extract(event_json,'$.event.type'),count(*),"
                                    +','.join(fields)+' FROM events GROUP BY 1')]
            result['catalog_digests']=c.execute('SELECT count(*),count(DISTINCT snapshot_json) FROM request_snapshots').fetchone()
        return result

def trace_product(binary, case, history, directory, project):
    directory.mkdir(parents=True,exist_ok=False)
    command=[str(binary),TEST,'--exact','--ignored','--nocapture']
    trace_command=['strace','-f','-yy','-ttt','-xx','-s','4096','-e',
                   'trace=pwrite64,write,writev,fsync,fdatasync,ftruncate,rename,renameat,renameat2,unlink,unlinkat',
                   '-o',str(directory/'calls.strace'),'--',*command]
    start=subprocess.Popen
    state={}
    phases=[]
    problems=[]
    stop=threading.Event()
    with tempfile.TemporaryDirectory(prefix='rxw') as temp:
        sock_path=Path(temp)/'p'
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as listener:
            listener.bind(str(sock_path));listener.listen(1);listener.settimeout(.25)
            def product(command_,*args,**kwargs):
                if command_==command:
                    process=start(trace_command,*args,**kwargs)
                    state['tracer']=process.pid
                    return process
                return start(command_,*args,**kwargs)

            def phases_worker():
                try:
                    while not stop.is_set():
                        try:
                            conn,_=listener.accept()
                        except TimeoutError:
                            continue
                        with conn,conn.makefile('r') as reader:
                            name=reader.readline().strip()
                            children=Path(f"/proc/{state['tracer']}/task/{state['tracer']}/children").read_text().split()
                            assert len(children)==1,children
                            pid=children[0]
                            point={'phase':name,'epoch_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns(),
                                   'pid':int(pid),'io':Path(f'/proc/{pid}/io').read_text()}
                            if name in ('after_initialization','before_measured_turns','after_turns','after_final_writer_close'):
                                dbs=[db for db in directory.rglob('*') if db.suffix in ('.sqlite','.sqlite3','.db') and db.is_file()]
                                snapshots=[s for db in dbs if (s:=layout(db,immutable=name=='after_final_writer_close')) is not None]
                                assert len(snapshots)==1, dbs
                                dump(directory/f'{name}-layout.json',snapshots[0])
                            phases.append(point)
                            conn.sendall(b'K')
                except Exception:
                    problems.append(traceback.format_exc())

            thread=threading.Thread(target=phases_worker,daemon=True);thread.start()
            env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
            env.update(RUSTX_BENCH_CASE=case,RUSTX_BENCH_OUTPUT=str(directory/'sample.json'),
                       RUSTX_BENCH_OBSERVER_MODE='live-subscriber',RUSTX_BENCH_PROFILE_SOCKET=str(sock_path),UV_OFFLINE='1')
            if history is not None:
                env.update(RUSTX_BENCH_DIAGNOSTIC_HISTORY=str(history))
            subprocess.Popen=product
            try:
                verdict=run(command,directory/'sample',case,env,project)
            finally:
                subprocess.Popen=start
                stop.set();thread.join(12)
                dump(directory/'phases.json',phases)
                dump(directory/'trace-identity.json',{'binary':str(binary),'command':trace_command,'diagnostic_problems':problems,
                                                     'affinity':sorted(os.sched_getaffinity(0))})
    assert not problems,problems
    assert verdict['accepted'],verdict.get('error')
    print(directory, 'accepted', len(phases), flush=True)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--binary',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--provider-project',type=Path,default=Path('test-support/fake-provider'))
    parser.add_argument('--history',type=int,action='append',required=True)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    for n in args.history:
        trace_product(args.binary.resolve(),'short-large' if n==64 else 'short-small',
                      None if n in (8,64) else n,(args.output/f'h{n}').resolve(),args.provider_project.resolve())

if __name__=='__main__':
    main()
