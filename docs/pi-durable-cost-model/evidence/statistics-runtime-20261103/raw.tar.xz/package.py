"""Archive retained evidence without executable build products or checkouts."""
import hashlib,json,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=repo/'docs/pi-durable-cost-model/evidence/statistics-runtime-20261103';out.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
archive=out/'raw.tar.xz';assert not archive.exists()
entries=[];paths=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 relative=p.relative_to(r)
 if any(part in ['explain-before','explain-after','__pycache__','.git','.venv'] or part.startswith('.tmp') for part in relative.parts):continue
 if p.name in ['WORK-IN-PROGRESS.txt','conformance','librustx.rlib','statistics-probe','boundary-probe','explanation-probe','inspection-probe','probe'] or p.suffix in ['.pyc','.rlib']:continue
 # Defend against accidentally adding a renamed executable.
 with p.open('rb') as stream:assert stream.read(4)!=b'\x7fELF',relative
 entries.append({'path':relative.as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)});paths.append(p)
with tarfile.open(archive,'x:xz',preset=6) as t:
 for p,e in zip(paths,entries):t.add(p,arcname=e['path'],recursive=False)
with tarfile.open(archive,'r:xz') as t:
 assert t.getnames()==[e['path'] for e in entries]
 for member,e in zip(t,entries):
  assert member.isfile();body=t.extractfile(member).read();assert len(body)==e['bytes'] and hashlib.sha256(body).hexdigest()==e['sha256']
manifest={'archive':{'path':'raw.tar.xz','bytes':archive.stat().st_size,'sha256':sha(archive)},'members':entries,'scope':'Regular retained records, all successes and failures. No private directions, checkouts, environments, binaries, rlibs or symlinks.'};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'members':len(entries),'archive':manifest['archive']}))
