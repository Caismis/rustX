import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;label=sys.argv[1];repo=r/('explain-'+label);out=r/('explain-'+label+'-build');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=lambda:{str(p.relative_to(repo)):sha(p) for d in ['src','tests','benchmarks/runtime','test-support/fake-provider'] for p in sorted((repo/d).rglob('*')) if p.is_file() and '__pycache__' not in p.parts and '.venv' not in p.parts}|{n:sha(repo/n) for n in ['Cargo.toml','Cargo.lock']}
source=files();meta={'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source_files':source,'diagnostic_only':True,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2'}
for name,cmd in [('clean',['cargo','clean','--release','--package','rustx']),('build',['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json'])]:
 with (out/(name+'.stdout')).open('x') as so,(out/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,env=env,stdout=so,stderr=se)
 meta['commands'].append({'command':cmd,'exit':done.returncode});(out/'identity.json').write_text(json.dumps(meta,indent=2)+'\n');print(label,name,done.returncode,flush=True)
 if done.returncode:raise SystemExit(done.returncode)
rows=[json.loads(l) for l in (out/'build.stdout').read_text().splitlines() if l.startswith('{')];arts=[v for v in rows if v.get('reason')=='compiler-artifact' and v['target']['src_path'].startswith(str(repo))];assert arts and all(v['profile']['opt_level']=='3' and v['features']==[] and not v['fresh'] for v in arts)
for v in arts:
 if v['target']['name']=='conformance' and v.get('executable'):shutil.copy2(v['executable'],out/'conformance')
 if v['target']['name']=='rustx' and v['target']['kind']==['lib']:
  shutil.copy2(next(f for f in v['filenames'] if f.endswith('.rlib')),out/'librustx.rlib')
assert files()==source;meta.update(binary=str(out/'conformance'),sha256=sha(out/'conformance'),end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),verified=True)
(out/'identity.json').write_text(json.dumps(meta,indent=2)+'\n');print(label,'done',flush=True)
