import argparse,hashlib,importlib.util,json,re,statistics,sys
from pathlib import Path
from types import SimpleNamespace
from fixture_binding import FORMAL_PROTOCOL,validate_affinity
r=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--raw-only',action='store_true');p.add_argument('--output',type=Path);args=p.parse_args()
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mod(name,file):
 s=importlib.util.spec_from_file_location(name,r/file);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);return v
a=mod('paired_audit','direct-audit.py');a.MATH=mod('counter_math','recompute-pi.py');pre=load(r/'premeasurement.json');audit=a.Audit()
assert pre['accepted'] and pre['protocol']==FORMAL_PROTOCOL
assert sha(r/'recompute-pi.py')=='e2879454bd2c6ed1add046dd55d6ceaa3c7451087ee92e6e008afcbf7a7e1ac3'
validate_affinity(pre['affinity']);final_affinity=load(r/'affinity-after.json');validate_affinity(final_affinity);assert final_affinity['topology']==pre['affinity']['topology']
assert all(sha(r/n)==h for n,h in pre['scripts'].items())
assert load(r/'source-after-measurement.json')==pre['source']
assert load(r/'checks-final-2/source-before.json')['files']==load(r/'checks-final-2/source-after.json')['files']==pre['source']['source_files']
checks=load(r/'checks-final-2/check-build-commands.json');assert len(checks)==16 and all(x['status']=='complete' and x['exit']==0 for x in checks)
seen=set();ignored=0
for item in checks:
 if item['label'].startswith('tests-') and item['label']!='tests-build':
  text=(r/'checks-final-2'/(item['label']+'.stdout')).read_text();m=re.search(r'test result: ok[.] (\d+) passed; (\d+) failed; (\d+) ignored;',text);assert m
  names=set(re.findall(r'^test (\S+) \.\.\. ok$',text,re.M));assert len(names)==int(m[1]) and int(m[2])==0 and not names&seen;seen|=names;ignored+=int(m[3])
assert len(seen)==2371 and ignored==1
builds=pre['builds']
for label in ['baseline','candidate']:
 b=builds[label];assert b==load(r/(label+'-build/identity.json'))
 artifacts=[json.loads(line) for line in (r/(label+'-build/build.stdout')).read_text().splitlines() if line.startswith('{')]
 artifacts=[v for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name'] in ['rustx','conformance']]
 assert artifacts and all(v['profile']['opt_level']=='3' and v['features']==[] and not v['fresh'] for v in artifacts)
 assert all(c['exit']==0 for c in b['commands'])
 if not args.raw_only:assert b['sha256']==sha(Path(b['binary']))
audit_args=SimpleNamespace(root=r,expected_harness_revision=builds['candidate']['head'],raw_only=True)
data=a.paired_dataset(audit_args,audit,'direct',builds['baseline'],builds['candidate'])
diagnostics=[]
for label,revision in [('baseline','baseline'),('complete','candidate')]:
 for kind in ['columns','wal']:
  records=load(r/(kind+'-records-'+label+'.json'));assert len(records)==2 and all(x['accepted'] for x in records)
  for case in ['short-small','short-large']:
   directory=r/(kind+'-'+label+'-'+case+('-rust' if kind=='wal' else ''))
   identity=load(directory/'identity-before.json');after=load(directory/'identity-after.json');assert identity['binary_sha256']==after['binary_sha256']==builds[revision]['sha256']
   raw=load(directory/'sample.json');proc=load(directory/'sample.process.json');assert raw['schema']==(89 if revision=='baseline' else 90)
   a.derived_product(raw,proc,case,'no-live-subscriber','before' if revision=='baseline' else 'after',{'clock_ticks':100,'executables':{engine:{'path':builds[key]['binary'],'sha256':builds[key]['sha256']} for engine,key in [('before','baseline'),('after','candidate')]}})
   if kind=='columns':
    b=load(directory/'before_measured_turns.json');e=load(directory/'after_turns.json');tables={}
    for t,x in e['tables'].items():
     y=b['tables'][t];tables[t]={'rows':x['rows']-y['rows'],'bytes':sum(x['column_value_bytes'].values())-sum(y['column_value_bytes'].values()),'columns':{c:n-y['column_value_bytes'].get(c,0) for c,n in x['column_value_bytes'].items()}}
    assert tables['events']['rows']==256
    source='observation_source_overlay' if revision=='baseline' else 'observation_source';assert tables['events']['columns'][source]>0
    if revision=='candidate':assert tables['events']['columns'][source]==256*33
    diagnostics.append({'revision':revision,'case':case,'tables':tables,'source_records_before':b['event_source_records'],'source_records_after':e['event_source_records'],'statistics':{key:e['statistics_layout'][key]-b['statistics_layout'][key] for key in ['facts','fact_bytes','full_states','full_state_bytes']},'dbstat_before':b['dbstat'],'dbstat_after':e['dbstat']})
wal={label:load(r/('wal-summary-'+label+'-corrected.json')) for label in ['baseline','complete']}
assert all(w['wal_write_commits']==160 for rows in wal.values() for w in rows.values())
commands=load(r/'net-probes/commands.json');assert len(commands)==32
probes=[];by_pair={}
for row in commands:
 pair,case,label=row['pair'],row['case'],row['revision'];assert row['exit']==0
 kind=row['kind'];meta=load(r/(label+'-build')/(kind+'-probe.json'));assert row['binary_sha256']==meta['binary_sha256'] and meta['source_sha256']==pre['scripts'][kind+'-probe.rs']
 stem=f'{pair}-{case}-{label}';raw=load(r/'net-probes'/(stem+'.json'));assert raw['oracle']=='passed'
 times=[float(x) for x in (r/'net-probes'/(stem+'.time')).read_text().split()];assert len(times)==4 and all(x>=0 for x in times)
 metrics={'full_cpu_ms':(times[0]+times[1])*1000,'max_rss_kib':times[2]}
 if kind=='statistics':
  assert raw['events']==int(case.split('-')[1]) and raw['concurrent']==case.endswith('concurrent')
  assert raw['tail']['cut']==63 and raw['checkpoint']['cut']==64
  for cut in ['tail','checkpoint']:
   v=raw[cut];assert len(v['repeated_ns'])==32
   metrics[cut+'_first_us']=v['first_ns']/1000;metrics[cut+'_repeat_us']=statistics.median(v['repeated_ns'])/1000
  metrics['append_ms']=raw['append_ns']/1e6
  assert len(raw['concurrent_reads_ns'])==(64 if raw['concurrent'] else 0)
  metrics['concurrent_read_us']=statistics.median(raw['concurrent_reads_ns'])/1000 if raw['concurrent'] else None
  metrics['concurrent_writer_ms']=raw['concurrent_writer_ns']/1e6 if raw['concurrent'] else None
  def io(text):return {k:int(v) for k,v in (line.split(':',1) for line in text.splitlines())}
  phases=[io(raw[k]) for k in ['io_before','io_after_append','io_after_read','io_after_close']]
  assert all(v['write_bytes']<=w['write_bytes'] for v,w in zip(phases,phases[1:]))
  metrics['append_write_bytes']=phases[1]['write_bytes']-phases[0]['write_bytes'];metrics['read_write_bytes']=phases[2]['write_bytes']-phases[1]['write_bytes'];metrics['full_write_bytes']=phases[-1]['write_bytes']
 else:
  assert raw['native_bytes']==int(case.split('-')[-1]) and len(raw['read_ns'])==9 and raw['structural_bytes']>=raw['native_bytes']
  metrics['first_read_us']=raw['read_ns'][0]/1000;metrics['repeat_read_us']=statistics.median(raw['read_ns'][1:])/1000
  if row['traced']:
   trace=(r/'net-probes'/(stem+'.strace')).read_text();start=trace.index('BOUNDARY_READ_BEGIN');end=trace.index('BOUNDARY_READ_END');lines=trace[start:end].splitlines()
   creates=sum('openat(' in line and 'index.sqlite' in line and 'O_CREAT' in line for line in lines);metrics['read_temp_index_creations']=creates;assert creates==(9 if label=='baseline' else 0)
 by_pair.setdefault((pair,case),{})[label]=raw
 probes.append({'pair':pair,'case':case,'revision':label,'traced':row['traced'],'metrics':metrics})
for (pair,case),values in by_pair.items():
 assert set(values)=={'baseline','candidate'}
 if case.startswith('statistics'):
  for cut in ['tail','checkpoint']:assert values['baseline'][cut]['value']==values['candidate'][cut]['value']
 else:assert values['baseline']['structural_bytes']==values['candidate']['structural_bytes']
assert len([x for x in probes if x['case'].startswith('statistics')])==12
assert len([x for x in probes if x['traced']])==4
report={'accepted':not audit.errors,'errors':audit.errors,'raw_only':args.raw_only,'distinct_tests_passed':len(seen),'ignored':ignored,'dataset':data,'columns':diagnostics,'wal':wal,'probes':probes,'scope':'Fresh Rust only; 32 formal + 12 Statistics + 16 boundary + 4 traced boundary + 8 columns/WAL products, phases separate. Prior explanation stage 40 diagnostic products remains separate. No Pi/DeepSeek runs or new ratios.'}
output=args.output or r/'audit.json';assert not output.exists();output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'accepted':report['accepted'],'errors':audit.errors,'products':data['derived_products'],'probes':len(probes),'tests':len(seen)}));raise SystemExit(int(bool(audit.errors)))
