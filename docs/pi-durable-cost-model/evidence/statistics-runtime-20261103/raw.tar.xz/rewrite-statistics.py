from pathlib import Path
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
p=repo/'src/durable/sqlite/observation_statistics.rs';s=p.read_text();s=s.replace('//! Finite aggregate read layouts attached to the existing native Journal commit.','//! Independent statistical facts with bounded checkpoint replay in the native commit.')
s=s.replace('use crate::runtime_client::response::{ConversationStatistics, ConversationTurnClock};','use crate::runtime_client::response::{ConversationStatistics, ConversationTurnClock};\nmod contribution;\nmod history;\nmod owner;\npub(super) use owner::FoldCache;')
a=s.index('#[derive(Default)]\npub(super) struct FoldCache(');b=s.index('fn at_cut(',a)
s=s[:a]+'''fn layout(connection: &Connection, through: u64) -> Result<StatisticsLayout, ConversationStoreError> {
    Ok(history::layout(connection, through)?.state)
}
'''+s[b:]
a=s.index('/// Reuse the freshly encoded value');b=s.index('pub(super) fn agent_read(',a);s=s[:a]+s[b:]
s=s.replace('fold: Option<StatisticsLayout>,','pub(super) checkpoint: Option<Vec<u8>>,\n    fold: Option<(history::Frame, u64)>,')
a=s.index('impl Prepared {');b=s.index('\n#[cfg(test)]\npub(super) fn prepare(',a)
s=s[:a]+'''impl Prepared {
    pub(super) fn remember(self, cache: &FoldCache) {
        if let Some((fold, data)) = self.fold { cache.stage(fold, data); }
    }
}
'''+s[b:]
s=s.replace('statistics: None,\n        fold: None,','statistics: None,\n        checkpoint: None,\n        fold: None,')
a=s.index('    let mut state = layout_cached(');b=s.index('// These are exactly the fields',a)
s=s[:a]+'''    let through=event.sequence.saturating_sub(1);
    let (data,cached)=match cache {Some(cache)=>cache.take(connection,through)?,None=>(0,None)};
    let mut frame=match cached {Some(frame)=>frame,None=>history::layout(connection,through)?};
    let contribution=contribution::Contribution::capture(connection,event,attempt,&frame.state)?;
    contribution.apply(event.sequence,&mut frame.state)?;
    frame.state=normalized_fold(frame.state);
    let (record,checkpoint)=history::Record::capture(&frame,event.sequence,contribution,&frame.state)?;
    let bytes=record.encode()?;
    let value=frame.state.statistics.clone();
    frame.sequence=event.sequence;frame.anchor=record.anchor;frame.distance=record.distance;
    if cache.is_some(){prepared.fold=Some((frame,data));}
    prepared.statistics=Some(super::append_facts::Captured{bytes,value});
    prepared.checkpoint=checkpoint;
    Ok(prepared)
}
'''+s[b:]
a=s.index('fn fold_statistics(');b=s.index('fn settle_duration(',a);s=s[:a]+s[b:]
a=s.index('fn record_duration(');b=s.index('fn tool_settlement(',a);s=s[:a]+s[b:]
a=s.index('fn close_clock(');b=s.index('pub(super) fn trace_total(',a);s=s[:a]+s[b:]
s=s.replace('#[cfg(test)]\npub(super) fn original_read()', '''#[cfg(test)]
fn record_read(rows: usize, bytes: usize) {
    READ_WORK.with(|work| { let (prior,total,original)=work.get();work.set((prior+rows,total+bytes,original)); });
}
#[cfg(test)]
pub(super) fn original_read()''')
p.write_text(s)
p=repo/'src/durable/sqlite/observation_turn.rs';s=p.read_text().replace('super::observation_statistics::read_prepared(connection, event.sequence, statistics)?.turns','super::observation_statistics::read(connection, event.sequence)?.turns');p.write_text(s)
p=repo/'src/durable/sqlite/event_heads.rs';s=p.read_text();a=s.index('pub(super) const STATISTICS:');b=s.index('pub(super) const TRACE_TOTAL:',a);old=s[a:b];new=old.replace('STATISTICS:', 'STATISTICS_SEQUENCE:').replace('SELECT observation_statistics FROM events WHERE sequence=(\n    SELECT max(sequence) FROM (','SELECT max(sequence) FROM (').replace('    ))";','    )";');s=s[:a]+new+s[b:];p.write_text(s)
p=repo/'src/durable/sqlite/event_heads/tests.rs';s=p.read_text().replace('(STATISTICS,','(STATISTICS_SEQUENCE,');s=s.replace('let oracle = format!(\n            "SELECT {column}', 'let selected_column=if sql==STATISTICS_SEQUENCE {"sequence"} else {column};\n        let oracle = format!(\n            "SELECT {selected_column}');p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics/owner.rs';s=p.read_text().replace('selected.get(3).is_none_or(|column|new.get_new_column_value(*column).is_err_or(|value|value!=rusqlite::types::ValueRef::Integer(0)))','selected.get(3).is_none_or(|column|!new.get_new_column_value(*column).is_ok_and(|value|value==rusqlite::types::ValueRef::Integer(0))) || selected.get(1..3).is_none_or(|columns|columns.iter().any(|column|!new.get_new_column_value(*column).is_ok_and(|value|value==rusqlite::types::ValueRef::Null)))');p.write_text(s)
p=repo/'src/durable/sqlite/event_insert.rs';s=p.read_text().replace('statistics: observation_statistics::FoldCache,','statistics: std::sync::Arc<observation_statistics::FoldCache>,').replace('statistics: observation_statistics::FoldCache::default(),','statistics: observation_statistics::FoldCache::uninstalled(),',1).replace('pub(super) fn new(connection: &Connection) -> Self {','pub(super) fn new(connection: &Connection, statistics: std::sync::Arc<observation_statistics::FoldCache>) -> Self {').replace('statistics: observation_statistics::FoldCache::default(),','statistics,',1)
s=s.replace('        Self {\n            installed,\n            statistics,','        if installed.is_none(){statistics.disable();}\n        Self {\n            installed,\n            statistics,')
s=s.replace('        no_custom_triggers(connection)\n    }','        self.statistics.disable();\n        no_custom_triggers(connection)\n    }\n    pub(super) fn publish_statistics(&self, connection: &Connection) { self.statistics.publish(connection); }',1)
s=s.replace('observation_trace_total,observation_statistics,observation_members,','observation_trace_total,observation_statistics,observation_statistics_checkpoint,observation_members,')
s=s.replace('?35,?36,?37,?38)",','?35,?36,?37,?38,?39)",')
# Append the checkpoint as parameter 39 to keep all existing positional bindings unchanged.
s=s.replace('observation_turn_prompt_positive,observation_unavailable)','observation_turn_prompt_positive,observation_unavailable,observation_statistics_checkpoint)')
# The checkpoint name appears once, at the final positional column only.
s=s.replace('observation_trace_total,observation_statistics,observation_statistics_checkpoint,observation_members,','observation_trace_total,observation_statistics,observation_members,')
s=s.replace('!row.available])','!row.available,aggregate.and_then(|value|value.statistics.checkpoint.as_ref())])')
p.write_text(s)
p=repo/'src/durable/sqlite/append_facts.rs';s=p.read_text();s=s.replace('    let anchor = prepared.member_anchor();','    let anchor = prepared.member_anchor();\n    let checkpoint=prepared.statistics.checkpoint.as_ref();')
s=s.replace('observation_statistics=?2,','observation_statistics=?2,observation_statistics_checkpoint=?6,').replace('observation_statistics=?2 WHERE','observation_statistics=?2,observation_statistics_checkpoint=?6 WHERE')
s=s.replace('                event.sequence\n','                event.sequence,\n                checkpoint\n')
p.write_text(s)
p=repo/'src/durable/sqlite.rs';s=p.read_text().replace('/// Version 89 tags exact inline event sources and defers closed-family navigation.\npub const SQLITE_SCHEMA_VERSION: i64 = 89;','/// Version 90 stores independent statistical contributions with sparse checkpoints.\npub const SQLITE_SCHEMA_VERSION: i64 = 90;')
s=s.replace('    observer: &\'a Mutex<Option<(Arc<dyn super::presentation::JournalObserver>, u64)>>,','    observer: &\'a Mutex<Option<(Arc<dyn super::presentation::JournalObserver>, u64)>>,\n    event_guard: &\'a event_insert::Guard,')
s=s.replace('        if self.connection.total_changes() == self.changes || !self.connection.is_autocommit() {','        self.event_guard.publish_statistics(&self.connection);\n        if self.connection.total_changes() == self.changes || !self.connection.is_autocommit() {',1)
s=s.replace('        let rollback = Arc::clone(&append_validation);','        let statistics=observation_statistics::FoldCache::new(&connection)?;\n        let statistics_rollback=Arc::clone(&statistics);\n        let rollback = Arc::clone(&append_validation);')
s=s.replace('.rollback_hook(Some(move || rollback.invalidate()))','.rollback_hook(Some(move || { rollback.invalidate(); statistics_rollback.invalidate(); }))')
s=s.replace('            Arc::clone(&response),\n        )?;','            Arc::clone(&response),\n            Arc::clone(&statistics),\n        )?;',1).replace('event_insert::Guard::new(&connection)','event_insert::Guard::new(&connection, statistics)')
s=s.replace('            observer: &self.journal_observer,','            observer: &self.journal_observer,\n            event_guard: &self.conn.event_guard,')
# Only events get a checkpoint; rustx_store retains the authoritative bootstrap.
a=s.index('CREATE TABLE IF NOT EXISTS events (') if 'CREATE TABLE IF NOT EXISTS events (' in s else s.index('CREATE TABLE events (')
b=s.index('observation_statistics BLOB CHECK(observation_statistics IS NULL OR length(observation_statistics)<=49152),',a)
e=b+len('observation_statistics BLOB CHECK(observation_statistics IS NULL OR length(observation_statistics)<=49152),')
s=s[:e]+'\n                observation_statistics_checkpoint BLOB CHECK(observation_statistics_checkpoint IS NULL OR (typeof(observation_statistics_checkpoint)=\'blob\' AND length(observation_statistics_checkpoint)<=49152)),'+s[e:]
s=s.replace('                "observation_statistics_required",','                "observation_statistics_required",\n                "observation_statistics_checkpoint",')
p.write_text(s)
p=repo/'src/durable/sqlite/manifest.rs';s=p.read_text().replace('        response: Arc<super::observation_response::Owner>,','        response: Arc<super::observation_response::Owner>,\n        statistics: Arc<super::observation_statistics::FoldCache>,').replace('                    response.observe(table, change);','                    response.observe(table, change);\n                    statistics.observe(table, change);');p.write_text(s)
