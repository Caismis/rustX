from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent
profile='''//! Diagnostic-only patch; never shipped as an ordinary production artifact.
use std::sync::atomic::{AtomicU64,Ordering};
static VALUES:[AtomicU64;16]=[const{AtomicU64::new(0)};16];
pub fn count(key:usize){VALUES[key].fetch_add(1,Ordering::Relaxed);}
pub struct Span(usize,std::time::Instant);
pub fn time(key:usize)->Span{Span(key,std::time::Instant::now())}
impl Drop for Span{fn drop(&mut self){VALUES[self.0].fetch_add(u64::try_from(self.1.elapsed().as_nanos()).unwrap_or(u64::MAX),Ordering::Relaxed);}}
pub fn snapshot()->serde_json::Value{
 let names=["source_builds","source_build_ns","source_encodes","source_encode_ns","layout_builds","layout_build_ns","temp_indexes","event_schema_builds","event_schema_ns","event_plan_builds","event_plan_ns","all_encodes","all_encode_ns","source_loads","source_load_ns","geometry_visits"];
 serde_json::Value::Object(names.into_iter().enumerate().map(|(i,k)|(k.into(),VALUES[i].load(Ordering::Relaxed).into())).collect())
}
'''
def replace(p,old,new):
 s=p.read_text();assert s.count(old)==1,(p,old,s.count(old));p.write_text(s.replace(old,new))
for label in ['before','after']:
 repo=r/('explain-'+label)
 (repo/'src/observation_probe.rs').write_text(profile)
 with (repo/'src/lib.rs').open('a') as f:f.write('\n#[doc(hidden)] pub mod observation_probe;\n')
 p=repo/'src/runtime/read_layout.rs'
 replace(p,'fn initialize_index(&mut self, memory: bool) -> Result<(), &\'static str> {','fn initialize_index(&mut self, memory: bool) -> Result<(), &\'static str> {\n        if !memory { crate::observation_probe::count(6); }')
 replace(p,'let mut layout = Layout::unindexed();\n        {\n            use std::io::Write as _;','crate::observation_probe::count(0);\n        let _source_span = crate::observation_probe::time(1);\n        let mut layout = Layout::unindexed();\n        {\n            crate::observation_probe::count(2);\n            let _encode_span = crate::observation_probe::time(3);\n            use std::io::Write as _;')
 replace(p,'fn from_layout(mut layout: Layout) -> Result<Self, &\'static str> {','fn from_layout(mut layout: Layout) -> Result<Self, &\'static str> {\n        crate::observation_probe::count(4);\n        let _layout_span=crate::observation_probe::time(5);')
 replace(p,'pub(crate) fn visit_field_geometry(\n        &self,\n        mut visit: impl FnMut(FieldGeometry) -> Result<(), &\'static str>,\n    ) -> Result<(), &\'static str> {','pub(crate) fn visit_field_geometry(\n        &self,\n        mut visit: impl FnMut(FieldGeometry) -> Result<(), &\'static str>,\n    ) -> Result<(), &\'static str> {\n        crate::observation_probe::count(15);')
 p=repo/'src/runtime_client/structural_json.rs'
 replace(p,'struct SchemaOwner {','struct SchemaOwner {\n    diagnostic_event: bool,')
 replace(p,'schema: schema.clone(),\n        plan: std::sync::OnceLock::new(),','schema: schema.clone(),\n        diagnostic_event: identity == std::any::type_name::<crate::events::types::RuntimeEventEnvelope>(),\n        plan: std::sync::OnceLock::new(),')
 replace(p,'std::sync::Arc::new(plan::Plan::new(&self.schema, &self.schema))','{\n                    let _span=self.diagnostic_event.then(|| {crate::observation_probe::count(9);crate::observation_probe::time(10)});\n                    std::sync::Arc::new(plan::Plan::new(&self.schema, &self.schema))\n                }')
 replace(p,'let schema = std::sync::Arc::new(\n        serde_json::to_value(schemars::schema_for!(T)).expect("native structural schema"),\n    );','let schema = {\n        let _span=(identity == std::any::type_name::<crate::events::types::RuntimeEventEnvelope>()).then(|| {crate::observation_probe::count(7);crate::observation_probe::time(8)});\n        std::sync::Arc::new(serde_json::to_value(schemars::schema_for!(T)).expect("native structural schema"))\n    };')
 replace(p,'let root = root::<T>();\n    serde_json::to_writer(','crate::observation_probe::count(11);\n    let _span=crate::observation_probe::time(12);\n    let root = root::<T>();\n    serde_json::to_writer(')
 p=repo/'src/durable/sqlite/observation_event/inline.rs'
 replace(p,') -> Result<Self, ConversationStoreError> {\n        //',') -> Result<Self, ConversationStoreError> {\n        crate::observation_probe::count(13);\n        let _span=crate::observation_probe::time(14);\n        //')
 p=repo/'tests/conformance/agent_loop/runtime_benchmark.rs'
 replace(p,'"smaps_rollup": std::fs::read_to_string("/proc/self/smaps_rollup").ok(),','"smaps_rollup": std::fs::read_to_string("/proc/self/smaps_rollup").ok(),\n        "observation_probe":rustx::observation_probe::snapshot(),')
 p=repo/'tests/conformance/agent_loop/runtime_benchmark/aligned.rs'
 replace(p,'"stream" | "large" | "tool" | "cancel" => (0, 1),','"stream" => (0, 8),\n        "large" | "tool" | "cancel" => (0, 1),')
 replace(p,'let began = Instant::now();\n        driver.display.lock().unwrap().first_content = None;','let began = Instant::now();\n        let diagnostic_before=process_sample();\n        let mut diagnostic_finish=serde_json::Value::Null;\n        driver.display.lock().unwrap().first_content = None;')
 replace(p,'let gate = format!("delta-{delta}");','let gate = format!("turn-{turn}-delta-{delta}");')
 replace(p,'emulator.release_gate(&gate).await;\n            }','emulator.release_gate(&gate).await;\n            }\n            let gate=format!("turn-{turn}-settlement");\n            emulator.await_gate(&gate).await;\n            diagnostic_finish=process_sample();\n            emulator.release_gate(&gate).await;')
 replace(p,'"accepted_us":accepted_us,"settled_us":settled_us,','"accepted_us":accepted_us,"settled_us":settled_us,\n            "diagnostic_before":diagnostic_before,"diagnostic_finish":diagnostic_finish,')
 replace(p,'"stream" => (0..128).map(|i| format!("stream-delta-{i:04} ")).collect(),','"stream" => (0..measured).flat_map(|_|(0..128).map(|i| format!("stream-delta-{i:04} "))).collect(),')
 p=repo/'tests/conformance/agent_loop/runtime_benchmark/request_oracle.rs'
 replace(p,'if case.starts_with("short-") {','if case == "stream" {\n        for turn in 0..index {\n            messages.push(user(&format!("benchmark turn {turn:04}")));\n            messages.push(assistant(&(0..128).map(|i|format!("stream-delta-{i:04} ")).collect::<String>()));\n        }\n        messages.push(user(&format!("benchmark turn {index:04}")));\n    } else if case.starts_with("short-") {')
 p=repo/'test-support/fake-provider/src/fake_provider/scenarios/runtime_benchmark.py'
 replace(p,'count = {"short-small": 40, "short-large": 96}.get(case, 1)','count = {"short-small": 40, "short-large": 96, "stream": 8}.get(case, 1)')
 replace(p,'Gate(f"delta-{i}"))] + [Finish()]','Gate(f"turn-{turn}-delta-{i}"))] + [Gate(f"turn-{turn}-settlement"), Finish()]')
 replace(p,'if turn:\n            expected.append(f"reply {turn-1:04}")','if turn and case != "stream":\n            expected.append(f"reply {turn-1:04}")')
 p=repo/'benchmarks/runtime/controller.py'
 replace(p,"expected_requests = {'short-small':40,'short-large':96,'tool':2}.get(case,1)","expected_requests = {'short-small':40,'short-large':96,'tool':2,'stream':8}.get(case,1)")
 replace(p,'expected_measured=32 if expected_history else 1','expected_measured=32 if expected_history else 8 if case=="stream" else 1')
 replace(p,"assert set(point['process'])=={'stat','io','smaps_rollup'}","assert set(point['process'])=={'stat','io','smaps_rollup','observation_probe'}")
 replace(p,"assert all(set(point['process']) == {'stat', 'io', 'smaps_rollup'} for point in phases)","assert all(set(point['process']) == {'stat', 'io', 'smaps_rollup', 'observation_probe'} for point in phases)")
 (r/('explain-'+label+'.patch')).write_bytes(subprocess.check_output(['git','diff'],cwd=repo))
 print(label,'patched')
