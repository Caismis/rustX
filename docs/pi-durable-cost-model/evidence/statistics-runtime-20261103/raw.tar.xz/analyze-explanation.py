import hashlib,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;o=r/'explanation-products';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pre=load(o/'premeasurement.json');records=load(o/'commands.json');assert load(o/'completed.json')['accepted'] and len(records)==40
assert all(sha(r/n)==h for n,h in pre['scripts'].items())
def ticks(p):
 v=p['stat'].rsplit(') ',1)[1].split();return int(v[11])+int(v[12])
def diff(a,b):return {k:b[k]-a[k] for k in a}
stream=[];inspection=[]
for row in records:
 if row['kind']=='stream':
  assert row['accepted'];process=load(o/row['process_file']);assert process['accepted'] and process['product_exit']==process['provider_exit']==0
  raw=load(o/row['process_file'].replace('.process.json','.json'));assert raw['oracle']=='passed' and raw['measured']==8 and raw['verified_live_requests']==raw['verified_reopened_requests']==8 and len(raw['samples'])==8
  samples=raw['samples'];life={p['phase']:p['process'] for p in raw['lifecycle']}
  values={'streaming_cpu_ms':sum((ticks(p['diagnostic_finish'])-ticks(p['diagnostic_before']))*10 for p in samples),'finish_to_settled_cpu_ms':sum((ticks(p['process'])-ticks(p['diagnostic_finish']))*10 for p in samples),'complete_turn_window_cpu_ms':(ticks(samples[-1]['process'])-ticks(samples[0]['diagnostic_before']))*10,'late_snapshot_and_verification_cpu_ms':(ticks(life['after_verification'])-ticks(life['after_turns']))*10,'reopen_verification_cpu_ms':(ticks(life['after_reopen_verification'])-ticks(life['after_final_writer_close']))*10,'whole_product_cpu_ms':ticks(life['after_cleanup'])*10,'median_settled_ms':statistics.median(p['settled_us'] for p in samples)/1000}
  counters={'request':diff(samples[0]['diagnostic_before']['observation_probe'],samples[-1]['process']['observation_probe']),'checks':diff(life['after_turns']['observation_probe'],life['after_verification']['observation_probe']),'reopen':diff(life['after_final_writer_close']['observation_probe'],life['after_reopen_verification']['observation_probe'])}
  stream.append({'pair':row['pair'],'mode':row['mode'],'revision':row['revision'],'metrics':values,'counters':counters})
 else:
  assert row['exit']==0;stem=f"inspection-{row['pair']}-{row['case']}-{row['revision']}";raw=load(o/(stem+'.json'));assert raw['oracle']=='passed'
  points=raw['points'];assert len(points)==(3 if row['case']=='aba' else 9)
  calls=[{'elapsed_us':p['elapsed_ns']/1e3,'source_bytes':p['source_bytes'],'counters':diff(p['before'],p['after'])} for p in points]
  inspection.append({'pair':row['pair'],'case':row['case'],'revision':row['revision'],'native_lengths':raw['native_lengths'],'append_counters':diff(raw['initial'],raw['after_append']),'calls':calls,'repeat_median_us':statistics.median(p['elapsed_us'] for p in calls[1:])})
result={'accepted':True,'stream':stream,'inspection':inspection,'scope':'Eight diagnostic stream products (64 requests), 32 inspection products. Explicit instrumented O3 patches; no ordinary performance/parity claim; no Pi/DSH.'};p=r/'explanation-analysis.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
for x in stream:print('STREAM',x['pair'],x['mode'],x['revision'],x['metrics'],{k:v for k,v in x['counters']['request'].items() if not k.endswith('_ns')})
for x in inspection:
 if x['pair']==0:print('INSPECT',x['case'],x['revision'],'append schema/plan',x['append_counters']['event_schema_builds'],x['append_counters']['event_plan_builds'],'calls',[(round(c['elapsed_us'],2),c['source_bytes'],c['counters']['event_schema_builds'],c['counters']['event_plan_builds'],c['counters']['temp_indexes']) for c in x['calls'][:3]],'repeat',round(x['repeat_median_us'],2))
