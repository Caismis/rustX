import hashlib,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;label=sys.argv[1];out=r/('explain-'+label+'-build');repo=r/('explain-'+label)
rows=[json.loads(l) for l in (out/'build.stdout').read_text().splitlines() if l.startswith('{')]
cmd=['rustc','--edition=2024','-O','-D','warnings',str(r/'explanation-probe.rs'),'--extern','rustx='+str(out/'librustx.rlib'),'-L','dependency=/home/capi/.cache/rustx-pr485-target/release/deps']
for name in ['chrono','serde_json']:
 path=next(f for v in rows if v.get('reason')=='compiler-artifact' and v['target']['name']==name for f in v['filenames'] if f.endswith('.rlib'));cmd+=['--extern',name+'='+path]
for d in Path('/home/capi/.cache/rustx-pr485-target/release/build').glob('*/out'):cmd+=['-L','native='+str(d)]
cmd+=['-o',str(out/'inspection-probe')]
with (out/'probe.stdout').open('x') as so,(out/'probe.stderr').open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
meta={'command':cmd,'exit':done.returncode,'source_sha256':hashlib.sha256((r/'explanation-probe.rs').read_bytes()).hexdigest()}
if done.returncode==0:meta['binary_sha256']=hashlib.sha256((out/'inspection-probe').read_bytes()).hexdigest()
(out/'probe.json').write_text(json.dumps(meta,indent=2)+'\n');print('probe',label,done.returncode);raise SystemExit(done.returncode)
