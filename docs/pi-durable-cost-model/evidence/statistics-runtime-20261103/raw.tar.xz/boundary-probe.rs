use rustx::durable::{ConversationStore,SqliteConversationStore};
use rustx::events::types::{RuntimeEvent,RuntimeEventEnvelope,EVENT_SCHEMA_VERSION};
use rustx::runtime::identity::{ConversationId,AttemptId,EventId};
use serde_json::json;
use std::time::Instant;
fn ns(at:Instant)->u64{at.elapsed().as_nanos().try_into().unwrap()}
fn event(store:&SqliteConversationStore,seq:u64,id:&str,owner:String)->RuntimeEventEnvelope{
 RuntimeEventEnvelope{schema_version:EVENT_SCHEMA_VERSION,event_id:EventId::new(id),sequence:seq,tool_occurrence:None,observation:None,conversation_id:store.conversation_id().clone(),attempt_id:Some(AttemptId::new(owner.clone())),turn_id:None,timestamp:chrono::DateTime::parse_from_rfc3339("2026-01-01T00:00:00Z").unwrap().with_timezone(&chrono::Utc),event:RuntimeEvent::AttemptStarted{attempt_id:AttemptId::new(owner)}}
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let root=std::path::Path::new(&args[1]);let size:usize=args[2].parse().unwrap();std::fs::create_dir_all(root).unwrap();let store=SqliteConversationStore::open(ConversationId::new("conv_36524fd8-f674-7fc2-8125-06d01fee0e18"),&root.join("conversation.sqlite")).unwrap();store.initialize(&[]).unwrap();
 let base=serde_json::to_vec(&event(&store,1,"boundary","".into())).unwrap().len();let extra=(size-base)%2;let id=if extra==0{"boundary"}else{"boundaryx"};let e=store.append_event(event(&store,0,id,"x".repeat((size-base)/2))).unwrap();assert_eq!(serde_json::to_vec(&e).unwrap().len(),size);
 println!("BOUNDARY_READ_BEGIN");let mut timings=Vec::new();let mut original=None;
 for _ in 0..9{let at=Instant::now();let value=store.event_value_read(1,1,&[],0,65_536).unwrap();timings.push(ns(at));if let Some(original)=&original{assert_eq!(&value,original)}else{let parsed:serde_json::Value=serde_json::from_slice(&value.bytes).unwrap();assert_eq!(parsed["event"]["type"],"attempt_started");assert!(value.next_offset.is_none());original=Some(value);}}
 println!("BOUNDARY_READ_END");println!("{}",json!({"native_bytes":size,"structural_bytes":original.unwrap().readable_end,"read_ns":timings,"oracle":"passed"}));
}
