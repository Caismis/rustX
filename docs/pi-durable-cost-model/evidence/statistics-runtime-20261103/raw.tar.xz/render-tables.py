import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
load=lambda p:json.loads(p.read_text())
f=lambda v:'missing' if v is None else f'{v:.6f}'
out=['# Statistics 历史重构完整配对表','', '每个数值来自保留原始计数的独立复算。旧→新；百分比先逐对计算。四对为描述样本，不提供置信区间，不计算新 Pi/DSH 倍数。第一候选与最终候选分开，不合并样本。','']
for title,path in [('初始候选 ecf0efa00',r),('最终候选 c9d5f73e5',r/'refined')]:
 a=load(path/'audit.json');out+=['## '+title,'',a['scope'],'']
 for row in a['dataset']['table']:
  out+=['### '+row['mode']+' / '+row['case'],'','| 指标 | 旧侧中位数 | 新侧中位数 | 配对变化中位数 % | 配对范围 % |','|---|---:|---:|---:|---:|']
  for k,m in row['metrics'].items():out.append('| '+k+' | '+f(m['denominator_median'])+' | '+f(m['numerator_median'])+' | '+f(m['paired_percent_median'])+' | '+', '.join(map(f,m['paired_percent_range']))+' |')
  out+=['','| 指标 | pair | 旧 | 新 | 变化 % | 比例不可用原因 |','|---|---:|---:|---:|---:|---|']
  for g in a['dataset']['groups']:
   if g['mode']==row['mode'] and g['case']==row['case']:
    for p in g['pairs']:out.append(f"| {g['metric']} | {p['pair']} | {f(p['denominator'])} | {f(p['numerator'])} | {f(p['percent_change'])} | {p['ratio_unavailable_reason'] or ''} |")
  out+=['']
 out+=['### 列值和 WAL（独立诊断）','','| 版本 | 历史 | 全表逻辑列值字节 | 贡献条数 / 字节 | 完整 tuple 条数 / 字节 | WAL 帧 | 提交 |','|---|---|---:|---:|---:|---:|---:|']
 for d in a['columns']:
  w=a['wal']['baseline' if d['revision']=='baseline' else 'complete'][d['case']+'-rust'];s=d['statistics'];out.append(f"| {d['revision']} | {d['case']} | {sum(t['bytes'] for t in d['tables'].values())} | {s['facts']} / {s['fact_bytes']} | {s['full_states']} / {s['full_state_bytes']} | {w['wal_frames']} | {w['wal_write_commits']} |")
 out+=['','### 独立检查原值','','首次为进程内首次对应读取，未清内核缓存。strace 产品的时间不属于普通读取性能结果。并发产品的 read_write_bytes 包含同时进行的追加写入。','','| case | pair | 版本 | 指标 | 数值 |','|---|---:|---|---|---:|']
 for p in a['probes']:
  for k,v in p['metrics'].items():out.append(f"| {p['case']} | {p['pair']} | {p['revision']} | {k} | {f(v)} |")
 out+=['']
(repo/'docs/pi-durable-cost-model/2026-11-03-statistics-history-tables.md').write_text('\n'.join(out)+'\n')
