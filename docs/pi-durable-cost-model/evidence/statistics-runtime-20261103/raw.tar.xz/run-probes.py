import datetime,hashlib,json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'net-probes';out.mkdir(exist_ok=False)
os.sched_setaffinity(0,[2,8]);commands=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(pair,case,label,kind,args,traced=False):
 name=f'{pair}-{case}-{label}';binary=r/(label+'-build')/(kind+'-probe');root=out/(name+'-db');root.mkdir()
 argv=[str(binary),str(root),*map(str,args)];cmd=['/usr/bin/time','-f','%U %S %M %e','-o',str(out/(name+'.time'))]
 if traced:cmd+=['strace','-f','-s','256','-e','trace=openat,write,writev','-o',str(out/(name+'.strace')),'--']
 cmd+=argv;row={'pair':pair,'case':case,'revision':label,'kind':kind,'traced':traced,'binary_sha256':sha(binary),'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.stdout')).open('x') as so,(out/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,stdout=so,stderr=se)
 row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());commands.append(row);(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,done.returncode,flush=True);assert done.returncode==0
 lines=(out/(name+'.stdout')).read_text().splitlines();raw=json.loads(lines[-1]);assert raw['oracle']=='passed';(out/(name+'.json')).write_text(json.dumps(raw,indent=2)+'\n')
for pair in range(2):
 for count,mode in [(64,'plain'),(512,'plain'),(512,'concurrent')]:
  for label in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):run(pair,f'statistics-{count}-{mode}',label,'statistics',[count,mode])
for pair in range(2):
 for size in [16320,16321,16383,16384]:
  for label in (['baseline','candidate'] if pair%2==0 else ['candidate','baseline']):run(pair,f'boundary-{size}',label,'boundary',[size])
for size in [16383,16384]:
 for label in ['baseline','candidate']:run(0,f'trace-boundary-{size}',label,'boundary',[size],True)
assert len(commands)==32
