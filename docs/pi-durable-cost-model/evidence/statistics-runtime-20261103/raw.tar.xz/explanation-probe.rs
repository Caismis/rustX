use rustx::durable::{ConversationStore,SqliteConversationStore};
use rustx::events::types::{RuntimeEvent,RuntimeEventEnvelope,EVENT_SCHEMA_VERSION};
use rustx::runtime::identity::{AttemptId,ConversationId,EventId};
use serde_json::json;
use std::time::Instant;
fn ns(t:Instant)->u64{t.elapsed().as_nanos().try_into().unwrap()}
fn event(store:&SqliteConversationStore,seq:u64,id:&str,owner:String)->RuntimeEventEnvelope{
 RuntimeEventEnvelope{schema_version:EVENT_SCHEMA_VERSION,event_id:EventId::new(id),sequence:seq,tool_occurrence:None,observation:None,conversation_id:store.conversation_id().clone(),attempt_id:Some(AttemptId::new(owner.clone())),turn_id:None,timestamp:chrono::DateTime::parse_from_rfc3339("2026-01-01T00:00:00Z").unwrap().with_timezone(&chrono::Utc),event:RuntimeEvent::AttemptStarted{attempt_id:AttemptId::new(owner)}}
}
fn read(store:&SqliteConversationStore,sequence:u64,through:u64)->serde_json::Value{
 let before=rustx::observation_probe::snapshot();let at=Instant::now();let value=store.event_value_read(sequence,through,&[],0,65_536).unwrap();let elapsed=ns(at);let parsed:serde_json::Value=serde_json::from_slice(&value.bytes).unwrap();assert_eq!(parsed["event"]["type"],"attempt_started");assert!(value.next_offset.is_none());
 json!({"elapsed_ns":elapsed,"source_bytes":value.readable_end,"before":before,"after":rustx::observation_probe::snapshot(),"io":std::fs::read_to_string("/proc/self/io").unwrap()})
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let root=std::path::Path::new(&args[1]);std::fs::create_dir_all(root).unwrap();let case=&args[2];let store=SqliteConversationStore::open(ConversationId::new("conv_36524fd8-f674-7fc2-8125-06d01fee0e18"),&root.join("conversation.sqlite")).unwrap();store.initialize(&[]).unwrap();
 let initial=rustx::observation_probe::snapshot();let mut points=Vec::new();let mut native_lengths=Vec::new();
 if case=="aba"{
  for (i,id) in ["event-a","event-b"].into_iter().enumerate(){let mut e=event(&store,0,id,format!("owner-{i}"));e=store.append_event(e).unwrap();native_lengths.push(serde_json::to_vec(&e).unwrap().len());}
  let append=rustx::observation_probe::snapshot();for seq in [1,2,1]{points.push(read(&store,seq,2));}
  println!("{}",json!({"case":case,"initial":initial,"after_append":append,"native_lengths":native_lengths,"points":points,"oracle":"passed"}));
 }else{
  let target:usize=case.strip_prefix("native-").unwrap().parse().unwrap();let base=serde_json::to_vec(&event(&store,1,"boundary","".into())).unwrap().len();let padding=(target-base)/2;let extra=(target-base)%2;let id=if extra==0{"boundary"}else{"boundaryx"};let e=event(&store,0,id,"x".repeat(padding));let e=store.append_event(e).unwrap();let actual=serde_json::to_vec(&e).unwrap().len();assert_eq!(actual,target);native_lengths.push(actual);let append=rustx::observation_probe::snapshot();for _ in 0..9{points.push(read(&store,1,1));}
  println!("{}",json!({"case":case,"initial":initial,"after_append":append,"native_lengths":native_lengths,"points":points,"oracle":"passed"}));
 }
}
