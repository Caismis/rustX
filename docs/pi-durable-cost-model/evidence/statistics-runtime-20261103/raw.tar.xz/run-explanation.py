"""Eight paced stream requests per process plus A/B/A and threshold probes.
Diagnostic counters/timers are patched into separate O3 worktrees, never headline artifacts.
"""
import datetime,hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;out=r/'explanation-products';out.mkdir(exist_ok=False);os.sched_setaffinity(0,[2,8]);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
labels=['before','after'];builds={label:json.loads((r/('explain-'+label+'-build/identity.json')).read_text()) for label in labels}
for label,b in builds.items():
 assert b['verified'] and b['diagnostic_only'] and b['sha256']==sha(Path(b['binary']))
 meta=json.loads((r/('explain-'+label+'-build/probe.json')).read_text());assert meta['exit']==0 and meta['source_sha256']==sha(r/'explanation-probe.rs')
pre={'utc':now(),'pairs':2,'stream_products':8,'requests_per_stream_product':8,'modes':['no-live-subscriber','live-subscriber'],'inspection_cases':['aba']+[f'native-{n}' for n in range(16379,16386)],'inspection_products':32,'inspection_repeated_calls':8,'cpu_affinity':sorted(os.sched_getaffinity(0)),'builds':builds,'scripts':{p.name:sha(p) for p in r.glob('*') if p.is_file() and p.suffix in ['.py','.rs']},'scope':'Diagnostic patches/counters; separate from ordinary production matrix. Two balanced pairs, descriptive only; no Pi/DSH.'}
(out/'premeasurement.json').write_text(json.dumps(pre,indent=2)+'\n');records=[]
controllers={}
for label in labels:
 repo=r/('explain-'+label);sys.path.insert(0,str(repo/'benchmarks/runtime'));spec=importlib.util.spec_from_file_location('diagnostic_'+label,repo/'benchmarks/runtime/controller.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);controllers[label]=m
safe={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))};safe|={'UV_OFFLINE':'1'}
for pair in range(2):
 for mode in pre['modes']:
  for label in (labels if pair%2==0 else labels[::-1]):
   stem=out/f'stream-{pair}-{mode}-{label}';binary=builds[label]['binary'];argv=[binary,controllers[label].TEST,'--exact','--ignored','--nocapture'];env=safe|{'RUSTX_BENCH_OBSERVER_MODE':mode,'RUSTX_BENCH_CASE':'stream','RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json'))};start=now()
   record=controllers[label].run(argv,stem,'stream',env,r/('explain-'+label+'/test-support/fake-provider'))
   records.append({'kind':'stream','pair':pair,'mode':mode,'revision':label,'start_utc':start,'end_utc':now(),'accepted':record['accepted'],'process_file':str(stem.with_suffix('.process.json').relative_to(out))});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem.name,record['accepted'],flush=True);assert record['accepted'],record.get('error')
for pair in range(2):
 for case in pre['inspection_cases']:
  for label in (labels if pair%2==0 else labels[::-1]):
   stem=out/f'inspection-{pair}-{case}-{label}';binary=r/('explain-'+label+'-build/inspection-probe');argv=[str(binary),str(stem),case];start=now()
   with stem.with_suffix('.json').open('x') as so,stem.with_suffix('.stderr').open('x') as se:done=subprocess.run(argv,stdout=so,stderr=se)
   records.append({'kind':'inspection','pair':pair,'case':case,'revision':label,'argv':argv,'binary_sha256':sha(binary),'start_utc':start,'end_utc':now(),'exit':done.returncode});(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(stem.name,done.returncode,flush=True);assert done.returncode==0
assert all(sha(r/n)==h for n,h in pre['scripts'].items())
for label in labels:
 repo=r/('explain-'+label);b=builds[label]
 current={str(p.relative_to(repo)):sha(p) for d in ['src','tests','benchmarks/runtime','test-support/fake-provider'] for p in sorted((repo/d).rglob('*')) if p.is_file() and '__pycache__' not in p.parts and '.venv' not in p.parts}|{n:sha(repo/n) for n in ['Cargo.toml','Cargo.lock']}
 assert current==b['source_files']
(out/'completed.json').write_text(json.dumps({'accepted':True,'products':len(records),'all_scripts_and_inputs_unchanged':True,'utc':now()},indent=2)+'\n')
