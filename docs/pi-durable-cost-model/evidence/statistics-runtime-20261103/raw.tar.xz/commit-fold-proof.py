from pathlib import Path
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
p=repo/'src/durable/sqlite/event_heads.rs';s=p.read_text();a=s.index('pub(super) const STATISTICS_SEQUENCE:');b=s.index('pub(super) const TRACE_TOTAL:',a)
s=s[:a]+'''pub(super) const STATISTICS: &str = "SELECT sequence,
    CASE WHEN typeof(observation_statistics)='blob' AND length(observation_statistics)<=49152 THEN observation_statistics ELSE 0 END,
    CASE WHEN observation_statistics_checkpoint IS NULL THEN NULL WHEN typeof(observation_statistics_checkpoint)='blob' AND length(observation_statistics_checkpoint)<=49152 THEN observation_statistics_checkpoint ELSE 0 END
    FROM events WHERE sequence=(SELECT max(sequence) FROM (
        SELECT (SELECT sequence FROM events INDEXED BY events_aggregate_heads_idx
            WHERE observation_aggregate_heads>0 AND observation_aggregate_heads=2
            AND sequence<=?1 ORDER BY sequence DESC LIMIT 1) AS sequence
        UNION ALL
        SELECT (SELECT sequence FROM events INDEXED BY events_aggregate_heads_idx
            WHERE observation_aggregate_heads>0 AND observation_aggregate_heads=3
            AND sequence<=?1 ORDER BY sequence DESC LIMIT 1)
    ))";

'''+s[b:];p.write_text(s)
p=repo/'src/durable/sqlite/event_heads/tests.rs';s=p.read_text().replace('(STATISTICS_SEQUENCE, "observation_statistics", false, 0)','(STATISTICS, "observation_statistics", false, 1)');a=s.index('        let selected_column = if sql == STATISTICS_SEQUENCE');b=s.index('        let oracle = format!(',a);s=s[:a]+s[b:];s=s.replace('SELECT {selected_column} FROM events','SELECT {column} FROM events');p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics/history.rs';s=p.read_text();a=s.index('    let latest: Option<u64> =');b=s.index('    let mut frame = if last.distance == 0',a)
s=s[:a]+'''    let latest=connection.prepare_cached(super::super::event_heads::STATISTICS)
        .and_then(|mut statement|statement.query_row([through],|row|{
            let sequence:u64=row.get(0)?;
            let rusqlite::types::ValueRef::Blob(bytes)=row.get_ref(1)? else{return Ok(Err(storage("statistics fact type invalid")))};
            let checkpoint:Option<Vec<u8>>=row.get(2)?;
            #[cfg(test)] super::record_read(1,bytes.len()+checkpoint.as_ref().map_or(0,Vec::len));
            Ok(Record::decode(sequence,bytes).map(|record|(sequence,record,checkpoint)))
        })).optional().map_err(|error|storage(error.to_string()))?.transpose()?;
    let Some((sequence,last,checkpoint))=latest else {
        hole(connection,0,through)?;
        return Ok(Frame{sequence:0,anchor:0,distance:0,state:bootstrap(connection)?});
    };
'''+s[b:];p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics/owner.rs';s=p.read_text().replace('    data: u64,\n}','    data: u64,\n    fact: Vec<u8>,\n    checkpoint: Option<Vec<u8>>,\n}',1).replace('    enabled: AtomicBool,','    enabled: AtomicBool,\n    history_started: AtomicBool,',1).replace('enabled: AtomicBool::new(true),','enabled: AtomicBool::new(true),\n            history_started:AtomicBool::new(false),').replace('enabled: AtomicBool::new(false),','enabled: AtomicBool::new(false),\n            history_started:AtomicBool::new(false),')
a=s.index('        if changed {\n            self.invalidate();\n        }',s.index('fn observe('));b=a+len('        if changed {\n            self.invalidate();\n        }')
s=s[:a]+'''        if table=="events" && matches!(change,PreUpdateCase::Insert(_)) {
            if changed {self.history_started.store(true,Ordering::Release);self.invalidate();}
            else if self.seat.lock().expect("statistics fold").pending.is_some(){
                // A provisional append may have been rolled back and its
                // native sequence reused by this non-statistical event.
                self.invalidate();
            }
        }else if changed {
            // Product statistics are append-only after bootstrap. An UPDATE,
            // DELETE or bootstrap rewrite disables reuse for this connection,
            // including changes later undone by ROLLBACK TO.
            if table=="events" || self.history_started.load(Ordering::Acquire){self.disable();}
            else{self.invalidate();}
        }'''+s[b:]
s=s.replace('pub(super) fn stage(&self, frame: Frame, data: u64)','pub(super) fn stage(&self, frame: Frame, data: u64, fact:Vec<u8>, checkpoint:Option<Vec<u8>>)')
s=s.replace('                data,\n            });','                data,\n                fact,\n                checkpoint,\n            });')
a=s.index('        // The rollback hook invalidates full rollbacks.');b=s.index('        if accepted {',a)
s=s[:a]+'''        // Publish after COMMIT only if the actual newest statistical fact
        // and its optional checkpoint are exactly the ones we staged. Borrow
        // SQLite cells; no copy, new state row or transaction is introduced.
        let accepted = connection.is_autocommit()
            && self.enabled.load(Ordering::Acquire)
            && certificate.epoch == self.epoch.load(Ordering::Acquire)
            && connection.prepare_cached(super::super::event_heads::STATISTICS)
                .and_then(|mut statement|statement.query_row([i64::MAX],|row|{
                    let sequence:u64=row.get(0)?;
                    let fact=matches!(row.get_ref(1)?,rusqlite::types::ValueRef::Blob(bytes) if bytes==certificate.fact);
                    let checkpoint=match(row.get_ref(2)?,certificate.checkpoint.as_deref()){
                        (rusqlite::types::ValueRef::Null,None)=>true,
                        (rusqlite::types::ValueRef::Blob(bytes),Some(expected))=>bytes==expected,
                        _=>false,
                    };
                    Ok(sequence==certificate.frame.sequence&&fact&&checkpoint)
                })).unwrap_or(false);
'''+s[b:];p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics.rs';s=p.read_text().replace('        if let Some((fold, data)) = self.fold {\n            cache.stage(fold, data);','        if let (Some((fold, data)),Some(capture)) = (self.fold,self.statistics) {\n            cache.stage(fold, data, capture.bytes, self.checkpoint);');p.write_text(s)
