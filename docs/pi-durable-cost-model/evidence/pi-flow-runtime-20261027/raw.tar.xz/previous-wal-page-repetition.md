# 旧轮 WAL：跨事务页重写是主量，同事务重复写不是主量

这是对上一轮 `rustx-pr485-complete-costs-final` 已接受原始证据的事后只读复算，不是本轮尚未测量的 schema80 性能结果。旧轮 `complete` 是源码 `f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20`、binary SHA256 `8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7`，也是本轮 Pi-flow 的基线。旧轮 `baseline` 是源码 `123accb38fd8cf1e8f88583c1858d514cb453870`，不可混淆。

只读取旧 `calls.strace`、同步阶段标记、数据库路径与已接受的 `diagnostic-audit.json`。没有运行产品、构建或 SQLite，没有修改旧证据。所有八个产品的提交数、frame 总数和每笔事务 frame 数都与旧严格审计完全一致。

## 可以直接从原始 syscall 证明什么

对 `before_measured_turns` 到 `after_turns` 内每次 WAL 写逐一配对：24-byte frame header 必须是顺序追加，紧随其后的是同一 offset+24 的单次4096-byte page payload。提交由 header 的非零数据库页数标记识别，在对应 payload 写完后结束该事务；WAL reset 必须有显式32-byte WAL header。未闭合/短写/非追加 header/没有新header的payload重写都拒绝，不能悄悄当作普通 frame。

| 旧轮身份 | case | engine | commits | frames | 唯一 measured 页号 | 跨事务重复出现 | 同事务重复 frames | frame bytes |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| baseline | short-small | rust | 512 | 9,892 | 951 | 8,941 | 0 | 40,755,040 |
| baseline | short-large | rust | 512 | 10,831 | 1,101 | 9,730 | 0 | 44,623,720 |
| complete | short-small | rust | 416 | 9,475 | 759 | 8,716 | 0 | 39,037,000 |
| complete | short-large | rust | 416 | 10,406 | 884 | 9,522 | 0 | 42,872,720 |
| baseline | short-small | pi | 160 | 1,683 | 28 | 1,655 | 0 | 6,933,960 |
| baseline | short-large | pi | 160 | 1,688 | 32 | 1,656 | 0 | 6,954,560 |
| complete | short-small | pi | 160 | 1,683 | 28 | 1,655 | 0 | 6,933,960 |
| complete | short-large | pi | 160 | 1,688 | 32 | 1,656 | 0 | 6,954,560 |

每个产品都是32个 measured turns。八个 trace 都没有原位 payload/header 重写；每个事务 frames 都等于本事务 unique page IDs。`complete` 的91.99%/91.50% frame 是 measured 区间内已经在前面事务出现过的页号。分解恒等式是：`frames = unique measured page numbers + cross-transaction repeated page occurrences + within-transaction repeated frames`。

这**不是字节内容相同或写入都可删除的证明**：页号只是物理地址；页内容可能变化、页可能中途复用。同一页跨提交再次写入通常是持久边界的正常成本。没有把事后 dbstat 的页号映射当作精确表归因。

## 13个时序槽：readiness 不是约40MB的主要来源

旧 `sql-complete-tx-no-live/prepares.jsonl` 的 measured 段有416个 `BEGIN IMMEDIATE` prepare。其前7个调用栈帧形成完全一致的13项序列，重复32次。WAL 的416个提交也可按先后每13项分成32组。下表的槽名取自**独立 SQL 产品**的重复栈，是支持性的跨产品时序对照，不是为每个 WAL 事务采到了调用栈；short-small 的对照还利用了相同请求流程。没有独立证明时序槽与产品 turn 的逐个对齐。

| 时序槽 | 独立SQL栈对照 | short-small frames中位[min,max] | short-large frames中位[min,max] |
| ---: | --- | ---: | ---: |
| 1 | accept_inbound | 16 [16,21] | 16 [16,23] |
| 2 | mark_observation_transcript_ready | 2 [2,2] | 2 [2,2] |
| 3 | adopt_pending_batch | 55 [49,66] | 58 [53,67] |
| 4 | mark_native_observation_ready | 2 [2,2] | 2 [2,2] |
| 5 | append_event / run_owned | 28 [28,36] | 28 [28,37] |
| 6 | mark_native_observation_ready | 2 [2,2] | 2 [2,2] |
| 7 | append_event / run_turn_body | 23 [23,30] | 23 [23,29] |
| 8 | mark_native_observation_ready | 2 [2,2] | 2 [2,2] |
| 9 | commit_model_turn_start | 66 [58,80] | 74 [67,85] |
| 10 | mark_native_observation_ready | 2 [2,2] | 2 [2,2] |
| 11 | open_publication_stream | 4 [4,7] | 4 [4,9] |
| 12 | settle_model_turn | 87 [70,97] | 100 [84,118] |
| 13 | mark_native_observation_ready | 4 [4,4] | 4 [4,4] |

按上述有明确边界的对齐，6个readiness槽每组共14 frames；32组448 frames，即1,845,760 bytes。它们占46.15%的commit，但只占short-small的4.73%、short-large的4.31% WAL bytes；占所有跨事务重复出现的5.14%/4.70%。其余7槽分别写9,027/9,958 frames，占95.27%/95.69% WAL。不能从13→7 commits直接推导写字节下降46%。

也不能把4–5%误当作 TEMP readiness 改动的全部收益上限。readiness槽触达页号并集各只有4个（small:52/53/115/117；large:52/53/117/1393）；其余语义槽还在这些**相同物理地址**上写了448 frames。两者共896 frames，占9.46%/8.61%。该数字只证明地址共现，不能证明精确的表归属或所有这些写都可删；但它提示，移除主库 readiness 维护还可能减少原语义事务中的写，而不只是删除 release 事务。

槽3、9、12仍占旧完整写量的大部分。对当前改动的实际收益必须等待新 WAL/SQL 诊断；新的固定5次/turn方案不能仅凭源码或此旧表宣称达到5次，解析器会要求实际新记录和重复序列吻合。

## 为什么1.8MB逻辑增量不等于约40MB WAL

旧 `complete` 的逻辑列净增量是1,770,302/1,826,076 bytes；WAL是39,037,000/42,872,720 frame bytes。它们来自独立诊断产品，边界也不同：逻辑列测量是保留值的净增量，不计 B-tree 索引、页内空白、已覆盖/删除中间值；WAL每次记录完整4096-byte page和24-byte frame header，跨事务修改同一页仍写完整页。这不是可以逐字节相除并精确归因的“写放大率”。

原始 trace 支持把主要方向放在**语义事务触页数量、冗余持久结构/索引和可安全合并的事务边界**。它不支持把约40MB主要归因于同事务同页被cache spill反复写出。Pi本身跨事务页号重复比例也高达98%，但总frame只有约1.7k；重复比例高本身不是性能问题，绝对提交数、每次触页数及功能要求共同决定成本。

## cache spill 的可证明范围

本地锁定 `libsqlite3-sys 0.38.2/sqlite3/sqlite3.c`：`pagerStress`（64214起）在WAL模式可调用非commit的`pagerWalFrames`；`walFrames`（71474起，尤其71581–71616）可将本事务已写页直接覆写旧frame的payload，再重写checksum headers。这正是为何本分析同时检查header和payload，而非只数24-byte headers。所读源码SHA256为`0a409f1633283fa31a9126b11fbfd64a1991c5d30defad07e5745d4667f5e23d`。

**零重复写不证明零spill。** 一个页可能spill一次后不再变脏，原始syscall看不出它来自commit脏页列表还是pagerStress。旧证据未采pager spill计数或每次WAL写的pager栈，不能据此断言`cache_size`充足、没有cache压力，或估算调大cache收益。结论仅是：这八个既有trace没有同事务重复页/原位覆写造成的额外WAL写。

## 可复算产物与本轮复用

- `analyze-wal-repeated-pages.py` → `previous-wal-page-repetition.json`：保留每TX页号计数、raw trace SHA、所有总数与旧严格结果一致检查。它会拒绝未来非追加写形状，不能默默算错。
- `analyze-wal-transaction-slots.py` → `previous-wal-transaction-slots.json`：从SQL原始记录复算时序，保存每槽32个值、范围、栈前缀及readiness条件对照。
- `test-wal-repeated-pages.py`：5项纯合成parser测试通过，覆盖跨/同TX重复分离、原位payload/header重写拒绝、缺payload/commit以及显式WAL reset。

新诊断全部完成并通过主严格审计后，给第一脚本传新的`--input-root`与一个**新的、在输入根之外**的`--output`，再把新报告传给第二脚本的`--repetition-report`。槽数由实际SQL/WAL计数导出，未硬编码13或5。分析输出可在冻结打包前另行保留到本轮证据目录。不要在产品采样期间运行解析，不混入正式276个产品的性能统计。
