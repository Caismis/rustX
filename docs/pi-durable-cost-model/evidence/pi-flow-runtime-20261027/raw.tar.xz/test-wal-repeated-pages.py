#!/usr/bin/env python3
"""Synthetic parser cases; never runs SQLite or products."""
import importlib.util
from pathlib import Path
import struct
import tempfile
import unittest

path = Path(__file__).with_name('analyze-wal-repeated-pages.py')
spec = importlib.util.spec_from_file_location('repeat', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
PHASES = ['before_measured_turns', 'after_turns']
BEGIN = '1 sendto(3<UNIX-STREAM:[x]>, "before_measured_turns", 21, 0, NULL, 0) = 21\n'
END = '1 sendto(3<UNIX-STREAM:[x]>, "after_turns", 11, 0, NULL, 0) = 11\n'


def frame(index, page, commit=False):
    offset = 32 + index * 4120
    header = struct.pack('>II', page, 20 if commit else 0) + bytes(16)
    return f'1 pwrite64(4</db-wal>, {repr(header)[1:]}, 24, {offset}) = 24\n1 pwrite64(4</db-wal>, "truncated"..., 4096, {offset+24}) = 4096\n'


class WalTests(unittest.TestCase):
    def parse(self, raw):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'trace';path.write_text(raw)
            return module.parse_trace(path, '/db', PHASES)

    def test_within_and_cross_transaction_repeats_are_separate(self):
        result = self.parse(BEGIN + frame(0, 1) + frame(1, 2, True) + frame(2, 1) + frame(3, 1, True) + frame(4, 3, True) + END)
        self.assertEqual((result['frames'], result['unique_measured_page_numbers'], result['cross_transaction_repeat_page_occurrences'], result['within_transaction_repeat_frames']), (5, 3, 1, 1))
        self.assertEqual([row['frames'] for row in result['transactions']], [2, 2, 1])

    def test_payload_rewrite_is_rejected_instead_of_hidden(self):
        with self.assertRaisesRegex(ValueError, 'payload without new'):
            self.parse(BEGIN + frame(0, 1) + '1 pwrite64(4</db-wal>, "again"..., 4096, 56) = 4096\n' + END)

    def test_rewritten_header_is_not_a_new_frame(self):
        with self.assertRaisesRegex(ValueError, 'nonappend header'):
            self.parse(BEGIN + frame(0, 1) + frame(0, 1, True) + END)

    def test_missing_payload_or_commit_cannot_close_at_boundary(self):
        for raw in [frame(0, 1), frame(0, 1, True).splitlines(keepends=True)[0]]:
            with self.assertRaisesRegex(ValueError, 'boundary splits'):
                self.parse(BEGIN + raw + END)

    def test_explicit_wal_reset_does_not_hide_cross_transaction_repetition(self):
        header = bytes(8) + struct.pack('>I', 4096) + bytes(20)
        reset = f'1 pwrite64(4</db-wal>, {repr(header)[1:]}, 32, 0) = 32\n'
        result = self.parse(BEGIN + frame(0, 1, True) + reset + frame(0, 1, True) + END)
        self.assertEqual(result['measured_wal_header_writes'], 1)
        self.assertEqual(result['cross_transaction_repeat_page_occurrences'], 1)


if __name__ == '__main__':
    unittest.main()
