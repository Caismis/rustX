# Screen24: fixed CPU cost review (read-only)

Source: candidate `d22ce66c5`, compared with `bc5c5613d65dd06bea09cfccb61f7b4b32942371`. No product, build, or source mutation was performed for this note. Existing screen, SQL and sampled CPU files were read. This is a diagnosis plan, not a claim that a regression or its cause has been established.

## What the completed screen actually shows

Inputs: `exploratory-screen/{no-live,live}/0-{short-small,short-large}-{before,after}.json`. Each cell has **one pair**, 32 measured turns after 8 (small) or 64 (large) warm turns. Means/medians below use `settled_us` only for `measured=true`. CPU is the last warm sample's `/proc/stat` utime+stime to the last measured sample, at 100 ticks/second; it does not include later validation/reopen. Ten-millisecond ticks are not precise per-turn timings.

| Mode / history | Wall mean before → after, ms | Wall median before → after, ms | Measured CPU before → after, ms | Mean acceptance before → after, µs |
|---|---:|---:|---:|---:|
| No live / small | 13.489 → 18.620 | 12.632 → 18.437 | 490 → 670 | 572 → 1,005 |
| Live / small | 15.838 → 17.768 | 15.667 → 17.733 | 720 → 820 | 676 → 1,032 |
| No live / large | 22.593 → 18.083 | 23.016 → 19.278 | 810 → 660 | 1,116 → 897 |
| Live / large | 28.296 → 37.433 | 29.238 → 24.073 | 1,230 → 1,080 | 1,231 → 1,160 |

The live-large candidate mean includes measured turns 84/88/92 at 107.618/227.934/218.943 ms. Its median and CPU improve. Keep these samples in accepted results; they prevent attributing that mean difference to increased CPU. Neither small cell has a measured turn above 50 ms, so the small median changes cannot be dismissed as those same three outliers. Still, one pair does not separate fixed product CPU from run-to-run scheduling/frequency/cache effects.

The no-live-small CPU increase is mostly user CPU (380 → 540 ms; system 110 → 130 ms); live-small user CPU is 590 → 680 ms (system 130 → 140 ms). Conversely, measured `rchar` and `syscw` fall in every cell. No-live-small `rchar` is 9,836,436 → 6,487,393 bytes and `syscw` 26,082 → 15,871; live-small is 9,836,305 → 6,487,405 and 26,171 → 15,932. These counters include the harness and filesystem sampling and are neither disk-read bytes nor SQL execution counts. Live notification deltas (last measured minus last warm, not sums of cumulative counters) also fall: small 451 → 409, large 448 → 416.

Both screen `sql_statements` and `allocations` are null. Thus the screen itself cannot establish the number of query executions, JSON parses or allocations.

## Current completed diagnostics narrow the possibilities

Read `sql-{baseline,complete}-tx-no-live/{phases.json,prepares.jsonl}`. Select records at `before_measured_turns <= monotonic_ns < after_turns`. Both have complete later boundaries. These are the standard **large no-live** diagnostic runs, not small profiles or ordinary timing runs.

| sqlite3_prepare_v3 calls in that interval | Baseline | Candidate |
|---|---:|---:|
| All calls / per measured turn | 4,546 / 142.0625 | 1,784 / 55.75 |
| Distinct SQL text shapes | 49 | 4 |
| Non-transaction calls | 2,528 | 0 |
| BEGIN IMMEDIATE | 416 | 160 |
| BEGIN DEFERRED | 593 | 732 |
| COMMIT | 817 | 700 |
| ROLLBACK | 192 | 192 |

All these prepares have flags 0. The candidate's four shapes are only BEGIN IMMEDIATE, BEGIN DEFERRED, COMMIT and ROLLBACK. This means warmed cached business statements avoid re-preparation in this run, **not that they stop executing**. IMMEDIATE is 13 → 5 per turn. The DEFERRED increase mostly reflects moving former durable readiness releases to TEMP-only deferred transactions, and must not be described as 139 additional transactions: total BEGIN falls 1,009 → 892 and total transaction prepares 2,018 → 1,784. Prepare hooks cannot measure B-tree seeks, VM steps or all cache-hit executions.

Read `profile-{baseline,complete}-live-large-cpu/{manifest.json,steady-collapsed.txt}`. The manifests identify 250 Hz diagnostic CPU sampling, all product/driver threads and phase handshake overhead. The reports contain 268 → 258 measured-window samples. Inclusive stack membership below counts a matching stack once per row; rows overlap and are **not additive/exclusive CPU or causal wall attribution**:

| Stack group | Baseline samples | Candidate samples |
|---|---:|---:|
| sqlite3_step | 55 | 53 |
| sqlite3LockAndPrepare | 11 | 2 |
| observation_readiness | 3 | 5 |
| observation_statistics/members/turn/trace | 18 | 10 |
| capture_facts / persist_part | 2 | 2 |
| composed::read::preview/field/page | 0 | 0 |
| original_node_count | 0 | 1 |
| native_request | 7 | 1 |
| publication admission/stream validation | 3 | 1 |
| PublicationDraft::encode | 54 | 61 |
| sqlite3Btree / sqlite3Pager / sqlite3VdbeExec | 49 | 52 |
| malloc / alloc::alloc / _int_malloc | 39 | 33 |
| Condvar / pthread_mutex / futex / parking_lot | 5 | 17 |

These few large-only samples cannot resolve the small-cell increase. They provide no evidence of a new dominant request-preview or admission-validation stack. The serialization and lock groups deserve observation if a small regression repeats, but 54 versus 61 samples is not a measured exclusive encoding regression; the mutex group is not an off-CPU time measurement.

## Concrete new fixed-cost candidates and exclusions

1. **Merged sparse hole probes trade fewer maintained B-trees for extra constant query work.** `src/durable/sqlite/event_holes.rs:10` defines two virtual three-bit masks and two sparse `(mask, sequence)` indexes. For example, `observation_statistics.rs:160`, `:229`, `:644`, `observation_turn.rs:414`, `:464`, and `observation_members.rs:427` each enumerate four exact mask values. A negative check can now make up to four mask/range seeks instead of one sequence-range seek in its old dedicated index. The virtual expression also evaluates several CASE branches when an event is changed. This is a credible history-independent CPU tradeoff; it is not a history scan. The existing `event_holes/tests.rs:171` query test establishes zero FullscanStep and fewer than 200 VmStep with 4,096 unrelated holes; it does **not** establish equal VM cost to the old query. Count execution frequency plus StatementStatus::VmStep for those actual SQL shapes if attribution becomes necessary. An IN-list's possible temporary set construction needs actual SQLite EXPLAIN/opcode evidence; it is not established here.

2. **TEMP readiness removes WAL work, not all release SQL.** `observation_readiness.rs:8` installs the TEMP epoch once; normal methods still insert/update TEMP B-trees and inspect main durable evidence. `validate_mark:67`, `frontier:123`, `mark_transcript:161`, `mark_canonical:186`, and `transcript_frontier:209` add epoch joins/subqueries to distinguish current installation from committed pre-epoch history. `observation_receipt.rs:172` also authenticates stored evidence with epoch-dependent checks. These are plausible extra fixed VM/cursor steps, partially offset by fewer native families and fewer transactions. Installation itself happens before the warm window, so repeatedly creating the TEMP schema is not the explanation. `manifest.rs:476` explicitly ignores preupdate hooks outside `main`: TEMP readiness cannot, through that hook, invalidate native-input owners and trigger full history revalidation. TEMP state is O(epoch J+T), not constant space, but its bounded index queries do not visibly introduce a full-epoch scan into this loop. Observe readiness VM steps/CPU and connection lock hold/wait times; do not equate all COMMIT calls with main WAL commits.

3. **Lazy publication admission adds a specific stored readback, while removing separate opening work and repeated decoding.** `sqlite.rs:11978` first looks for a stream, validates the owning started request on absence, inserts, then reads the stored stream back to detect trigger/identity corruption. The readback is real work on first durable output. `native_request.rs:162` and `:211` compare exact configuration bytes for transaction-local typed reuse; these checks remain proportional to configuration length. They are not zero-cost digest-only cache hits. However, the former separate opening transaction already performed request/generation checks, and later settlement repeated full typed reads. The large profile shows native_request 7 → 1 and stream-validation 3 → 1 inclusive samples; it does not support blaming this overall path without small-case evidence. Observe `Validation::metadata`, `FreshConfiguration::matches`, `require_started_request_with_validation`, `ensure_publication_stream_tx`, and their serde/SHA/memcmp descendants if needed.

4. **Fact geometry shifts real CPU to explicit request inspection, but this warm workload does not request it.** `composed/fragments.rs:99` now validates each maximal bounded JSON subtree once with `original_node_count` and persists geometry, avoiding eagerly constructing every field preview. `composed/read.rs:338` / `:398` reconstruct the requested preview from geometry and exact bytes on a field/page read. That can cost more than reading the former saved preview and is a deliberate write/read tradeoff. The benchmark loop is `tests/conformance/agent_loop/runtime_benchmark/aligned.rs:632–694`; its live consumer (`:131`) handles content, descriptors and checkpoints, not request structural-field/page queries. Late full snapshot and request verification start after `after_turns`. Neither large profile has a sampled composed preview/field/page stack. Therefore this added explicit-inspection work is a low-priority explanation for the present ordinary short-cell CPU, unless execution counters show an indirect caller. Source-admission `original_node_count` remains a possible small fixed component; it replaces the old preview parse and is not obviously an extra full parse of every descendant. Existing test-only request-source WORK counters (header_decodes, source/index bytes/nodes) can distinguish the two if needed; the current screen does not record them.

The fixed Attempt+first-Turn path (`sqlite/attempt_start.rs:9`, `observation_receipt.rs:225`) removes one transaction and one projection installation, retains two event writes and two stored witnesses, and introduces small identity checks and a two-member receipt. No new unbounded loop is apparent. Immutable capability sharing removes repeated allocation/encoding work; neither change offers an obvious source-level explanation for +160 ms in the no-live-small window.

## Later five-pair direct cohort: retained separately

The subsequently completed `complete-direct-audit.json` is accepted in strict mode (SHA-256 `8930512790a281c1162067147ce2765e7a33a9127d0380d5fc3818f991135f51`). I independently parsed the raw 120 product files, verified their recorded raw hashes, recalculated six metrics and the five paired percentages for every cell, and matched the formal table. Results and all raw identities are retained in `independent-direct12-arithmetic.json`. This independent check is arithmetic-only and does not replace the formal identity, request, observer and recovery oracles.

Values below are **medians of five paired percentage changes** (candidate/baseline − 1), not ratios of separately computed medians. Wall is each run's mean measured turn; full CPU/write are process self counters through cleanup, while memory is maximum sampled anonymous PSS across the retained samples/lifecycle. These endpoints are intentionally different.

| Mode / case | Mean-turn wall | Full self CPU | Full process write bytes | Max sampled anonymous PSS |
|---|---:|---:|---:|---:|
| No live / short-small | −12.05% | −8.55% | −29.37% | −0.62% |
| No live / short-large | −46.89% | −1.99% | −30.86% | −0.59% |
| No live / stream | −0.05% | 0.00% | −15.00% | −1.20% |
| No live / large response | −3.45% | 0.00% | −17.23% | −0.19% |
| No live / tool | −13.16% | −5.26% | −16.80% | −1.13% |
| No live / cancel | **+12.14%** | −6.25% | −16.11% | −0.63% |
| Live / short-small | −17.14% | −8.25% | −29.34% | −1.52% |
| Live / short-large | −21.50% | −9.54% | −30.83% | −0.24% |
| Live / stream | −0.16% | −3.23% | −15.00% | −0.42% |
| Live / large response | **+4.13%** | **+5.56%** | −17.23% | −0.72% |
| Live / tool | **+14.71%** | **+5.56%** | −16.80% | −1.03% |
| Live / cancel | −7.35% | −5.56% | −16.11% | **+0.21%** |

The small-screen regression did **not recur in these five pairs**. That neither explains the screen discrepancy nor proves it was noise. Every no-live-small paired wall change was negative (−30.83% to −9.79%). Large warm results remain variable: no-live short-large paired mean wall spans −76.43% to +29.86%; its −46.89% median is not a claim of a stable universal reduction. All individual values and ranges remain in the arithmetic artifact/formal auditor.

The separate 32-turn measured CPU endpoint also improves in all four warm-cell paired medians: no-live-small −10.67%, no-live-large −9.52%, live-small −10.26%, live-large −16.91%. Do not confuse those with the full-through-cleanup CPU percentages in the table. For single-turn scenarios the same 10 ms counter granularity is coarse: no-live cancel's measured CPU changes +33.33% and live tool's +16.67%, even though the full CPU changes differ. No single endpoint erases another retained regression.

Root is collecting eight supplemental small CPU-profile products in separate diagnostic directories. They are exploratory samples, not additions to the five ordinary timing pairs. The final Pi/DeepSeek cohort had not run at this update; the same-engine direct table alone is not a Pi parity result.

## Decision and minimal next observation

The now-completed matched direct cohort does not establish a repeatable small regression. Use the separately collected small profiles to inspect the same inclusive groups, user/system CPU and scheduler/lock evidence; do not pool their profiled timings into ordinary results. Target VM execution counts only if SQLite remains material. Large-only diagnostics could not by themselves prove or disprove a small-only CPU floor; the source-based tradeoffs above remain hypotheses rather than the explanation for the screen result.

Do not roll back fewer physical indexes, remove epoch correctness, or add a new speculative format based on this single screen. There are real fixed-cost tradeoffs above, but current evidence does not identify one as the cause, nor show that all safe CPU optimization is exhausted. Existing measured I/O reductions and remaining functional requirements are separate facts from the unresolved small-case CPU behavior.
