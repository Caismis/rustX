#!/usr/bin/env python3
"""Read-only audit of eight post-hoc short-small profiles; never runs products."""
import argparse
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
HEAD = 'd22ce66c5a1cda895cac382ce2c350f345933876'
SHA = '775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb'
DEPENDENCIES = {
    'audit-diagnostics.py': 'a8cdd4ceb8b0181a9fc07d09387479cbd7351989c8d799db92858e54233e95ab',
    'audit-complete.py': 'e348d51a1b847f22a705b911b0f28dc8f91a272499884963e0159da5f999b201',
    'recompute-pi.py': 'e2879454bd2c6ed1add046dd55d6ceaa3c7451087ee92e6e008afcbf7a7e1ac3',
}
MATRIX = [(f'{revision}-{observer}-{mode}', revision, observer + '-subscriber', mode)
          for observer in ('no-live', 'live') for revision in ('baseline', 'complete')
          for mode in ('control', 'cpu')]
SCOPE = ('Post-hoc exploratory short-small diagnostics prompted by the small-history screen. '
         'Eight products, one control and one CPU profile per revision/observer cell. '
         'Separate from the canonical 18 diagnostics and the formal 276 products; no pooling or parity claim.')


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def module(name):
    path = HERE / name
    require(sha(path) == DEPENDENCIES[name], 'changed independent dependency: ' + name)
    spec = importlib.util.spec_from_file_location('small_' + name.replace('-', '_'), path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def dependencies():
    diag, formal = module('audit-diagnostics.py'), module('audit-complete.py')
    formal.MATH = module('recompute-pi.py')
    return diag, formal


def source_fields(value):
    return {key: item for key, item in value.items() if key != 'utc'}


def exact_matrix(rows):
    require([row['name'] for row in rows] == [name for name, _, _, _ in MATRIX],
            'supplement must contain exactly the ordered eight exploratory products')
    require(all(row['status'] == 'complete' and row['exit'] == 0 for row in rows),
            'supplement has failed, pending or omitted products')


def canonical_predecessor(root, diag):
    rows = load(root / 'diagnostic-commands.json')
    require(len(rows) == 10 and all(row['status'] == 'complete' and row['exit'] == 0 for row in rows),
            'canonical diagnostic collection must finish before supplemental profiles')
    spans = [diag.window(row['start_utc'], row['end_utc']) for row in rows]
    require(all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), 'canonical diagnostic command order differs')
    after = load(root / 'diagnostic-source-after.json')
    require(spans[-1][1] <= diag.utc(after['utc']), 'canonical source-after precedes collection end')
    return {'commands_sha256': sha(root / 'diagnostic-commands.json'),
            'source_after_sha256': sha(root / 'diagnostic-source-after.json'), 'end_utc': after['utc']}


def cpu_rows(text, total):
    lines = text.splitlines()
    require(lines and lines[0] == f'Total: {total} samples', 'symbolized cumulative total differs')
    rows = []
    for line in lines[1:]:
        if not line.strip():
            continue
        match = re.fullmatch(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)', line)
        require(match is not None, 'unrecognized cumulative row')
        rows.append({'symbol': match[3], 'flat': int(match[1]), 'inclusive': int(match[2])})
    return rows


def profile(args, row, definition, builds, counts, diag, formal):
    name, revision, observer, mode = definition
    directory = args.root / 'supplemental-small-profiles' / name
    build = builds[revision]
    require(row['build_identity'] == build, 'product build differs from retained identity')
    diag.window(row['start_utc'], row['end_utc'])
    command = row['command']
    require(command[:2] == ['python3', 'benchmarks/runtime/profiling/run.py'], 'profile runner differs')
    require(len(command) == 14 and command[2::2] ==
            ['--binary', '--profiler-root', '--output', '--mode', '--case', '--observer-mode'],
            'profile option inventory/order differs')
    options = dict(zip(command[2::2], command[3::2]))
    require(options['--binary'] == build['binary'] and options['--mode'] == mode
            and options['--case'] == 'short-small' and options['--observer-mode'] == observer,
            'profile workload or binary differs')
    require(Path(options['--output']).parts[-2:] == ('supplemental-small-profiles', name),
            'profile output lies outside its supplemental cell')
    require(row['producer_sha256'] == row['harness_files']['benchmarks/runtime/profiling/run.py'],
            'profiling producer hash differs')
    for suffix in ('.stdout', '.stderr'):
        require((directory.parent / (name + suffix)).is_file(), 'product command log missing')
    manifest = load(directory / 'manifest.json')
    require((manifest['mode'], manifest['case'], manifest['observer_mode'], manifest['binary_sha256']) ==
            (mode, 'short-small', observer, build['sha256']), 'profile manifest identity differs')
    argv = manifest['argv']
    require(argv[-5:] == [build['binary'], diag.TEST, '--exact', '--ignored', '--nocapture'],
            'profile product argv differs')
    preload = row['preload_sha256']
    if mode == 'cpu':
        require(len(argv) == 10 and argv[0] == 'env' and argv[4] == 'CPUPROFILE_FREQUENCY=250',
                'CPU environment/frequency differs')
        env = dict(item.split('=', 1) for item in argv[1:5])
        require(set(env) == {'LD_PRELOAD', 'RUSTX_BENCH_PROFILE_SOCKET', 'RUSTX_BENCH_PROFILE_DIR', 'CPUPROFILE_FREQUENCY'},
                'CPU environment keys differ')
        profiler = Path(options['--profiler-root'])
        expected_preload = {str(profiler / 'bridge.so'), str(profiler / 'unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0')}
        require(set(preload) == expected_preload == set(env['LD_PRELOAD'].split(':'))
                and all(re.fullmatch('[0-9a-f]{64}', digest) for digest in preload.values()), 'preload identity differs')
        require(env['RUSTX_BENCH_PROFILE_DIR'] == options['--output']
                and env['RUSTX_BENCH_PROFILE_SOCKET'] == options['--output'] + '/control.sock',
                'CPU boundary outputs differ')
        if not args.raw_only:
            require(all(sha(path) == digest for path, digest in preload.items()), 'actual preload changed')
    else:
        require(len(argv) == 5 and not preload and not list(directory.glob('*.cpu')),
                'control unexpectedly uses profiling')
    product = diag.product(directory, revision, build, 'short-small', observer, argv)
    formal.observer_check(load(directory / 'sample.json'), 'rust', observer)
    result = {'name': name, 'revision': revision, 'observer_mode': observer, 'mode': mode,
              'product': product, 'manifest_sha256': sha(directory / 'manifest.json'),
              'window': {key: row[key] for key in ('start_utc', 'end_utc')}}
    if mode == 'cpu':
        result['cpu'] = diag.cpu_profile(directory, build, row, counts, args.raw_only)
    return result


def audit(args):
    diag, formal = dependencies()
    base = args.root / 'supplemental-small-profiles'
    manifest = load(base / 'manifest.json')
    require(manifest['scope'] == SCOPE and manifest['expected_products'] == 8 and manifest['accepted'] is True,
            'supplement scope/count/completion differs')
    require(manifest['independent_dependencies'] == DEPENDENCIES, 'independent dependency pins differ')
    require(manifest['runner_sha256'] == sha(HERE / 'run-small-profiles.py')
            and manifest['auditor_sha256'] == sha(__file__), 'supplement runner/auditor changed')
    predecessor = canonical_predecessor(args.root, diag)
    require(manifest['canonical_predecessor'] == predecessor, 'canonical predecessor evidence changed')
    builds, receipts = {}, {}
    for revision in ('baseline', 'complete'):
        builds[revision], receipts[revision] = diag.verify_build(args, revision)
    require(builds['complete']['head'] == HEAD and builds['complete']['sha256'] == SHA, 'candidate pin differs')
    require(all(builds['baseline'][key] == builds['complete'][key] for key in ('harness', 'rustc', 'cargo')),
            'baseline/candidate harness/compiler differ')
    require(manifest['identities'] == builds, 'manifest build identity differs')
    for revision, receipt in receipts.items():
        require(manifest['identity_files'][revision] == receipt['sha256'], 'retained identity file changed')
    left, right = load(base / 'source-before.json'), load(base / 'source-after.json')
    require(source_fields(left) == source_fields(right) and left['files'] == builds['complete']['source_files']
            and left['head'] == HEAD, 'supplement source changed or differs from tested/built candidate')
    require(diag.utc(predecessor['end_utc']) <= diag.utc(left['utc']), 'supplement overlaps canonical diagnostics')
    require(load(args.root / 'diagnostic-source-after.json')['files'] == left['files'], 'canonical/supplement source differs')
    require(left['runner_sha256'] == manifest['runner_sha256'] and left['auditor_sha256'] == manifest['auditor_sha256'],
            'source snapshot producer/auditor binding differs')
    require(left['fixtures'] and all(re.fullmatch('[0-9a-f]{64}', value) for value in left['fixtures'].values()),
            'missing fixture hash inventory')
    require(all(left['harness_files'][name] == digest for name, digest in builds['complete']['harness'].items()),
            'supplement harness differs from performance build')
    require(left['harness_files'] == {**left['fixtures'], **builds['complete']['harness']}, 'extra/missing harness hashes')
    if not args.raw_only:
        require(not diag.git(args.repo, 'status', '--porcelain', '--', 'src', 'tests', 'Cargo.toml', 'Cargo.lock', 'benchmarks/runtime'),
                'current source/harness dirty')
        require(all(sha(args.repo / name) == digest for name, digest in {**left['files'], **left['harness_files']}.items()),
                'current source/harness bytes differ')
        actual = {str(p.relative_to(args.repo)): sha(p) for p in sorted((args.repo / 'benchmarks/runtime').rglob('*'))
                  if p.is_file() and '__pycache__' not in p.parts}
        require(left['fixtures'] == actual, 'runtime fixture set differs')
    rows = load(base / 'commands.json')
    exact_matrix(rows)
    require(all(row['harness_files'] == left['harness_files'] for row in rows), 'product-specific harness binding differs')
    spans = [diag.window(row['start_utc'], row['end_utc']) for row in rows]
    require(all(a[1] <= b[0] for a, b in zip(spans, spans[1:])), 'supplement products overlap')
    require(diag.utc(left['utc']) <= spans[0][0] and spans[-1][1] <= diag.utc(right['utc']), 'source snapshots do not bracket products')
    counts_rows = load(base / 'cpu-counts.json')
    counts = {row['name']: row for row in counts_rows}
    require(len(counts_rows) == len(counts) == 4 and set(counts) == {name for name, _, _, mode in MATRIX if mode == 'cpu'},
            'CPU count inventory differs')
    symbols = load(base / 'symbolization-commands.json')
    symbol_expected = [(name, report, flags) for name, _, _, mode in MATRIX if mode == 'cpu'
                       for report, flags in [('steady-cumulative.txt', ['--text', '--cum', '--nodecount=200']), ('steady-collapsed.txt', ['--collapsed'])]]
    require(len(symbols) == len(symbol_expected), 'symbolization command inventory differs')
    for row, (name, filename, flags) in zip(symbols, symbol_expected):
        require(row['name'] == name and row['report'] == filename and row['status'] == 'complete' and row['exit'] == 0,
                'symbolization failed/omitted/reordered')
        directory = base / name
        build = builds[name.split('-')[0]]
        command = row['command']
        require(Path(command[0]).name == 'google-pprof' and command[1:] ==
                [*flags, '--no_strip_temp', build['binary'], str(Path(manifest['output']) / name / 'before_measured_turns.cpu')],
                'symbolizer command changed')
        require(row['tool_sha256'] == manifest['symbolizer']['sha256'] and command[0] == manifest['symbolizer']['path'],
                'symbolizer pin differs')
        require(sha(directory / filename) == row['stdout_sha256'] and sha(directory / (filename + '.stderr')) == row['stderr_sha256']
                and sha(directory / 'before_measured_turns.cpu') == row['raw_sha256'], 'symbolized/raw artifact changed')
        if not args.raw_only:
            require(sha(command[0]) == row['tool_sha256'], 'actual symbolizer changed')
    symbol_spans = [diag.window(row['start_utc'], row['end_utc']) for row in symbols]
    require(spans[-1][1] <= symbol_spans[0][0] and all(a[1] <= b[0] for a, b in zip(symbol_spans, symbol_spans[1:]))
            and symbol_spans[-1][1] <= diag.utc(right['utc']), 'symbolization overlaps products or escapes snapshots')
    products = [profile(args, row, definition, builds, counts, diag, formal) for row, definition in zip(rows, MATRIX)]
    return {'accepted': True, 'scope': SCOPE, 'products': products, 'product_count': len(products),
            'identities': {label: {key: value[key] for key in ('head', 'production_tree', 'sha256', 'harness')} for label, value in builds.items()},
            'source_before_sha256': sha(base / 'source-before.json'), 'source_after_sha256': sha(base / 'source-after.json'),
            'commands_sha256': sha(base / 'commands.json'), 'symbolization_commands_sha256': sha(base / 'symbolization-commands.json'),
            'manifest_sha256': sha(base / 'manifest.json'), 'independent_dependencies': DEPENDENCIES,
            'limits': ['Post-hoc one product per cell; not repeated estimation or formal performance evidence.',
                       'CPU profiles include all product threads, boundary sampling/handshakes and between-turn work; inclusive stacks overlap.',
                       'Read-only replay validates raw CPU headers/counts and retained symbolization consistency; it does not re-symbolize PCs.',
                       'Raw-only checks retained identities; it never reopens original binaries, profiler libraries, repository or database paths.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HERE)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--baseline-identity', type=Path)
    parser.add_argument('--candidate-identity', type=Path)
    parser.add_argument('--raw-only', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    args.root = args.root.resolve()
    args.baseline_identity = args.baseline_identity or args.root / 'baseline-build/identity.json'
    args.candidate_identity = args.candidate_identity or args.root / 'candidate-complete-build/identity.json'
    args.expect_rust_sha256 = SHA
    output = args.output or args.root / 'supplemental-small-profiles' / ('raw-audit.json' if args.raw_only else 'audit.json')
    require(not output.exists(), 'preserve earlier audit; select a new output')
    require(not args.raw_only or not output.resolve().is_relative_to(args.root), 'portable replay output must be outside retained raw tree')
    report = {'accepted': False, 'errors': [], 'mode': 'raw-only' if args.raw_only else 'strict',
              'script_sha256': sha(__file__), 'started_utc': now(), 'strict_identity_verified': False}
    try:
        report.update(audit(args))
        report['strict_identity_verified'] = not args.raw_only
    except Exception as error:
        report['errors'].append(f'{type(error).__name__}: {error}')
    report['finished_utc'] = now()
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: report.get(key) for key in ('accepted', 'mode', 'product_count', 'errors')}, indent=2))
    return 0 if report['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
