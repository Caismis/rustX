# Publication CPU attribution prepared before the new run

This is a source and prior-evidence review, not a new product run or a claim of measured improvement. Product execution, compilation and profiler collection remain root-owned. The current source is frozen for coordinated checks.

## Inputs and counting

Use each fresh `profile-{baseline,complete}-live-large-cpu/steady-collapsed.txt`, its retained raw CPU profile count and interval, and that product's `sample.json`. Sum the integer weight at the end of every collapsed line; independently compare this with raw-profile counts from the accepted diagnostic auditor. Retain input hashes and identities. A sample is CPU exposure, not a function invocation, publication, cache miss or reconstruction count.

The previous round's final candidate (the new round's baseline revision) had 312 total samples. Independent collapsed recount gives PublicationDraft encode 62 = capture 22 + structural-length envelope 36 + other 4. Its capture_working_seed had 23 samples; prior inspection identified 21 Snapshot clones, including 15 deep CapabilityView clones. Those historical numbers are a prioritization aid only: new fresh baseline and candidate must be compared as a pair. Do not substitute the earlier favorable 223-sample candidate or the previous round's 314-sample baseline.

## Mutually exclusive partitions

1. Assign stacks containing `PublicationDraft>::encode` to exactly one bucket, using visible descendants: checkpoint fit; `CheckpointSeed>::capture_checkpoint` (also recognize the older `checkpoint_prepared` name); `bounded_structural_len` / `bounded_structural_len_with_budget`; remaining publication work. Preserve an explicit residual so buckets sum to the encode total.
2. Split the structural-length envelope into observed conservative preflight (`preflight::Check`), actual `checkpoint::Length` serializer sink, and unresolved/inlined work. Within the actual length traversal, partition visible `ProjectionMetadata` serialization from event/envelope work. The enclosing event serializer always appears, so do not count it twice or interpret every event frame as an event-body-only sample.
3. Within capture, separately report visible PreparedCapture `OnceLock::initialize` stacks (with their concrete domain types), metadata/budget/evidence traversal, and unclassified work. Initialization samples prove some real capture work remains, not how many captures occurred or why a particular owner changed. Neither `capture_checkpoint` nor `Capture::prepared` alone proves full snapshot materialization.
4. Keep `capture_working_seed` outside the encode denominator. Partition explicit `RuntimeClientSnapshot as Clone` descendants, PreparedCaptures equality/inheritance, and other seed work. Within clone, identify the concrete domain when visible. Current capabilities are an Arc, so the target is the prior deep CapabilityView→ToolDefinition→JSON clone chain, not every Arc clone or every snapshot field.
5. Report ReadDomainCut reads and SQL preparation as separately labeled inclusive views. If making a whole-program mutually exclusive table, prioritize owning domain before nested SQLite operations and retain residuals; do not add overlapping inclusive buckets into a total.
6. Optionally partition publication by observed producer ancestry: read-worker `commit_display`, native batch, other prepared observations, residual. This diagnoses differing publication mix without inferring call counts from sample counts.

## Actual activity and instrumentation boundaries

From `sample.json`, confirm history/measured turns and take the difference in cumulative `notification_records` between the last history endpoint and last measured endpoint. This is consumer notification traffic, not necessarily projection publication count or read-domain refresh count. Keep sample/control wall and process CPU results separate: profiler overhead and scheduling can change worker wakeups and sampled work. The existing test-only PublicationEncodingProfile has record/byte/phase counters, but normal benchmark output must not be asserted to contain them without reading it.

No samples in `fit_checkpoint` is not proof of zero fit calls. Full snapshot construction is a deferred closure in capture_checkpoint; inlining may obscure it. Only an explicit work counter or an unambiguous sampled constructor path can prove that execution occurred; source control flow proves the conditional mechanism, not observed frequency.

## Current source contract and next decision

- `projection.rs:513–640`: successful ordinary deltas capture metadata/admission and perform one exact structural length traversal. Fit, eviction, explicit replacement or ordinary event admission failure can require materialization and replacement. Those are different output/error paths, not a repeated full snapshot on every delta.
- `projection.rs:869–1088`: prepared normalized domain values are borrowed; transcript rows have separate ownership from changing cut metadata. Fresh metadata, revision/read cut, evidence and conservative charges still require work. This is a concrete optimization candidate only where new samples identify a meaningful repeated immutable part.
- `projection.rs:6616–6658`: a frozen seed protects encoding outside the state lock and historical reads; deep-copying all domains is replaceable in principle. This round shares raw capability ownership and preserves invalid/oversized historical pages, targeting the prior largest concrete clone path without replacing those raw pages with normalized admission output.
- `checkpoint.rs:404–430` and `structural_json.rs:173–194`: the admission certificate is a sufficient upper bound, not exact wire bytes. Exact native u64 may be decimal strings even when numerically small; opaque JSON and bounded quantities have different encoding/error rules. Ordinary serde JSON is not an established byte-identical shortcut.
- `projection.rs:6523–6540`: exact event weight drives replay eviction and historical cursor availability. Replacing it with a conservative upper bound changes observable replay lifetime. A validated immutable exact-length fragment or compiled schema path could optimize it, but an unproven serializer shortcut cannot be called safe.

After the new profiles arrive, rank only observed major paths. A remaining bucket does not by itself establish redundant work. Any proposed change must identify the actual duplicated traversal/owner and preserve wire bytes, admission/eviction order, cuts, read failures and replay lifetime; report uncertain/inlined attribution rather than assigning it optimistically.
