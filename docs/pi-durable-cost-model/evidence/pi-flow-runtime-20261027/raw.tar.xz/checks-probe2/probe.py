import datetime,json,os,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
compiled=root.parent/'checks-retry4'
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
rows=[json.loads(l) for l in (compiled/'tests-build.stdout').read_text().splitlines() if l.startswith('{')]
artifacts={r['target']['name']:r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and (r['target']['kind']==['lib'] or r['target']['name'] in ('durable','process'))}
(root/'provenance.json').write_text(json.dumps(dict(scope='Exploratory remaining-suite probe against checks-retry4 compiled binaries while only a test fixture is repaired. Not final source validation.',compiled_source=str(compiled/'source-before.json'),source_sha256=hashlib.sha256((compiled/'source-before.json').read_bytes()).hexdigest(),artifacts=artifacts),indent=2)+'\n')
records=[]
env=os.environ|{'UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'}
steps=[('client','runtime_client::'),('conversation-runtime','runtime::conversation_runtime::'),('read-layout','runtime::read_layout::'),('content','boundary_suites::durable::content::'),('agent','agent::'),('recovery','runtime::recovery::'),('process-death','boundary_suites::durable::process_death::')]
commands=[('tests-'+label,[artifacts['rustx'],selector,'--skip','::scale::','--test-threads=2']) for label,selector in steps]+[('tests-'+name,[artifacts[name],'--test-threads=2']) for name in ('durable','process')]
for label,cmd in commands:
 record=dict(label=label,command=cmd,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');records.append(record)
 (root/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 record.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True)
