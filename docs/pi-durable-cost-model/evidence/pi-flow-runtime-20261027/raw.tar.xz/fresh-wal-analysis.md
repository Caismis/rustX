# 本轮 fresh WAL：提交数达到 Pi 的5次，触页量仍为4.22–4.74倍

所有数据来自本轮新采集的8份WAL与2份SQL-TX诊断，已与本轮 accepted strict `diagnostic-audit.json` 的总数及每笔事务frame数逐一一致。没有复用上一轮的性能样本；旧分析文件保持不变。

固定基线f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20（schema79，SHA8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7）；候选d22ce66c5a1cda895cac382ce2c350f345933876（schema80，SHA775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb）。short-small/large分别8/64 history，均32 measured turns，no-live。

| 身份 | case | engine | commits | frames | frame bytes | unique measured页号 | 跨TX重复出现 | 同TX重复frames |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| baseline | short-small | rust | 416 | 9478 | 39049360 | 759 | 8719 | 0 |
| baseline | short-small | pi | 160 | 1683 | 6933960 | 28 | 1655 | 0 |
| baseline | short-large | rust | 416 | 10414 | 42905680 | 882 | 9532 | 0 |
| baseline | short-large | pi | 160 | 1688 | 6954560 | 32 | 1656 | 0 |
| complete | short-small | rust | 160 | 7106 | 29276720 | 626 | 6480 | 0 |
| complete | short-small | pi | 160 | 1683 | 6933960 | 28 | 1655 | 0 |
| complete | short-large | rust | 160 | 7997 | 32947640 | 744 | 7253 | 0 |
| complete | short-large | pi | 160 | 1688 | 6954560 | 32 | 1656 | 0 |

Rust本轮fresh baseline 416→160 commits，即13→5次/turn平均值，候选与Pi的160相同。候选frame bytes small 29,276,720、large 32,947,640，较fresh baseline下降25.03%/23.21%，仍是Pi的4.222×/4.738×。事务数量相同没有消除每次语义事务触页量差距；不能据此声称整体追平Pi。

独立SQL采样的BEGIN IMMEDIATE前7调用栈帧严格重复32组，基线13槽、候选5槽。按同binary/source、相同总数和流程对照，候选时序槽如下。SQL与WAL是独立产品，不是逐WAL事务捕获的调用栈，也没有额外逐turn标记来直接证明两个产品每一轮的配对。

| 槽 | 独立SQL栈对照 | small中位[min,max] | large中位[min,max] | small总frames | large总frames |
| --- | --- | --- | --- | --- | --- |
| 1 | accept_inbound | 11 [11,16] | 11 [11,18] | 377 | 389 |
| 2 | adopt_pending_batch | 48 [42,59] | 51 [46,60] | 1547 | 1648 |
| 3 | attempt_start::commit | 28.5 [25,38] | 31 [28,40] | 931 | 1007 |
| 4 | commit_model_turn_start | 57 [50,72] | 64.5 [57,76] | 1843 | 2068 |
| 5 | settle_model_turn | 76 [61,86] | 90.5 [76,99] | 2408 | 2885 |

最后request-start+settlement仍写4,251/4,953 frames，占候选59.82%/61.94%。这是组合实现的源级流程对照，不能把净减少精确分配给单项改动。基线6个readiness释放槽共448 frames、1,845,760B，只占基线4.73%/4.30%写量；因此13→5的61.54%提交数减少不能被写成61.54%WAL减少。主库readiness触页也可能存在于语义事务内，单看release槽不能量出TEMP总收益。

候选跨TX重复页出现6,480/7,253次，占91.19%/90.70%frames。八份trace均无同事务重复页、无原位payload/checksum header重写；header和payload配对及commit marker都验证。该结果排除这些trace中“同TX同页反复写”是约30MB的来源，但不能证明没有cache spill——页可能spill一次后不再变脏。更不能把重复页号当成相同内容或可删写入：页号是物理地址，内容和所有者可能变，不使用事后dbstat映射作精确表归因。

这里记录的是4096B页+24B WAL frame headers，WAL重置的32B headers另计，未把checkpoint、文件系统或设备放大混入。process write_bytes、logical列净增量与WAL frame bytes不是同一个指标。

复算脚本为`analyze-wal-repeated-pages-v2.py`和`analyze-wal-transaction-slots-v2.py`，旧版/旧报告均保留。重复页报告先写输入树外的新文件，再逐字节复制为`fresh-wal-page-repetition.json`；两份时序报告为`fresh-wal-slots-baseline.json`及`fresh-wal-slots-complete.json`。没有运行产品、构建、SQLite或重新符号化。
