import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
before=Path('/home/capi/.cache/rustx-pr485-complete-costs-final/candidate-complete-build/conformance');after=root/'candidate-complete-build/conformance'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
ids={name:json.loads((path.parent/'identity.json').read_text()) for name,path in [('before',before),('after',after)]}
assert all(sha(path)==ids[name]['sha256'] and ids[name]['verified'] for name,path in [('before',before),('after',after)])
assert ids['before']['harness']==ids['after']['harness']
def source():
 assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime'],cwd=repo,text=True).strip()
 files={str(p.relative_to(repo)):sha(p) for folder in ('src','tests') for p in sorted((repo/folder).rglob('*')) if p.is_file()}
 files.update({p:sha(repo/p) for p in ('Cargo.toml','Cargo.lock')})
 assert files==ids['after']['source_files']
 fixtures={str(p.relative_to(repo)):sha(p) for p in sorted((repo/'benchmarks/runtime').rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
 assert all(sha(repo/p)==h for p,h in ids['after']['harness'].items())
 return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),files=files,fixtures=fixtures,runner_sha256=sha(__file__))
initial=source()
out=root/'exploratory-screen';out.mkdir(exist_ok=False)
(out/'source-before.json').write_text(json.dumps(initial,indent=2)+'\n')
records=[]
for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
 cmd=[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(out/label),'--pairs','1','--observer-mode',mode]
 record={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','identities':ids,'scope':'Exploratory one-pair correctness/performance screen; never pooled with final five-pair matrix.'};records.append(record)
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:r=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=stdout,stderr=stderr)
 record.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
assert all(sha(path)==ids[name]['sha256'] for name,path in [('before',before),('after',after)])

final=source();assert {k:v for k,v in initial.items() if k!='utc'}=={k:v for k,v in final.items() if k!='utc'}
(out/'source-after.json').write_text(json.dumps(final,indent=2)+'\n')
