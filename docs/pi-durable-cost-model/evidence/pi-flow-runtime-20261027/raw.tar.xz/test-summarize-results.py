#!/usr/bin/env python3
"""Synthetic formatter contracts only; no products, raw inputs, or formal audit run."""
import copy,importlib.util,unittest
from pathlib import Path
p=Path(__file__).with_name('summarize-results.py')
spec=importlib.util.spec_from_file_location('summary',p);summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)

def fixture():
    # Deliberately synthetic unit values: they are never written as measured evidence.
    def paired():
        groups=[]
        for mode in summary.MODES:
            for case in summary.CASES:
                for metric in summary.DISPLAY_METRICS:
                    pairs=[dict(pair=i,ratio=0.9,ratio_unavailable_reason=None) for i in range(5)]
                    groups.append(dict(mode=mode,case=case,metric=metric,pairs=pairs,
                        summary=dict(n=5,median=0.9,minimum=0.9,maximum=0.9,available=5),
                        percent_change=dict(n=5,median=-10,minimum=-10,maximum=-10,available=5),
                        numerator_values=dict(median=9),denominator_values=dict(median=10),
                        numerator_higher=0,all_five_higher=False))
        return dict(derived_products=120,valid_comparisons=60,checked_requests=1410,products=[{}]*120,
                    table=[dict(mode=m,case=c) for m in summary.MODES for c in summary.CASES],groups=groups)
    groups=[];supplements=[]
    for case in summary.NATIVE_CASES:
        for engine in summary.ENGINES:
            keys=(summary.MEAN,summary.TURN_CPU,'turn_write_mib_per_turn')
            groups.append(dict(case=case,engine=engine,samples=3,medians=dict.fromkeys(keys,1),
                ranges=dict.fromkeys(keys,[0.5,1.5]),available_samples=dict.fromkeys(keys,3)))
            metrics={summary.MEDIAN:dict(median=0.8)}
            if engine=='deepseek':
                metrics.update({k:dict(median=2) for k in ('first_native_runtime_wait4_cpu_ms','verification_native_runtime_wait4_cpu_ms','both_native_runtimes_wait4_cpu_ms')})
                metrics['through_cleanup_process_write_bytes']=dict(median=None)
            supplements.append(dict(case=case,engine=engine,samples=3,metrics=metrics))
    native=dict(accepted=True,errors=[],durability_equivalence=False,derived_products=36,valid_comparisons=12,
                checked_requests=414,groups=groups,supplementary_table=supplements)
    return dict(accepted=True,errors=[],stage='all',mode='strict',strict_identity_verified=True,
                recorded_build_identity_verified=True,datasets=dict(direct=paired(),final=paired(),**{'three-engine':native}),
                identities={k:dict(head='a'*40,sha256='b'*64) for k in ('complete','baseline')})

class FormatterTests(unittest.TestCase):
    def render(self,report):return summary.render(report,'synthetic.json','0'*64,'1'*64)
    def test_all_twelve_cells_and_both_warm_cohorts(self):
        text=self.render(fixture())
        for mode in ('live','no-live'):
            for case in summary.CASES:self.assertGreaterEqual(text.count('| '+mode+' | '+case+' |'),2)
        self.assertIn('Direct批次',text);self.assertIn('Fresh Pi批次',text)
        self.assertIn('SDK idle不等待最终JSONL flush/fsync',text)
        self.assertIn('schema 79',text);self.assertIn('schema 80',text)
        self.assertIn('不再持久保存旧进程是否完成安装或发布',text)
        self.assertIn('O0、all-features',text);self.assertIn('O3、default features',text)
    def test_extra_metric_adverse_and_missing_ratio_remain_visible(self):
        report=fixture();row=copy.deepcopy(report['datasets']['direct']['groups'][0]);row['metric']='unexpected_extra_cost'
        row.update(numerator_higher=1);row['summary'].update(available=4)
        row['pairs'][0].update(ratio=None,ratio_unavailable_reason='zero_denominator')
        report['datasets']['direct']['groups'].append(row)
        text=self.render(report)
        self.assertIn('unexpected_extra_cost',text);self.assertIn('仅部分配对较高',text)
        self.assertIn('pair 0: zero_denominator',text)
    def test_rejects_incomplete_matrix_and_unaccepted_audit(self):
        report=fixture();report['datasets']['direct']['table'].pop()
        with self.assertRaisesRegex(ValueError,'inventory'):self.render(report)
        report=fixture();report['accepted']=False
        with self.assertRaisesRegex(ValueError,'accepted'):self.render(report)
    def test_native_unavailable_full_writes_cannot_be_filled_with_zero(self):
        report=fixture()
        for row in report['datasets']['three-engine']['supplementary_table']:
            if row['engine']=='deepseek':row['metrics']['through_cleanup_process_write_bytes']['median']=0
        with self.assertRaisesRegex(ValueError,'unavailable'):self.render(report)

if __name__=='__main__':unittest.main()
