"""Independent read-only arithmetic recheck; writes only final-number-check.json."""
import ast
import collections
import hashlib
import json
import math
import re
import statistics as st
import struct
from pathlib import Path

N = Path(__file__).resolve().parent
sources = {}
checks = 0


def load(path):
    path = N / path
    raw = path.read_bytes()
    sources[str(path.relative_to(N))] = hashlib.sha256(raw).hexdigest()
    return json.loads(raw)


def eq(a, b, label):
    global checks
    checks += 1
    assert (a is b) if a is None or b is None else math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-9), (label, a, b)


def counter(raw, key):
    if key == 'cpu':
        f = raw['stat'].rsplit(')', 1)[1].split()
        return (int(f[11]) + int(f[12])) * 10
    name, source = ('write_bytes', 'io') if key == 'write' else (key, 'smaps_rollup')
    return int(next(x.split(':', 1)[1].split()[0] for x in raw[source].splitlines() if x.startswith(name + ':')))


def product(raw, proc):
    measured = [x for x in raw['samples'] if x['measured']]
    life = {x['phase']: x for x in raw['lifecycle']}
    start = raw['samples'][raw['history'] - 1] if raw['history'] else life['after_initialization']
    end, cleanup = measured[-1], life['after_cleanup']
    n = len(measured)
    cpu = counter(end['process'], 'cpu') - counter(start['process'], 'cpu')
    writes = counter(end['process'], 'write') - counter(start['process'], 'write')
    m = {'mean_turn_ms': st.mean(x['settled_us'] for x in measured) / 1000,
         'median_measured_turn_ms': st.median(x['settled_us'] for x in measured) / 1000,
         'turn_cpu_ms_per_turn': cpu / n, 'measured_turn_cpu_ms': cpu,
         'turn_write_bytes_per_turn': writes / n, 'measured_turn_write_bytes': writes,
         'through_cleanup_self_cpu_ms': counter(cleanup['process'], 'cpu'),
         'through_cleanup_process_write_bytes': counter(cleanup['process'], 'write'),
         'through_cleanup_process_write_mib': counter(cleanup['process'], 'write') / 2**20,
         'lifecycle_self_cpu_ms': counter(cleanup['process'], 'cpu') - counter(life['before_initialization']['process'], 'cpu'),
         'lifecycle_ms': (cleanup['elapsed_us'] - life['before_initialization']['elapsed_us']) / 1000,
         'max_sampled_turn_rss_mib': max(counter(x['process'], 'Rss') for x in measured) / 1024,
         'through_product_exit_wall_ms': proc['through_product_exit_ns'] / 1e6,
         'complete_harness_lifecycle_wall_ms': proc['complete_lifecycle_ns'] / 1e6,
         'closed_logical_bytes': sum(x['logical'] for x in raw['closed_footprint']),
         'closed_allocated_bytes': sum(x['allocated'] for x in raw['closed_footprint'])}
    for name, key in [('anon_pss', 'Pss_Anon'), ('pss', 'Pss'), ('rss', 'Rss')]:
        m['max_sampled_' + name + '_mib'] = max(counter(x['process'], key) for x in raw['samples'] + raw['lifecycle']) / 1024
    return m


formal = load('complete-all-audit.json')
diag = load('diagnostic-audit.json')
assert formal['accepted'] and formal['mode'] == 'strict' and not formal['errors']
assert diag['accepted'] and diag['mode'] == 'strict' and not diag['errors'] and not diag['pending']
out = {'accepted': False, 'scope': 'Independent raw arithmetic and report-table number check. Not a replacement for strict oracle/source/build authentication. No products or builds executed.',
       'identities': {k: {n: v[n] for n in ['head', 'sha256', 'production_tree']} for k, v in formal['identities'].items()},
       'warm': {}, 'direct12': [], 'direct_positive_median_metrics': [], 'logical': [], 'wal': [], 'sql': [], 'native_three_engine': []}
all_products = {}
for stage in ['direct', 'final']:
    data = formal['datasets'][stage]
    indexed = {}
    for p in data['products']:
        raw = load(p['file'])
        assert sources[p['file']] == p['raw_sha256']
        process_file = p['file'][:-5] + '.process.json'
        proc = load(process_file)
        assert sources[process_file] == p['process_sha256']
        m = product(raw, proc)
        assert set(m) == set(p['metrics'])
        for k, v in m.items():
            eq(v, p['metrics'][k], (p['file'], k))
        indexed[(p['cohort'], p['case'], p['pair'], p['engine'])] = m
    warm = []
    for t in data['table']:
        cell = {'mode': t['mode'], 'case': t['case'], 'metrics': {}}
        for metric, expected in t['metrics'].items():
            num = [indexed[(t['cohort'], t['case'], i, t['numerator_engine'])][metric] for i in range(5)]
            den = [indexed[(t['cohort'], t['case'], i, t['denominator_engine'])][metric] for i in range(5)]
            ratios = [a / b for a, b in zip(num, den)]
            eq(st.median(ratios), expected['paired_ratio_median'], (stage, t['case'], metric, 'ratio'))
            eq(st.median(num), expected['numerator_median'], (stage, t['case'], metric, 'num'))
            eq(st.median(den), expected['denominator_median'], (stage, t['case'], metric, 'den'))
            eq((st.median(ratios) - 1) * 100, expected['paired_percent_median'], (stage, t['case'], metric, 'percent'))
            for actual, value in zip([min(ratios), max(ratios)], expected['paired_percent_range']):
                eq((actual - 1) * 100, value, (stage, t['case'], metric, 'range'))
            cell['metrics'][metric] = {'numerator_median': st.median(num), 'denominator_median': st.median(den), 'paired_ratio_median': st.median(ratios), 'paired_ratio_range': [min(ratios), max(ratios)], 'paired_percent_median': (st.median(ratios) - 1) * 100, 'higher_pairs': sum(x > 1 for x in ratios)}
            if stage == 'direct' and st.median(ratios) > 1:
                out['direct_positive_median_metrics'].append({'mode': t['mode'], 'case': t['case'], 'metric': metric, **cell['metrics'][metric]})
        if stage == 'direct':
            out['direct12'].append(cell)
        if t['case'].startswith('short-'):
            warm.append(cell)
    out['warm'][stage] = warm
    all_products[stage] = indexed

# Recompute main-database column-value deltas; TEMP is outside this collector.
column_index = {}
for row in diag['columns']:
    base = f"columns-{row['revision']}-{row['case']}"
    before = load(base + '/before_measured_turns.json')
    after = load(base + '/after_turns.json')
    assert sources[base + '/before_measured_turns.json'] == row['before_sha256']
    assert sources[base + '/after_turns.json'] == row['after_sha256']
    totals = lambda d: {k: sum(v['column_value_bytes'].values()) for k, v in d['tables'].items()}
    b, a = totals(before), totals(after)
    delta = {k: a[k] - b.get(k, 0) for k in a}
    eq(sum(delta.values()), row['total_logical_delta'], base)
    for k, v in delta.items():
        eq(v, row['table_deltas'][k]['total_column_value_bytes'], (base, k))
    column_index[(row['revision'], row['case'])] = delta
for case in ['short-small', 'short-large']:
    before, after = [column_index[(r, case)] for r in ['baseline', 'complete']]
    row = {'case': case, 'scope': '32 measured turns; main logical column values, not B-tree allocation/WAL/device bytes. TEMP state not measured, not zero.', 'metrics': {}}
    for name, tables in [('all_main_logical', None), ('request_source_pages', ['request_source_pages']), ('all_request_source', ['request_source_pages', 'request_source_nodes', 'request_source_roots', 'request_source_scalars'])]:
        b = sum(before.values()) if tables is None else sum(before[t] for t in tables)
        a = sum(after.values()) if tables is None else sum(after[t] for t in tables)
        row['metrics'][name] = {'baseline': b, 'complete': a, 'difference': a - b, 'percent_change': (a / b - 1) * 100}
    expected = next(x for x in diag['column_comparison'] if x['case'] == case)
    for mine, theirs in [('all_main_logical', 'all_logical'), ('request_source_pages', 'request_source_pages')]:
        for k in ['baseline', 'complete', 'difference']:
            eq(row['metrics'][mine][k], expected['logical_bytes'][theirs][k], (case, mine, k))
    assert 'event_observation_readiness' not in after and 'transcript_observation_readiness' not in after
    out['logical'].append(row)

# Recount physical WAL frame headers and commit markers from retained strace.
wal_index = {}
for version in ['baseline', 'complete']:
    summary = load(f'wal-summary-{version}.json')
    for key, expected in summary.items():
        path = N / f'wal-{version}-{key}' / 'calls.strace'
        sources[str(path.relative_to(N))] = hashlib.sha256(path.read_bytes()).hexdigest()
        pending, phase, frames, commits, unfinished = {}, 'startup', 0, 0, 0
        for line in path.open():
            match = re.match(r'(\d+)\s+(.*)', line)
            if not match:
                continue
            pid, call = match.groups()
            if '<unfinished ...>' in call:
                assert pid not in pending
                pending[pid] = call.split('<unfinished ...>')[0]
                continue
            match = re.match(r'<\.\.\. \w+ resumed>(.*)', call)
            if match:
                call = pending.pop(pid) + match[1]
            if 'UNIX-STREAM' in call and 'before_measured_turns' in call:
                phase = 'steady'
            if 'UNIX-STREAM' in call and 'after_turns' in call:
                phase = 'after'
            if phase != 'steady':
                continue
            match = re.match(r'pwrite64\(\d+<[^>]+-wal>, ("(?:\\.|[^"\\])*"), 24, (\d+)\) = 24$', call)
            if not match:
                continue
            header = ast.literal_eval('b' + match[1])
            assert len(header) == 24 and (int(match[2]) - 32) % 4120 == 0
            page, size = struct.unpack('>II', header[:8])
            frames += 1
            unfinished += 1
            if size:
                commits += 1
                unfinished = 0
        assert not pending and not unfinished and phase == 'after'
        values = {'wal_write_commits': commits, 'wal_frames': frames, 'wal_frame_bytes': frames * 4120}
        for k, value in values.items():
            eq(value, expected[k], (version, key, k))
        wal_index[(version, key)] = values
for case in ['short-small', 'short-large']:
    b, a, pi = [wal_index[(v, case + '-' + e)] for v, e in [('baseline', 'rust'), ('complete', 'rust'), ('complete', 'pi')]]
    out['wal'].append({'case': case, 'measured_turns': 32, 'baseline': b, 'complete': a, 'pi': pi, 'complete_per_turn': {k: v / 32 for k, v in a.items()}, 'percent_change': {k: (a[k] / b[k] - 1) * 100 for k in a}, 'complete_over_pi': {k: a[k] / pi[k] for k in a}, 'scope': 'WAL write-commit markers and frame-header counts; not all SQL transactions, fsync counts, device writes or exclusive CPU time.'})

for row in diag['sql']:
    directory = row['name']
    phases = load(directory + '/phases.json')
    times = {x['phase']: x['monotonic_ns'] for x in phases}
    path = N / directory / 'prepares.jsonl'
    sources[str(path.relative_to(N))] = hashlib.sha256(path.read_bytes()).hexdigest()
    assert sources[str(path.relative_to(N))] == row['raw_sha256']
    counts = collections.Counter()
    for line in path.open():
        r = json.loads(line)
        if times['before_measured_turns'] <= r['monotonic_ns'] < times['after_turns']:
            counts[(r['flags'], r['sql'])] += 1
    total = sum(counts.values())
    eq(total, row['measured_prepare_calls'], row['name'])
    eq(len(counts), row['unique_flag_sql'], row['name'])
    transactions = {q: n for (_, q), n in counts.items() if q.split()[0].upper() in ['BEGIN', 'COMMIT', 'ROLLBACK']}
    out['sql'].append({'revision': row['revision'], 'prepare_calls': total, 'per_turn': total / 32, 'distinct_flag_sql': len(counts), 'transaction_shapes': transactions, 'business_prepare_calls': total - sum(transactions.values()), 'scope': 'sqlite3_prepare_v3 calls, not cache-hit query execution/VM steps.'})

# Native reference: recompute each engine's measured windows independently.
native = formal['datasets']['three-engine']
rows = []
for r in native['rows']:
    stem = f"final-cohorts/three-engine/{r['repetition']}-{r['case']}-{r['engine']}"
    raw = load(stem + ('/result.json' if r['engine'] == 'deepseek' else '.json'))
    assert sources[stem + ('/result.json' if r['engine'] == 'deepseek' else '.json')] == r['raw_result_sha256']
    measured = [x for x in raw['samples'] if x['measured']]
    if r['engine'] == 'deepseek':
        start = raw['samples'][raw['history'] - 1]['after'] if raw['history'] else measured[0]['before']
        end = measured[-1]['after']
        def tree_cpu(tree):
            return sum(sum(int(p['stat'].rsplit(')', 1)[1].split()[i]) for i in [11, 12, 13, 14]) * 10 for p in tree.values())
        cpu = tree_cpu(end) - tree_cpu(start)
        write = sum(counter(p, 'write') for p in end.values()) - sum(counter(p, 'write') for p in start.values())
        wall = [x['settled_ns'] / 1e6 for x in measured]
    else:
        life = {x['phase']: x for x in raw['lifecycle']}
        start = raw['samples'][raw['history'] - 1] if raw['history'] else life['after_initialization']
        end = measured[-1]
        cpu = counter(end['process'], 'cpu') - counter(start['process'], 'cpu')
        write = counter(end['process'], 'write') - counter(start['process'], 'write')
        wall = [x['settled_us'] / 1000 for x in measured]
    m = {'mean_turn_ms': st.mean(wall), 'median_turn_ms': st.median(wall), 'turn_cpu_ms_per_turn': cpu / len(measured), 'turn_write_bytes_per_turn': write / len(measured)}
    eq(m['mean_turn_ms'], r['mean_turn_ms'], stem)
    eq(m['turn_cpu_ms_per_turn'], r['turn_cpu_ms_per_turn'], stem)
    eq(m['turn_write_bytes_per_turn'] / 2**20, r['turn_write_mib_per_turn'], stem)
    supplement = next(x for x in native['supplementary_products'] if (x['case'], x['engine'], x['repetition']) == (r['case'], r['engine'], r['repetition']))
    eq(m['median_turn_ms'], supplement['metrics']['median_measured_turn_ms'], stem)
    rows.append({'case': r['case'], 'engine': r['engine'], 'repetition': r['repetition'], **m})
for case in ['short-small', 'short-large', 'stream', 'large']:
    for engine in ['rust', 'pi', 'deepseek']:
        chosen = [r for r in rows if r['case'] == case and r['engine'] == engine]
        assert len(chosen) == 3
        values = {k: [r[k] for r in chosen] for k in ['mean_turn_ms', 'median_turn_ms', 'turn_cpu_ms_per_turn', 'turn_write_bytes_per_turn']}
        out['native_three_engine'].append({'case': case, 'engine': engine, 'samples': 3, 'metrics': {k: {'median': st.median(v), 'range': [min(v), max(v)], 'values': v} for k, v in values.items()}})

# Independently check the first six display tables' rounded numeric cells.
table_text = (N / 'report-tables.md').read_text()
sources['report-tables.md'] = hashlib.sha256(table_text.encode()).hexdigest()
sections = []
table = []
for line in table_text.splitlines() + ['']:
    if line.startswith('|'):
        table.append([x.strip() for x in line.strip('|').split('|')])
    elif table:
        sections.append(table[2:])
        table = []
def numeric(cell):
    return [float(x.replace(',', '')) for x in re.findall(r'[+-]?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?', cell)]
def displayed(value, cell, decimals):
    eq(float(f'{value:.{decimals}f}'), numeric(cell)[0], ('display', value, cell))
for stage, number, metrics in [('direct', 0, ['mean_turn_ms', 'median_measured_turn_ms', 'through_cleanup_self_cpu_ms', 'through_cleanup_process_write_bytes', 'max_sampled_anon_pss_mib']), ('final', 1, ['mean_turn_ms', 'median_measured_turn_ms', 'through_cleanup_self_cpu_ms', 'through_cleanup_process_write_bytes', 'max_sampled_anon_pss_mib'])]:
    table = sections[number]
    assert len(table) == 12
    for cells, expected in zip(table, formal['datasets'][stage]['table']):
        assert cells[1] == expected['case']
        for column, metric in enumerate(metrics, 2):
            displayed(expected['metrics'][metric]['paired_percent_median' if stage == 'direct' else 'paired_ratio_median'], cells[column], 2 if stage == 'direct' else 3)
for stage, number in [('direct', 2), ('final', 3)]:
    for cells, row in zip(sections[number], out['warm'][stage]):
        assert cells[1] == row['case']
        for i, metric in enumerate(['median_measured_turn_ms', 'turn_cpu_ms_per_turn', 'turn_write_bytes_per_turn'], 3):
            values = numeric(cells[i])
            for v, key in zip(values, ['denominator_median', 'numerator_median']):
                eq(v, float(f"{row['metrics'][metric][key]:.{1 if i == 5 else 3}f}"), ('display absolute', stage, cells))
for cells, row in zip(sections[4], out['native_three_engine']):
    assert (cells[0], cells[1]) == (row['case'], row['engine'])
    for i, metric in enumerate(['mean_turn_ms', 'median_turn_ms', 'turn_cpu_ms_per_turn', 'turn_write_bytes_per_turn'], 2):
        displayed(row['metrics'][metric]['median'], cells[i], 1 if i == 5 else 3)

out['notes'] = [
    'Five pairs are descriptive; paired ratio median is not the ratio of the displayed marginal medians. Means and per-run turn medians are distinct.',
    'Direct compares two Rust revisions with full native request equivalence; Pi/DeepSeek have native tool/context/observer differences and are not a full-function equality proof.',
    'Warm CPU uses last warm/after-initialization through last measured turn; full CPU/write through cleanup includes startup, verification and reopen. CPU counts use 100 Hz. Single-turn CPU percent changes are coarse.',
    'DeepSeek idle does not await final JSONL flush/fsync; sampled tree CPU includes waited children, sampled I/O excludes exited descendants. Its turn results are supplementary, not equal-durability ratios.',
    'Logical main-column bytes omit B-tree/index overhead and unobserved TEMP state. WAL frame bytes are distinct from process write_bytes and device writes.',
    'Source and raw hashes are retained for this arithmetic check; complete oracle/build provenance acceptance remains the responsibility of the existing strict auditors.'
]
out['numeric_checks'] = checks
out['sources'] = sources
out['script_sha256'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
out['accepted'] = True
(N / 'final-number-check.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'accepted': True, 'numeric_checks': checks, 'source_files': len(sources), 'warm_cells': {k: len(v) for k, v in out['warm'].items()}, 'direct_cells': len(out['direct12']), 'native_groups': len(out['native_three_engine'])}))
