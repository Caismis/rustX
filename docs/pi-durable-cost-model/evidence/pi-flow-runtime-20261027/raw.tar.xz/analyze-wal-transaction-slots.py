#!/usr/bin/env python3
"""Describe WAL temporal slots and compare a separate retained SQL-TX sequence.

No claim that a SQL stack and a WAL transaction were captured in one process.
No fixed 13/5-slot assumption; the observed counts must agree and repeat 32 times.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import statistics


HERE = Path(__file__).resolve().parent


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repetition-report', type=Path, default=HERE / 'previous-wal-page-repetition.json')
    parser.add_argument('--revision', default='complete', choices=['baseline', 'complete'])
    parser.add_argument('--output', type=Path, default=HERE / 'previous-wal-transaction-slots.json')
    args = parser.parse_args()
    require(not args.output.exists(), 'preserve prior analysis; choose a new output')
    repetition = load(args.repetition_report)
    require(repetition['accepted'] is True, 'page repetition analysis not accepted')
    root = Path(repetition['input_root'])
    audit_path = root / 'diagnostic-audit.json'
    require(sha(audit_path) == repetition['input_audit_sha256'], 'strict evidence changed')
    audit = load(audit_path)
    sql = next(row for row in audit['sql'] if row['revision'] == args.revision and '-tx-' in row['name'])
    raw = root / sql['name'] / 'prepares.jsonl'
    require(sha(raw) == sql['raw_sha256'], 'SQL raw differs from accepted audit')
    times = {row['phase']: row['monotonic_ns'] for row in sql['phases']}
    starts = []
    with raw.open() as stream:
        for line in stream:
            row = json.loads(line)
            if row['sql'] == 'BEGIN IMMEDIATE' and times['before_measured_turns'] <= row['monotonic_ns'] < times['after_turns']:
                starts.append(row)
    require(starts and len(starts) % 32 == 0, 'SQL sequence does not divide into 32 equal temporal groups')
    slots = len(starts) // 32
    stack_counts = collections.Counter(tuple(row['first_call_stack']) for row in starts)
    require(stack_counts == {tuple(row['stack']): row['count'] for row in sql['write_begin_prepare_stacks']}, 'SQL stack recount differs')
    sql_slots = []
    for slot in range(slots):
        rows = starts[slot::slots]
        prefixes = {tuple(row['first_call_stack'][:7]) for row in rows}
        require(len(rows) == 32 and len(prefixes) == 1, 'SQL temporal slot does not have one repeated stack prefix')
        stack = list(prefixes.pop())
        ready = any('>::mark_native_observation_ready' in s or '>::mark_observation_transcript_ready' in s for s in stack)
        sql_slots.append({'slot': slot + 1, 'samples': 32, 'stack_prefix': stack, 'readiness_stack': ready})
    results = []
    for wal in repetition['results']:
        if wal['label'] != args.revision or wal['engine'] != 'rust':
            continue
        require(wal['commits'] == len(starts), 'WAL/SQL counts differ; no equal-slot alignment claimed')
        require(all(wal['identity']['build'][key] == sql['identity']['build_identity'][key] for key in ('head', 'sha256', 'production_tree')), 'SQL/WAL binary source identity differs')
        rows = []
        for slot, definition in enumerate(sql_slots):
            transactions = wal['transactions'][slot::slots]
            values = [row['frames'] for row in transactions]
            rows.append({**definition, 'frame_values': values, 'frames_min': min(values), 'frames_median': statistics.median(values), 'frames_max': max(values),
                         'frames_total': sum(values), 'frame_bytes': 4120 * sum(values),
                         'cross_transaction_repeat_occurrences': sum(row['page_numbers_seen_in_prior_measured_transactions'] for row in transactions),
                         'within_transaction_repeat_frames': sum(row['within_transaction_repeat_frames'] for row in transactions),
                         'also_in_immediately_prior_transaction': sum(row['page_numbers_also_in_previous_transaction'] for row in transactions)})
        categories = []
        for readiness in (True, False):
            selected = [row for row in rows if row['readiness_stack'] is readiness]
            count = sum(row['frames_total'] for row in selected)
            repeated = sum(row['cross_transaction_repeat_occurrences'] for row in selected)
            categories.append({'sql_alignment': 'readiness' if readiness else 'other_semantic', 'slots': [row['slot'] for row in selected], 'commits': len(selected) * 32,
                               'frames': count, 'frame_bytes': count * 4120, 'share_of_wal_frames': count / wal['frames'],
                               'cross_transaction_repeat_occurrences': repeated, 'share_of_cross_transaction_repeats': repeated / wal['cross_transaction_repeat_page_occurrences']})
        results.append({'case': wal['case'], 'binary_head': wal['identity']['build']['head'], 'binary_sha256': wal['identity']['binary_sha256'],
                        'slots_per_temporal_group': slots, 'groups': 32, 'slots': rows, 'conditional_alignment_totals': categories})
    require(len(results) == 2, 'missing two warm Rust cases')
    report = {'accepted': True, 'scope': 'Temporal ordinal slots, not exact per-WAL-transaction stack attribution. SQL and WAL were separate intrusive products with identical binary/source. A 32-times repeated SQL sequence supports but does not directly prove the cross-run alignment, especially for the separate short-small WAL run.',
              'repetition_report_sha256': sha(args.repetition_report), 'strict_audit_sha256': sha(audit_path), 'sql_trace_sha256': sha(raw), 'script_sha256': sha(Path(__file__)),
              'sql_begin_count': len(starts), 'sql_slots_per_group': slots, 'sql_case': 'short-large', 'results': results,
              'limits': ['No dbstat page-to-table attribution is used.', 'Prepare observations are not themselves commit proof; the independently parsed WAL gives commit counts.', 'Readiness frame savings here only describe those aligned old slots, not indirect benefits of new storage/schema changes.', 'A new candidate must supply its own actual repeated sequence and WAL count; this tool never assumes five commits per turn.']}
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'output': str(args.output), 'slots': slots, 'results': [{'case': row['case'], 'conditional_alignment_totals': row['conditional_alignment_totals']} for row in results]}, indent=2))


if __name__ == '__main__':
    main()
