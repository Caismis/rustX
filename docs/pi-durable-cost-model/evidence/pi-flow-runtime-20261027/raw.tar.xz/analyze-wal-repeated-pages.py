#!/usr/bin/env python3
"""Read retained WAL syscall traces; never execute products or alter old evidence.

This focused parser accepts only proved 4096-byte append-frame traces. It refuses
an in-place payload/header rewrite instead of silently treating it as a new
transaction. Those writes require a separate checksum/rewrite-aware analysis.
"""
import argparse
import ast
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re
import statistics


HERE = Path(__file__).resolve().parent
OLD = Path('/home/capi/.cache/rustx-pr485-complete-costs-final')


def require(value, message):
    if not value:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def parse_trace(path, database, expected_phases):
    pending = {}
    seen_phases = []
    active = False
    frame = None
    last_offset = None
    resets = 0
    tx = collections.Counter()
    transactions = []
    pages_seen = set()
    previous_pages = set()
    measured_target = database + '-wal'
    with path.open() as stream:
        for line_number, line in enumerate(stream, 1):
            match = re.match(r'(\d+)\s+(.*)', line)
            if not match:
                continue
            pid, call = match.groups()
            if '<unfinished ...>' in call:
                require(pid not in pending, 'duplicate unfinished syscall')
                pending[pid] = call.split('<unfinished ...>')[0]
                continue
            resumed = re.match(r'<\.\.\. \w+ resumed>(.*)', call)
            if resumed:
                require(pid in pending, 'resumed syscall without start')
                call = pending.pop(pid) + resumed[1]
            if 'UNIX-STREAM' in call:
                for phase in expected_phases:
                    if '"' + phase + '"' in call or '"' + phase + '\\n"' in call:
                        seen_phases.append(phase)
                        if phase in ('before_measured_turns', 'after_turns'):
                            require(frame is None and not tx, 'phase boundary splits a WAL transaction')
                            active = phase == 'before_measured_turns'
                        break
            if not active:
                continue
            match = re.match(r'pwrite64\(\d+<([^>]+-wal)>, (.*), (\d+), (\d+)\) = (\d+)$', call)
            if not match:
                require(not (measured_target in call and re.match(r'(?:pwrite|write)', call)), 'unsupported WAL syscall shape')
                continue
            target, quoted, size, offset, returned = match.groups()
            size, offset, returned = map(int, (size, offset, returned))
            require(target == measured_target and returned == size, 'foreign target or short WAL write')
            if size == 32:
                require(offset == 0 and frame is None and not tx, 'WAL reset inside a transaction')
                header = ast.literal_eval('b' + quoted)
                require(len(header) == 32 and int.from_bytes(header[8:12], 'big') == 4096, 'unsupported WAL page size')
                last_offset = None
                resets += 1
            elif size == 24:
                require(frame is None, 'header without previous payload: possible checksum rewrite')
                header = ast.literal_eval('b' + quoted)
                require(len(header) == 24 and offset >= 32 and (offset - 32) % 4120 == 0, 'invalid frame header geometry')
                require(last_offset is None or offset == last_offset + 4120, 'nonappend header write: possible checksum rewrite or reset missing')
                page, commit_size = (int.from_bytes(header[i:i+4], 'big') for i in (0, 4))
                require(page > 0, 'invalid page number')
                frame = page, commit_size, offset, line_number
            elif size == 4096:
                require(frame is not None, 'payload without new frame header: possible in-place rewrite')
                page, commit_size, header_offset, _ = frame
                require(offset == header_offset + 24, 'payload/header offset mismatch')
                last_offset = header_offset
                tx[page] += 1
                frame = None
                if commit_size:
                    page_set = set(tx)
                    transactions.append({
                        'ordinal': len(transactions), 'frames': sum(tx.values()),
                        'unique_page_numbers': len(tx), 'within_transaction_repeat_frames': sum(tx.values()) - len(tx),
                        'page_numbers_seen_in_prior_measured_transactions': len(page_set & pages_seen),
                        'page_numbers_also_in_previous_transaction': len(page_set & previous_pages),
                        'first_measured_page_numbers': len(page_set - pages_seen),
                        'commit_database_pages': commit_size, 'commit_trace_line': line_number,
                        'page_frame_counts': {str(p): n for p, n in sorted(tx.items())},
                    })
                    pages_seen.update(page_set)
                    previous_pages = page_set
                    tx.clear()
            else:
                raise ValueError('unsupported WAL write length: ' + str(size))
    require(not pending and frame is None and not tx and not active, 'incomplete trace/transaction')
    require(seen_phases == expected_phases and transactions, 'missing phase/transaction inventory')
    frames = sum(row['frames'] for row in transactions)
    unique_exposures = sum(row['unique_page_numbers'] for row in transactions)
    within = frames - unique_exposures
    across = unique_exposures - len(pages_seen)
    require(frames == len(pages_seen) + across + within, 'page occurrence decomposition failed')
    totals = collections.Counter()
    for row in transactions:
        totals.update({int(p): n for p, n in row['page_frame_counts'].items()})
    return {
        'commits': len(transactions), 'frames': frames, 'frame_bytes': frames * 4120,
        'payload_bytes': frames * 4096, 'measured_wal_header_writes': resets,
        'traced_wal_pwrite_bytes': frames * 4120 + resets * 32,
        'unique_measured_page_numbers': len(pages_seen),
        'unique_page_transaction_pairs': unique_exposures,
        'cross_transaction_repeat_page_occurrences': across,
        'cross_transaction_repeat_share_of_frames': across / frames,
        'within_transaction_repeat_frames': within,
        'within_transaction_repeat_share_of_frames': within / frames,
        'transactions_with_repeated_page_numbers': sum(row['within_transaction_repeat_frames'] > 0 for row in transactions),
        'frames_per_transaction': {'minimum': min(row['frames'] for row in transactions), 'median': statistics.median(row['frames'] for row in transactions), 'maximum': max(row['frames'] for row in transactions)},
        'page_frame_frequency_histogram': {str(count): sum(v == count for v in totals.values()) for count in sorted(set(totals.values()))},
        'transactions': transactions,
        'in_place_payload_or_checksum_header_rewrites': 0,
        'write_shape': 'Every observed 24-byte header was a sequential append and was followed by its single matching 4096-byte page payload; in-place rewrites would reject this result.',
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input-root', type=Path, default=OLD)
    parser.add_argument('--output', type=Path, default=HERE / 'previous-wal-page-repetition.json')
    args = parser.parse_args()
    root = args.input_root.resolve()
    output = args.output.resolve()
    require(not output.exists() and not output.is_relative_to(root), 'output must be new and outside retained input tree')
    audit_path = root / 'diagnostic-audit.json'
    audit = load(audit_path)
    require(audit['accepted'] is True and audit['errors'] == [] and audit['mode'] == 'strict', 'requires accepted retained strict diagnostics')
    results = []
    for retained in audit['wal']:
        label, case, engine = (retained[k] for k in ('label', 'case', 'engine'))
        directory = root / f'wal-{label}-{case}-{engine}'
        before = load(directory / 'before_measured_turns-database.json')
        after = load(directory / 'after_turns-database.json')
        require(len(before) == len(after) == 1 and before[0]['path'] == after[0]['path'], 'database snapshot identity differs')
        phases = load(directory / 'phases.json')
        digest = sha(directory / 'calls.strace')
        require(digest == retained['summary']['raw_sha256'], 'trace differs from accepted strict record')
        result = parse_trace(directory / 'calls.strace', before[0]['path'], [r['phase'] for r in phases])
        expected = retained['summary']
        require((result['commits'], result['frames'], result['frame_bytes']) == (expected['wal_write_commits'], expected['wal_frames'], expected['wal_frame_bytes']), 'original strict WAL totals differ')
        require([row['frames'] for row in result['transactions']] == expected['transaction_page_counts'], 'per-transaction original frame counts differ')
        result.update(label=label, case=case, engine=engine, measured_turns=32,
                      identity=retained['identity'], trace_file=str((directory / 'calls.strace').relative_to(root)), trace_sha256=digest,
                      phases_sha256=sha(directory / 'phases.json'))
        results.append(result)
    require(len(results) == 8, 'requires the retained eight WAL diagnostics')
    report = {'accepted': True, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'input_root': str(root), 'input_audit_sha256': sha(audit_path), 'script_sha256': sha(Path(__file__)),
              'scope': 'Post-hoc raw-only page-number repetition analysis of prior measurements; not current Pi-flow performance. No dbstat owner attribution, products, builds, or source mutations.',
              'limits': ['A page number is a physical address, not a stable table/object identity; intermediate page reuse is possible.',
                         'Cross-transaction repetitions count page addresses seen again after a commit, not byte-identical data or automatically avoidable writes.',
                         'Zero same-transaction duplicate writes does not prove no cache spill: a page can spill once and never become dirty again. No pager cache-spill counter or pager call stacks were recorded.',
                         'The parser proves the append-only observed syscall shape or fails; it cannot classify a future trace containing in-place payload/checksum rewrites.',
                         'WAL commit markers exclude read-only commits; WAL bytes exclude checkpoints and filesystem/device amplification.',
                         'Logical retained-byte deltas and WAL traces come from separate diagnostic products and measure different quantities.'],
              'results': results}
    output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'accepted': True, 'summary': [{key: row[key] for key in ('label', 'case', 'engine', 'commits', 'frames', 'unique_measured_page_numbers', 'cross_transaction_repeat_page_occurrences', 'within_transaction_repeat_frames', 'in_place_payload_or_checksum_header_rewrites')} for row in results]}, indent=2))


if __name__ == '__main__':
    main()
