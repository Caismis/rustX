# Request inspection residual write audit

2026-10-27. Read-only source investigation of the schema-80 candidate during its coordinated checks. No product, build, or benchmark was run for this audit. Prior measured data is the accepted schema-79 final round at `/home/capi/.cache/rustx-pr485-complete-costs-final`; these numbers do not describe the still-unmeasured schema-80 candidate. Source paths below are relative to the rustX worktree.

## What was actually written

Independent subtraction of `columns-complete-short-{small,large}/{before_measured_turns,after_turns}.json` reproduces the following logical column-value increases for 32 warm requests. These count stored column values, not SQL traffic, WAL bytes, device bytes, CPU, or allocation volume.

| New retained values | short-small | short-large |
|---|---:|---:|
| request_source_pages | 520,977 bytes / 384 rows | 521,664 bytes / 384 rows |
| request_source_nodes | 143,920 bytes / 285 rows | 187,716 bytes / 351 rows |
| request_source_roots | 11,288 bytes / 32 rows | 11,424 bytes / 32 rows |
| three-table sum | 676,185 bytes | 720,804 bytes |
| all-table logical increase | 1,770,302 bytes | 1,826,076 bytes |
| three-table share | 38.2% | 39.5% |
| request_source_scalars | 0 bytes / 0 rows | 0 bytes / 0 rows |
| request_configurations | 0 bytes / 0 rows | 0 bytes / 0 rows |
| native_input_nodes | 43,559 bytes / 285 rows | 50,891 bytes / 351 rows |

The native leaf digest increase is 2,048 bytes in each case, i.e. 64 new leaf rows. The remaining new native/source nodes are branch paths in the immutable selected-input tree. The measurements do **not** show full historical input or unchanged system/tools being copied on every request. The old diagnostic databases were removed by their recorded product cleanup, so the retained column snapshots cannot further classify individual page bodies. No exact byte saving is asserted for the proposal below.

## Existing reuse and its limits

`sqlite.rs:index_request_read_layouts` (about line 6130) eagerly constructs optional inspection layouts in the native RequestStart transaction. `composed.rs:206–295` captures source augmentations, the scalar source, path and byte geometry, then one immutable request root and content frontier.

* `composed/nodes.rs:174–245` reuses an existing augmentation by native node ID plus native digest, and only captures missing immutable leaves/branches. Existing invalid metadata is an error, not a cache miss. Roots keep the actual selected order, including repeated/reordered occurrences; the native tree already owns that order.
* `composed/index.rs:28–73` content-addresses pages with SHA-256 and `INSERT OR IGNORE`. Equal complete encoded pages share storage. This does not make different message IDs, provenance, offsets or field metadata equal.
* `composed/scalar.rs:99–167` reuses an exact stable scalar suffix. `scalar.rs:169–195` still serializes and hashes the stable prototype each request to establish its identity; it builds F/C navigation only on a miss. The six changing fields are contributions/request/attempt/step/retry/assistant identity (`trace/frozen.rs:43–69`). The suffix includes allowlisted model/options/system/tools and fixed status placeholders (`trace/frozen.rs:70–105`). It is broader than native `configuration_digest`, so substituting that digest alone would be incorrect.
* Native configuration is already shared in `native_request.rs:240–283`. Its system prompt, accepted sections and tool definitions are separate from per-request metadata. Sharing that owner with the stable inspection suffix could avoid some repeated serialization if it also proves all other allowlisted inputs. It cannot explain or remove the measured 521 KB warm page increase: both stable-source and native-configuration row growth are already zero.

The 384 new pages are consistent with 32 changing prefixes × 2 pages plus 64 new message fragments × 5 pages (two field/byte parts and a template); this is a source-derived interpretation, not a measured page-kind partition.

## Which data is duplicated

A native Original input stores a `CanonicalMessageRef` (conversation/message/content digest); Derived and RequestOnly inputs own typed content (`model/projected.rs:149–156`). Canonical body data and finite native observation headers already exist. `observation_request.rs:input_view` obtains that canonical `MessageHeader` and binds original provenance. `message_value_capture` (about line 1081) produces a finite trace descriptor with content bindings and collection frontiers, often referring to canonical body storage rather than copying an entire large body.

A new inspection leaf then does additional work in `composed/fragments.rs:392–426`:

1. Encode the allowlisted TraceRequestMessage, including original provenance and references/finite block descriptors.
2. Index its prefix and suffix around the generated request-sequence/rank provenance hole.
3. Persist original byte chunks **and** F/C navigation pages (`fragments.rs:205–227`).
4. Persist a `Template` containing another finite message header split around that hole (`fragments.rs:298–318,413–426`).

Within each F fact, `capture_facts` computes a finite preview and stores `Fact.header` (`fragments.rs:107–155`). Parent previews contain child values, while those child facts carry their own previews, and the original JSON chunks already retain the source bytes. This is actual redundant representation, not merely verbose MessagePack. C records have already been reduced to child paths instead of duplicating full F records (`fragments.rs:267–275`).

`request_source_nodes` also retains 80 sequence/rank width classes and branch source hashes alongside the native child coordinates (`composed.rs:109–123`, `nodes.rs:214–245`, `weights.rs:3–5`). Those let range reads skip large subtrees and handle decimal-width crossings and header budget changes. It is additional source geometry rather than another copy of message bodies. Replacing it needs an exact parametric-length design; this audit does not pretend that dropping the vector preserves arbitrary range lookup.

## A focused next change with the existing bounded reader

The clearest next target is **ordinary F.header**. `composed/read.rs:339–388` already has `preview()`, whose rules match the producer `runtime/read_layout.rs:868–940`: at most 32 preview nodes; direct parse only for a subtree at most 16 KiB and at most 32 nodes; otherwise bounded child traversal; large noncontainer values become null. `field_in` currently uses this only for root/messages and returns the persisted `Fact.header` for other ordinary fields (`read.rs:418–425`).

The coordinated implementation plan is to remove that persisted mirror, preserve exact byte chunks and F/C geometry, and generate the ordinary field preview only when inspection actually requests it. Writer capture should use the existing `visit_field_geometry` and must still validate all newly uncovered bounded original subtrees with `original_node_count`; removing the header must not silently drop numeric/syntax/depth admission. Reader output must retain the final `bounded_bytes(..., 16384)` / null behavior.

This has specific boundaries:

* Synthetic `$key` fields deliberately expose an empty-string preview while retaining exact key bytes for range reading. They must not become the key text merely because raw bytes are now available.
* `Template.header_prefix/header_suffix` remain. Their finite descriptor is not always a preview of the complete raw provenance. Removing them together would conflate two public representations.
* Original chunks, F/C paths, native-root digest, start sequence, rank, revision, `ContentRef` and read-cut checks remain authoritative. Nothing is rebuilt from latest request/configuration data.
* A corrupt/missing original byte page now makes a requested ordinary preview unavailable as well. A successful header cannot be reconstructed from a detached stored mirror after its required source is lost. This must be documented and tested as source unavailability, not used as a repair path.
* Inspection reads do more bounded work than loading a cached field preview. This is an explicit writer-versus-reader tradeoff, not free performance. The existing 32-node/16 KiB/per-page limits remain; actual live and no-live end-to-end results must determine the benefit.

Required proof: byte-identical field headers/pages against the independent eager-preview oracle; exact original byte ranges; negative zero and large opaque numbers; aliased/reserved/escaped/oversized keys and `$key`; 16 KiB and 32-node boundaries; reordered and repeated inputs, old cuts/reopen; malformed/rehashed source geometry and source-byte corruption; zero writer preview construction with retained admission failures. Existing layout-byte tests will need to compare the new private geometry representation while retaining the independent public-byte oracle.

The paragraphs above record the source investigation before implementation. After checks-retry2 completed, root authorized the focused change below; prior measured column data remain baseline-only, not measurements of this implementation.

## Why not defer the entire source until inspection

The native sources are sufficient to reconstruct semantic requests, but not a drop-in bounded field index. `manifest.rs:185–196` loads and authenticates an entire native leaf, up to 64 MiB; native configuration reads have the same 64 MiB class. Ordinary `request_field_header/page/read` promises field/range reads without materializing all request history or a huge opaque field. Building the entire derived index on first inspection would move unbounded first-read work and write side effects into that contract, and would risk reconstructing from changed canonical/raw metadata. A correct fully lazy design would first need immutable source-owned byte navigation or a new explicit preparation operation. It is a broader source-layout replacement, not a safe deletion of all three tables.

Pi's pinned `session-manager.ts:1172–1215` retains typed entries and appends one JSON line per entry; its context is assembled from the retained entry tree (`1490–1500`). DeepSeek's pinned `session-persistence-jsonl/src/index.ts:1407–1442` appends an event batch then syncs it, while client `ui-conversation/.../request-inspection.ts:93–128` derives prompt inspection from retained request-header/system events. These inspected paths do not eagerly build rustX's arbitrary field/range inspection tree. The applicable pattern is to derive finite display previews when requested, while retaining rustX's native cut/source authority and bounded navigation. The implementations are not asserted to expose identical inspection APIs or durability controls.

## Current-check regression is separate from this retained cost

The schema-80 check failures reporting 13 new immutable leaves instead of zero, and a corrupt old source being bypassed, were traced jointly to the manifest preupdate observer: a new middle VIRTUAL column made `table_info` column numbering differ from the logical ordinals consumed by the hook. Native IDs were consequently invalidated and recaptured. The native agent has corrected this using `table_xinfo` logical coordinates and added a real hook regression; coordinated rerun is pending. No expected reuse counts were relaxed, and no request-source production patch was made to hide that regression.


## Implemented geometry-only ordinary field records (awaiting coordinated checks)

Ordinary `Fact` now stores eight geometry/key fields and no preview mirror. The old nine-field record is rejected, not decoded through an alternate path. `Template.header_prefix/header_suffix` remain unchanged. `capture_facts` visits field geometry without constructing any previews and validates each uncovered bounded subtree once using the existing original JSON node visitor, retaining numeric, syntax and serde-depth admission. The no-longer-used eager `visit_field_metadata` API is removed.

`field_in` retains template overrides and authenticated synthetic `$key` empty-string headers. Other fields reuse the established bounded `preview` algorithm followed by the same finite JSON byte encoding and 16 KiB admission. F/C records and raw chunks retain their existing hash, byte-size and closed-record checks. This moves ordinary display computation from every capture to actual inspection; it does not remove source navigation or change raw range bytes. The 16 KiB cap is per directly parsed subtree and per encoded header, **not** a claim that an entire recursive preview reads only 16 KiB: up to 32 bounded node visits can read separate subtrees, and a page can request up to 32 fields.

The test-only old eager producer retains its independent nine-field `LegacyFact` representation. The differential checks compare every new field against its old header bytes, F/C geometry and original byte-tree identity. They also compare actual stored page-payload lengths and assert zero writer preview constructions. Existing hidden invalid-number, duplicate-key, excessive-depth, byte/node-boundary, alias and source-span tests retain their contracts. A new file-backed storage scenario damages only the raw byte-page tree, requires ordinary field/page Storage errors, checks that the synthetic key header still authenticates F independently, proves native request/J/C state and historical selection unchanged, restores the page byte-for-byte, and then damages F to prove the empty key header cannot bypass authentication.

New/renamed exact test leaves:

- `geometry_capture_preserves_eager_headers_and_raw_chunks_without_preview_mirrors`
- `geometry_only_headers_authenticate_raw_chunks_without_changing_native_history_or_old_cuts`
- `compact_request_fact_contains_only_geometry_and_omits_preview_mirrors`
- `compact_request_metadata_exact_byte_bound_is_enforced`

`range_filter_skips_preview_work_but_keeps_selected_facts` now requires zero writer previews. This subagent ran scoped rustfmt and `git diff --check`, but no build, test, product or benchmark. Final correctness and end-to-end benefit are pending the root's coordinated queue and fresh measurements; source deletion alone is not a measured speedup.
