import argparse,datetime,hashlib,json,os,subprocess,sys,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
before=Path('/home/capi/.cache/rustx-pr485-complete-costs-final/candidate-complete-build/conformance')
after=root/'candidate-complete-build/conformance'; pi=Path('/home/capi/Documents/codes/pi-rustx-benchmark')
p=argparse.ArgumentParser();p.add_argument('--stage',choices=['direct','final'],required=True);a=p.parse_args()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(binary):
 data=json.loads((binary.parent/'identity.json').read_text());assert data['verified'] and data['build_exit']==0 and data['sha256']==sha(binary)
 assert data['production_tree']==subprocess.check_output(['git','rev-parse',data['head']+':src'],cwd=repo,text=True).strip()
 for f,h in data['harness'].items():assert sha(repo/f)==h
 return data
ids={n:identity(b) for n,b in [('before',before),('after',after)]};assert ids['before']['harness']==ids['after']['harness'];assert ids['before']['rustc']==ids['after']['rustc'];assert ids['before']['sha256']!=ids['after']['sha256']
def source_snapshot():
 paths=['src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime']
 dirty=subprocess.check_output(['git','status','--porcelain','--',*paths],cwd=repo,text=True).strip()
 assert not dirty,dirty
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip()
 assert tree==ids['after']['production_tree']
 source_files={str(p.relative_to(repo)):sha(p) for folder in ('src','tests') for p in sorted((repo/folder).rglob('*')) if p.is_file()}
 source_files.update({name:sha(repo/name) for name in ('Cargo.toml','Cargo.lock')})
 assert source_files==ids['after']['source_files']
 fixture_paths=sorted(path for path in (repo/'benchmarks/runtime').rglob('*') if path.is_file() and '__pycache__' not in path.parts)
 fixtures={str(path.relative_to(repo)):sha(path) for path in fixture_paths}
 for path,value in ids['after']['harness'].items():assert sha(repo/path)==value
 assert 'pub const SQLITE_SCHEMA_VERSION: i64 = 80;' in (repo/'src/durable/sqlite.rs').read_text()
 return dict(head=head,production_tree=tree,schema=80,source_files=source_files,fixtures=fixtures,utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
initial_source=source_snapshot()
base=root/('direct-cohorts' if a.stage=='direct' else 'final-cohorts');base.mkdir(exist_ok=False)
steps=[]
def add(name,cmd,audit=False,out=None):steps.append(dict(name=name,command=cmd,kind='audit' if audit else 'cohort',stdout=str(out or base/(name+'.stdout')),stderr=str(base/(name+'.stderr')),status='pending'))
if a.stage=='direct':
 for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
  name='direct-'+label;add(name,[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(base/name),'--pairs','5','--observer-mode',mode])
else:
 for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
  name='pi-'+label;add(name,[sys.executable,'benchmarks/runtime/controller.py','--rust',str(after),'--pi',str(pi),'--output',str(base/name),'--pairs','5','--observer-mode',mode])
 add('three-engine',[sys.executable,'benchmarks/runtime/deepseek-compare.py','--rust',str(after),'--pi',str(pi),'--deepseek','/home/capi/.cache/rustx-pr485-next/deepseek-checkout','--output',str(base/'three-engine'),'--repetitions','3'])
plan=dict(stage=a.stage,identities=ids,steps=steps,source_before=initial_source,explicit_environment={'UV_OFFLINE':'1'})
def save():(base/'commands.json').write_text(json.dumps(plan,indent=2)+'\n')
save()
for s in steps:
 s.update(status='running',start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 with Path(s['stdout']).open('w') as out,Path(s['stderr']).open('w') as err:r=subprocess.run(s['command'],cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 s.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(s['name'],r.returncode,flush=True)
 if r.returncode:
  for remaining in steps[steps.index(s)+1:]:remaining.update(status='not_run',reason='prior step failed')
  save();raise SystemExit(r.returncode)

plan['source_after']=source_snapshot()
assert {k:v for k,v in plan['source_after'].items() if k!='utc'}=={k:v for k,v in initial_source.items() if k!='utc'}
save()
