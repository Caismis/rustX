# d22ce66 publication / bounded read 独立诊断

本报告只复算本轮 fresh `profile-{baseline,complete}-live-large-{cpu,control}` 四个产品。它们实际 case 是 **short-large，history 64，measured 32，live-subscriber**，不是所有大历史场景。baseline 为上一轮 `f5cf22a8` 的 O3 SHA `8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7`；candidate 为 `d22ce66c5a1cda895cac382ce2c350f345933876`，O3 SHA `775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb`。根代理报告最终 checks-retry7 为 2,083 passed、1 ignored；此处不代替其检查身份审计。正式矩阵及最终 strict audit 尚未完成。

复算入口是 `publication-profile-recount-d22ce66-v2.py`，结果为同名 `.json`。它独立解析原始 gperftools CPU binary 记录并核对 `cpu-counts.json` 的总数、间隔与 raw SHA；解析 retained collapsed stacks，每个样本在同一互斥表中只分配一次，保留每行归属及输入 hash。没有重新符号化 PC，没有验证当时运行的外部 binary，也没有运行产品/构建。原始 v1 脚本/JSON 保留：v1 漏识别 free function `host::commit_display` 的来源归属，v2 已纠正；以下仅使用 v2，其他主桶数字不受这项修正影响。

复现时给新的输出路径，脚本拒绝覆盖现有文件：

```sh
python3 publication-profile-recount-d22ce66-v2.py --root EXTRACTED_ROOT --output /tmp/publication-recount-new.json
```

## 1. 总量与观察边界

| 产品 | 32 turn mean settled wall (ms/turn) | measured phase self CPU 原始 ticks | measured consumer notifications |
| --- | ---: | ---: | ---: |
| baseline + CPU profiler | 24.585531 | 108 | 449 |
| candidate + CPU profiler | 22.561781 | 104 | 418 |
| baseline 无 profiler control | 22.547250 | 98 | 449 |
| candidate 无 profiler control | 22.377531 | 104 | 417 |

ticks 是最后 measured sample 减最后 history sample 的 `/proc/stat` utime+stime；100 Hz 惯例下 1 tick=10 ms，但原始 ticks 为主，避免将粗粒度单样本当精确每 turn CPU。notifications 同样用两个累积边界相减，是消费记录数，**不是** publication、read refresh、cache miss 或 capture 调用次数。

CPU profile raw total 为 **268 → 258 samples**，均 4,000 µs 采样间隔；raw hashes 分别为 `a56022128cb802ac4a1b0a3464af81edbed40390f8368405db7ab653eae11fd2` 和 `50b7206120e1690eef5763eb13aab054aa732f70dc4407ba56c7e37a700fb557`。它们覆盖 measured phase 的产品线程及 in-process driver，包括阶段/计数器采集开销。

profile 中 CPU ticks 降低，但 control 中是 98→104 的反向结果；control wall 接近。此组不能建立总体 CPU 改善，不能据 profile 中 publication 比重上升断言实际回退，也不能用它覆盖 screen 的 small CPU 上升。原始 adverse 信号全部保留，正式重复矩阵才能判断完整场景结果。

## 2. PublicationDraft::encode 的互斥桶

| 采样落点 | fresh baseline | candidate |
| --- | ---: | ---: |
| encode 总计 | 54 | 61 |
| 实际 capture_checkpoint 函数帧 | 20 | 29 |
| exact structural length envelope | 32 | 26 |
| fit_checkpoint | 0 | 0 |
| encode 其他 | 2 | 6 |

这里精确匹配函数帧，排除 drop/closure 泛型参数中仅仅出现 `capture_checkpoint` 名字的栈；简单 substring 会误把 baseline 算成 22，candidate 算成 32。fit 没被采到不证明没有调用。`capture_checkpoint` 也不等于完整 snapshot materialization：其主要路径借用 prepared body，并返回必要时才调用的构造 closure（`projection.rs:869`、`:1034`）；普通 delta 在 `:556` 可不实例化 snapshot，fit/replacement 才在 `:561`/`:610` 实例化。

capture 进一步互斥划分：

| capture 子项 | baseline | candidate |
| --- | ---: | ---: |
| transcript entries PreparedCapture 初始化 | 4 | 8 |
| messages PreparedCapture 初始化 | 0 | 3 |
| statistics PreparedCapture 初始化 | 1 | 1 |
| attempt capture | 4 | 7 |
| 可见 budget/preflight | 1 | 4 |
| prepared 非初始化或符号未展开 | 2 | 2 |
| 其他或内联 | 8 | 4 |
| 合计 | 20 | 29 |

初始化栈证明本次确实发生过这些域的构造，但 8 不等于 8 次重建，也不证明先前 transcript rows 复用失效。每 turn 本来新增 transcript 内容，完整 read refresh 还会重新装饰内容；这份采样没有 owner revision/命中次数计数。不能从这些数字恢复准确调用频次。

exact length 互斥划分为 metadata **16→11**、其他 event/envelope **16→15**；两组该 envelope 都没有采到可见 `preflight::Check`。candidate 的 schema `resolve` 出现在其中 8 samples（baseline 2），是嵌套 inclusive，不能再次相加。可见 `RuntimeClientCheckpoint` serialization 6→2 同样是其中子集：存在需要 replacement 的路径，不是每个 delta 重建全 checkpoint 的证据。

按 encode 祖先归属互斥分为 read-worker `host::commit_display` **22→35**、native_batch **12→13**、其他/内联 **20→13**。与 notifications 449→418 一起看，publication 混合和调度确有变化；不能把少约一条/turn 的通知直接换算为少多少 publication CPU。

## 3. freeze、SQL、read 的具体结果

seed freeze 单独统计，不加入 encode：**8→9**。其中显式 snapshot clone **7→6**；baseline 七个 clone 样本全部落在 raw CapabilityView→ToolDefinition/JSON 链，candidate 该链为 **0**。candidate 六个 snapshot clone 样本是 message descriptors 3、transcript page 1、context 1、未展开 1；另有 equality/inheritance visitor 1 和其他 seed 2。源码 Arc 共享与回归已经证明未变 capability 不深复制，这份采样与之相符，但它没有证明 freeze 总成本下降或其他 clone 不重要。

单独 inclusive 视图：SQL prepare **11→2**；ReadDomainCut **33→34**；request layout indexing **14→19**；composed nodes Capture::ensure **10→9**。最后一项递归会让一个样本包含多个 ensure 帧，逐帧相加可误报 76/68，不能这样累计。这里每条 stack 最多计算一次。indexing 的 adverse 采样也保留，不能因为删了 Fact.header 就先声称整个 indexing CPU 已降低。

完整互斥表使用“encode、seed、read-domain 优先，之后 SQLite、其他 runtime-client、剩余”的顺序：

| 互斥 owner | baseline | candidate |
| --- | ---: | ---: |
| publication encode | 54 | 61 |
| seed freeze | 8 | 9 |
| read-domain | 33 | 34 |
| 上述之外的 SQLite step/prepare | 52 | 42 |
| 其他 runtime-client | 41 | 41 |
| 其余 | 80 | 71 |
| 总计 | 268 | 258 |

它只是防止重叠相加的粗分，不是完整 native 操作级成本拆解。

## 4. response read 的重复到底在哪里

ReadDomainCut 内部互斥分为 response **21→23**、transcript **12→9**、其他 **0→2**。因此候选 23/258 的主要具体读路径是 `observation_response::read_validated`，不是笼统“所有 SQLite 读取”。

`observation_checkpoint.rs:15` 每次读取整个有界 transcript head，`:28` 对其 selections 再装饰 response。`observation_response.rs:72` 每次新建 Reader，其 executions/members/processes/responses/fields 六个 map 仅在这一次调用内有效。已经完成、仍在最近 32 项 head 中的同一历史 owner，在下次刷新仍会经历：

1. 每个 selection 的 T→native ledger 查询（`:171`），从 observation header 再提取 role（`:183`），工具 result/proposal 关系（`:185`）。注意 `observation::transcript` 刚在 `:750`/`:797` 读取并解码了 header；其中正常未损坏消息的 role 确实是重复读取/JSON 提取。
2. assistant ledger→member anchor，以及新 cut 下该 anchor 的最新 member sequence（`:155`、`:157`）；继承关系查询（`:199`）。user/process selections 也进入 owner；不能简单认为“非 assistant 不需要查”，因为原实现还验证 alias/Tool 等边界。
3. 读取 execution layout、查 prefix holes、选择 cut 内最新 execution layout（`observation_execution.rs:112`、`:124`–`:134`），读取 member bytes 并解码（`observation_response.rs:113`、`:131`）。Reader 内已做同一次 page 的 owner 去重，所以并非同一 page 的每个 item 都重复完整解码；重复主要跨刷新发生。
4. 已完成 response 的 closing canonical locator、first append revision（`:233`），retry request 的 start 认证与 retry ledger/header（`:250`），最终 message id→position 匹配（`:419`）。models/identity fields 仍有各自条件与来源。

普通完成的历史 request/response 经常没有改变，重复构造并非每次都在表达新的事实。与此同时 current cut 的 latest-owner 选择、全 prefix holes、历史 canonical locator 与同连接/外部真实存储变更仍影响合法性，不能不区分地删除这整个读取链。

### 与此前被拒绝 read-cache trial 的区别

`docs/pi-durable-cost-model/2026-10-27-performance.md:134` 的 C trial 只将 22 个 query call sites / 18 条 SQL 改用 prepared statement reuse，保留相同读取/解码次数；并非复用上次 response 结果或已完成 owner。其 adverse 多场景结果仍有效，但不证明“按 immutable owner 消除重复读/算”无收益。此次 prepare 只剩 2 个样本，也说明继续仅扩大 statement cache 不是这 23 个 response 样本的主要解法。

### 有明确可复用事实，但尚无证明完成的小型跨刷新跳读方案

小范围、最容易保持现有错误合同的入口是 **同一次 aggregate read transaction 内携带已验证的 transcript/native facts**：正常消息的 decoded role/header、native T→L 映射、message-id 对应位置在后续 owner/closing-locator 检查重复查询。可以在读取 transcript 的同一 snapshot 中保留 private evidence sidecar，后续在证明其与原 native 查询选中同一 row 时复用。这样删除重复查询/JSON 提取，不必引入跨 cut cache 或额外主库写入。

但不能直接拿 display header 的 ledger/role 当 native ledger authority：当前 transcript 只验证 header 内 ledger 与选中 h.ledger 相等（`observation.rs:799`），response 还独立从 `message_ledger.native_transcript` 找位置，两个 owner 可能在损坏测试中不一致。合法实现必须保留这种错位/alias 时的原匹配与错误顺序；对 source 不确定的页保留真实 native 查询，是当前合同的必要分支，不是旧格式兼容层。该方向当前只证明重复的数据来源，尚未测量收益，亦不能声称消掉全部 23 个样本。

跨刷新沿 Pi commit→adopt 共享 immutable response artifact 是更大的实际机会：终态 owner 的已解码 execution/member/CompletedResponseView 不必因无关新 attempt 重新构造。然而不能仅以 T cursor、completed flag 或 terminal sequence 为 cache validity。新 J cut 可选择更新的同 owner source，prefix hole 会影响旧页；旧 bytes 被同连接 UPDATE、触发器、DELETE 或外部写入改变时，原 reader 必须拒绝/重读。现有 `append_validation::Owner` 只监控 canonical identity 与投影相关表（`append_validation.rs:93`），并不覆盖 response 的 events/header/tool/inherited/request 依赖，不能直接当这份 cache 的通用证书。

要跳过这些真实读取，必须明确证明 owner 内容与依赖在当前 pinned transaction 未变，或在 native commit/adopt 时携带并维护完整 owner 变更与失效；缓存限定在 bounded head、保留旧 cut、未完成 owner 的进展、错误顺序和 native mutation 检测。源码尚没有这份完整证明。此报告因此把它列为有源依据的结构冗余，而不是宣传所有读都必要，也不将一个未经实现验证的广泛 invalidation 系统说成安全小修。

## 5. 本轮结论与优先级

本轮数据确认旧 capability 深 clone 已不出现在新采样链中，prepare 剩余也较小；同时 encode 总样本和 response 读取仍显著。下一处应优先验证的是已完成历史 response owner 的重复读取/装饰，再是 exact structural length 内的 schema/metadata 重复工作；二者都比继续微调 2 个 prepare 样本更有依据。transcript entries 初始化也仍有实际采样，需把真实内容变化与 cut-only 变化区分，不能由样本数认定缓存命中率。

不会以此单组作为“已追平 Pi”或“所有优化完成”的证据，也不会因 control CPU 不利就擅自重改正在正式测量的冻结源码。要保留 small screen 的不利结果及后续独立 small 诊断；最终收益由全矩阵、CPU/wall/write/PSS 与严格身份审计共同给出。
