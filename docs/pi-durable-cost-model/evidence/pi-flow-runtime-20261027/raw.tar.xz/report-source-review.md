# Pi-flow 本轮源码与语义复核（性能数据尚未回填）

本稿针对 `/home/capi/.codex/worktrees/pr485-pi-performance/rustX` 当前冻结源码，比较上一轮 complete-costs 的 `f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20`（schema 79）与本轮 schema 80。行号对应本稿检查时的工作树。根代理正在执行 `checks-retry6`；本稿不将此前 probe、失败队列或局部通过视为最终验证，也不预先声称本轮性能提升、Pi parity 或全部冗余已经消除。未运行构建、产品、基准或修改仓库源码。

上轮已经实现的 metadata-first/lazy checkpoint、完整 ModelTurnSettlement family、按 transcript rows 复用，仍是当前基础，不重复计算为本轮新增成果。本轮新增的是进程内安装进度的正确生命周期、流首次写入合并、固定首轮 admission family、原始 capability owner 共享、普通字段预览按需构造，以及相关验证/SQL/索引改动。

## 1. Pi Durable 的实际参照是 commit → adopt → publish

参照 checkout `/home/capi/Documents/codes/pi-rustx-benchmark` 的提交是 `90d863f7c1183b965f099855715d6e88c7b8a52c`。

- `packages/durable/src/session/session.ts:103` 说明 mutation line 覆盖准备、Storage settlement、adoption 和 publication enqueue，监听器在后面执行；`:724` 等待 `storage.commit`，`:732` 执行 `tx.adopt(seq)`，`:739` 发布。adopt 失败时，durable state 已提交，当前 Session 失败并关闭；重开从 committed state 恢复（`:106`、`:734`）。它没有为了持久记录“内存已经安装完成”再提交一份数据库 ready 状态。
- `packages/durable/src/storage/sqlite/storage.ts:187` 将一批 StorageWrite 放在一次数据库事务中，事务内仍做身份/文档验证；`node.ts:144` 使用串行 `BEGIN IMMEDIATE`/`COMMIT`，`:194` 使用 WAL/NORMAL。Pi 不是没有验证或没有持久写入。
- 不应以 `packages/coding-agent/src/core/session-manager.ts` 的 JSONL 路径解释本次 Pi Durable SQLite 基准；它是另一条产品路径。本轮参照的是上面已核实的 durable Session。

rustX 本轮采用其中的生命周期原则：已经提交的原生事实是重开后的 authority，当前实例是否已经安装/直接发布是实例内状态。rustX 仍保留自己的 typed receipt、独立 owner、历史 cut、分页、ContentRef 与失败隔离，不能据此宣称两者功能或每个提交边界完全相同。

## 2. readiness/direct 从主库持久表迁到连接内 TEMP epoch

实现入口为 `src/durable/sqlite/observation_readiness.rs:8`。`PRAGMA temp_store=MEMORY` 后创建 TEMP epoch、J readiness/direct、T readiness 表及 holes 索引；epoch 初值直接读取 `rustx_store` 当前 J/T head（`:11`），没有按历史长度回填 readiness 行。`sqlite.rs:884` 在 owner 连接初始化时安装这些对象。

安装后的 release 路径 `sqlite.rs:5305` 在 Deferred 事务中调用 TEMP `mark_canonical`、`mark_transcript`、`mark_direct`（`:5350`、`:5362`），提交后才唤醒一次观察者（`:5369`）。这些 release 更新不再修改主库页或其 WAL。它们仍执行 SQL、查验证据、持有连接锁并提交 TEMP 事务；不能写成“发布完成后完全没有事务/CPU”。native append 自身的主库写入与 `observation_readiness_missing` 证据也仍存在。

当前 epoch 的语义保留：

- 只有完整 receipt 成功安装后才 release；RuntimeObserver 安装失败或缺 receipt 均调用 `source_failed`，没有按单事件放行的替代分支（`runtime/conversation_runtime.rs:7430`、`:7575`）。
- indexed holes 保留精确乱序与不同 owner 的阻塞边界，而不是只使用一个 high-water mark（`observation_readiness.rs:123`、`:209`）。
- TEMP trigger 随主库 source 删除移除对应 TEMP 行，并与 source 删除处于同一事务，rollback 一起恢复（`:31`）。
- 共享同一个 ConnectionOwner 的读者看到同一 epoch；另开 SQLite 连接拥有自己的 TEMP 基线，不会读取旧连接内的 direct claims。

明确的持久性取舍：新连接或重新安装 Journal owner 时，已提交历史直接成为 committed baseline。`recover_journal`/`recover_transcript` 只更新基线并清本 epoch TEMP 行（`:60`、`:155`）。旧进程是否完成内存安装/通知不再持久恢复，旧 direct 也不会被继承。当前 epoch 的 durable append-missing 检测只作用于 baseline 之后。因此不能宣传所有旧的恢复/损坏行为完全不变；这是有意采用 Pi commit-then-adopt 原则的行为变更。

内存不是固定 32 项：TEMP 行规模是当前 epoch 新增 J+T 的 O(J+T)，随 owner 重建清理；没有实现按所有 reader frontier 逐项回收。诊断中的独立连接主库列字节统计看不到 TEMP，不能把“不可见”填成零内存；需要结合实际 PSS。`native_readiness_tests.rs:51`、`:93`、`:161`、`:207`、`:236` 分别覆盖 release/WAL、失败回滚、重开零回填、source 删除回滚与另一 owner 的洞。这些是应由最终队列验收的合同证据。

## 3. 流只在首次实际持久输出/结算时入库

`agent/execution.rs:5572` 的 `open_publication` 现在只固定 attempt/turn/request/message identity、建立 coalescer 并通知内存观察者，没有独立的 stream-open 数据库事务。`sqlite.rs:11975` 的 `ensure_publication_stream_tx` 在已有调用者事务内验证 exact started request generation，或确认已有 stream 完全相同。

- 首次 frame staging：`sqlite.rs:5680` 在同一事务里 admission + frames，commit 后才返回 receipts。
- terminal/audit：`final_settlement.rs:19`、`sqlite.rs:5786` 在各自结算事务里 admission；正常完整模型结算也在其原子事务里调用 helper（`final_settlement.rs:331`）。
- opening 回调本身不意味着 SQLite 中已存在 stream。没有任何持久 frame 或结算、随即进程死亡的 request，不再因一条空 open row 被恢复为 empty-stream audit。原始 started request 与其恢复义务仍由 request/event authority 处理，不能称为“丢失已释放输出”。
- 已持久输出仍有原来的 generation、sequence、terminal、ContentRef 和 audit/canonical 互斥约束；首次 frame 失败会回滚 admission 与所有同批源，而不是留下孤立 open row。

对应回归在 `tests/durable/publication.rs:4461`（首写失败）、`:4514`（foreign generation）、`:4575`（首次 audit 回滚）和 `:4625`（未发布 request 的重开语义）。这些明确说明此次删除的是无独立事实价值的提前 stream-open 写入，不是关闭持久 staging。

## 4. 普通 Fact.header 镜像删除，原始 authority 与 bounded navigation 保留

普通 `Fact` 现在只存八个 geometry/key 字段，path/parent/ordinal 仍由 F/C 索引键拥有（`observation_request/composed.rs:166`）。`composed/fragments.rs:99` 改走 `visit_field_geometry`，不为每个普通字段提前生成并持久化 header。对于每个最大、尚未验证的 ≤16 KiB 子树，仍调用 `original_node_count` 检查原始 JSON 数值、语法和 serde 深度（`:124`），其后代复用该证明。它不是简单跳过输入校验。

读取时 `composed/read.rs:408` 先认证选中字段；普通字段复用既有 `preview`（`:338`），最后仍使用 `bounded_bytes(...,16384)` 生成原有规范化 JSON header。超正常预览预算是 `null`，原始字节/索引损坏则是 Storage 错误，二者没有混淆。

保持的细节：

- `Template.header_prefix/header_suffix` 仍保留（`composed.rs:94`），其 raw-message descriptor 语义不同于普通子树；读取的 template override 仍优先（`read.rs:420`）。
- synthetic `$key` 的 header 仍是空字符串，先认证 F，再返回 `""`；真实 encoded key 仍可按原 range 读取（`:422`）。
- 原始 JSON 数字文本、opaque u64、负零、重复 alias/大键、deferred 与历史 cut 的原始范围没有改成重新序列化结果；header 继续使用旧的规范化预览规则。
- F/C/raw byte-tree 的 hash、有限深度与单页字节限制保留（`composed/index.rs:72`、`:82`）。新 codec 不接受旧九字段 Fact，没有兼容分支。

损坏行为确实改变：原来普通 header 的独立镜像可能在另一份 raw byte page 损坏时仍可读取；现在普通 field/page 预览需要的 raw page 损坏会显式失败。不会悄悄重建全源或返回 null。native request reconstruction、原生 Journal/Canonical 不依赖这份 display raw tree，其读取仍可成功。`composed/scalar_tests.rs:582` 用真实已提交的坏 byte 页、随后恢复原 bytes，验证这一差异与 native/历史 cut 的独立性。

计算从每次写入移到真正 inspection 时发生。预览仍有界，但 **16 KiB 是单个完整子树/最终 header 的边界，不是一次预览总读取量的上限**；递归有 32 节点预算，分页又可请求多个字段。因此本稿只断言去掉 writer 预览构造和镜像存储，不预判 inspection latency 或总体 CPU 一定改善。独立 eager 旧预览 oracle、raw chunk hash 与 work counter 回归用于验证等价输出及 writer 不再计算预览。

## 5. capability 原始 header 用不可变 Arc 共享

`runtime_client/snapshot.rs:267` 将 capabilities 置于 `Arc<CapabilityView>`；`projection.rs:6636` 冻结 snapshot 时，只增加其引用，不再深复制未变的工具说明/JSON。能力或资源更新才替换 Arc（`:3809`、`:3856`）。这不是把所有 snapshot 字段都改成共享，也不是消除 seed freeze。

raw capability header 与规范化 checkpoint head 继续分离。不能拿后者替代前者，否则超预算/无效但可分页的原始条目、偏移与历史 capability cut 会丢失。Arc 本身不进入 wire/schema，过去的 seed 保留旧 owner。`projection/capability_owner_tests.rs:111`、`:185`、`:280` 分别验证未变 owner 共享、replacement 后历史原始分页/预算边界、schema/wire 与副本隔离。

## 6. AttemptStarted + 首个 TurnStarted 是固定原子 family

`sqlite/attempt_start.rs:9` 仅接受同一 attempt 的 AttemptStarted 和 TurnStarted("1")，按原序持久化两个事件，构造一个共同 receipt，在一次事务中提交（`:31`、`:39`、`:43`、`:51`）。不是任意增长事件数组。`agent/execution.rs:1687` 在 commit 成功后仍按 Attempt→Turn 依次调用原事件观察者；后续 continuation 仍是单 Turn。

RuntimeObserver 对非最终成员不安装、不 release；最终 Turn 回调才将整个 family 安装一次（`conversation_runtime.rs:7436`）。projection 仍依次折叠两 witness，然后作为一个 publication 处理（`projection.rs:4538`）。缺 receipt 或安装失败均保持当前 epoch 未 ready，不允许 worker 发布半个 family。

这有意改变一个中间可见性：Attempt 回调时，存储中 Turn 也已提交；旧的“只有 Attempt 已提交”的正常首轮前缀消失。两个公共事件本身及顺序仍在。预取消/首轮前置失败没有 Turn，仍提交单 Attempt 后 terminal（`execution.rs:1488`、`:1566`）；原来的模型请求开始前取消仲裁继续执行（`:1713`）。提交前或事务中进程死亡看不到半对，提交后的任一 after-event hook 都看到完整一对（`attempt_start.rs:54`）。

检验包括 `attempt_start_tests.rs:22`/`:74`/`:91` 的一次提交、第二成员失败回滚、坏证据隔离；`execution_attempt_start_tests.rs:2`/`:40` 的预取消/观察者/provider 约束；`runtime/conversation_runtime/native_readiness_tests.rs:127` 的最终成员门控；`projection/attempt_first_turn_tests.rs:5` 的旧 cut/单 cursor/worker 去重；`tests/boundary/durable/process_death/conformance.rs:565` 的真实进程死亡边界。

## 7. request 验证复用减少重复解码，但不是零计算

`native_request.rs:240` 用 borrowed configuration 序列化，`:162` 在 SQLite 内对真实存储 cell 做 type/length/byte equality；没有把完整配置为了比较又搬回应用层。`:190` 的 Validation 只在同一事务生命周期内共享已解码 RequestSnapshot Arc；每次复用仍比较 metadata 与真实配置 bytes（`:215`）。变化则重新进行 bounded/digest/typed 认证（`:221`），防止 coherently rehashed 非法类型继承旧证明。

配置跨请求持久共享本来就存在；本轮不能写成第一次消除了所有配置重复存储。当前每个 fresh request 仍需序列化配置并计算 digest（`:244`、`:252`），SQLite equality 仍遍历 bytes，不同事务的首次读取仍需验证/解码。这是源码确认的剩余工作，尚不能从源码量级直接推断它在新 profile 中的占比。

## 8. 剩余成本：应按新样本定位，不能说“checkpoint 每次完整重建”

| 当前确实存在的工作 | 原因、已减少部分与可优化边界 |
| --- | --- |
| `PublicationDraft::encode` 的 exact structural length，`projection.rs:597`、`checkpoint.rs:404` | prepared certificate 省掉可证明的 admission traversal，但仍通过 schema-aware serializer 计 exact wire bytes（`:425`）。它控制有限 transition/replay byte budget；native u64、opaque JSON、字段省略与错误规则不允许直接假设普通 serde JSON 等价。可以研究 immutable metadata/body 的 exact-length 组合，但当前没有完成的安全通用替换。 |
| metadata/evidence 再装配与预算，`projection.rs:1020`、`:1260` | 需要把当前 revision、read cut、collection frontier、ContentRef authority 绑定到共享 body。复用 body 不等于 metadata 也不变。新样本若显示未变 metadata 是主要成本，应按 owner 与变动 envelope 拆分，而不是每次构造 JSON/hash witness 证明自己没变。 |
| `capture_working_seed`，`projection.rs:6623` | capability 本轮已共享；snapshot 其他值和 head_bindings/frontiers/content_metadata 等仍复制以冻结历史。共享所有域需调整各 mutation owner 和历史 cut，不是可以直接删除 clone。当前不能声称 freeze 已零成本。 |
| 有限请求 inspection tree | 删除普通 header 镜像后仍保留 byte chunks/F/C/roots，服务原始字节范围、任意字段定位、历史 cut 与有界首次读取。整树改为首次 inspection 构造会把完整源扫描塞进首次读取，不符合当前 bounded read 合同；不能把余下表一概当可删冗余。 |
| native/source 认证、固定域读取与 SQL | prepared statements 与 aggregate read 已减少部分准备/事务；请求配置与原生 witness 的实际 bytes 认证仍在。只凭旧 prepare/read 样本不能断言新最大热点仍相同。 |
| TEMP release | 主库 WAL 已移除，但 exact holes、连接锁、SQL、事务与唤醒仍执行；epoch 行内存增长也需实测观察。 |

`capture_checkpoint` 的函数名尤其容易误读：`projection.rs:869` 返回借用 prepared body 的 closure，`:1034` 才是实际 snapshot 构造。普通可认证 delta 在 `:556` 不调用它；fit、eviction、显式 replacement 或 transition 无法入场才在 `:561`/`:610` 构造。采到 capture 函数不能等同于完整 checkpoint 重建；在 replacement/fit 采到构造也不能证明 lazy 失效。

新归因使用本目录 `publication-profile-method.md`：保留 raw sample counts，encode 内划分互斥桶，freeze 另计，normal/control 的实际 wall/CPU 分开，通知条数只作为 consumer traffic；不由采样数推断调用次数/命中率。不以之前 223 或 312 样本的百分比冒充本轮结果。

## 结论边界

本轮落地的是可定位的重复持久镜像、无独立事实的提前提交、重复的内存 owner 复制与固定同一事务 family 的重复发布。它没有删掉历史请求检查、原始字节、分页、cut 或 native receipt，也并非完全无语义变化：连接 epoch 重开基线、未输出流不留空 audit、普通预览对 raw page 损坏的依赖、首次 Attempt/Turn 原子可见性都必须随结果报告保留。最终是否缩小 Pi 差距、哪一项成为新大头，只能在最终正确性队列和独立新 profile/正式矩阵完成后填写。
