#!/usr/bin/env python3
"""Read completed supplemental profiles and small-history screen/direct raw records only."""
import collections
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import statistics
import sys
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def module(name, digest=None):
    path = ROOT / name
    require(digest is None or sha(path) == digest, 'changed analysis dependency')
    spec = importlib.util.spec_from_file_location(name.replace('-', '_'), path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


SMALL = module('audit-small-profiles.py')
DIAG, FORMAL = SMALL.dependencies()
PUBLICATION = module('publication-profile-recount-d22ce66-v2.py', 'c1deff864bf61e35d1773fc0394fce2486397985bd72bfb5f4129057e3fca7d9')
POLICY = ('harness_sampling', 'readiness', 'request_layout_index', 'native_configuration',
          'publication_encode', 'seed_freeze', 'read_domain', 'sqlite_other', 'runtime_client_other', 'other')
METRICS = ('median_measured_turn_ms', 'mean_turn_ms', 'turn_cpu_ms_per_turn',
           'through_cleanup_self_cpu_ms', 'through_cleanup_process_write_bytes')


def profile(directory, reported):
    publication = PUBLICATION.profile(directory, reported)
    totals, inclusive, concrete, leaves = (collections.Counter() for _ in range(4))
    assignments = []
    for line, row in enumerate((directory / 'steady-collapsed.txt').read_text().splitlines(), 1):
        stack, value = row.rsplit(' ', 1)
        weight = int(value)
        frames = [PUBLICATION.frame(frame) for frame in stack.split(';')]
        starts = lambda prefix: any(frame.startswith(prefix) for frame in frames)
        markers = {
            'harness_sampling': any(starts('conformance::agent_loop::runtime_benchmark::' + name)
                                    for name in ('process_sample', 'lifecycle_sample', 'footprint', 'profiling::')),
            'readiness': starts('rustx::durable::sqlite::observation_readiness::') or
                         any(frame in frames for frame in (
                         '<rustx::durable::sqlite::SqliteConversationStore as rustx::durable::inbox::ConversationStore>::mark_native_observation_ready',
                         '<rustx::durable::sqlite::SqliteConversationStore as rustx::durable::inbox::ConversationStore>::mark_observation_transcript_ready')),
            'request_layout_index': starts('rustx::durable::sqlite::index_request_read_layouts'),
            'native_configuration': starts('rustx::durable::sqlite::native_request::'),
            'publication_encode': PUBLICATION.ENCODE in frames,
            'seed_freeze': PUBLICATION.SEED in frames,
            'read_domain': PUBLICATION.READ in frames,
            'sqlite_other': starts('sqlite3'),
            'runtime_client_other': starts(('rustx::runtime_client::', '<rustx::runtime_client::')),
        }
        owner = next((key for key in POLICY if markers.get(key)), 'other')
        totals[owner] += weight
        assignments.append({'collapsed_line': line, 'samples': weight, 'owner': owner})
        exact = {
            'sql_prepare': 'sqlite3Prepare' in frames or 'sqlite3LockAndPrepare' in frames,
            'sqlite_vm': 'sqlite3VdbeExec' in frames,
            'request_preview_display': starts('rustx::durable::sqlite::observation_request::composed::fragments::display'),
            'request_geometry_capture': starts('rustx::durable::sqlite::observation_request::composed::nodes::capture'),
            'request_source_range': starts('rustx::durable::sqlite::observation_request::composed::read::range'),
            **{key: value for key, value in markers.items() if key != 'sqlite_other'},
        }
        for key, present in exact.items():
            if present:
                inclusive[key] += weight
        for frame in set(frames):
            if frame.startswith('rustx::durable::sqlite::observation_readiness::'):
                concrete[frame] += weight
        leaves[frames[-1]] += weight
    total = publication['raw']['samples']
    require(sum(totals.values()) == sum(row['samples'] for row in assignments) == total, 'exclusive buckets do not sum to raw PC count')
    return {'raw': publication['raw'], 'collapsed_sha256': publication['collapsed_sha256'],
            'exclusive_counts': {key: totals[key] for key in POLICY}, 'inclusive_counts': dict(inclusive),
            'concrete_readiness_inclusive': dict(concrete), 'top_flat': leaves.most_common(20),
            'publication_exclusive': publication['publication_exclusive'],
            'seed_exclusive': publication['seed_exclusive'], 'read_domain_exclusive': publication['read_domain_exclusive'],
            'stack_assignments': assignments}


def cohort(relative, pairs, mode, identities):
    directory = ROOT / relative
    manifest = load(directory / 'manifest.json')
    require(manifest['head'] == SMALL.HEAD and manifest['pairs'] == pairs and manifest['clock_ticks'] == 100
            and manifest['observer_mode'] == mode and manifest['comparison_kind'] == 'production-revision', 'small comparison identity differs')
    require(manifest['executables'] == {engine: {'path': build['binary'], 'sha256': build['sha256']}
                                       for engine, build in [('before', identities['baseline']), ('after', identities['complete'])]},
            'small comparison binaries differ')
    rows, products = [], []
    for pair in range(pairs):
        values = {}
        for engine, schema in [('before', 79), ('after', 80)]:
            stem = f'{pair}-short-small-{engine}'
            raw, proc = load(directory / (stem + '.json')), load(directory / (stem + '.process.json'))
            require(raw['schema'] == schema, 'small comparison schema differs')
            derived = FORMAL.derived_product(raw, proc, 'short-small', mode, engine, manifest)
            values[engine] = {key: derived['metrics'][key] for key in METRICS}
            products.append({'pair': pair, 'engine': engine, 'metrics': values[engine],
                             'raw_sha256': sha(directory / (stem + '.json')), 'process_sha256': sha(directory / (stem + '.process.json'))})
        comparison = directory / f'{pair}-short-small-comparison.json'
        require(FORMAL.comparison(comparison, 'short-small', mode, True) == 40, 'small request comparison count differs')
        rows.append({'pair': pair, 'comparison_sha256': sha(comparison),
                     'percent_changes': {key: 100 * (values['after'][key] / values['before'][key] - 1) for key in METRICS}})
    return {'directory': relative, 'pairs': pairs, 'manifest_sha256': sha(directory / 'manifest.json'),
            'products': products, 'paired': rows,
            'summary': {key: {'median': statistics.median(row['percent_changes'][key] for row in rows),
                              'minimum': min(row['percent_changes'][key] for row in rows),
                              'maximum': max(row['percent_changes'][key] for row in rows),
                              'candidate_higher_pairs': [row['pair'] for row in rows if row['percent_changes'][key] > 0]}
                        for key in METRICS}}


def table(headers, rows):
    return '\n'.join(['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |',
                     *('| ' + ' | '.join(str(cell) for cell in row) + ' |' for row in rows)])


def render(result):
    byname = {row['name']: row for row in result['products']}
    activity = []
    for row in result['products']:
        value = row['product']
        activity.append([row['name'], f"{value['mean_measured_turn_ms']:.3f}",
                         value['measured_phase_self_cpu_ms_at_100hz'], value['full_self_cpu_ms_at_100hz'],
                         value['measured_phase_process_write_bytes'], row.get('profile', {}).get('raw', {}).get('samples', '—')])
    attribution = []
    names = ['baseline-no-live-cpu', 'complete-no-live-cpu', 'baseline-live-cpu', 'complete-live-cpu']
    for key in POLICY:
        attribution.append([key, *(byname[name]['profile']['exclusive_counts'][key] for name in names)])
    metrics = []
    for mode in ('no-live', 'live'):
        for key in METRICS:
            screen, direct = result['comparisons'][mode]['screen']['summary'][key], result['comparisons'][mode]['direct']['summary'][key]
            metrics.append([mode, key, f"{screen['median']:+.2f}%", f"{direct['median']:+.2f}% [{direct['minimum']:+.2f},{direct['maximum']:+.2f}]",
                            ', '.join(map(str, direct['candidate_higher_pairs'])) or '无'])
    return f'''# 小历史补充诊断：screen 回退未成为稳定的实现回退证据

固定基线为 schema79 / `{result['identities']['baseline']['head']}` / SHA256 `{result['identities']['baseline']['sha256']}`；候选为 schema80 / `{SMALL.HEAD}` / SHA256 `{SMALL.SHA}`。同一 O3/default features、同一 harness，全部 short-small，8 history +32 measured turns。补充审计 `supplemental-small-profiles/audit.json` accepted strict，SHA256 `{result['supplemental_audit_sha256']}`。

八个补充产品是发现 screen 回退后的探索性诊断，各 revision × observer × control/CPU 只有一个产品，独立保留，不加入原18 canonical诊断或276正式矩阵。以下 screen/direct 对照只复算已完成的 short-small 子集，不声明尚未完成的整轮 final 严格审计已通过。保留全部 adverse pair，未筛选结果。

## 单个 control 与 CPU 产品

{table(['产品', 'measured turn mean ms', 'measured self CPU ms', 'through-cleanup self CPU ms', 'measured process write B', '250Hz raw samples'], activity)}

候选 no-live control→profile 的 measured CPU 为400→700ms，live为1000→630ms，方向相反。基线对应750→790ms和1230→1250ms。单对独立运行不能把这些差值视为固定 profiler overhead，也不能用诊断耗时取代正式结果。/proc CPU按100 ticks/s换算，累计端点粒度10ms；raw signal采样为250Hz，每样本名义4ms，两者是不同计数。

## 与 screen/direct 的关系

{table(['observer', '指标', 'screen单对变化', 'direct五对变化中位[min,max]', 'direct回退pair(0起)'], metrics)}

screen no-live 的CPU/turn +36.73%来自15.3125→20.9375ms；正式direct基线本身变为22.8125–26.25ms，候选18.4375–22.1875ms，五对全部改善。live五对仍有pair3/4回退，CPU/turn分别+49.30%/+17.20%；不能把中位改善说成每次都改善。两组through-cleanup process writes均稳定减少约29.3%，这与CPU波动分开陈述。

## 原始栈互斥归类

{table(['互斥owner', *names], attribution)}

每条 collapsed 栈按表中优先顺序只分配一次，总计严格等于独立解码的 raw CPU 二进制196/175/312/152样本。脚本保留逐行归类、raw/折叠栈SHA和独立出版分析依赖SHA；真实函数帧去掉末尾地址后匹配，避免把泛型参数里出现的函数名误当调用。不能从该表精确分配未显式呈现的inline路径，inclusive子项另列JSON且不可相加。

## TEMP、四值mask探测、preview的可见边界

- readiness真实owner采样并未显示一致回退；详细mark/insert/frontier函数及整数样本保留JSON。单次几个样本只能证明该路径被执行，不能可靠估计改动的净CPU。候选live确有TEMP insert和内存journal/manifest hook栈，但这不是screen整体回退的因果证明。
- `IN (4,5,6,7)`一类四值mask探测和生成列计算在SQLite VM中执行。CPU栈不能按SQL谓词/opcode拆开；VM与索引路径总样本不是mask专项成本。因此当前证据不能把回退归因于mask，也不能证明其成本为零。需要特定SQL执行计数/VM profile或同功能隔离对照才能做该归因，本次没有。
- request layout真实index采样为no-live18→17、live18→7；旧`fragments::display`在两个基线各1样本，候选均0。新geometry capture在候选有采样，但baseline的capture内部结构不同，不能直接把新函数样本当增量。`preview`字符串还能来自turn/trace/event字段，不能统称为已删除的request写入preview。没有观察到可支撑“大量新增preview成本”的证据。

这里能支持的结论是：screen回退未在两组direct五对中位重现；live仍有两个明显不利配对，全部保留。CPU profile显示了剩余publication/seed/read/layout成本，但不能从一次采样把组合改动的单项因果收益或回退精确拆出。原始证据的语义、reopen和observer校验通过；readiness改为连接epoch、重开采用已提交J/T基线的持久性取舍仍然存在。

复算：`python3 analyze-small-profiles.py`，需输出文件尚不存在。该脚本只读completed supplemental + screen/direct short-small原始数据；不会读取进行中的final队列，不运行产品、构建、profiler或重新符号化。
'''


def main():
    output, markdown = ROOT / 'supplemental-small-analysis.json', ROOT / 'supplemental-small-analysis.md'
    require(not output.exists() and not markdown.exists(), 'preserve prior analyses')
    base = ROOT / 'supplemental-small-profiles'
    audit = load(base / 'audit.json')
    require(audit['accepted'] is True and audit['mode'] == 'strict' and audit['strict_identity_verified'] is True
            and audit['product_count'] == 8 and audit['errors'] == [], 'supplemental strict audit incomplete')
    require(audit['script_sha256'] == sha(ROOT / 'audit-small-profiles.py'), 'supplemental auditor changed')
    builds = {label: load(ROOT / folder / 'identity.json') for label, folder in [('baseline', 'baseline-build'), ('complete', 'candidate-complete-build')]}
    require(builds['complete']['head'] == SMALL.HEAD and builds['complete']['sha256'] == SMALL.SHA, 'candidate changed')
    counts = {row['name']: row for row in load(base / 'cpu-counts.json')}
    products = []
    for original in audit['products']:
        row = dict(original)
        directory = base / row['name']
        require(sha(directory / 'sample.json') == row['product']['sample_sha256']
                and sha(directory / 'sample.process.json') == row['product']['process_sha256'], 'supplement raw changed')
        if row['mode'] == 'cpu':
            row['profile'] = profile(directory, counts[row['name']])
            require(row['profile']['raw']['sha256'] == original['cpu']['raw_sha256'], 'raw CPU differs from strict audit')
        products.append(row)
    comparisons = {label: {'screen': cohort('exploratory-screen/' + label, 1, mode, builds),
                           'direct': cohort('direct-cohorts/direct-' + label, 5, mode, builds)}
                   for label, mode in [('no-live', 'no-live-subscriber'), ('live', 'live-subscriber')]}
    result = {'scope': SMALL.SCOPE, 'analysis_accepted': True, 'formal_final_audit_claimed': False,
              'source': SMALL.HEAD, 'candidate_sha256': SMALL.SHA, 'identities': audit['identities'],
              'supplemental_audit_sha256': sha(base / 'audit.json'), 'script_sha256': sha(Path(__file__)),
              'dependency_sha256': {name: sha(ROOT / name) for name in ('audit-small-profiles.py', 'publication-profile-recount-d22ce66-v2.py')},
              'exclusive_priority': POLICY, 'products': products, 'comparisons': comparisons,
              'limits': ['Single intrusive profile/control per cell; not causal attribution or formal performance estimates.',
                         'Concrete frame matching cannot expose inlined functions or SQL opcode/statement identity.',
                         'Mask/preview/TEMP-specific net CPU regression is not established by these observations.',
                         'Direct analysis covers only completed short-small subset; does not replace complete strict matrix audit.']}
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    markdown.write_text(render(result))
    print(json.dumps({'json': str(output), 'markdown': str(markdown), 'profile_samples': {row['name']: row['profile']['raw']['samples'] for row in products if 'profile' in row}}))


if __name__ == '__main__':
    main()
