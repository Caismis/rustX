#!/usr/bin/env python3
"""Collect eight separate exploratory short-small profiles serially. Root executes this."""
import argparse
import datetime
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('small_profile_audit', HERE / 'audit-small-profiles.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, default=audit.REPO)
    parser.add_argument('--profiler-root', type=Path, default=Path('/home/capi/.cache/rustx-pr485-profilers'))
    args = parser.parse_args()
    args.root = HERE
    args.raw_only = False
    args.expect_rust_sha256 = audit.SHA
    args.baseline_identity = HERE / 'baseline-build/identity.json'
    args.candidate_identity = HERE / 'candidate-complete-build/identity.json'
    args.repo, args.profiler_root = args.repo.resolve(), args.profiler_root.resolve()
    diag, _ = audit.dependencies()
    predecessor = audit.canonical_predecessor(HERE, diag)
    builds = {label: diag.verify_build(args, label)[0] for label in ('baseline', 'complete')}
    audit.require((builds['complete']['head'], builds['complete']['sha256']) == (audit.HEAD, audit.SHA), 'unexpected candidate pin')
    audit.require(all(builds['baseline'][key] == builds['complete'][key] for key in ('harness', 'rustc', 'cargo')), 'toolchain/harness changed')
    audit.require(not any(key == 'LD_PRELOAD' or key.startswith(('CPUPROFILE', 'HEAPPROFILE', 'RUSTX_BENCH_PROFILE_')) for key in os.environ), 'inherited profiling environment')
    output = HERE / 'supplemental-small-profiles'
    audit.require(not output.exists(), 'preserve prior attempt; supplemental output already exists')
    audit.require(all(len(str(output / name / 'control.sock').encode()) < 108 for name, _, _, mode in audit.MATRIX if mode == 'cpu'), 'Unix profile socket path too long')
    producer = args.repo / 'benchmarks/runtime/profiling/run.py'
    pprof = args.profiler_root / 'unpacked/usr/bin/google-pprof'
    symbolizer = {'path': str(pprof), 'sha256': audit.sha(pprof)}
    profiler_paths = [args.profiler_root / 'bridge.so', args.profiler_root / 'unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0']
    preload = {str(path): audit.sha(path) for path in profiler_paths}

    def source():
        audit.require(not diag.git(args.repo, 'status', '--porcelain', '--', 'src', 'tests', 'Cargo.toml', 'Cargo.lock', 'benchmarks/runtime'), 'dirty source/harness')
        files = {str(path.relative_to(args.repo)): audit.sha(path) for folder in ('src', 'tests')
                 for path in sorted((args.repo / folder).rglob('*')) if path.is_file()}
        files.update({name: audit.sha(args.repo / name) for name in ('Cargo.toml', 'Cargo.lock')})
        audit.require(files == builds['complete']['source_files'], 'source differs from tested ordinary build')
        fixtures = {str(path.relative_to(args.repo)): audit.sha(path) for path in sorted((args.repo / 'benchmarks/runtime').rglob('*'))
                    if path.is_file() and '__pycache__' not in path.parts}
        harness = {name: audit.sha(args.repo / name) for name in builds['complete']['harness']}
        audit.require(harness == builds['complete']['harness'], 'harness changed')
        audit.require(all(audit.sha(build['binary']) == build['sha256'] for build in builds.values()), 'actual binary changed')
        audit.require(all(audit.sha(path) == digest for path, digest in preload.items()) and audit.sha(pprof) == symbolizer['sha256'], 'profiler/symbolizer changed')
        head = diag.git(args.repo, 'rev-parse', 'HEAD')
        audit.require(head == audit.HEAD, 'candidate source HEAD changed')
        return {'utc': audit.now(), 'head': head, 'files': files, 'fixtures': fixtures,
                'harness_files': {**fixtures, **harness}, 'runner_sha256': audit.sha(__file__),
                'auditor_sha256': audit.sha(HERE / 'audit-small-profiles.py')}

    initial = source()
    output.mkdir()
    write(output / 'source-before.json', initial)
    manifest = {'scope': audit.SCOPE, 'expected_products': 8, 'accepted': False, 'errors': [],
                'output': str(output), 'start_utc': audit.now(), 'identities': builds,
                'identity_files': {label: audit.sha(path) for label, path in [('baseline', args.baseline_identity), ('complete', args.candidate_identity)]},
                'runner_sha256': initial['runner_sha256'], 'auditor_sha256': initial['auditor_sha256'],
                'independent_dependencies': audit.DEPENDENCIES, 'symbolizer': symbolizer,
                'canonical_predecessor': predecessor,
                'explicit_environment': {'UV_OFFLINE': '1', 'PYTHONDONTWRITEBYTECODE': '1'}}
    write(output / 'manifest.json', manifest)
    rows = []
    for name, revision, observer, mode in audit.MATRIX:
        command = ['python3', 'benchmarks/runtime/profiling/run.py', '--binary', builds[revision]['binary'],
                   '--profiler-root', str(args.profiler_root), '--output', str(output / name), '--mode', mode,
                   '--case', 'short-small', '--observer-mode', observer]
        rows.append({'name': name, 'command': command, 'status': 'pending', 'build_identity': builds[revision],
                     'preload_sha256': preload if mode == 'cpu' else {}, 'producer_sha256': audit.sha(producer),
                     'harness_files': initial['harness_files']})
    write(output / 'commands.json', rows)
    symbols, counts = [], []
    try:
        for row in rows:
            audit.require(audit.source_fields(source()) == audit.source_fields(initial), 'source changed before product')
            row.update(status='running', start_utc=audit.now())
            write(output / 'commands.json', rows)
            with (output / (row['name'] + '.stdout')).open('x') as stdout, (output / (row['name'] + '.stderr')).open('x') as stderr:
                result = subprocess.run(row['command'], cwd=args.repo, stdout=stdout, stderr=stderr,
                                        env=os.environ | manifest['explicit_environment'])
            row.update(status='complete' if result.returncode == 0 else 'failed', exit=result.returncode, end_utc=audit.now())
            write(output / 'commands.json', rows)
            print(row['name'], result.returncode, flush=True)
            audit.require(result.returncode == 0, 'supplemental product failed: ' + row['name'])
            audit.require(audit.source_fields(source()) == audit.source_fields(initial), 'source changed during product')
        # Symbolization starts only after all eight products have stopped.
        for name, revision, _, mode in audit.MATRIX:
            if mode != 'cpu':
                continue
            directory = output / name
            raw = directory / 'before_measured_turns.cpu'
            info, _ = diag.raw_cpu(raw, builds[revision]['binary'])
            for filename, flags in [('steady-cumulative.txt', ['--text', '--cum', '--nodecount=200']), ('steady-collapsed.txt', ['--collapsed'])]:
                command = [str(pprof), *flags, '--no_strip_temp', builds[revision]['binary'], str(raw)]
                row = {'name': name, 'report': filename, 'command': command, 'tool_sha256': symbolizer['sha256'],
                       'raw_sha256': info['raw_sha256'], 'status': 'running', 'start_utc': audit.now()}
                symbols.append(row)
                write(output / 'symbolization-commands.json', symbols)
                with (directory / filename).open('x') as stdout, (directory / (filename + '.stderr')).open('x') as stderr:
                    result = subprocess.run(command, stdout=stdout, stderr=stderr)
                row.update(status='complete' if result.returncode == 0 else 'failed', exit=result.returncode, end_utc=audit.now(),
                           stdout_sha256=audit.sha(directory / filename), stderr_sha256=audit.sha(directory / (filename + '.stderr')))
                write(output / 'symbolization-commands.json', symbols)
                audit.require(result.returncode == 0, 'symbolization failed')
            total = info['total_samples']
            audit.require(sum(int(line.rsplit(' ', 1)[1]) for line in (directory / 'steady-collapsed.txt').read_text().splitlines()) == total,
                          'collapsed/raw totals differ')
            counts.append({'name': name, 'samples': total, 'interval_us': info['interval_us'], 'raw_sha256': info['raw_sha256'],
                           'rows': audit.cpu_rows((directory / 'steady-cumulative.txt').read_text(), total)})
            write(output / 'cpu-counts.json', counts)
        final = source()
        audit.require(audit.source_fields(final) == audit.source_fields(initial), 'source changed during supplement')
        write(output / 'source-after.json', final)
        manifest['accepted'] = True
    except Exception as error:
        manifest['errors'].append(f'{type(error).__name__}: {error}')
        for row in rows:
            if row['status'] == 'pending':
                row.update(status='not_run', reason='earlier failure; no retry or overwrite')
            elif row['status'] == 'running':
                row.update(status='failed', exit=-1, end_utc=audit.now())
        write(output / 'commands.json', rows)
        for row in symbols:
            if row['status'] == 'running':
                row.update(status='failed', exit=-1, end_utc=audit.now())
        if symbols:
            write(output / 'symbolization-commands.json', symbols)
        try:
            write(output / 'source-after.json', source())
        except Exception as snapshot_error:
            manifest['errors'].append('after-source unavailable: ' + repr(snapshot_error))
    manifest['end_utc'] = audit.now()
    write(output / 'manifest.json', manifest)
    print(json.dumps({'output': str(output), 'accepted': manifest['accepted'], 'errors': manifest['errors']}), flush=True)
    return 0 if manifest['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
