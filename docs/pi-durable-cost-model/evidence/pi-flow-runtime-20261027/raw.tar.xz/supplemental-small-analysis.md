# 小历史补充诊断：screen 回退未成为稳定的实现回退证据

固定基线为 schema79 / `f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20` / SHA256 `8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7`；候选为 schema80 / `d22ce66c5a1cda895cac382ce2c350f345933876` / SHA256 `775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb`。同一 O3/default features、同一 harness，全部 short-small，8 history +32 measured turns。补充审计 `supplemental-small-profiles/audit.json` accepted strict，SHA256 `f9a1ceb361577ebb6cbdc71be76f8fce01baa7a9e3088cd3364c44db80dbdef7`。

八个补充产品是发现 screen 回退后的探索性诊断，各 revision × observer × control/CPU 只有一个产品，独立保留，不加入原18 canonical诊断或276正式矩阵。以下 screen/direct 对照只复算已完成的 short-small 子集，不声明尚未完成的整轮 final 严格审计已通过。保留全部 adverse pair，未筛选结果。

## 单个 control 与 CPU 产品

| 产品 | measured turn mean ms | measured self CPU ms | through-cleanup self CPU ms | measured process write B | 250Hz raw samples |
| --- | --- | --- | --- | --- | --- |
| baseline-no-live-control | 20.952 | 750 | 1530 | 50298880 | — |
| baseline-no-live-cpu | 21.477 | 790 | 1610 | 50319360 | 196 |
| complete-no-live-control | 10.900 | 400 | 1070 | 35119104 | — |
| complete-no-live-cpu | 19.568 | 700 | 1500 | 35147776 | 175 |
| baseline-live-control | 27.716 | 1230 | 2120 | 50225152 | — |
| baseline-live-cpu | 28.021 | 1250 | 2200 | 50274304 | 312 |
| complete-live-control | 21.359 | 1000 | 1810 | 35131392 | — |
| complete-live-cpu | 13.218 | 630 | 1380 | 35143680 | 152 |

候选 no-live control→profile 的 measured CPU 为400→700ms，live为1000→630ms，方向相反。基线对应750→790ms和1230→1250ms。单对独立运行不能把这些差值视为固定 profiler overhead，也不能用诊断耗时取代正式结果。/proc CPU按100 ticks/s换算，累计端点粒度10ms；raw signal采样为250Hz，每样本名义4ms，两者是不同计数。

## 与 screen/direct 的关系

| observer | 指标 | screen单对变化 | direct五对变化中位[min,max] | direct回退pair(0起) |
| --- | --- | --- | --- | --- |
| no-live | median_measured_turn_ms | +45.96% | -14.20% [-30.54,-10.57] | 无 |
| no-live | mean_turn_ms | +38.03% | -12.05% [-30.83,-9.79] | 无 |
| no-live | turn_cpu_ms_per_turn | +36.73% | -10.67% [-29.76,-5.33] | 无 |
| no-live | through_cleanup_self_cpu_ms | +10.40% | -8.55% [-18.40,-4.55] | 无 |
| no-live | through_cleanup_process_write_bytes | -29.40% | -29.37% [-29.45,-29.25] | 无 |
| live | median_measured_turn_ms | +13.19% | -21.01% [-25.41,+41.65] | 3, 4 |
| live | mean_turn_ms | +12.19% | -17.14% [-25.42,+42.15] | 3, 4 |
| live | turn_cpu_ms_per_turn | +13.89% | -10.26% [-24.79,+49.30] | 3, 4 |
| live | through_cleanup_self_cpu_ms | +11.56% | -8.25% [-14.71,+29.93] | 3, 4 |
| live | through_cleanup_process_write_bytes | -29.34% | -29.34% [-29.41,-29.29] | 无 |

screen no-live 的CPU/turn +36.73%来自15.3125→20.9375ms；正式direct基线本身变为22.8125–26.25ms，候选18.4375–22.1875ms，五对全部改善。live五对仍有pair3/4回退，CPU/turn分别+49.30%/+17.20%；不能把中位改善说成每次都改善。两组through-cleanup process writes均稳定减少约29.3%，这与CPU波动分开陈述。

## 原始栈互斥归类

| 互斥owner | baseline-no-live-cpu | complete-no-live-cpu | baseline-live-cpu | complete-live-cpu |
| --- | --- | --- | --- | --- |
| harness_sampling | 14 | 16 | 12 | 9 |
| readiness | 4 | 1 | 5 | 5 |
| request_layout_index | 18 | 17 | 18 | 7 |
| native_configuration | 4 | 3 | 4 | 2 |
| publication_encode | 28 | 40 | 66 | 41 |
| seed_freeze | 5 | 3 | 17 | 4 |
| read_domain | 0 | 0 | 28 | 26 |
| sqlite_other | 58 | 39 | 53 | 26 |
| runtime_client_other | 15 | 18 | 48 | 11 |
| other | 50 | 38 | 61 | 21 |

每条 collapsed 栈按表中优先顺序只分配一次，总计严格等于独立解码的 raw CPU 二进制196/175/312/152样本。脚本保留逐行归类、raw/折叠栈SHA和独立出版分析依赖SHA；真实函数帧去掉末尾地址后匹配，避免把泛型参数里出现的函数名误当调用。不能从该表精确分配未显式呈现的inline路径，inclusive子项另列JSON且不可相加。

## TEMP、四值mask探测、preview的可见边界

- readiness真实owner采样并未显示一致回退；详细mark/insert/frontier函数及整数样本保留JSON。单次几个样本只能证明该路径被执行，不能可靠估计改动的净CPU。候选live确有TEMP insert和内存journal/manifest hook栈，但这不是screen整体回退的因果证明。
- `IN (4,5,6,7)`一类四值mask探测和生成列计算在SQLite VM中执行。CPU栈不能按SQL谓词/opcode拆开；VM与索引路径总样本不是mask专项成本。因此当前证据不能把回退归因于mask，也不能证明其成本为零。需要特定SQL执行计数/VM profile或同功能隔离对照才能做该归因，本次没有。
- request layout真实index采样为no-live18→17、live18→7；旧`fragments::display`在两个基线各1样本，候选均0。新geometry capture在候选有采样，但baseline的capture内部结构不同，不能直接把新函数样本当增量。`preview`字符串还能来自turn/trace/event字段，不能统称为已删除的request写入preview。没有观察到可支撑“大量新增preview成本”的证据。

这里能支持的结论是：screen回退未在两组direct五对中位重现；live仍有两个明显不利配对，全部保留。CPU profile显示了剩余publication/seed/read/layout成本，但不能从一次采样把组合改动的单项因果收益或回退精确拆出。原始证据的语义、reopen和observer校验通过；readiness改为连接epoch、重开采用已提交J/T基线的持久性取舍仍然存在。

复算：`python3 analyze-small-profiles.py`，需输出文件尚不存在。该脚本只读completed supplemental + screen/direct short-small原始数据；不会读取进行中的final队列，不运行产品、构建、profiler或重新符号化。
