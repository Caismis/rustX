import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path(__file__).parent
old=root.parent/'checks-retry1'
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
rows=[json.loads(l) for l in (old/'tests-build.stdout').read_text().splitlines() if l.startswith('{')]
a={r['target']['name']:r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and (r['target']['kind']==['lib'] or r['target']['name'] in ('durable','process'))}
steps=[(k,[a['rustx'],v,'--skip','::scale::','--test-threads=2']) for k,v in [('client','runtime_client::'),('conversation-runtime','runtime::conversation_runtime::'),('read-layout','runtime::read_layout::'),('content','boundary_suites::durable::content::'),('agent','scripted_suites::agent::'),('recovery','runtime::recovery::'),('process-death','boundary_suites::durable::process_death::')]]+[(n,[a[n],'--test-threads=2']) for n in ['durable','process']]
records=[]
for label,cmd in steps:
 rec=dict(label=label,command=cmd,status='running',start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_snapshot=str(old/'source-before.json'),scope='exploratory failure collection; binary predates active repairs, not final verification');records.append(rec);(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:r=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'},stdout=out,stderr=err)
 rec.update(exit=r.returncode,status='complete' if not r.returncode else 'failed',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True)
