#!/usr/bin/env python3
"""Synthetic/parser checks only. Never produces benchmark evidence or runs products."""
import copy,importlib.util,json,shutil,tempfile,types,unittest
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnostics',ROOT/'audit-diagnostics.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)

def snapshot(revision):
    tables={'events':{'rows':1,'column_value_bytes':{'event_json':10,'observation_statistics':3,'observation_execution':4}},
            'request_configurations':{'rows':1,'column_value_bytes':{'digest':64,'configuration_json':100}},
            'request_snapshots':{'rows':1,'column_value_bytes':{'snapshot_json':50}}}
    if revision=='baseline':
        for name in ('event_observation_readiness','transcript_observation_readiness'):tables[name]={'rows':1,'column_value_bytes':{'position':1,'ready':1}}
    return {'scope':'main_database_only; connection-local TEMP owner state and virtual generated columns are outside this read-only connection measurement',
            'tables':tables,'events_by_kind':[{'kind':'synthetic','rows':1,'column_value_bytes':dict(tables['events']['column_value_bytes'])}],
            'equal_event_observation_json':{'status':'retired_layout_absent','table':'events','column':'observation_json','rows':None,'native_bytes':None},
            'dbstat':[['events',4096,100,1]]}

class EvidenceAuditTests(unittest.TestCase):
    def setUp(self):
        self.args=types.SimpleNamespace(root=ROOT,repo=audit.REPO,raw_only=True,expect_rust_sha256=None,
            baseline_identity=ROOT/'baseline-build/identity.json',candidate_identity=ROOT/'candidate-complete-build/identity.json')
        self.build=audit.load(self.args.baseline_identity)
    def test_both_current_schemas_have_explicit_retired_payload_absence(self):
        for revision in ('baseline','complete'):audit.validate_snapshot(snapshot(revision),revision)
    def test_readiness_main_absence_is_not_a_measured_zero(self):
        data=snapshot('baseline')
        with self.assertRaisesRegex(ValueError,'main/TEMP'):audit.validate_snapshot(data,'complete')
        with self.assertRaisesRegex(ValueError,'main/TEMP'):audit.validate_snapshot(snapshot('complete'),'baseline')
    def test_retired_payload_cannot_be_reported_as_zero(self):
        data=snapshot('complete');data['equal_event_observation_json']={'rows':0,'native_bytes':0}
        with self.assertRaisesRegex(ValueError,'measured zero'):audit.validate_snapshot(data,'complete')
    def test_old_event_payload_layout_cannot_be_relabelled(self):
        data=snapshot('complete');data['tables']['events']['column_value_bytes']['observation_json']=10
        with self.assertRaisesRegex(ValueError,'recorded revision'):audit.validate_snapshot(data,'complete')
    def test_column_kind_totals_must_match_actual_cells(self):
        data=snapshot('baseline');data['events_by_kind'][0]['rows']+=1
        with self.assertRaisesRegex(ValueError,'rows do not sum'):audit.validate_snapshot(data,'baseline')
        data=snapshot('complete');data['events_by_kind'][0]['column_value_bytes']['event_json']+=1
        with self.assertRaisesRegex(ValueError,'byte values do not sum'):audit.validate_snapshot(data,'complete')
    def test_scope_cannot_claim_visibility_of_owner_temp(self):
        data=snapshot('complete');del data['scope']
        with self.assertRaisesRegex(ValueError,'main-only'):audit.validate_snapshot(data,'complete')
    def test_diagnostic_runtime_fixture_binding_is_required_and_matches_formal(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);self.args.root=root
            files={'src/lib.rs':'1'*64,'tests/test.rs':'2'*64,'Cargo.toml':'3'*64,'Cargo.lock':'4'*64}
            fixtures={'benchmarks/runtime/controller.py':'5'*64}
            builds={label:dict(binary='/not-followed/'+label,source_files=files) for label in ('baseline','complete')}
            for label,build in builds.items():(root/(label+'.json')).write_text(json.dumps(build))
            self.args.baseline_identity=root/'baseline.json';self.args.candidate_identity=root/'complete.json'
            self.args.formal_audit=root/'formal.json'
            formal={'queue_states':{stage:{'source_before':{'fixtures':fixtures}} for stage in ('direct','final')}}
            self.args.formal_audit.write_text(json.dumps(formal))
            commands=[]
            for label,build in builds.items():commands.append(('columns-'+label,'columns-complete.py',['--binary',build['binary'],'--label',label]))
            commands.extend([('profiles','run-profiles.py',[]),('profile-reports','profile-reports.py',[])])
            for label,build in builds.items():commands.append(('sql-'+label+'-tx-no-live','run-sql-prepare-tx.py',['--binary',build['binary'],'--name','sql-'+label+'-tx-no-live']))
            for label,build in builds.items():commands.extend([('wal-'+label,'run-wal-compact.py',['--binary',build['binary'],'--label',label]),('wal-summary-'+label,'analyze-wal-verified.py',['--label',label])])
            rows=[]
            for i,(name,script,argv) in enumerate(commands):
                (root/script).write_text('# synthetic parser fixture only\n')
                for suffix in ('.stdout','.stderr'):(root/(name+suffix)).write_text('')
                rows.append(dict(name=name,command=['python3',str(root/script),*argv],producer_sha256=audit.sha(root/script),status='complete',exit=0,start_utc=f'2026-10-27T01:00:{2*i+1:02d}+00:00',end_utc=f'2026-10-27T01:00:{2*i+2:02d}+00:00'))
            (root/'diagnostic-commands.json').write_text(json.dumps(rows))
            (root/'run-diagnostics.py').write_text('# synthetic wrapper\n')
            source=dict(head='a'*40,files=files,fixtures=fixtures,runner_sha256=audit.sha(root/'run-diagnostics.py'))
            def save_source():
                for side,second in [('before',0),('after',21)]:(root/('diagnostic-source-'+side+'.json')).write_text(json.dumps(dict(source,utc=f'2026-10-27T01:00:{second:02d}+00:00')))
            save_source();self.assertTrue(audit.producer_windows(self.args)['verified'])
            del source['fixtures'];save_source()
            with self.assertRaisesRegex(ValueError,'fixture binding'):audit.producer_windows(self.args)
            source['fixtures']={'benchmarks/runtime/controller.py':'6'*64};save_source()
            with self.assertRaisesRegex(ValueError,'fixture bytes differ'):audit.producer_windows(self.args)
    def test_truncated_cpu_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.cpu';p.write_bytes(b'\0'*40)
            with self.assertRaisesRegex(ValueError,'CPU header'):audit.raw_cpu(p,'nonexistent')
    def test_raw_identity_does_not_follow_embedded_binary_path(self):
        with tempfile.TemporaryDirectory() as d:
            directory=Path(d);build=dict(self.build);build['binary']='/absent/do-not-open/product'
            (directory/'identity.json').write_text(json.dumps(build));shutil.copy2(ROOT/'baseline-build/build.stdout',directory/'build.stdout')
            self.args.baseline_identity=directory/'identity.json'
            actual,_=audit.verify_build(self.args,'baseline');self.assertEqual(actual['binary'],build['binary'])
            self.args.raw_only=False
            with self.assertRaises(FileNotFoundError):audit.verify_build(self.args,'baseline')
    def test_sql_recounts_raw_instead_of_trusting_summary(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);directory=root/'sql-baseline-tx-no-live';directory.mkdir()
            for name in ('run-sql-prepare-tx.py','sql-prepare-tx.gdb.py'):shutil.copy2(ROOT/name,root/name)
            identity={'build_identity':self.build,'binary':self.build['binary'],'accepted':True,'errors':[],
                      **dict.fromkeys(('thread_finished','binary_unchanged','runner_unchanged','gdb_script_unchanged'),True),
                      'start_utc':'2026-10-27T01:00:00+00:00','end_utc':'2026-10-27T01:00:01+00:00',
                      'runner_sha256':audit.sha(root/'run-sql-prepare-tx.py'),'gdb_script_sha256':audit.sha(root/'sql-prepare-tx.gdb.py'),
                      'argv':['gdb','--quiet','--nx','--batch','-ex','source '+str(root/'sql-prepare-tx.gdb.py'),'--args',self.build['binary'],audit.TEST,'--exact','--ignored','--nocapture']}
            (directory/'identity.json').write_text(json.dumps(identity));(directory/'phases.json').write_text('[]')
            (directory/'prepares.jsonl').write_text(''.join(json.dumps(dict(monotonic_ns=t,sql='SELECT 1',flags=0,connection=1,thread=1))+'\n' for t in (5,8)))
            (directory/'prepare-counts.json').write_text(json.dumps({'whole_prepare_calls':2,'measured_prepare_calls':3,'measured_turns':32,'unique_flag_sql':1,'flags':{'0':2},'counts':[{'flags':0,'sql':'SELECT 1','count':2}]}))
            self.args.root=root
            with patch.object(audit,'product',return_value={'accepted':True}),patch.object(audit,'phase_points',return_value=([],{'before_measured_turns':1,'after_turns':9})):
                with self.assertRaisesRegex(ValueError,'SQL total'):audit.sql_diagnostic(self.args,directory.name,self.build,'baseline',True)
            identity['gdb_script_sha256']='0'*64;(directory/'identity.json').write_text(json.dumps(identity))
            with self.assertRaisesRegex(ValueError,'probe/runner'):audit.sql_diagnostic(self.args,directory.name,self.build,'baseline',True)

if __name__=='__main__':unittest.main()
