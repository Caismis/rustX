#!/usr/bin/env python3
"""Synthetic supplemental-auditor checks only; no products/builds/profiling."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('supplement', ROOT / 'audit-small-profiles.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
diag, formal = audit.dependencies()


def counters(index):
    tail = ['0'] * 40
    tail[0], tail[11], tail[12], tail[19] = 'R', str(index), '0', '12345'
    return {'stat': '111 (synthetic) ' + ' '.join(tail), 'io': f'write_bytes: {index * 4096}\n'}


def fixture(root, observer='no-live-subscriber'):
    name = 'baseline-no-live-control' if observer.startswith('no-live') else 'baseline-live-control'
    directory = root / 'supplemental-small-profiles' / name
    directory.mkdir(parents=True)
    binary = '/absent/fixture/product'
    argv = [binary, diag.TEST, '--exact', '--ignored', '--nocapture']
    build = {'binary': binary, 'sha256': '1' * 64}
    command = ['python3', 'benchmarks/runtime/profiling/run.py', '--binary', binary,
               '--profiler-root', '/absent/profiler', '--output', str(directory), '--mode', 'control',
               '--case', 'short-small', '--observer-mode', observer]
    row = {'name': name, 'command': command, 'build_identity': build, 'preload_sha256': {},
           'start_utc': '2026-10-27T01:00:00+00:00', 'end_utc': '2026-10-27T01:00:01+00:00',
           'producer_sha256': '2' * 64, 'harness_files': {'benchmarks/runtime/profiling/run.py': '2' * 64}}
    raw = {'schema': 79, 'oracle': 'passed', 'oracle_version': 2, 'case': 'short-small', 'observer_mode': observer,
           'history': 8, 'measured': 32, 'workload_version': 3, 'measurement_version': 4,
           'canonical': [], 'late_snapshot': {}, 'closed_footprint': {'synthetic': True}, 'observer_validation': None,
           'samples': [{'turn': i, 'measured': i >= 8, 'observer_mode': observer, 'settled_us': 1000, 'accepted_us': 100,
                        'first_consumed_publication_us': 500 if observer == 'live-subscriber' else None,
                        'notification_records': 1 if observer == 'live-subscriber' else 0, 'process': counters(i)} for i in range(40)],
           'lifecycle': [{'phase': phase, 'elapsed_us': i, 'process': counters(40 + i)} for i, phase in enumerate(diag.LIFECYCLE)],
           'wire_requests': [{'index': i} for i in range(40)], 'live_requests': [], 'reopened_requests': [],
           'verified_live_requests': 40, 'verified_reopened_requests': 40}
    if observer == 'live-subscriber':
        raw['observer_validation'] = {'oracle_version': 2, 'completed_attempts': 40,
                                     'explicit_settlements': [{'outcome': {'type': 'completed'}}] * 40}
    proc = {'argv': argv, 'accepted': True, 'product_exit': 0, 'provider_exit': 0,
            'case': 'short-small', 'observer_mode': observer, 'provider_report': {'complete': True, 'ok': True, 'failures': [],
            'requestCount': 40, 'stepsTotal': 40, 'stepsMatched': 40, 'stepsSettled': 40,
            'stepStates': ['settled'] * 40, 'requests': raw['wire_requests']}}
    for name_, value in [('sample.json', raw), ('sample.process.json', proc), ('manifest.json',
         {'mode': 'control', 'case': 'short-small', 'observer_mode': observer, 'binary_sha256': build['sha256'], 'argv': argv})]:
        (directory / name_).write_text(json.dumps(value))
    for suffix in ('.stdout', '.stderr'):
        (directory.parent / (name + suffix)).write_text('')
    args = SimpleNamespace(root=root, raw_only=True)
    definition = (name, 'baseline', observer, 'control')
    return args, row, definition, {'baseline': build}, directory, raw, proc


class SmallProfileTests(unittest.TestCase):
    def test_exact_eight_and_no_failed_or_duplicate_products(self):
        rows = [{'name': name, 'status': 'complete', 'exit': 0} for name, _, _, _ in audit.MATRIX]
        audit.exact_matrix(rows)
        for changed in [rows[:-1], rows + rows[:1], [dict(rows[0], status='failed'), *rows[1:]]]:
            with self.assertRaises(ValueError):
                audit.exact_matrix(changed)

    def test_short_socket_paths_fit_without_touching_producer(self):
        self.assertEqual(len(audit.MATRIX), 8)
        for name, _, _, mode in audit.MATRIX:
            if mode == 'cpu':
                self.assertLess(len(str(ROOT / 'supplemental-small-profiles' / name / 'control.sock').encode()), 108)

    def test_real_product_and_observer_helpers_accept_both_controls(self):
        for mode in ('no-live-subscriber', 'live-subscriber'):
            with tempfile.TemporaryDirectory() as temporary:
                args, row, definition, builds, _, _, _ = fixture(Path(temporary), mode)
                result = audit.profile(args, row, definition, builds, {}, diag, formal)
                self.assertEqual(result['product']['measured_turns'], 32)
                self.assertEqual(result['product']['request_count'], 40)

    def test_wrong_schema_and_turn_count_and_oracle_rejected(self):
        for key, value in [('schema', 80), ('measured', 31), ('oracle', 'failed')]:
            with tempfile.TemporaryDirectory() as temporary:
                args, row, definition, builds, directory, raw, _ = fixture(Path(temporary))
                raw[key] = value
                (directory / 'sample.json').write_text(json.dumps(raw))
                with self.assertRaises(ValueError):
                    audit.profile(args, row, definition, builds, {}, diag, formal)

    def test_exit_and_provider_failure_rejected(self):
        for key in ('product_exit', 'provider_exit'):
            with tempfile.TemporaryDirectory() as temporary:
                args, row, definition, builds, directory, _, proc = fixture(Path(temporary))
                proc[key] = 1
                (directory / 'sample.process.json').write_text(json.dumps(proc))
                with self.assertRaises(ValueError):
                    audit.profile(args, row, definition, builds, {}, diag, formal)

    def test_no_live_cannot_hide_consumed_publication(self):
        with tempfile.TemporaryDirectory() as temporary:
            args, row, definition, builds, directory, raw, _ = fixture(Path(temporary))
            raw['samples'][0]['first_consumed_publication_us'] = 500
            (directory / 'sample.json').write_text(json.dumps(raw))
            with self.assertRaisesRegex(ValueError, 'no-live'):
                audit.profile(args, row, definition, builds, {}, diag, formal)

    def test_raw_only_control_never_opens_absent_binary(self):
        with tempfile.TemporaryDirectory() as temporary:
            args, row, definition, builds, _, _, _ = fixture(Path(temporary))
            self.assertTrue(audit.profile(args, row, definition, builds, {}, diag, formal)['product']['accepted'])

    def test_symbolized_total_not_filled_or_guessed(self):
        self.assertEqual(audit.cpu_rows('Total: 2 samples\n 2 100.0% 100.0% 2 100.0% example\n', 2),
                         [{'symbol': 'example', 'flat': 2, 'inclusive': 2}])
        with self.assertRaises(ValueError):
            audit.cpu_rows('Total: 1 samples\n', 2)


if __name__ == '__main__':
    unittest.main()
