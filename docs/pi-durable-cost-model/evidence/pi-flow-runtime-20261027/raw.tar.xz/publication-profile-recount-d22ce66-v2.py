#!/usr/bin/env python3
"""Read retained samples only; no product execution or address symbolization."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import statistics
import struct

ENCODE = '<rustx::runtime_client::projection::PublicationDraft>::encode'
CAPTURE = '<rustx::runtime_client::projection::CheckpointSeed>::capture_checkpoint'
SEED = '<rustx::runtime_client::projection::RuntimeClientProjection>::capture_working_seed'
READ = '<rustx::runtime_client::projection::ReadDomainCut>::read_with_trace'
SNAPSHOT = '<rustx::runtime_client::snapshot::RuntimeClientSnapshot as core::clone::Clone>::clone'
CAPABILITY = '<rustx::runtime_client::snapshot::CapabilityView as core::clone::Clone>::clone'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def raw_count(path):
    data = path.read_bytes()
    assert struct.unpack_from('<5Q', data) == (0, 3, 0, 4000, 0)
    offset, total, records = 40, 0, 0
    while True:
        assert offset + 16 <= len(data)
        count, depth = struct.unpack_from('<2Q', data, offset)
        offset += 16
        assert 0 < depth < 10000 and offset + depth * 8 <= len(data)
        pcs = struct.unpack_from(f'<{depth}Q', data, offset)
        offset += depth * 8
        if count == 0 and pcs == (0,):
            break
        assert count > 0
        total += count
        records += 1
    assert data[offset:].decode()
    return {'samples': total, 'records': records, 'interval_us': 4000,
            'sha256': sha(path)}


def frame(raw):
    return re.sub(r'<[0-9a-f]{16}>$', '', raw)


def starts(frames, prefix):
    return any(item.startswith(prefix) for item in frames)


def capture_bucket(frames):
    # A generic closure/drop symbol mentioning capture_checkpoint is not the
    # actual capture frame. The caller checks exact frame equality first.
    initializers = [item for item in frames if item.startswith('<std::sync::once_lock::OnceLock<')
                    and '>::initialize::' in item]
    if initializers:
        joined = ' '.join(initializers)
        if 'PreparedCapture<alloc::vec::Vec<rustx::runtime_client::snapshot::RuntimeClientTranscriptEntry' in joined:
            return 'prepared_init_transcript_entries'
        if 'PreparedCapture<alloc::vec::Vec<rustx::message::types::MessageBlock' in joined:
            return 'prepared_init_messages'
        if 'PreparedCapture<core::option::Option<rustx::runtime_client::response::ConversationStatistics' in joined:
            return 'prepared_init_statistics'
        return 'prepared_init_other'
    if starts(frames, '<rustx::runtime_client::projection::CheckpointSeed>::capture_attempt'):
        return 'attempt_capture'
    if starts(frames, '<rustx::runtime_client::projection::CheckpointSeed>::capture_evidence'):
        return 'capture_evidence'
    if any('preflight::Check' in item for item in frames):
        return 'visible_budget_preflight'
    if starts(frames, '<rustx::runtime_client::checkpoint::Capture>::prepared::'):
        return 'prepared_noninitializing_or_unresolved'
    return 'capture_other_or_inlined'


def metrics(directory):
    value = json.loads((directory / 'sample.json').read_text())
    samples = value['samples']
    assert value['case'] == 'short-large' and value['history'] == 64 and value['measured'] == 32
    assert len(samples) == 96 and all(not row['measured'] for row in samples[:64])
    assert all(row['measured'] for row in samples[64:]) and value['oracle'] == 'passed'
    def ticks(row):
        tail = row['process']['stat'].rsplit(')', 1)[1].split()
        return int(tail[11]) + int(tail[12])
    measured = samples[64:]
    return {'oracle': value['oracle'], 'schema': value['schema'],
            'history': 64, 'measured_turns': 32,
            'mean_settled_ms': statistics.mean(row['settled_us'] for row in measured) / 1000,
            'median_settled_ms': statistics.median(row['settled_us'] for row in measured) / 1000,
            'measured_phase_self_cpu_ticks': ticks(samples[-1]) - ticks(samples[63]),
            'measured_notifications': samples[-1]['notification_records'] - samples[63]['notification_records'],
            'sample_sha256': sha(directory / 'sample.json'),
            'manifest': json.loads((directory / 'manifest.json').read_text()),
            'manifest_sha256': sha(directory / 'manifest.json')}


def profile(directory, reported):
    raw = raw_count(directory / 'before_measured_turns.cpu')
    rows = []
    buckets, capture, length, seed, seed_clone, origin = (Counter() for _ in range(6))
    inclusive, whole, flat = Counter(), Counter(), Counter()
    read_detail, length_nested = Counter(), Counter()
    top_rustx = Counter()
    for line_no, line in enumerate((directory / 'steady-collapsed.txt').read_text().splitlines(), 1):
        raw_stack, n = line.rsplit(' ', 1)
        assert n.isdecimal() and int(n) > 0
        weight = int(n)
        frames = [frame(part) for part in raw_stack.split(';')]
        stack = ';'.join(frames)
        flat[frames[-1]] += weight
        # Inclusive functions: use real frame names, never matches inside their
        # generic arguments. Nested operations intentionally remain overlapping.
        markers = {'publication_encode': ENCODE in frames, 'checkpoint_capture': CAPTURE in frames,
                   'seed_freeze': SEED in frames, 'read_domain': READ in frames,
                   'sql_prepare': 'sqlite3Prepare' in frames,
                   'checkpoint_fit': starts(frames, 'rustx::runtime_client::checkpoint::fit_checkpoint'),
                   'sqlite_step': any(item in frames for item in ('sqlite3_step', 'sqlite3VdbeExec')),
                   'native_request_persist': starts(frames, 'rustx::durable::sqlite::native_request::persist'),
                   'native_request_read': starts(frames, 'rustx::durable::sqlite::native_request::read'),
                   'response_read_validated': starts(frames, 'rustx::durable::sqlite::observation_response::read_validated'),
                   'request_layout_index': starts(frames, 'rustx::durable::sqlite::index_request_read_layouts'),
                   'request_composed_ensure': starts(frames, '<rustx::durable::sqlite::observation_request::composed::nodes::Capture>::ensure'),
                   'readiness': starts(frames, 'rustx::durable::sqlite::observation_readiness::')}
        for key, present in markers.items():
            if present:
                inclusive[key] += weight
        if ENCODE in frames:
            if markers['checkpoint_fit']:
                bucket = 'checkpoint_fit'
            elif CAPTURE in frames:
                bucket = 'checkpoint_capture'
                capture[capture_bucket(frames)] += weight
            elif starts(frames, 'rustx::runtime_client::checkpoint::bounded_structural_len'):
                bucket = 'exact_structural_length_envelope'
                if 'preflight::Check' in stack:
                    detail = 'preflight'
                elif 'checkpoint::Length' in stack:
                    detail = 'metadata_exact_length' if 'checkpoint::ProjectionMetadata' in stack else 'event_or_envelope_exact_length'
                else:
                    detail = 'unresolved_or_inlined'
                length[detail] += weight
                for symbol in ('RuntimeClientCheckpoint', 'ProjectionMetadata', 'structural_json::resolve', 'preflight::Check'):
                    if symbol in stack:
                        length_nested[symbol] += weight
            else:
                bucket = 'publication_other'
            buckets[bucket] += weight
            source = ('read_worker' if starts(frames, 'rustx::runtime_client::host::commit_display::') else
                      'native_batch' if any('>::native_batch' in f for f in frames) else 'other_or_inlined')
            origin[source] += weight
            owner = 'publication_encode'
        elif SEED in frames:
            if SNAPSHOT in frames:
                detail = 'snapshot_clone'
                if CAPABILITY in frames:
                    clone_detail = 'deep_raw_capabilities'
                elif 'RuntimeClientTranscriptPage as core::clone::Clone' in stack:
                    clone_detail = 'transcript_page'
                elif 'RuntimeClientMessageDescriptor as core::clone::Clone' in stack:
                    clone_detail = 'message_descriptors'
                elif 'RuntimeClientContextView as core::clone::Clone' in stack:
                    clone_detail = 'context'
                else:
                    clone_detail = 'snapshot_other_or_inlined'
                seed_clone[clone_detail] += weight
            elif 'UnambiguousEquality' in stack or 'PreparedCaptures' in stack:
                detail = 'prepared_inheritance_equality'
            else:
                detail = 'seed_other_or_inlined'
            seed[detail] += weight
            owner = 'seed_freeze'
        elif READ in frames:
            owner = 'read_domain'
            source = next((name for name, prefix in (
                ('response', 'rustx::durable::sqlite::observation_response::'),
                ('transcript', 'rustx::durable::sqlite::observation::transcript'))
                if starts(frames, prefix)), 'other_or_inlined')
            read_detail[source] += weight
        elif 'sqlite3_step' in frames or 'sqlite3VdbeExec' in frames or 'sqlite3Prepare' in frames:
            owner = 'sqlite_outside_above'
        elif any('rustx::runtime_client::' in f for f in frames):
            owner = 'runtime_client_other'
        else:
            owner = 'other'
        whole[owner] += weight
        # First concrete rustX function below generic runtime wrappers. For
        # exploration only, not an additive whole-program attribution.
        for function in frames:
            if function.startswith('rustx::') or function.startswith('<rustx::'):
                top_rustx[function] += weight
                break
        rows.append({'collapsed_line': line_no, 'samples': weight, 'owner': owner,
                     'publication_bucket': bucket if ENCODE in frames else None})
    total = sum(row['samples'] for row in rows)
    assert total == raw['samples'] == reported['samples']
    assert reported['interval_us'] == raw['interval_us'] and reported['raw_sha256'] == raw['sha256']
    assert sum(buckets.values()) == inclusive['publication_encode']
    assert sum(capture.values()) == buckets['checkpoint_capture']
    assert sum(length.values()) == buckets['exact_structural_length_envelope']
    assert sum(seed.values()) == inclusive['seed_freeze']
    assert sum(seed_clone.values()) == seed['snapshot_clone']
    assert sum(whole.values()) == total
    assert (directory / 'steady-cumulative.txt').read_text().splitlines()[0] == f'Total: {total} samples'
    return {'raw': raw, 'collapsed_sha256': sha(directory / 'steady-collapsed.txt'),
            'cumulative_sha256': sha(directory / 'steady-cumulative.txt'),
            'inclusive': dict(inclusive), 'publication_exclusive': dict(buckets),
            'capture_exclusive': dict(capture), 'length_exclusive': dict(length),
            'length_nested_inclusive': dict(length_nested), 'read_domain_exclusive': dict(read_detail),
            'seed_exclusive': dict(seed), 'snapshot_clone_exclusive': dict(seed_clone),
            'publication_origin_exclusive': dict(origin), 'whole_program_exclusive': dict(whole),
            'top_flat': flat.most_common(20), 'first_rustx_function': top_rustx.most_common(20),
            'stack_assignments': rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.root
    counts = {row['name']: row for row in json.loads((root / 'cpu-counts.json').read_text())}
    result = {'kind': 'independent_read_only_profile_recount',
              'format_revision': 2,
              'correction': 'Revision 2 recognizes host::commit_display as a free function for origin attribution; revision 1 is retained as a superseded exploratory result.',
              'scope': 'One 64-history/32-turn short-large live-subscriber profile/control per revision; not formal acceptance.',
              'symbol_boundary': 'Retained symbol reports only; raw PC counts independently parsed, no new symbolization or live binary verification.',
              'script_sha256': sha(Path(__file__)), 'cpu_counts_sha256': sha(root / 'cpu-counts.json'),
              'clock': 'Raw /proc CPU ticks are primary. 100 Hz conversion, when shown, follows the retained cohort convention.',
              'revisions': {}}
    for label in ('baseline', 'complete'):
        name = f'profile-{label}-live-large-cpu'
        result['revisions'][label] = {'profile': profile(root / name, counts[name]),
                                      'profile_activity': metrics(root / name),
                                      'control_activity': metrics(root / f'profile-{label}-live-large-control')}
    assert result['revisions']['complete']['profile_activity']['manifest']['binary_sha256'] == '775b6426d1ce59e1f80e746000d52527e876917f117361841ce120b183d042bb'
    assert result['revisions']['baseline']['profile_activity']['manifest']['binary_sha256'] == '8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7'
    for revision in result['revisions'].values():
        assert revision['profile_activity']['manifest']['binary_sha256'] == revision['control_activity']['manifest']['binary_sha256']
    with args.output.open('x') as handle:
        json.dump(result, handle, indent=2, ensure_ascii=False)
        handle.write('\n')
    print(json.dumps({label: {key: values['profile'][key] for key in ('raw', 'publication_exclusive', 'capture_exclusive', 'length_exclusive', 'seed_exclusive', 'snapshot_clone_exclusive', 'publication_origin_exclusive', 'whole_program_exclusive')} for label, values in result['revisions'].items()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
