#!/usr/bin/env python3
"""Audit retained complete diagnostics without running products or re-symbolizing.

Portable raw-only usage accepts explicit archived build identities. Raw-only never
follows the absolute binary, preload, database, or workspace paths in evidence.
"""
import argparse
import ast
import collections
import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
BASELINE_HEAD = 'f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20'
BASELINE_TREE = '09ca4b97e5f0c71f97dd53e2df87a28c4dffc3aa'
BASELINE_SHA = '8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7'
TEST = 'agent_loop::runtime_benchmark::measure_runtime'
PHASES = ['before_initialization', 'after_provider_start', 'after_initialization',
          'before_measured_turns', 'after_turns', 'after_late_snapshot',
          'after_verification', 'after_shutdown', 'after_driver_drop',
          'after_final_writer_close', 'after_reopen_verification', 'after_cleanup']
LIFECYCLE = [phase for phase in PHASES if phase != 'before_measured_turns']
PROFILE_NAMES = [f'profile-{revision}-live-large-{mode}'
                 for revision in ('baseline', 'complete') for mode in ('control', 'cpu')]
NEEDLES = {
    'read_with_trace': 'ReadDomainCut>::read_with_trace',
    'index_request_read_layouts': 'index_request_read_layouts',
    'sqlite_prepare': 'sqlite3LockAndPrepare',
    'publication_encode': 'PublicationDraft>::encode',
    'checkpoint_unfitted': 'CheckpointSeed>::checkpoint_unfitted',
    'checkpoint_prepared': 'CheckpointSeed>::checkpoint_prepared',
    'prepared_domain_inherit': 'PreparedCaptures>::inherit',
    'prepared_capture': 'Capture>::prepared',
    'capture_evidence': 'capture_evidence',
    'fit_checkpoint': 'fit_checkpoint',
    'native_request_persist': 'native_request::persist',
    'native_request_read': 'native_request::read',
    'native_request_full': 'native_request::full',
    'statistics_prepare': 'observation_statistics::prepare',
    'append_aggregates': 'append_facts::aggregates',
    'model_turn_receipt': 'observation_receipt::model_turn_settlement',
    'final_stored_evidence': 'observation_receipt::stored_events',
    'execution_seal': 'seal_execution',
    'content_persist_part': 'persist_part',
}


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, f'invalid {label}')
    return value


def utc(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None and result.utcoffset() == datetime.timedelta(0),
            'timestamp is not explicitly UTC')
    return result


def window(start, end):
    begin, finish = utc(start), utc(end)
    require(begin < finish, 'empty/reversed command window')
    return begin, finish


def disjoint(left, right):
    return left[1] <= right[0] or right[1] <= left[0]


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


def verify_build(args, label):
    path = args.baseline_identity if label == 'baseline' else args.candidate_identity
    build = load(path)
    require(all(re.fullmatch('[0-9a-f]{40}', build[key]) for key in ('head', 'production_tree'))
            and re.fullmatch('[0-9a-f]{64}', build['sha256']), f'{label} malformed identity')
    require(build['verified'] is True and build['build_exit'] == build['clean_exit'] == 0, 'ordinary build failed')
    require(build['commands'] == [['cargo','clean','--release','--package','rustx'],
        ['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json']], 'build commands differ')
    require(build['harness'] and build['rustc'] and build['cargo'], 'missing toolchain/harness')
    require(all(re.fullmatch('[0-9a-f]{64}', v) for v in build['harness'].values()), 'bad harness hash')
    stdout = path.parent / 'build.stdout'
    rows = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
    require([r for r in rows if r.get('reason') == 'build-finished'] == [{'reason':'build-finished','success':True}], 'Cargo success missing')
    artifacts = [r for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] in ('rustx','conformance')]
    require(any(r['target']['name'] == 'conformance' and r['executable'] for r in artifacts), 'conformance missing')
    require(all(r['profile']['opt_level']=='3' and r['features']==[] and not r['fresh'] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts), 'ordinary O3 artifacts differ')
    if label == 'baseline':
        require((build['head'],build['production_tree'],build['sha256']) == (BASELINE_HEAD,BASELINE_TREE,BASELINE_SHA), 'pinned baseline differs')
    if label == 'complete' and args.expect_rust_sha256:
        require(build['sha256'] == args.expect_rust_sha256, 'candidate SHA differs')
    if not args.raw_only:
        require(sha(build['binary']) == build['sha256'], 'actual binary differs')
        require(git(args.repo,'rev-parse',build['head']+':src') == build['production_tree'], 'source tree differs')
        for source,digest in build['harness'].items():
            require(sha(args.repo/source)==digest, 'current harness differs: '+source)
        schema=79 if label=='baseline' else 80
        require(f'pub const SQLITE_SCHEMA_VERSION: i64 = {schema};' in git(args.repo,'show',build['head']+':src/durable/sqlite.rs'), 'schema differs')
    return build, {'file':str(path),'sha256':sha(path),'cargo_stdout_sha256':sha(stdout)}


def counters(point):
    process = point['process']
    stat = process['stat']
    tail = stat.rsplit(')', 1)[1].split()
    io = {key: int(value.strip()) for key, value in
          (line.split(':', 1) for line in process['io'].splitlines())}
    return {'identity': (int(stat.split('(', 1)[0]), int(tail[19])),
            'cpu_ticks': int(tail[11]) + int(tail[12]), 'write_bytes': io['write_bytes']}


def product(directory, revision, build, case, observer, argv):
    raw, proc = load(directory / 'sample.json'), load(directory / 'sample.process.json')
    require(proc['argv'] == argv and proc['accepted'] is True and
            proc['product_exit'] == proc['provider_exit'] == 0, 'product argv/admission differs')
    require(proc['case'] == raw['case'] == case and proc['observer_mode'] ==
            raw['observer_mode'] == observer, 'product case/observer differs')
    require(raw['schema'] == (79 if revision == 'baseline' else 80), 'product schema differs')
    require(raw['oracle'] == 'passed' and raw['workload_version'] == 3
            and raw['measurement_version'] == 4, 'product oracle/version differs')
    history = 8 if case == 'short-small' else 64
    count = history + 32
    require(raw['history'] == history and raw['measured'] == 32 and len(raw['samples']) == count,
            'product turn dimensions differ')
    require(all(s['turn'] == i and s['measured'] is (i >= history)
                and s['observer_mode'] == observer for i, s in enumerate(raw['samples'])),
            'product measured phase identities differ')
    require([point['phase'] for point in raw['lifecycle']] == LIFECYCLE, 'product lifecycle differs')
    elapsed = [point['elapsed_us'] for point in raw['lifecycle']]
    require(all(type(value) is int and value >= 0 for value in elapsed) and elapsed == sorted(elapsed),
            'lifecycle times invalid/decreased')
    provider = proc['provider_report']
    require(provider['complete'] is True and provider['ok'] is True and not provider['failures']
            and provider['requestCount'] == provider['stepsTotal'] == provider['stepsMatched'] ==
            provider['stepsSettled'] == count and provider['stepStates'] == ['settled'] * count,
            'provider completion differs')
    require(raw['wire_requests'] == provider['requests'] and raw['live_requests'] == raw['reopened_requests']
            and raw['verified_live_requests'] == raw['verified_reopened_requests'] == count,
            'persisted/reopened request admission differs')
    points = raw['samples'] + raw['lifecycle']
    require(len({counters(point)['identity'] for point in points}) == 1,
            'self PID/start-time changed between counters')
    for series in (raw['samples'], raw['lifecycle']):
        for key in ('cpu_ticks', 'write_bytes'):
            values = [counters(point)[key] for point in series]
            require(min(values) >= 0 and values == sorted(values), f'{key} invalid/decreased')
    begin, end, final = (counters(raw['samples'][history - 1]),
                         counters(raw['samples'][-1]), counters(raw['lifecycle'][-1]))
    settled = [sample['settled_us'] for sample in raw['samples'][history:]]
    require(all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in settled),
            'invalid settled counter')
    return {'accepted': True, 'schema': raw['schema'], 'history_turns': history,
            'measured_turns': 32, 'request_count': count,
            'sample_sha256': sha(directory / 'sample.json'),
            'process_sha256': sha(directory / 'sample.process.json'),
            'mean_measured_turn_ms': sum(settled) / 32000,
            'measured_phase_self_cpu_ticks': end['cpu_ticks'] - begin['cpu_ticks'],
            'measured_phase_self_cpu_ms_at_100hz': (end['cpu_ticks'] - begin['cpu_ticks']) * 10,
            'measured_phase_process_write_bytes': end['write_bytes'] - begin['write_bytes'],
            'full_self_cpu_ticks': final['cpu_ticks'], 'full_self_cpu_ms_at_100hz': final['cpu_ticks'] * 10,
            'full_process_write_bytes': final['write_bytes'],
            'clock_ticks_note': 'Raw ticks are primary; milliseconds use the formal cohort 100 Hz clock convention.'}


def raw_cpu(path, binary):
    raw = path.read_bytes()
    require(len(raw) >= 64 and struct.unpack_from('<5Q', raw) == (0, 3, 0, 4000, 0),
            f'{path.name}: invalid 250 Hz CPU header')
    offset, total, records = 40, 0, 0
    while True:
        require(offset + 16 <= len(raw), f'{path.name}: truncated raw count')
        count, depth = struct.unpack_from('<2Q', raw, offset)
        offset += 16
        require(0 < depth < 10000 and offset + depth * 8 <= len(raw),
                f'{path.name}: invalid/truncated raw stack')
        pcs = struct.unpack_from(f'<{depth}Q', raw, offset)
        offset += depth * 8
        if count == 0 and pcs == (0,):
            break
        require(count > 0, f'{path.name}: invalid raw sample count')
        total += count
        records += 1
    maps = raw[offset:].decode()
    require(binary in maps, f'{path.name}: maps lack recorded measured binary')
    return {'total_samples': total, 'sample_records': records,
            'interval_us': 4000, 'raw_sha256': sha(path)}, maps


def cpu_profile(directory, build, command, counts, raw_only):
    require({path.name for path in directory.glob('*.cpu')} ==
            {phase + '.cpu' for phase in PHASES[:-1]}, 'CPU phase file inventory differs')
    inventory = {}
    for phase in PHASES[:-1]:
        info, maps = raw_cpu(directory / (phase + '.cpu'), build['binary'])
        inventory[phase] = info
        if not raw_only:
            require(all(str(Path(path).resolve()) in maps for path in command['preload_sha256']),
                    f'{phase}: raw maps lack actual preload')
    steady = inventory['before_measured_turns']
    total = steady['total_samples']
    require(total > 0, 'measured CPU interval has no samples')
    stacks = []
    for line in (directory / 'steady-collapsed.txt').read_text().splitlines():
        stack, value = line.rsplit(' ', 1)
        require(stack and value.isdigit() and int(value) > 0, 'invalid collapsed stack/count')
        stacks.append((stack, int(value)))
    require(sum(count for _, count in stacks) == total, 'raw and collapsed totals differ')
    cumulative = (directory / 'steady-cumulative.txt').read_text().splitlines()
    require(cumulative and cumulative[0] == f'Total: {total} samples', 'cumulative total differs')
    rows = []
    for line in cumulative[1:]:
        if not line.strip():
            continue
        match = re.fullmatch(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)', line)
        require(match is not None, 'unrecognized cumulative row')
        row = {'symbol': match[3], 'flat': int(match[1]), 'inclusive': int(match[2])}
        require(0 <= row['flat'] <= row['inclusive'] <= total, 'invalid cumulative counts')
        rows.append(row)
    require(rows and len({row['symbol'] for row in rows}) == len(rows), 'empty/duplicate cumulative symbols')
    require(sum(row['flat'] for row in rows) <= total, 'cumulative flat counts exceed raw samples')
    record = counts[command['name']]
    require(record['samples'] == total and record['interval_us'] == 4000 and
            record['raw_sha256'] == steady['raw_sha256'] and record['rows'] == rows,
            'cpu-counts summary differs from independently parsed evidence')
    inclusive = {}
    for label, needle in NEEDLES.items():
        value = sum(count for stack, count in stacks if needle in stack)
        matches = [row for row in rows if needle in row['symbol']]
        # pprof text shortens Rust generics and truncates at 200 nodes. Only a
        # unique text match supports a direct equality check. Multiple matches
        # are retained individually, never added as independent costs.
        agreement = None
        if len(matches) == 1:
            require(matches[0]['inclusive'] == value, f'inclusive raw-stack/text counts differ: {label}')
            agreement = True
        inclusive[label] = {'needle': needle, 'samples': value, 'share_percent': 100 * value / total,
                            'cumulative_matches': matches, 'unique_cumulative_agreement': agreement}
    return {**steady, 'raw_header': [0, 3, 0, 4000, 0], 'collapsed_total': total,
            'collapsed_sha256': sha(directory / 'steady-collapsed.txt'),
            'cumulative_sha256': sha(directory / 'steady-cumulative.txt'),
            'phase_inventory': inventory, 'inclusive': inclusive,
            'phase': 'before_measured_turns starts this file; after_turns stops it. All product threads, '
                     '32 measured turns plus between-turn counters/footprints and control overhead.',
            'symbol_binding': 'Retained symbolized reports are bound by raw SHA and count consistency; '
                              'this read-only audit does not independently symbolize program counters.'}


def profile(args, command, identities, counts):
    name = command['name']
    revision, mode = name.split('-')[1], name.split('-')[-1]
    directory, build = args.root / name, identities[revision]
    require(command['build_identity'] == build, 'profile build differs from archived identity')
    require(command['status'] == 'complete' and command['exit'] == 0, 'profile command failed')
    window(command['start_utc'], command['end_utc'])
    argv_command = command['command']
    require(argv_command[:2] == ['python3', 'benchmarks/runtime/profiling/run.py'], 'profile runner differs')
    for flag, expected in [('--binary', build['binary']), ('--mode', mode), ('--case', 'short-large'),
                           ('--observer-mode', 'live-subscriber')]:
        require(argv_command.count(flag) == 1 and argv_command[argv_command.index(flag) + 1] == expected,
                f'profile command {flag} differs')
    require(argv_command.count('--output') == 1 and
            Path(argv_command[argv_command.index('--output') + 1]).name == name, 'profile output identity differs')
    manifest = load(directory / 'manifest.json')
    require(manifest['mode'] == mode and manifest['binary_sha256'] == build['sha256'] and
            manifest['case'] == 'short-large' and manifest['observer_mode'] == 'live-subscriber',
            'profile manifest identity differs')
    argv = manifest['argv']
    require(argv[-5:] == [build['binary'], TEST, '--exact', '--ignored', '--nocapture'], 'profile target differs')
    if mode == 'cpu':
        require(argv[0] == 'env' and len(argv) == 10 and argv[4] == 'CPUPROFILE_FREQUENCY=250',
                'CPU environment/frequency differs')
        env = dict(value.split('=', 1) for value in argv[1:5])
        require(set(env) == {'LD_PRELOAD', 'RUSTX_BENCH_PROFILE_SOCKET', 'RUSTX_BENCH_PROFILE_DIR',
                             'CPUPROFILE_FREQUENCY'}, 'CPU env keys differ')
        preload = command['preload_sha256']
        require(len(preload) == 2 and set(env['LD_PRELOAD'].split(':')) == set(preload), 'preload identity differs')
        require({Path(path).name for path in preload} == {'bridge.so', 'libprofiler.so.0'} and
                all(re.fullmatch('[0-9a-f]{64}', digest) for digest in preload.values()), 'preload hashes malformed')
        require(Path(env['RUSTX_BENCH_PROFILE_DIR']).name == name and
                Path(env['RUSTX_BENCH_PROFILE_SOCKET']).parent == Path(env['RUSTX_BENCH_PROFILE_DIR']),
                'CPU phase output/socket identity differs')
        if not args.raw_only:
            require(all(sha(path) == digest for path, digest in preload.items()), 'actual preload differs')
    else:
        require(len(argv) == 5 and not command['preload_sha256'] and not list(directory.glob('*.cpu')),
                'control unexpectedly preloaded/profiled')
    result = {'name': name, 'revision': revision, 'mode': mode,
              'window': {key: command[key] for key in ('start_utc', 'end_utc')},
              'build_head': build['head'], 'binary_sha256': build['sha256'],
              'manifest_sha256': sha(directory / 'manifest.json'), 'preload_sha256': command['preload_sha256'],
              'product': product(directory, revision, build, 'short-large', 'live-subscriber', argv)}
    if mode == 'cpu':
        result['cpu'] = cpu_profile(directory, build, command, counts, args.raw_only)
    return result


def validate_snapshot(snapshot, revision):
    tables = snapshot['tables']
    require(tables and 'request_configurations' in tables,
            'schema-specific request_configurations presence differs')
    for name, table in tables.items():
        integer(table['rows'], name + ' rows')
        require(table['column_value_bytes'], name + ' has no column values')
        for column, value in table['column_value_bytes'].items():
            integer(value, name + '.' + column + ' bytes')
    require(all((name in tables) == (revision == 'baseline') for name in ('event_observation_readiness', 'transcript_observation_readiness')), 'readiness main/TEMP layout differs from recorded revision')
    event_columns = tables['events']['column_value_bytes']
    require({'observation_statistics', 'observation_execution', 'event_json'} <=
            event_columns.keys(), 'missing native/derived event columns')
    require('observation_json' not in event_columns,
            'retired event observation layout differs from the recorded revision')
    require('snapshot_json' in tables['request_snapshots']['column_value_bytes'], 'missing native snapshot column')
    if 'request_configurations' in tables:
        require(set(tables['request_configurations']['column_value_bytes']) == {'digest', 'configuration_json'},
                'request_configurations column shape differs')
    kinds = snapshot['events_by_kind']
    require(len({row['kind'] for row in kinds}) == len(kinds), 'duplicate event kind')
    require(all(row['column_value_bytes'].keys() == tables['events']['column_value_bytes'].keys()
                for row in kinds), 'event kind column shape differs')
    for row in kinds:
        integer(row['rows'], 'event kind rows')
        for column, value in row['column_value_bytes'].items():
            integer(value, 'event kind ' + column)
    require(sum(row['rows'] for row in kinds) == tables['events']['rows'], 'event kind rows do not sum')
    require(all(sum(row['column_value_bytes'][column] for row in kinds) == value
                for column, value in tables['events']['column_value_bytes'].items()),
            'event kind byte values do not sum')
    duplicate = snapshot['equal_event_observation_json']
    require(duplicate == {'status': 'retired_layout_absent', 'table': 'events',
                          'column': 'observation_json', 'rows': None, 'native_bytes': None},
            'retired event observation column must be absent, not reported as a measured zero')
    require(snapshot.get('scope') == 'main_database_only; connection-local TEMP owner state and virtual generated columns are outside this read-only connection measurement',
            'column snapshot must declare main-only storage scope')
    names = []
    for name, pages, payload, count in snapshot['dbstat']:
        names.append(name)
        integer(pages, 'dbstat page bytes')
        integer(payload, 'dbstat payload bytes')
        integer(count, 'dbstat page count')
        require(payload <= pages, 'dbstat payload exceeds allocated page bytes')
    require(len(set(names)) == len(names), 'duplicate dbstat object')


def row_delta(before, after):
    require(before['column_value_bytes'].keys() == after['column_value_bytes'].keys(), 'column identity changed')
    values = {column: after['column_value_bytes'][column] - value
              for column, value in before['column_value_bytes'].items()}
    return {'rows': after['rows'] - before['rows'], 'column_value_bytes': values,
            'total_column_value_bytes': sum(values.values())}


def columns(args, revision, case, identities):
    directory = args.root / f'columns-{revision}-{case}'
    build = identities[revision]
    require(load(directory / 'identity-before.json')['build'] == build, 'column build identity differs')
    require(load(directory / 'phases.json') == PHASES, 'column synchronous phase sequence differs')
    argv = [build['binary'], TEST, '--exact', '--ignored', '--nocapture']
    prod = product(directory, revision, build, case, 'no-live-subscriber', argv)
    before, after = load(directory / 'before_measured_turns.json'), load(directory / 'after_turns.json')
    for snapshot in (before, after):
        validate_snapshot(snapshot, revision)
    require(before['path'] == after['path'] and before['tables'].keys() == after['tables'].keys(),
            'column database/table identity changed during measured phase')
    delta = {name: row_delta(table, after['tables'][name]) for name, table in before['tables'].items()}
    require(delta['events']['rows'] == 256 and delta['request_snapshots']['rows'] == 32,
            'measured native event/request count differs')
    before_kinds, after_kinds = ({row['kind']: row for row in snapshot['events_by_kind']}
                                for snapshot in (before, after))
    kinds = {}
    empty = {'rows': 0, 'column_value_bytes': dict.fromkeys(before['tables']['events']['column_value_bytes'], 0)}
    for name in sorted(before_kinds.keys() | after_kinds.keys(), key=str):
        kinds[str(name)] = row_delta(before_kinds.get(name, empty), after_kinds.get(name, empty))
    totals = {label: sum(sum(table['column_value_bytes'].values()) for table in snapshot['tables'].values())
              for label, snapshot in [('before', before), ('after', after)]}
    total_delta = sum(row['total_column_value_bytes'] for row in delta.values())
    require(total_delta == totals['after'] - totals['before'], 'logical total arithmetic differs')
    configurations = {label: snapshot['tables'].get('request_configurations')
                      for label, snapshot in [('before', before), ('after', after)]}
    return {'revision': revision, 'case': case, 'build_head': build['head'], 'binary_sha256': build['sha256'],
            'product': prod, 'before_sha256': sha(directory / 'before_measured_turns.json'),
            'after_sha256': sha(directory / 'after_turns.json'), 'phases_sha256': sha(directory / 'phases.json'),
            'logical_totals': totals, 'total_logical_delta': total_delta, 'table_deltas': delta,
            'event_kind_deltas': kinds, 'request_configurations_retained': configurations,
            'equal_event_observation_json': {label: snapshot['equal_event_observation_json']
                                            for label, snapshot in [('before', before), ('after', after)]},
            'timing_isolation': 'Synchronous phase acknowledgments and exact phase order verified. '
                                'The separately audited serial wrapper brackets this column producer with UTC timestamps; no timing values are mixed with formal products.'}


def comparison(before, after):
    return {'baseline': before, 'complete': after, 'difference': after - before,
            'complete_over_baseline': None if before == 0 else after / before}


def column_comparisons(rows):
    result = []
    for case in ('short-small', 'short-large'):
        pair = {row['revision']: row for row in rows if row['case'] == case}
        if pair.keys() != {'baseline', 'complete'}:
            continue
        before, after = pair['baseline'], pair['complete']
        fields = {'all_logical': comparison(before['total_logical_delta'], after['total_logical_delta'])}
        selected = [('request_snapshots_all', 'request_snapshots', None),
                    ('request_source_pages', 'request_source_pages', None),
                    ('native_snapshot_json', 'request_snapshots', 'snapshot_json'),
                    ('native_event_json', 'events', 'event_json'),
                    ('observation_event_json', 'events', 'observation_json'),
                    ('event_statistics', 'events', 'observation_statistics'),
                    ('event_execution', 'events', 'observation_execution')]
        for label, table, column in selected:
            def value(row):
                data = row['table_deltas'][table]
                return data['total_column_value_bytes'] if column is None else data['column_value_bytes'][column]
            if column is not None and column not in after['table_deltas'][table]['column_value_bytes']:
                require((table, column) == ('events', 'observation_json'),
                        'unexpected missing comparison column')
                fields[label] = {'baseline': (value(before) if column in before['table_deltas'][table]['column_value_bytes'] else None), 'complete': None, 'difference': None,
                                 'complete_over_baseline': None, 'status': 'retired_layout_absent',
                                 'note': 'Final events schema omits this former column; absence is not a measured zero. Total logical bytes include only actual stored columns.'}
            else:
                fields[label] = comparison(value(before), value(after))
        # Both schemas retain shared configuration. Include each revision's
        # actual measured configuration delta in its native snapshot total.
        config = after['table_deltas']['request_configurations']['total_column_value_bytes']
        fields['native_snapshot_and_configuration'] = comparison(
            before['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + before['table_deltas']['request_configurations']['total_column_value_bytes'],
            after['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + config)
        all_tables = {}
        for table in sorted(before['table_deltas'].keys() | after['table_deltas'].keys()):
            b, a = before['table_deltas'].get(table), after['table_deltas'].get(table)
            values = (comparison(b['total_column_value_bytes'], a['total_column_value_bytes']) if b is not None and a is not None else
                      {'baseline': None if b is None else b['total_column_value_bytes'], 'complete': None if a is None else a['total_column_value_bytes'],
                       'difference': None, 'complete_over_baseline': None, 'status': 'outside_measured_main_layout',
                       'note': 'Table absence from main is explicit. Connection-local TEMP memory/state is not observable from this collector and is not assigned zero.'})
            all_tables[table] = {'present_in_baseline': b is not None, 'present_in_complete': a is not None, **values}
        result.append({'case': case, 'logical_bytes': fields, 'all_table_logical_bytes': all_tables,
                       'shared_configuration_measured_delta': {'baseline': before['table_deltas']['request_configurations']['total_column_value_bytes'], 'complete': config},
                       'shared_configuration_note': 'Both revision retained totals are in columns; '
                                                    'seeded shared payload is not charged again as a measured-turn insertion; both schemas retain it.'})
    return result


PI_REVISION = '90d863f7c1183b965f099855715d6e88c7b8a52c'
PI_PHASES = [p for p in PHASES if p not in ('after_shutdown','after_driver_drop')]

def phase_points(path, expected=PHASES):
    points = load(path)
    require([p['phase'] for p in points] == expected, 'synchronous phase inventory differs')
    ticks = [integer(p['monotonic_ns'], 'phase time', 1) for p in points]
    require(all(a < b for a,b in zip(ticks,ticks[1:])), 'phase times not strictly increasing')
    return points, {p['phase']:p['monotonic_ns'] for p in points}


def sql_diagnostic(args, name, build, revision, tx):
    directory = args.root/name
    identity = load(directory/'identity.json')
    require(identity['build_identity'] == build and identity['binary']==build['binary'], 'SQL binary identity differs')
    require(identity['accepted'] is True and identity['errors']==[] and
            all(identity[k] is True for k in ('thread_finished','binary_unchanged','runner_unchanged','gdb_script_unchanged')), 'SQL run incomplete or mutated')
    window(identity['start_utc'],identity['end_utc'])
    script = 'sql-prepare-tx.gdb.py' if tx else 'sql-prepare.gdb.py'
    runner = 'run-sql-prepare-tx.py' if tx else 'run-sql-prepare.py'
    require(sha(args.root/script)==identity['gdb_script_sha256'] and sha(args.root/runner)==identity['runner_sha256'], 'SQL probe/runner hash differs')
    argv=identity['argv']
    require(argv[:4]==['gdb','--quiet','--nx','--batch'] and argv[-6:]==['--args',build['binary'],TEST,'--exact','--ignored','--nocapture'], 'SQL debugger argv differs')
    require('source '+str(args.root/script) in argv or any(v.startswith('source ') and Path(v[7:]).name==script for v in argv), 'SQL probe argv differs')
    prod=product(directory,revision,build,'short-large','no-live-subscriber',argv)
    points,times=phase_points(directory/'phases.json')
    start,end=times['before_measured_turns'],times['after_turns']
    count=collections.Counter(); flags=collections.Counter(); stacks=collections.Counter(); calls=0; measured=0; previous=0; connection=collections.Counter(); threads=collections.Counter()
    with (directory/'prepares.jsonl').open() as stream:
        for line in stream:
            row=json.loads(line); require('error' not in row, 'debugger emitted error')
            timestamp=integer(row['monotonic_ns'],'prepare timestamp',1)
            require(timestamp>=previous,'prepare timestamps reversed');previous=timestamp
            require(isinstance(row['sql'],str) and row['sql'], 'empty SQL')
            flag=integer(row['flags'],'prepare flags');integer(row['connection'],'connection',1);integer(row['thread'],'thread',1)
            calls+=1
            if start<=timestamp<end:
                measured+=1;count[(flag,row['sql'])]+=1;flags[flag]+=1;connection[row['connection']]+=1;threads[row['thread']]+=1
                if tx and row['sql']=='BEGIN IMMEDIATE':
                    stack=row.get('first_call_stack')
                    require(stack and stack[0]=='sqlite3_prepare_v3' and len(stack)<=24,'missing write-BEGIN call stack')
                    stacks[tuple(stack)]+=1
    require(measured>0,'no measured SQL calls')
    result={'whole_prepare_calls':calls,'measured_prepare_calls':measured,'measured_turns':32,'unique_flag_sql':len(count),
            'flags':{str(k):v for k,v in sorted(flags.items())},
            'counts':[{'flags':f,'sql':s,'count':n} for (f,s),n in count.most_common()]}
    retained=directory/'prepare-counts.json'
    if retained.exists():
        saved=load(retained)
        require(all(saved[k]==result[k] for k in result if k!='counts'), 'retained SQL total differs')
        require({(r['flags'],r['sql']):r['count'] for r in saved['counts']}==dict(count),'retained SQL shape counts differ')
    tx_summary=directory/'write-transaction-stacks.json'
    if tx_summary.exists():
        require(tx and {tuple(r['stack']):r['count'] for r in load(tx_summary)}==dict(stacks),'retained write-BEGIN stacks differ')
    return {'name':name,'revision':revision,'identity':identity,'identity_sha256':sha(directory/'identity.json'),
            'phases':points,'phases_sha256':sha(directory/'phases.json'),'raw_sha256':sha(directory/'prepares.jsonl'),
            'product':prod,**result,'calls_per_measured_turn':measured/32,
            'measured_connection_counts':dict(connection),'measured_thread_counts':dict(threads),
            'write_begin_prepare_stacks':[{'count':n,'stack':list(s)} for s,n in stacks.most_common()],
            'limitations':'sqlite3_prepare_v3 invocations, not executions of cached statements. BEGIN IMMEDIATE stack counts are preparation observations, not independently proved commits; compare the separately traced WAL. Intrusive debugger timings are excluded from formal performance comparisons.'}


def pi_product(directory, case, argv):
    raw,proc=load(directory/'sample.json'),load(directory/'sample.process.json')
    count=(8 if case=='short-small' else 64)+32
    require(proc['accepted'] is True and proc['argv']==argv and proc['case']==case and proc['observer_mode']=='no-live-subscriber' and proc['product_exit']==proc['provider_exit']==0,'Pi diagnostic product failed')
    require(raw['oracle']=='passed' and raw['revision']==PI_REVISION and raw['scenario']==case and raw['workload_version']==3 and raw['measured']==32 and len(raw['samples'])==count,'Pi oracle/revision/dimensions differ')
    provider=proc['provider_report']
    require(provider['complete'] is True and provider['ok'] is True and provider['failures']==[] and provider['requestCount']==provider['stepsTotal']==provider['stepsMatched']==provider['stepsSettled']==count and provider['stepStates']==['settled']*count,'Pi provider admission differs')
    require([capture['messages'] for capture in raw['captures']]==raw['reopenedRequests'] and raw['requests']==provider['requests'] and len(raw['requests'])==count,'Pi reopened native requests differ')
    require([r['phase'] for r in raw['lifecycle']]==[p for p in PI_PHASES if p!='before_measured_turns'],'Pi lifecycle differs')
    return {'accepted':True,'request_count':count,'sample_sha256':sha(directory/'sample.json'),'process_sha256':sha(directory/'sample.process.json'),'revision':PI_REVISION}


def wal_frames(directory, before, after, expected_phases):
    owners=collections.defaultdict(set)
    for snapshot in (before,after):
        require(snapshot['counts'] and snapshot['pages'] and snapshot['tables'],'empty database snapshot')
        for name,page,kind,cells,payload in snapshot['pages']:
            integer(page,'page',1);integer(cells,'cells');integer(payload,'payload');owners[page].add(name)
    require(before['path']==after['path'],'WAL target database changed')
    frames=collections.Counter();commits=0;pending={};phase='startup';allcommits=collections.Counter();txpages=[];tx=collections.Counter();active=False;seen=[];payloads=0;frame_bytes=0
    with (directory/'calls.strace').open() as stream:
        for line in stream:
            m=re.match(r'(\d+)\s+(.*)',line)
            if not m:continue
            pid,call=m.groups()
            if '<unfinished ...>' in call:
                require(pid not in pending,'duplicate unfinished syscall');pending[pid]=call.split('<unfinished ...>')[0];continue
            m=re.match(r'<\.\.\. \w+ resumed>(.*)',call)
            if m:
                require(pid in pending,'resumed syscall has no start');call=pending.pop(pid)+m[1]
            if 'UNIX-STREAM' in call:
                for boundary in expected_phases:
                    if '"'+boundary+'"' in call or '"'+boundary+'\\n"' in call:
                        seen.append(boundary)
                        if boundary=='before_measured_turns':phase='steady';active=True
                        elif boundary=='after_turns':phase='after_turns';active=False
                        break
            m=re.match(r'pwrite64\(\d+<([^>]+-wal)>, (.*), (\d+), (\d+)\) = (\d+)$',call)
            if not m:continue
            target,quoted,n,offset,ret=m.groups();n,offset,ret=map(int,(n,offset,ret));require(ret==n,'short WAL write')
            if active:
                require(target==before['path']+'-wal','unexpected measured WAL target')
                require(n in (24,32,4096),'unsupported measured WAL write shape')
                if n==4096:payloads+=1;require((offset-56)%4120==0,'WAL payload misaligned')
            if n!=24:continue
            data=ast.literal_eval('b'+quoted);require(len(data)==24,'bad frame header bytes')
            page,size=struct.unpack('>II',data[:8]);require(page>0 and (offset-32)%4120==0,'bad WAL frame geometry')
            if active:frames[page]+=1;tx[page]+=1;frame_bytes+=4120
            if size:
                allcommits[phase]+=1
                if active:commits+=1;txpages.append(sum(tx.values()));tx.clear()
    require(not pending and not tx and phase=='after_turns' and commits>0,'unclosed trace/transaction or missing measured commits')
    require(seen==expected_phases,'strace boundary phase inventory differs')
    require(payloads==sum(frames.values()),'WAL frame headers and page payload counts differ')
    bytable=collections.Counter()
    for page,n in frames.items():bytable['|'.join(sorted(owners[page])) or '<unmapped>']+=n
    delta={k:after['counts'][k]-before['counts'].get(k,0) for k in after['counts'] if after['counts'][k]!=before['counts'].get(k,0)}
    return {'steady_turns':32,'wal_write_commits':commits,'wal_frames':sum(frames.values()),'wal_frame_bytes':frame_bytes,
            'commits_by_phase':dict(allcommits),'wal_frames_by_snapshot_page_owner':dict(bytable.most_common()),
            'net_row_count_changes':delta,'transaction_page_counts':txpages,
            'raw_sha256':sha(directory/'calls.strace'),'matched_page_payloads':payloads,
            'limits':'WAL commit markers exclude read-only commits. Snapshot page owners are endpoint classifications, not exact ownership at each write; mixed and unmapped owners remain explicit. WAL bytes are not process write_bytes/device traffic and are not attributed CPU time.'}


def wal_diagnostic(args, label, build, case, engine):
    directory=args.root/f'wal-{label}-{case}-{engine}'
    identity=load(directory/'identity-before.json')
    require(identity['build']==build and identity['binary_sha256']==build['sha256'] and identity['pi_revision']==PI_REVISION,'WAL build/source identity differs')
    whole=load(args.root/f'wal-identity-{label}.json')
    require(whole['rust_sha256']==build['sha256'] and whole['rust_source']==build['head'] and whole['pi_revision']==PI_REVISION,'WAL whole-run identity differs')
    script=args.root/f'pi-http-wal-{label}.mjs'
    require(sha(script)==identity['driver_sha256'],'WAL Pi driver hash differs')
    runner=args.root/'run-wal-compact.py'
    require(sha(runner)==identity['runner_sha256'],'WAL producer hash differs')
    argv=identity['argv']
    if engine=='rust':
        require(argv==[build['binary'],TEST,'--exact','--ignored','--nocapture'],'WAL Rust argv differs')
        prod=product(directory,label,build,case,'no-live-subscriber',argv);expected=PHASES
    else:
        require(argv[:2]==['node','--conditions=source'] and Path(argv[2]).name==script.name and argv[-2]==case and Path(argv[-1]).name=='sample.json','WAL Pi argv differs')
        prod=pi_product(directory,case,argv);expected=PI_PHASES
    points,times=phase_points(directory/'phases.json',expected)
    records=load(args.root/f'wal-records-{label}.json')
    require([(r['case'],r['engine']) for r in records]==[(c,e) for c in ('short-small','short-large') for e in ('rust','pi')],'WAL command inventory differs')
    require(all(r['accepted'] is True and r['error'] is None and r['diagnostic_error']==[] and 0<r['start_ns']<r['end_ns'] for r in records),'WAL command admission differs')
    require(all(a['end_ns']<=b['start_ns'] for a,b in zip(records,records[1:])),'WAL commands overlap')
    record=next(r for r in records if r['case']==case and r['engine']==engine)
    require(record['start_ns']<=points[0]['monotonic_ns']<points[-1]['monotonic_ns']<=record['end_ns'],'WAL boundaries outside command')
    before_list=load(directory/'before_measured_turns-database.json');after_list=load(directory/'after_turns-database.json')
    require(len(before_list)==len(after_list)==1,'WAL database snapshot inventory differs')
    derived=wal_frames(directory,before_list[0],after_list[0],expected)
    retained=load(args.root/f'wal-summary-{label}.json')[case+'-'+engine]
    require(all(retained[k]==derived[k] for k in retained if k!='limitations'),'retained WAL arithmetic differs')
    pair=load(args.root/f'wal-{label}-{case}-comparison.json')
    require(pair['workload_version']==3 and pair['case']==case and pair['observer_mode']=='no-live-subscriber' and len(pair['checked'])==prod['request_count'],'WAL request comparison shape differs')
    require(all(r['index']==i and r['coreSemanticEqual'] is True and r['fullSemanticRequestEqual'] is False and len(r['rustToolNames'])==7 and len(r['piToolNames'])==4 for i,r in enumerate(pair['checked'])),'WAL core semantics/tool mismatch evidence differs')
    return {'label':label,'case':case,'engine':engine,'identity':identity,'identity_sha256':sha(directory/'identity-before.json'),
            'phases':points,'phases_sha256':sha(directory/'phases.json'),'command':record,'product':prod,
            'before_sha256':sha(directory/'before_measured_turns-database.json'),'after_sha256':sha(directory/'after_turns-database.json'),
            'comparison_sha256':sha(args.root/f'wal-{label}-{case}-comparison.json'),'whole_identity_sha256':sha(args.root/f'wal-identity-{label}.json'),'summary':derived,
            'cross_engine_scope':pair['equality_scope'],'full_native_tool_equality':False}


def formal_binding(args, identities, timed):
    audit=load(args.formal_audit)
    require(audit['accepted'] is True and audit['errors']==[],'formal audit not accepted')
    require(audit['mode'] in ('strict','raw-only'),'unknown formal audit mode')
    if not args.raw_only:require(audit['mode']=='strict' and audit['strict_identity_verified'] is True,'strict formal identity missing')
    require(set(audit['identities'])=={'baseline','complete'},'formal identity labels differ')
    for label,build in identities.items():
        keys=('head','production_tree','sha256','harness','rustc')
        require({k:audit['identities'][label].get(k) for k in keys}=={k:build.get(k) for k in keys},'formal build differs: '+label)
    require(set(audit['datasets'])=={'direct','final','three-engine'},'formal datasets incomplete')
    for label,count in [('direct',120),('final',120),('three-engine',36)]:
        require(audit['datasets'][label]['derived_products']==count,'formal dataset count differs: '+label)
    require(set(audit['queue_states'])=={'direct','final'},'formal queue inventory differs')
    spans=[]
    for label,queue in audit['queue_states'].items():
        before,after=queue['source_before'],queue['source_after']
        require({k:v for k,v in before.items() if k!='utc'}=={k:v for k,v in after.items() if k!='utc'},'formal sources changed')
        require(before['production_tree']==identities['complete']['production_tree'] and before['schema']==80,'formal source/schema mismatch')
        span=window(before['utc'],after['utc']);spans.append(span)
        for name,start,end in timed:require(disjoint(span,window(start,end)),f'{name} overlaps formal {label}')
    require(disjoint(*spans),'formal queues overlap')
    return {'file':str(args.formal_audit),'sha256':sha(args.formal_audit),'mode':audit['mode'],
            'strict_identity_verified':audit['strict_identity_verified'],'products':276,
            'measurement_windows':audit.get('measurement_windows',[]),
            'source_windows':{label:{k:queue[k]['utc'] for k in ('source_before','source_after')} for label,queue in audit['queue_states'].items()},
            'scope':'Formal auditor owns its raw semantic/metric arithmetic. Here build identity, final counts and known UTC diagnostic-window non-overlap are checked. WAL monotonic and column phase-only boundaries do not independently prove UTC isolation.'}


def archive(args):
    rows=load(args.root/'baseline-archive.json')
    require(rows and len({r['archive'] for r in rows})==len(rows),'baseline archive inventory invalid')
    for row in rows:
        relative=Path(row['archive']);require(not relative.is_absolute() and '..' not in relative.parts,'unsafe archive path')
        require(sha(args.root/relative)==row['sha256'],'archived baseline file changed')
    return {'manifest_sha256':sha(args.root/'baseline-archive.json'),'files':rows,
            'scope':'Archived retained files match declared hashes; source paths are provenance only and never dereferenced by this audit.'}



def producer_windows(args):
    wrapper=args.root/'diagnostic-commands.json'
    rows=load(wrapper)
    expected=['columns-baseline','columns-complete','profiles','profile-reports',
              'sql-baseline-tx-no-live','sql-complete-tx-no-live',
              'wal-baseline','wal-summary-baseline','wal-complete','wal-summary-complete']
    require([r['name'] for r in rows]==expected,'diagnostic wrapper inventory/order differs')
    before,after=load(args.baseline_identity),load(args.candidate_identity)
    expected_commands={}
    for label,build in [('baseline',before),('complete',after)]:
        expected_commands['columns-'+label]=('columns-complete.py',['--binary',build['binary'],'--label',label])
        expected_commands['sql-'+label+'-tx-no-live']=('run-sql-prepare-tx.py',['--binary',build['binary'],'--name','sql-'+label+'-tx-no-live'])
        expected_commands['wal-'+label]=('run-wal-compact.py',['--binary',build['binary'],'--label',label])
        expected_commands['wal-summary-'+label]=('analyze-wal-verified.py',['--label',label])
    expected_commands.update({'profiles':('run-profiles.py',[]),'profile-reports':('profile-reports.py',[])})
    for row in rows:
        require(row['status']=='complete' and row['exit']==0,'diagnostic wrapper incomplete')
        window(row['start_utc'],row['end_utc'])
        command=row['command'];require(isinstance(command,list) and len(command)>=2 and Path(command[0]).name.startswith('python'),'diagnostic wrapper interpreter absent')
        producer=Path(command[1]).name
        require((producer,command[2:])==expected_commands[row['name']],'diagnostic wrapper argv differs')
        require((args.root/producer).is_file() and row['producer_sha256']==sha(args.root/producer),'diagnostic wrapper producer hash differs')
        require(all((args.root/(row['name']+suffix)).is_file() for suffix in ('.stdout','.stderr')),'diagnostic wrapper log absent')
    spans=[window(r['start_utc'],r['end_utc']) for r in rows]
    require(all(a[1]<=b[0] for a,b in zip(spans,spans[1:])),'diagnostic wrapper commands overlap/out of order')
    left,right=(load(args.root/('diagnostic-source-'+side+'.json')) for side in ('before','after'))
    require({k:v for k,v in left.items() if k!='utc'}=={k:v for k,v in right.items() if k!='utc'},'diagnostic source or runner changed')
    build=load(args.candidate_identity)
    require(left['files']==build['source_files'] and left['runner_sha256']==sha(args.root/'run-diagnostics.py'),'diagnostic source/build/runner binding differs')
    fixtures=left.get('fixtures')
    require(isinstance(fixtures,dict) and fixtures and all(not Path(name).is_absolute() and '..' not in Path(name).parts and re.fullmatch('[0-9a-f]{64}',digest) for name,digest in fixtures.items()),'diagnostic runtime fixture binding missing/invalid')
    formal=load(args.formal_audit)
    require(all(queue['source_before']['fixtures']==fixtures for queue in formal['queue_states'].values()),'diagnostic/formal runtime fixture bytes differ')
    require(utc(left['utc'])<=spans[0][0] and spans[-1][1]<=utc(right['utc']),'diagnostic source snapshots do not bracket all producers')
    if not args.raw_only:
        require(all(sha(args.repo/name)==digest for name,digest in left['files'].items()),'current diagnostic source differs')
        actual={str(path.relative_to(args.repo)):sha(path) for path in sorted((args.repo/'benchmarks/runtime').rglob('*')) if path.is_file() and '__pycache__' not in path.parts}
        require(actual==fixtures,'current diagnostic fixture inventory differs')
    return {'wrappers':rows,'wrapper_sha256':sha(wrapper),'source_before_sha256':sha(args.root/'diagnostic-source-before.json'),
            'source_after_sha256':sha(args.root/'diagnostic-source-after.json'),'verified':True,
            'scope':'Both baselines and candidate products are newly collected under this serialized wrapper; every source and producer hash is rechecked. Nested profile/SQL windows and formal queues are checked independently.'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=HERE)
    parser.add_argument('--repo',type=Path,default=REPO)
    parser.add_argument('--baseline-identity',type=Path)
    parser.add_argument('--candidate-identity',type=Path)
    parser.add_argument('--formal-audit',type=Path)
    parser.add_argument('--expect-rust-sha256')
    parser.add_argument('--raw-only',action='store_true')
    parser.add_argument('--allow-pending',action='store_true',help='Missing future artifacts are pending, never accepted; malformed existing evidence still fails.')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    args.baseline_identity=args.baseline_identity or args.root/'baseline-build/identity.json'
    args.candidate_identity=args.candidate_identity or args.root/'candidate-complete-build/identity.json'
    args.formal_audit=args.formal_audit or args.root/'complete-all-audit.json'
    output=args.output or args.root/('diagnostic-raw-audit.json' if args.raw_only else 'diagnostic-audit.json')
    require(not output.exists(), 'audit output already exists; retain it and choose a new --output path')
    report={'accepted':False,'mode':'raw-only' if args.raw_only else 'strict','allow_pending':args.allow_pending,
        'script_sha256':sha(__file__),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'errors':[],'pending':[],'build_receipts':{},'identities':{},'profiles':[],'columns':[],'sql':[],'wal':[],
        'column_comparison':[],'profile_comparison':[],'wal_comparison':[],'sql_comparison':None,
        'recorded_build_identity_verified':False,'actual_binary_and_preload_verified':False,'strict_identity_verified':False}
    def check(label,fn):
        try:return fn()
        except FileNotFoundError as error:
            (report['pending'] if args.allow_pending else report['errors']).append(f'{label}: missing {error.filename}')
        except Exception as error:report['errors'].append(f'{label}: {type(error).__name__}: {error}')
        return None
    plan=check('plan',lambda:load(args.root/'plan.json'))
    if plan is not None:check('pinned plan',lambda:require(plan['baseline_commit']==BASELINE_HEAD and plan['baseline_sha256']==BASELINE_SHA,'predeclared baseline differs'))
    report['baseline_archive']=check('baseline archive',lambda:archive(args))
    report['producer_windows']=check('producer command windows',lambda:producer_windows(args))
    identities={}
    for label in ('baseline','complete'):
        result=check(label+' ordinary build',lambda label=label:verify_build(args,label))
        if result:
            build,receipt=result;identities[label]=build;report['build_receipts'][label]=receipt
            report['identities'][label]={k:build.get(k) for k in ('head','production_tree','sha256','harness','rustc')}
    if len(identities)==2:
        check('build pair',lambda:require(all(identities['baseline'][k]==identities['complete'][k] for k in ('harness','rustc','cargo')) and identities['baseline']['sha256']!=identities['complete']['sha256'],'same-harness build pair differs'))
        report['recorded_build_identity_verified']=True
    for revision,build in identities.items():
        for case in ('short-small','short-large'):
            row=check(f'columns-{revision}-{case}',lambda revision=revision,case=case:columns(args,revision,case,identities))
            if row:report['columns'].append(row)
        names=[(f'sql-{revision}-tx-no-live',True)]
        for name,tx in names:
            row=check(name,lambda name=name,tx=tx,build=build,revision=revision:sql_diagnostic(args,name,build,revision,tx))
            if row:report['sql'].append(row)
        for case in ('short-small','short-large'):
            for engine in ('rust','pi'):
                row=check(f'wal-{revision}-{case}-{engine}',lambda revision=revision,build=build,case=case,engine=engine:wal_diagnostic(args,revision,build,case,engine))
                if row:report['wal'].append(row)
    commands=check('profile commands',lambda:load(args.root/'profile-commands.json'))
    records=check('CPU count summary',lambda:load(args.root/'cpu-counts.json'))
    if commands is not None:
        def profile_inventory():
            require([r['name'] for r in commands]==PROFILE_NAMES,'profile command inventory differs')
            spans=[window(r['start_utc'],r['end_utc']) for r in commands]
            require(all(a[1]<=b[0] for a,b in zip(spans,spans[1:])),'profiles overlap/out of order')
            require(commands[1]['preload_sha256']==commands[3]['preload_sha256'],'profile preload pair differs')
        check('profile inventory',profile_inventory)
    if records is not None:
        check('CPU inventory',lambda:require(len(records)==2 and {r['name'] for r in records}=={n for n in PROFILE_NAMES if n.endswith('-cpu')},'CPU count inventory differs'))
    if commands is not None and records is not None:
        counts={r['name']:r for r in records}
        for command in commands:
            label=command['name'].split('-')[1]
            if label in identities:
                row=check(command['name'],lambda command=command:profile(args,command,identities,counts))
                if row:report['profiles'].append(row)
    report['column_comparison']=check('column comparison arithmetic',lambda:column_comparisons(report['columns'])) or []
    for revision in ('baseline','complete'):
        pair={r['mode']:r for r in report['profiles'] if r['revision']==revision}
        if pair.keys()=={'control','cpu'}:
            report['profile_comparison'].append({'revision':revision,'metrics':{
                key:{'control':pair['control']['product'][key],'cpu':pair['cpu']['product'][key],
                     'cpu_over_control':None if pair['control']['product'][key]==0 else pair['cpu']['product'][key]/pair['control']['product'][key]}
                for key in ('mean_measured_turn_ms','measured_phase_self_cpu_ticks','measured_phase_process_write_bytes','full_self_cpu_ticks','full_process_write_bytes')},
                'interpretation':'Instrumentation/control overhead only. Inclusive sampled stacks overlap; no sum, exclusive-time attribution, or causal gain is computed.'})
    sqlpair={r['revision']:r for r in report['sql'] if '-tx-' in r['name']}
    if sqlpair.keys()=={'baseline','complete'}:
        report['sql_comparison']={k:comparison(sqlpair['baseline'][k],sqlpair['complete'][k]) for k in ('measured_prepare_calls','unique_flag_sql')}
    for case in ('short-small','short-large'):
        for engine in ('rust','pi'):
            pair={r['label']:r for r in report['wal'] if r['case']==case and r['engine']==engine}
            if pair.keys()=={'baseline','complete'}:
                report['wal_comparison'].append({'case':case,'engine':engine,'metrics':{k:comparison(pair['baseline']['summary'][k],pair['complete']['summary'][k]) for k in ('wal_write_commits','wal_frames','wal_frame_bytes')}})
    timed=[(r['name'],r['identity']['start_utc'],r['identity']['end_utc']) for r in report['sql']]
    timed.extend((r['name'],r['window']['start_utc'],r['window']['end_utc']) for r in report['profiles'])
    check('UTC diagnostic isolation',lambda:require(all(disjoint(window(a[1],a[2]),window(b[1],b[2])) for i,a in enumerate(timed) for b in timed[i+1:]),'diagnostic UTC windows overlap'))
    formal_timed=list(timed)
    if report['producer_windows']:
        records=report['producer_windows']['wrappers']
        formal_timed.extend((r['name'],r['start_utc'],r['end_utc']) for r in records)
    if len(identities)==2:report['formal_audit']=check('formal identity and UTC binding',lambda:formal_binding(args,identities,formal_timed))
    else:report['formal_audit']=None
    complete=(len(report['profiles'])==4 and len(report['columns'])==4 and len(report['sql'])==2 and len(report['wal'])==8 and report['formal_audit'] is not None and len(identities)==2)
    if not complete:
        (report['pending'] if args.allow_pending else report['errors']).append('Incomplete required diagnostic coverage: 2 ordinary builds, 4 profiles, 4 columns, 2 SQL-TX runs, 8 WAL runs and accepted complete-all formal binding required.')
    report['limits']=[
        'Diagnostic products are not pooled with formal medians. Debugger, strace, synchronized database reads and CPU sampling perturb execution.',
        'SQL prepare counts are not SQL step counts or timings; cached statement executions are absent. BEGIN IMMEDIATE preparation stacks do not independently establish committed write transactions.',
        'CPU inclusive stacks overlap and must not be summed as exclusive costs or independent gains; zero samples are not proof of no execution. Retained symbols are count/hash checked, not independently re-symbolized.',
        'WAL frame/commit counts are independently parsed from syscall bytes and exact phase boundaries. Endpoint dbstat ownership cannot exclude intermediate page reuse. WAL commit markers omit read-only commits.',
        'Main-only logical retained column bytes exclude connection-local TEMP and virtual generated columns, include textual numeric lengths, omit overwritten/deleted intermediate values, and are not WAL frames, process write_bytes, device bytes or CPU time.',
        'Connection-epoch ready/direct is not durably retained across reopen. A new owner adopts committed J/T as baseline; old-process installation/publication completion is deliberately not reconstructed. Current-epoch gating and transaction rollback remain distinct checks.',
        'SQL/profile UTC command windows are checked against formal queues. WAL records use monotonic intervals; column producers may record only phases. Cross-clock wall-time isolation is not fabricated when no wrapper timestamps exist.',
        'Rust/Pi requests pass core semantic checks but native tools differ (7 versus 4); full request equality is explicitly false. Different engine durability/flush boundaries remain outside this diagnostic equivalence claim.',
        'Raw-only reads only the selected retained archive and explicit identity/formal paths; it never follows embedded binary/preload/workspace/database paths. Strict mode verifies actual binaries/preloads plus source/harness identities.',
        '--allow-pending never sets accepted for incomplete evidence and never forgives malformed existing artifacts.'
    ]
    report['accepted']=complete and not report['errors'] and not report['pending']
    report['actual_binary_and_preload_verified']=report['accepted'] and not args.raw_only
    report['strict_identity_verified']=report['accepted'] and not args.raw_only
    output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(output),'accepted':report['accepted'],'errors':report['errors'],'pending':report['pending'],
          'counts':{k:len(report[k]) for k in ('profiles','columns','sql','wal')}},indent=2))
    return 0 if report['accepted'] or (args.allow_pending and not report['errors']) else 1


if __name__=='__main__':
    raise SystemExit(main())
