#!/usr/bin/env python3
"""Verify supplemental profiles after the separate canonical archive verifier succeeds.

Uses its existing extraction. Never changes the raw tree or runs products,
builds, profilers, symbolization or the canonical 18/276 auditors again.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys

sys.dont_write_bytecode = True


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    return json.loads(path.read_text())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def compare(raw, strict):
    require(strict['accepted'] is True and strict['strict_identity_verified'] is True and strict['mode'] == 'strict'
            and strict['errors'] == [] and strict['product_count'] == 8, 'retained supplemental strict audit failed')
    require(raw['accepted'] is True and raw['strict_identity_verified'] is False and raw['mode'] == 'raw-only'
            and raw['errors'] == [] and raw['product_count'] == 8, 'supplemental raw-only audit failed')
    exclude = {'started_utc', 'finished_utc', 'mode', 'strict_identity_verified'}
    left = {key: value for key, value in raw.items() if key not in exclude}
    right = {key: value for key, value in strict.items() if key not in exclude}
    require(left == right, 'supplemental raw-only numerical/admission/source/identity records differ')
    return sorted(left)


def selected_inventory(root, manifest):
    names = {name for name in manifest['files'] if name.startswith('supplemental-small-profiles/')}
    required = {'audit-small-profiles.py', 'run-small-profiles.py', 'verify-small-profiles-archive.py',
                'audit-diagnostics.py', 'audit-complete.py', 'recompute-pi.py',
                'baseline-build/identity.json', 'baseline-build/build.stdout',
                'candidate-complete-build/identity.json', 'candidate-complete-build/build.stdout',
                'diagnostic-commands.json', 'diagnostic-source-after.json'}
    require(required <= manifest['files'].keys() and names, 'supplemental archive inputs absent')
    expected = {name: manifest['files'][name] for name in names | required}
    for name, record in expected.items():
        relative = PurePosixPath(name)
        require(not relative.is_absolute() and '..' not in relative.parts and str(relative) == name,
                'unsafe archived supplemental path')
        path = root / name
        require(stat.S_ISREG(path.lstat().st_mode), 'supplement input is not a regular file')
        require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'supplement input changed: ' + name)
    actual = set()
    for directory, folders, files in os.walk(root / 'supplemental-small-profiles', followlinks=False):
        directory = Path(directory)
        require(all(stat.S_ISDIR((directory / name).lstat().st_mode) for name in folders), 'symlink/non-directory in supplemental tree')
        actual.update((directory / name).relative_to(root).as_posix() for name in files)
    require(actual == names, 'extra/missing supplemental extraction files')
    return expected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-root', type=Path, required=True, help='Existing WORK/raw from canonical verify-archive.py')
    parser.add_argument('--canonical-verification', type=Path, required=True, help='Accepted canonical portable-verification.json')
    parser.add_argument('--work-dir', type=Path, required=True, help='New external directory for supplementary replay/logs')
    parser.add_argument('--output', type=Path, help='Defaults to WORK/supplemental-portable-verification.json')
    args = parser.parse_args()
    root, work = args.raw_root.resolve(), args.work_dir.resolve()
    output = (args.output or work / 'supplemental-portable-verification.json').resolve()
    require(not work.exists() and not work.is_relative_to(root) and not output.exists()
            and not output.is_relative_to(root), 'use new work/output paths outside extracted raw')
    work.mkdir(parents=True)
    report = {'accepted': False, 'errors': [], 'started_utc': now(), 'commands': [],
              'canonical_counts_changed': False, 'actual_host_binaries_reverified': False,
              'verification_script_sha256': sha(Path(__file__))}
    try:
        canonical = load(args.canonical_verification)
        require(canonical['accepted'] is True and canonical['errors'] == [] and canonical['formal_products'] == 276
                and canonical['raw_only_audits_accepted'] is True and canonical['post_audit_raw_inventory_and_hashes_unchanged'] is True,
                'canonical archive verification has not succeeded')
        require(Path(canonical['external_verification_directory']).resolve() / 'raw' == root,
                'raw root is not the canonical verified extraction')
        require(sha(root / 'MANIFEST.json') == canonical['manifest_sha256'], 'extracted manifest differs from canonical verification')
        manifest = load(root / 'MANIFEST.json')
        require(manifest['phases']['final_products'] == 276 and manifest['phases']['diagnostic_products'] == 18,
                'canonical matrix count changed')
        before = selected_inventory(root, manifest)
        require(sha(root / 'verify-small-profiles-archive.py') == sha(Path(__file__)), 'archive does not contain this exact supplementary verifier')
        strict_path = root / 'supplemental-small-profiles/audit.json'
        strict = load(strict_path)
        require(strict['script_sha256'] == sha(root / 'audit-small-profiles.py'), 'archived supplementary auditor changed')
        destination = work / 'small-raw-audit.json'
        command = ['python3', '-B', 'audit-small-profiles.py', '--root', '.', '--raw-only',
                   '--baseline-identity', 'baseline-build/identity.json',
                   '--candidate-identity', 'candidate-complete-build/identity.json', '--output', str(destination)]
        record = {'argv': command, 'cwd': str(root), 'start_utc': now()}
        report['commands'].append(record)
        environment = os.environ | {'PYTHONDONTWRITEBYTECODE': '1'}
        environment.pop('PYTHONPATH', None)
        environment.pop('PYTHONHOME', None)
        with (work / 'audit.stdout').open('x') as stdout, (work / 'audit.stderr').open('x') as stderr:
            result = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr)
        record.update(exit=result.returncode, end_utc=now(), stdout_sha256=sha(work / 'audit.stdout'), stderr_sha256=sha(work / 'audit.stderr'))
        require(result.returncode == 0, 'supplementary raw-only audit failed; see external logs')
        report['equal_fields'] = compare(load(destination), strict)
        require(selected_inventory(root, manifest) == before, 'supplemental raw tree changed during replay')
        report.update(accepted=True, product_count=8, canonical_formal_products=276, canonical_diagnostic_products=18,
                      archive_sha256=canonical['archive_sha256'], manifest_sha256=canonical['manifest_sha256'],
                      canonical_verification_sha256=sha(args.canonical_verification),
                      retained_strict_report_sha256=sha(strict_path), raw_only_report_sha256=sha(destination),
                      checked_input_files=len(before), all_checked_hashes_match=True,
                      scope='Eight separate post-hoc exploratory profiles; does not add to or alter canonical 18 diagnostics or 276 formal products.')
    except Exception as error:
        report['errors'].append(f'{type(error).__name__}: {error}')
    report['finished_utc'] = now()
    with output.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'output': str(output), 'accepted': report['accepted'], 'errors': report['errors']}), flush=True)
    return 0 if report['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
