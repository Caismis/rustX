# 本轮源码独立复核

审查范围：`/home/capi/.codex/worktrees/pr485-pi-performance/rustX`，基线 HEAD `bc5c5613d65dd06bea09cfccb61f7b4b32942371` 上的冻结工作树差异，包括新文件。审查时 root 正在执行 `checks-retry6`。本文件只报告静态源码审查及已存在的回归覆盖，不代表该队列已经通过；本审查没有构建、运行产品或修改仓库源码。

**结论：未发现需要阻止本轮验证的实质缺陷。** 关键改变确实减少独立持久化边界、重复 B-tree 和重复表示，而不是绕过原生请求或输出校验。下面列出实际语义、保留的约束和仍需在结果中明确的取舍。

## 1. 首次 Attempt + Turn 的固定原子边界

- `src/agent/execution.rs:1487` 只把首次 Attempt 候选延后到第一个 Turn；`pending_attempt.take()` 只消费一次。预先取消、interaction failure 或初始化失败仍写单独 Attempt 后进入原 terminal 路径。后续循环仍在创建下一 Turn 前检查取消，未变成任意事件批处理。
- `src/agent/execution.rs:1667` 与 `src/durable/sqlite/attempt_start.rs:9` 将两个有序原生事实放在一个 Immediate transaction 中。固定 API 拒绝不同 conversation/attempt、缺失 attempt 身份、非首个 turn、错误 event kinds；随后两个原有 `persist_event_tx_deferred` 仍执行 schema、identity、lifecycle、uniqueness 及派生布局逻辑。第二条失败回滚第一条和其生命周期/就绪证据。
- `src/durable/sqlite/observation_receipt.rs:172,225` 在最终存储状态中重新验证两个 witness，再构造一个最终 cut/shared receipt。不能把内存捕获的 typed 值直接当作存储成功。任一坏 witness 会使两个 event 都没有 family receipt；原生语义提交仍可成功。
- 回调仍按 Attempt → Turn 在 COMMIT 后执行。`src/runtime/conversation_runtime.rs:7430` 复用既有 `journal_range.last` gate，只在末回调安装并 release；`src/runtime_client/projection.rs:4497` 按原序折叠两个 witness，保留两个事实而只发布一个客户端批次。中间 callback 不能提前 ready。
- 取消在 Attempt callback 或合并事务期间到达时，Turn 事实可能已经提交；它只表示逻辑准备开始，不代表外部请求。`execution.rs:2360` 的准备前检查以及 `:3244` 所调用的实际 start arbitration 仍阻止 provider/tool 启动。这个内部时间窗口变化是本次固定合并的真实语义，不能说两条提交仍独立可见。
- EventJournal 失败后仍沿用原 `execution.rs:5936` 单独尝试 AttemptFailed 的行为。因此写入拒绝可能留下独立失败 terminal，但不会发布半批 Start。真实进程死亡发生在事务中时则没有两条 Start；发生在 `after:event:attempt_started` 时已有两条。既有 adopted-unanswered obligation 不依赖 TurnStarted，被保留下来继续恢复。

针对性覆盖：`attempt_start_tests.rs` 的一次 COMMIT/shared receipt、错误身份、第二条失败完整回滚、任一 witness 损坏；`execution_attempt_start_tests.rs` 的预取消/同步 callback 取消/故障传播；`projection/attempt_first_turn_tests.rs` 的独立 Single 有序 oracle、旧 cut、一个 cursor、worker 不重复发布；`conversation_runtime/native_readiness_tests.rs:127` 的成功/CPU 拒绝/receipt 缺失；`tests/boundary/durable/process_death/conformance.rs:565` 的真实半批 SIGKILL 与 commit 后 SIGKILL。

## 2. TEMP readiness 的所有权与边界

`src/durable/sqlite/observation_readiness.rs:8` 创建连接内 MEMORY TEMP epoch 和 J/T 就绪表。初始化 baseline 是主库当前 J/T 的同一条 SELECT；旧历史不复制成 TEMP 行。`sqlite.rs:880` 每个真正新连接安装一次，`:3170` 的 presentation reader 共享 `ConnectionOwner`，因此同一运行时的读者仍看到同一份未安装洞及 direct 标记。

`sqlite.rs:5227,5305` 使用 Deferred transaction 统一 TEMP 更新；提交后、解锁后才通知 observer。native append 与对应 TEMP 插入仍在原事务中；可选插入失败留下主库 missing flag，当前 epoch 的 receipt/mark/frontier 继续拒绝它。`observation_readiness.rs:60,155` 只在新 owner 安装时推进 baseline 并清旧 TEMP 状态，未清其他派生域的 `observation_unavailable`/witness/trace 等失败事实。TEMP delete triggers 与源删除、rollback 保持同一连接事务。

**跨连接语义有明确变化：** 独立新开连接把已有主库记录视为 committed history，`native_direct=false`，不继承另一活跃 owner 的安装进度，也不能 release 它的洞。共享 presentation reader 才跟随活跃 owner。这里保留的是原生持久真相、当前运行时 install-before-release 和独立恢复，不是把旧的全数据库“客户端已安装”标记继续持久化。

**空间不是常量：** 新 epoch 只记录之后新增的 J/T；已 ready/direct 的 TEMP 行目前仍保留到 epoch 重置，驻留为 **O(epoch 内新增 J + T)**。直接删这些行会丢失 worker 的 direct 去重证据，不能作为无语义影响的清理。主库 logical-column/WAL 统计不包括这份内存，不得把未观测的 TEMP 占用报成零；应结合本轮 PSS/RSS 实测报告。这里没有新增 compact 协议，也没有声称长连接空间有固定上限。

覆盖包含 `native_readiness_tests.rs:51,93,161,207,236,249`：release 前后 WAL 原字节、整批 rollback、只读 reopen baseline、无历史复制、跨 owner 隔离、源删除/回滚、J/T 乱序洞。它们是对上述机制的验证，而不是保留旧机制的理由。

## 3. Publication 第一次实际写入才准入

`execution.rs:5580` 仅建立冻结 generation 的内存 owner。旧 `open_publication_stream` API 已删除。`sqlite.rs:11978` 的 `ensure_publication_stream_tx` 在第一次 frames、terminal、audit 或最终 canonical settlement 的同一事务内验证真实 started Request Snapshot、完整 stream/attempt/turn/request/message identity，插入并回读新 stream。已有 stream 也必须匹配 supplied start。

- `sqlite.rs:5680` 的非空 frame 批次、`:5786` 的 audit 和 `final_settlement.rs:320` 的 P/U/C/final boundary 都在准入后继续原序列、proposal、provider-outcome 与 canonical 校验；任一后续拒绝连准入一起回滚。
- 新 stream 的首次写入失败或进程在提交前死亡，主库无 stream，不会由恢复制造“空流审计”。先前已 staged 的流仍可恢复。**显式正常 audit settlement 仍可以提交空的 incomplete audit**；优化没有删除该功能，删掉的是只有内存 open、尚未发生 durable settlement 时的空行。
- 请求开始仍在 provider 调用前持久化。没有 stream 不等于 provider 未开始；恢复仍按 ModelRequestStarted 判断未知外部结果，不能自动重放请求。`runtime/recovery.rs:1716` 仅对真实已存 unsettled stream 使用其完整 start 做 audit。

覆盖：`tests/durable/publication.rs:4461,4514,4575,4625` 及 `process_death/conformance.rs:1098`；包含首次 frame/audit 失败、foreign generation、正常 next sequence=0、未输出恢复、P/frames/C 中途死亡。原 P→U→C 和不能执行 audit proposal 的规则保留。

## 4. 其余变化的风险核对

- **事件索引：** `sqlite/event_holes.rs` 把六个派生缺失谓词折叠成两个 SQLite VIRTUAL 三位 mask；每个 reader 用包含该 bit 的四个精确 mask 值及原 sequence cut 查找。没有手工镜像表，也没有把其他域失败当成本域失败。`event_holes/tests.rs:73` 枚举全部 64 组合与历史 cut，对照原始谓词；还覆盖 optional savepoint/rollback、索引实际 seek 和 schema 篡改。`manifest.rs:331` 改为 `table_xinfo`，避免生成列使 preupdate 列序号错位；相关原生 mutation/actual-only 回归保留。
- **请求 typed reuse：** `native_request.rs:190,211` 的 owner 只活在借用的同一个 transaction 内；每次重用仍比较当前完整 metadata 字节及 configuration 的 TEXT 类型、长度、BLOB 精确字节。`sqlite.rs:11815` 每次重读 root/digest/started/completed 等可变标量；fresh start 在 `:6093` 认证实际存储字节。不存在仅凭 digest 相同就跳过 typed 验证的授权。更改/rehashed-invalid/rollback/new transaction 测试见 `native_request_tests.rs:381–490`。
- **普通 Fact.header 删除：** `composed/fragments.rs:99` 保留几何、原始 chunks 和有限 JSON admission；每个最大 bounded subtree 仍运行原 node/type/depth 解析，后代只复用该证明。`composed/read.rs:338,408` 以同样 32-node/16KiB 限制按需生成普通 preview；`$key` 先认证 F 再返回原有空 preview；Template 特有的 RawMessage/provenance header 仍保留。负零/float/opaque integer、alias/重复保留键、边界页及旧 cut 有独立 LegacyFact oracle。普通 preview 现在依赖相应 raw chunk：chunk 损坏时该 preview 会失败；这是同一可选 request-source 域不再保存第二份正文后的真实故障边界，原生 J/C/request 恢复仍独立。见 `metadata_tests.rs:303,344,463,484`、`scalar_tests.rs:582`。
- **不可变 capability owner：** `runtime_client/snapshot.rs:270` 只改为 Arc 共享原始 header；替换 owner 仍改变 domain revision，旧 cut 持有旧 Arc。Serde/schema 对外仍是同一 header，copy-on-write 互不污染。`projection/capability_owner_tests.rs` 同时覆盖 wire/schema、unsafe JSON、旧 cut、有限 admission，没有删除精确预算检查。
- 固定 SQL 复用只缓存 statements，不缓存结果；查询参数、当前存储校验和原失败传播仍在。当前格式明确为 schema 80，旧格式拒绝，无 migration/兼容入口。

## 5. 与本次 Pi Durable 实际路径的关系

已核对本地 `/home/capi/Documents/codes/pi-rustx-benchmark` HEAD `90d863f7c1183b965f099855715d6e88c7b8a52c`，不是 coding-agent/RPC 路径。

Pi Durable 的 [`session.ts:690–750`](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/session/session.ts#L690) 顺序是准备 writes → `storage.commit` → 内存 `tx.adopt(seq)` → publish；storage 已提交后 adoption 失败会 fail Session，不回滚事实或追加一个持久“已安装”确认。其 [`storage/sqlite/storage.ts:187`](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/storage.ts#L187) 把一组语义 writes 放在同一数据库事务；[`node.ts:194`](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/node.ts#L194) 使用 WAL + NORMAL。本轮 rustX 主库配置仍是 WAL + NORMAL（`sqlite.rs:8126`）。

因此把内存安装进度移出 WAL、固定合并没有外部调用间隔的 A/T、删除先开空 stream 的独立事务，与其 committed truth → memory adoption → publication 的顺序相符。rustX 仍保留请求快照、流式帧、历史 cut、bounded inspection 和独立派生失败等能力，不能从这个设计相似性推出跨引擎语义完全相同、物理写入相同或性能已经追平。

普通无中途 flush 的首次轮次现可按源代码识别为 Pending / adoption / Attempt+Turn / request-start / final 五个主库语义提交；这是该路径的组成，**不是所有工具/重试/流式路径的事务数，也不是不可再减少的理论下界**。实际 CPU、WAL、wall、TEMP 驻留结果应由同轮已绑定源身份的正式测量给出。
