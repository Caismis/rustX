#!/usr/bin/env python3
"""Audit retained joint diagnostics without running products or re-symbolizing.

Portable raw-only usage accepts explicit archived build identities. Raw-only never
follows the absolute binary, preload, database, or workspace paths in evidence.
"""
import argparse
import datetime
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
BASELINE_HEAD = '063ef7a9b713e76efad6dc4e6b7122454023c67f'
BASELINE_TREE = 'ce0d7116a42d6d5eb15f2c7af923e204307a1201'
BASELINE_SHA = 'cce30715eed4b1700c5b3c5fee2a93db1fb4ca49c8847cf36dfe995e4470e9b0'
TEST = 'agent_loop::runtime_benchmark::measure_runtime'
PHASES = ['before_initialization', 'after_provider_start', 'after_initialization',
          'before_measured_turns', 'after_turns', 'after_late_snapshot',
          'after_verification', 'after_shutdown', 'after_driver_drop',
          'after_final_writer_close', 'after_reopen_verification', 'after_cleanup']
LIFECYCLE = [phase for phase in PHASES if phase != 'before_measured_turns']
PROFILE_NAMES = [f'profile-{revision}-live-large-{mode}'
                 for revision in ('baseline', 'joint') for mode in ('control', 'cpu')]
NEEDLES = {
    'read_with_trace': 'ReadDomainCut>::read_with_trace',
    'index_request_read_layouts': 'index_request_read_layouts',
    'sqlite_prepare': 'sqlite3LockAndPrepare',
    'publication_encode': 'PublicationDraft>::encode',
    'checkpoint_unfitted': 'CheckpointSeed>::checkpoint_unfitted',
    'checkpoint_prepared': 'CheckpointSeed>::checkpoint_prepared',
    'prepared_domain_inherit': 'PreparedCaptures>::inherit',
    'prepared_capture': 'Capture>::prepared',
    'capture_evidence': 'capture_evidence',
    'fit_checkpoint': 'fit_checkpoint',
    'native_request_persist': 'native_request::persist',
    'native_request_read': 'native_request::read',
    'native_request_full': 'native_request::full',
    'statistics_event': 'observation_statistics::event',
    'execution_seal': 'seal_execution',
    'content_persist_part': 'persist_part',
}


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, f'invalid {label}')
    return value


def utc(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None and result.utcoffset() == datetime.timedelta(0),
            'timestamp is not explicitly UTC')
    return result


def window(start, end):
    begin, finish = utc(start), utc(end)
    require(begin < finish, 'empty/reversed command window')
    return begin, finish


def disjoint(left, right):
    return left[1] <= right[0] or right[1] <= left[0]


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


def verify_builds(args, plan):
    identities, receipts = {}, {}
    for label, path in [('baseline', args.baseline_identity), ('joint', args.candidate_identity)]:
        build = load(path)
        require(all(re.fullmatch('[0-9a-f]{40}', build[key]) for key in ('head', 'production_tree'))
                and re.fullmatch('[0-9a-f]{64}', build['sha256']), f'{label} malformed build identity')
        require(build['verified'] is True and build['build_exit'] == build['clean_exit'] == 0,
                f'{label} unsuccessful ordinary build')
        require(build['commands'][-1] == ['cargo', 'test', '--release', '--locked', '--test',
                'conformance', '--no-run', '--message-format=json'], f'{label} build command differs')
        require(build['harness'] and build['rustc'] and build['cargo'], f'{label} missing toolchain/harness')
        require(all(re.fullmatch('[0-9a-f]{64}', value) for value in build['harness'].values()),
                f'{label} malformed harness digest')
        stdout = path.parent / 'build.stdout'
        rows = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
        require([row for row in rows if row.get('reason') == 'build-finished'] ==
                [{'reason': 'build-finished', 'success': True}], f'{label} missing Cargo success')
        artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact'
                     and row['target']['name'] in ('rustx', 'conformance')]
        require(artifacts and any(row['target']['name'] == 'conformance' and row['executable']
                                 for row in artifacts), f'{label} missing conformance artifact')
        require(all(row['profile']['opt_level'] == '3' and row['features'] == []
                    and row['fresh'] is False and not row['profile']['debug_assertions']
                    and not row['profile']['overflow_checks'] for row in artifacts),
                f'{label} ordinary O3 artifact differs')
        if not args.raw_only:
            require(sha(build['binary']) == build['sha256'], f'{label} actual binary differs')
            require(git(args.repo, 'rev-parse', build['head'] + ':src') == build['production_tree'],
                    f'{label} source identity differs')
            for source, digest in build['harness'].items():
                require(sha(args.repo / source) == digest, f'{label} current harness differs: {source}')
            schema = 77 if label == 'baseline' else 78
            require(f'pub const SQLITE_SCHEMA_VERSION: i64 = {schema};' in
                    git(args.repo, 'show', build['head'] + ':src/durable/sqlite.rs'),
                    f'{label} committed schema differs')
        identities[label] = build
        receipts[label] = {'file': str(path), 'sha256': sha(path), 'cargo_stdout_sha256': sha(stdout)}
    before, after = identities['baseline'], identities['joint']
    require((before['head'], before['production_tree'], before['sha256']) ==
            (BASELINE_HEAD, BASELINE_TREE, BASELINE_SHA), 'pinned baseline differs')
    require(plan['baseline_source'] == BASELINE_HEAD and plan['baseline_sha256'] == BASELINE_SHA
            and plan['schema'] == 78, 'predeclared baseline/schema differs')
    require(all(before[key] == after[key] for key in ('harness', 'rustc', 'cargo')),
            'baseline/joint harness or toolchain differs')
    require(before['sha256'] != after['sha256'], 'joint binary is identical to baseline')
    if args.expect_rust_sha256:
        require(after['sha256'] == args.expect_rust_sha256, 'explicit joint SHA differs')
    return identities, receipts


def counters(point):
    process = point['process']
    stat = process['stat']
    tail = stat.rsplit(')', 1)[1].split()
    io = {key: int(value.strip()) for key, value in
          (line.split(':', 1) for line in process['io'].splitlines())}
    return {'identity': (int(stat.split('(', 1)[0]), int(tail[19])),
            'cpu_ticks': int(tail[11]) + int(tail[12]), 'write_bytes': io['write_bytes']}


def product(directory, revision, build, case, observer, argv):
    raw, proc = load(directory / 'sample.json'), load(directory / 'sample.process.json')
    require(proc['argv'] == argv and proc['accepted'] is True and
            proc['product_exit'] == proc['provider_exit'] == 0, 'product argv/admission differs')
    require(proc['case'] == raw['case'] == case and proc['observer_mode'] ==
            raw['observer_mode'] == observer, 'product case/observer differs')
    require(raw['schema'] == (77 if revision == 'baseline' else 78), 'product schema differs')
    require(raw['oracle'] == 'passed' and raw['workload_version'] == 3
            and raw['measurement_version'] == 4, 'product oracle/version differs')
    history = 8 if case == 'short-small' else 64
    count = history + 32
    require(raw['history'] == history and raw['measured'] == 32 and len(raw['samples']) == count,
            'product turn dimensions differ')
    require(all(s['turn'] == i and s['measured'] is (i >= history)
                and s['observer_mode'] == observer for i, s in enumerate(raw['samples'])),
            'product measured phase identities differ')
    require([point['phase'] for point in raw['lifecycle']] == LIFECYCLE, 'product lifecycle differs')
    elapsed = [point['elapsed_us'] for point in raw['lifecycle']]
    require(all(type(value) is int and value >= 0 for value in elapsed) and elapsed == sorted(elapsed),
            'lifecycle times invalid/decreased')
    provider = proc['provider_report']
    require(provider['complete'] is True and provider['ok'] is True and not provider['failures']
            and provider['requestCount'] == provider['stepsTotal'] == provider['stepsMatched'] ==
            provider['stepsSettled'] == count and provider['stepStates'] == ['settled'] * count,
            'provider completion differs')
    require(raw['wire_requests'] == provider['requests'] and raw['live_requests'] == raw['reopened_requests']
            and raw['verified_live_requests'] == raw['verified_reopened_requests'] == count,
            'persisted/reopened request admission differs')
    points = raw['samples'] + raw['lifecycle']
    require(len({counters(point)['identity'] for point in points}) == 1,
            'self PID/start-time changed between counters')
    for series in (raw['samples'], raw['lifecycle']):
        for key in ('cpu_ticks', 'write_bytes'):
            values = [counters(point)[key] for point in series]
            require(min(values) >= 0 and values == sorted(values), f'{key} invalid/decreased')
    begin, end, final = (counters(raw['samples'][history - 1]),
                         counters(raw['samples'][-1]), counters(raw['lifecycle'][-1]))
    settled = [sample['settled_us'] for sample in raw['samples'][history:]]
    require(all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in settled),
            'invalid settled counter')
    return {'accepted': True, 'schema': raw['schema'], 'history_turns': history,
            'measured_turns': 32, 'request_count': count,
            'sample_sha256': sha(directory / 'sample.json'),
            'process_sha256': sha(directory / 'sample.process.json'),
            'mean_measured_turn_ms': sum(settled) / 32000,
            'measured_phase_self_cpu_ticks': end['cpu_ticks'] - begin['cpu_ticks'],
            'measured_phase_self_cpu_ms_at_100hz': (end['cpu_ticks'] - begin['cpu_ticks']) * 10,
            'measured_phase_process_write_bytes': end['write_bytes'] - begin['write_bytes'],
            'full_self_cpu_ticks': final['cpu_ticks'], 'full_self_cpu_ms_at_100hz': final['cpu_ticks'] * 10,
            'full_process_write_bytes': final['write_bytes'],
            'clock_ticks_note': 'Raw ticks are primary; milliseconds use the formal cohort 100 Hz clock convention.'}


def raw_cpu(path, binary):
    raw = path.read_bytes()
    require(len(raw) >= 64 and struct.unpack_from('<5Q', raw) == (0, 3, 0, 4000, 0),
            f'{path.name}: invalid 250 Hz CPU header')
    offset, total, records = 40, 0, 0
    while True:
        require(offset + 16 <= len(raw), f'{path.name}: truncated raw count')
        count, depth = struct.unpack_from('<2Q', raw, offset)
        offset += 16
        require(0 < depth < 10000 and offset + depth * 8 <= len(raw),
                f'{path.name}: invalid/truncated raw stack')
        pcs = struct.unpack_from(f'<{depth}Q', raw, offset)
        offset += depth * 8
        if count == 0 and pcs == (0,):
            break
        require(count > 0, f'{path.name}: invalid raw sample count')
        total += count
        records += 1
    maps = raw[offset:].decode()
    require(binary in maps, f'{path.name}: maps lack recorded measured binary')
    return {'total_samples': total, 'sample_records': records,
            'interval_us': 4000, 'raw_sha256': sha(path)}, maps


def cpu_profile(directory, build, command, counts, raw_only):
    require({path.name for path in directory.glob('*.cpu')} ==
            {phase + '.cpu' for phase in PHASES[:-1]}, 'CPU phase file inventory differs')
    inventory = {}
    for phase in PHASES[:-1]:
        info, maps = raw_cpu(directory / (phase + '.cpu'), build['binary'])
        inventory[phase] = info
        if not raw_only:
            require(all(str(Path(path).resolve()) in maps for path in command['preload_sha256']),
                    f'{phase}: raw maps lack actual preload')
    steady = inventory['before_measured_turns']
    total = steady['total_samples']
    require(total > 0, 'measured CPU interval has no samples')
    stacks = []
    for line in (directory / 'steady-collapsed.txt').read_text().splitlines():
        stack, value = line.rsplit(' ', 1)
        require(stack and value.isdigit() and int(value) > 0, 'invalid collapsed stack/count')
        stacks.append((stack, int(value)))
    require(sum(count for _, count in stacks) == total, 'raw and collapsed totals differ')
    cumulative = (directory / 'steady-cumulative.txt').read_text().splitlines()
    require(cumulative and cumulative[0] == f'Total: {total} samples', 'cumulative total differs')
    rows = []
    for line in cumulative[1:]:
        if not line.strip():
            continue
        match = re.fullmatch(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)', line)
        require(match is not None, 'unrecognized cumulative row')
        row = {'symbol': match[3], 'flat': int(match[1]), 'inclusive': int(match[2])}
        require(0 <= row['flat'] <= row['inclusive'] <= total, 'invalid cumulative counts')
        rows.append(row)
    require(rows and len({row['symbol'] for row in rows}) == len(rows), 'empty/duplicate cumulative symbols')
    require(sum(row['flat'] for row in rows) <= total, 'cumulative flat counts exceed raw samples')
    record = counts[command['name']]
    require(record['samples'] == total and record['interval_us'] == 4000 and
            record['raw_sha256'] == steady['raw_sha256'] and record['rows'] == rows,
            'cpu-counts summary differs from independently parsed evidence')
    inclusive = {}
    for label, needle in NEEDLES.items():
        value = sum(count for stack, count in stacks if needle in stack)
        matches = [row for row in rows if needle in row['symbol']]
        # pprof text shortens Rust generics and truncates at 200 nodes. Only a
        # unique text match supports a direct equality check. Multiple matches
        # are retained individually, never added as independent costs.
        agreement = None
        if len(matches) == 1:
            require(matches[0]['inclusive'] == value, f'inclusive raw-stack/text counts differ: {label}')
            agreement = True
        inclusive[label] = {'needle': needle, 'samples': value, 'share_percent': 100 * value / total,
                            'cumulative_matches': matches, 'unique_cumulative_agreement': agreement}
    return {**steady, 'raw_header': [0, 3, 0, 4000, 0], 'collapsed_total': total,
            'collapsed_sha256': sha(directory / 'steady-collapsed.txt'),
            'cumulative_sha256': sha(directory / 'steady-cumulative.txt'),
            'phase_inventory': inventory, 'inclusive': inclusive,
            'phase': 'before_measured_turns starts this file; after_turns stops it. All product threads, '
                     '32 measured turns plus between-turn counters/footprints and control overhead.',
            'symbol_binding': 'Retained symbolized reports are bound by raw SHA and count consistency; '
                              'this read-only audit does not independently symbolize program counters.'}


def profile(args, command, identities, counts):
    name = command['name']
    revision, mode = name.split('-')[1], name.split('-')[-1]
    directory, build = args.root / name, identities[revision]
    require(command['build_identity'] == build, 'profile build differs from archived identity')
    require(command['status'] == 'complete' and command['exit'] == 0, 'profile command failed')
    window(command['start_utc'], command['end_utc'])
    argv_command = command['command']
    require(argv_command[:2] == ['python3', 'benchmarks/runtime/profiling/run.py'], 'profile runner differs')
    for flag, expected in [('--binary', build['binary']), ('--mode', mode), ('--case', 'short-large'),
                           ('--observer-mode', 'live-subscriber')]:
        require(argv_command.count(flag) == 1 and argv_command[argv_command.index(flag) + 1] == expected,
                f'profile command {flag} differs')
    require(argv_command.count('--output') == 1 and
            Path(argv_command[argv_command.index('--output') + 1]).name == name, 'profile output identity differs')
    manifest = load(directory / 'manifest.json')
    require(manifest['mode'] == mode and manifest['binary_sha256'] == build['sha256'] and
            manifest['case'] == 'short-large' and manifest['observer_mode'] == 'live-subscriber',
            'profile manifest identity differs')
    argv = manifest['argv']
    require(argv[-5:] == [build['binary'], TEST, '--exact', '--ignored', '--nocapture'], 'profile target differs')
    if mode == 'cpu':
        require(argv[0] == 'env' and len(argv) == 10 and argv[4] == 'CPUPROFILE_FREQUENCY=250',
                'CPU environment/frequency differs')
        env = dict(value.split('=', 1) for value in argv[1:5])
        require(set(env) == {'LD_PRELOAD', 'RUSTX_BENCH_PROFILE_SOCKET', 'RUSTX_BENCH_PROFILE_DIR',
                             'CPUPROFILE_FREQUENCY'}, 'CPU env keys differ')
        preload = command['preload_sha256']
        require(len(preload) == 2 and set(env['LD_PRELOAD'].split(':')) == set(preload), 'preload identity differs')
        require({Path(path).name for path in preload} == {'bridge.so', 'libprofiler.so.0'} and
                all(re.fullmatch('[0-9a-f]{64}', digest) for digest in preload.values()), 'preload hashes malformed')
        require(Path(env['RUSTX_BENCH_PROFILE_DIR']).name == name and
                Path(env['RUSTX_BENCH_PROFILE_SOCKET']).parent == Path(env['RUSTX_BENCH_PROFILE_DIR']),
                'CPU phase output/socket identity differs')
        if not args.raw_only:
            require(all(sha(path) == digest for path, digest in preload.items()), 'actual preload differs')
    else:
        require(len(argv) == 5 and not command['preload_sha256'] and not list(directory.glob('*.cpu')),
                'control unexpectedly preloaded/profiled')
    result = {'name': name, 'revision': revision, 'mode': mode,
              'window': {key: command[key] for key in ('start_utc', 'end_utc')},
              'build_head': build['head'], 'binary_sha256': build['sha256'],
              'manifest_sha256': sha(directory / 'manifest.json'), 'preload_sha256': command['preload_sha256'],
              'product': product(directory, revision, build, 'short-large', 'live-subscriber', argv)}
    if mode == 'cpu':
        result['cpu'] = cpu_profile(directory, build, command, counts, args.raw_only)
    return result


def validate_snapshot(snapshot, revision):
    tables = snapshot['tables']
    require(tables and ('request_configurations' in tables) is (revision == 'joint'),
            'schema-specific request_configurations presence differs')
    for name, table in tables.items():
        integer(table['rows'], name + ' rows')
        require(table['column_value_bytes'], name + ' has no column values')
        for column, value in table['column_value_bytes'].items():
            integer(value, name + '.' + column + ' bytes')
    require({'observation_statistics', 'observation_execution', 'event_json', 'observation_json'} <=
            tables['events']['column_value_bytes'].keys(), 'missing native/derived event columns')
    require('snapshot_json' in tables['request_snapshots']['column_value_bytes'], 'missing native snapshot column')
    if revision == 'joint':
        require(set(tables['request_configurations']['column_value_bytes']) == {'digest', 'configuration_json'},
                'request_configurations column shape differs')
    kinds = snapshot['events_by_kind']
    require(len({row['kind'] for row in kinds}) == len(kinds), 'duplicate event kind')
    require(all(row['column_value_bytes'].keys() == tables['events']['column_value_bytes'].keys()
                for row in kinds), 'event kind column shape differs')
    for row in kinds:
        integer(row['rows'], 'event kind rows')
        for column, value in row['column_value_bytes'].items():
            integer(value, 'event kind ' + column)
    require(sum(row['rows'] for row in kinds) == tables['events']['rows'], 'event kind rows do not sum')
    require(all(sum(row['column_value_bytes'][column] for row in kinds) == value
                for column, value in tables['events']['column_value_bytes'].items()),
            'event kind byte values do not sum')
    duplicate = snapshot['equal_event_observation_json']
    integer(duplicate['rows'], 'equal JSON rows')
    integer(duplicate['native_bytes'], 'equal JSON bytes')
    require(duplicate['rows'] <= tables['events']['rows'] and
            duplicate['native_bytes'] <= tables['events']['column_value_bytes']['event_json'],
            'equal JSON extent exceeds native events')
    names = []
    for name, pages, payload, count in snapshot['dbstat']:
        names.append(name)
        integer(pages, 'dbstat page bytes')
        integer(payload, 'dbstat payload bytes')
        integer(count, 'dbstat page count')
        require(payload <= pages, 'dbstat payload exceeds allocated page bytes')
    require(len(set(names)) == len(names), 'duplicate dbstat object')


def row_delta(before, after):
    require(before['column_value_bytes'].keys() == after['column_value_bytes'].keys(), 'column identity changed')
    values = {column: after['column_value_bytes'][column] - value
              for column, value in before['column_value_bytes'].items()}
    return {'rows': after['rows'] - before['rows'], 'column_value_bytes': values,
            'total_column_value_bytes': sum(values.values())}


def columns(args, revision, case, identities):
    directory = args.root / f'columns-{revision}-{case}'
    build = identities[revision]
    require(load(directory / 'identity-before.json')['build'] == build, 'column build identity differs')
    require(load(directory / 'phases.json') == PHASES, 'column synchronous phase sequence differs')
    argv = [build['binary'], TEST, '--exact', '--ignored', '--nocapture']
    prod = product(directory, revision, build, case, 'no-live-subscriber', argv)
    before, after = load(directory / 'before_measured_turns.json'), load(directory / 'after_turns.json')
    for snapshot in (before, after):
        validate_snapshot(snapshot, revision)
    require(before['path'] == after['path'] and before['tables'].keys() == after['tables'].keys(),
            'column database/table identity changed during measured phase')
    delta = {name: row_delta(table, after['tables'][name]) for name, table in before['tables'].items()}
    require(delta['events']['rows'] == 256 and delta['request_snapshots']['rows'] == 32,
            'measured native event/request count differs')
    before_kinds, after_kinds = ({row['kind']: row for row in snapshot['events_by_kind']}
                                for snapshot in (before, after))
    kinds = {}
    empty = {'rows': 0, 'column_value_bytes': dict.fromkeys(before['tables']['events']['column_value_bytes'], 0)}
    for name in sorted(before_kinds.keys() | after_kinds.keys(), key=str):
        kinds[str(name)] = row_delta(before_kinds.get(name, empty), after_kinds.get(name, empty))
    totals = {label: sum(sum(table['column_value_bytes'].values()) for table in snapshot['tables'].values())
              for label, snapshot in [('before', before), ('after', after)]}
    total_delta = sum(row['total_column_value_bytes'] for row in delta.values())
    require(total_delta == totals['after'] - totals['before'], 'logical total arithmetic differs')
    configurations = {label: snapshot['tables'].get('request_configurations')
                      for label, snapshot in [('before', before), ('after', after)]}
    return {'revision': revision, 'case': case, 'build_head': build['head'], 'binary_sha256': build['sha256'],
            'product': prod, 'before_sha256': sha(directory / 'before_measured_turns.json'),
            'after_sha256': sha(directory / 'after_turns.json'), 'phases_sha256': sha(directory / 'phases.json'),
            'logical_totals': totals, 'total_logical_delta': total_delta, 'table_deltas': delta,
            'event_kind_deltas': kinds, 'request_configurations_retained': configurations,
            'equal_event_observation_json': {label: snapshot['equal_event_observation_json']
                                            for label, snapshot in [('before', before), ('after', after)]},
            'timing_isolation': 'Synchronous phase acknowledgments and exact phase order verified. '
                                'Column producer records no UTC command window; wall-clock isolation is not independently proved.'}


def comparison(before, after):
    return {'baseline': before, 'joint': after, 'difference': after - before,
            'joint_over_baseline': None if before == 0 else after / before}


def column_comparisons(rows):
    result = []
    for case in ('short-small', 'short-large'):
        pair = {row['revision']: row for row in rows if row['case'] == case}
        if pair.keys() != {'baseline', 'joint'}:
            continue
        before, after = pair['baseline'], pair['joint']
        fields = {'all_logical': comparison(before['total_logical_delta'], after['total_logical_delta'])}
        selected = [('request_snapshots_all', 'request_snapshots', None),
                    ('request_source_pages', 'request_source_pages', None),
                    ('native_snapshot_json', 'request_snapshots', 'snapshot_json'),
                    ('native_event_json', 'events', 'event_json'),
                    ('observation_event_json', 'events', 'observation_json'),
                    ('event_statistics', 'events', 'observation_statistics'),
                    ('event_execution', 'events', 'observation_execution')]
        for label, table, column in selected:
            def value(row):
                data = row['table_deltas'][table]
                return data['total_column_value_bytes'] if column is None else data['column_value_bytes'][column]
            fields[label] = comparison(value(before), value(after))
        # Explicit schema absence is recorded, not silently treated as a
        # missing/corrupt zero-byte table. Include shared config in native total.
        config = after['table_deltas']['request_configurations']['total_column_value_bytes']
        fields['native_snapshot_and_configuration'] = comparison(
            before['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'],
            after['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + config)
        all_tables = {}
        for table in sorted(before['table_deltas'].keys() | after['table_deltas'].keys()):
            b, a = before['table_deltas'].get(table), after['table_deltas'].get(table)
            all_tables[table] = {'present_in_baseline': b is not None, 'present_in_joint': a is not None,
                                **comparison(0 if b is None else b['total_column_value_bytes'],
                                             0 if a is None else a['total_column_value_bytes'])}
        result.append({'case': case, 'logical_bytes': fields, 'all_table_logical_bytes': all_tables,
                       'new_shared_configuration_measured_delta': config,
                       'shared_configuration_note': 'Joint before/after retained totals are in columns; '
                                                    'seeded shared payload is not charged again as a measured-turn insertion.'})
    return result


def formal_binding(args, identities, commands):
    audit = load(args.formal_audit)
    require(audit['accepted'] is True and audit['errors'] == [], 'formal audit not accepted')
    if not args.raw_only:
        require(audit['mode'] == 'strict' and audit['strict_identity_verified'] is True,
                'strict diagnostics require accepted strict formal audit')
    else:
        require(audit['mode'] in ('strict', 'raw-only'), 'unknown formal audit mode')
    require(set(audit['identities']) == {'baseline', 'joint'}, 'formal build labels differ')
    for revision, build in identities.items():
        require(audit['identities'][revision] ==
                {key: build.get(key) for key in ('head', 'production_tree', 'sha256', 'harness', 'rustc')},
                f'formal {revision} build binding differs')
    datasets = audit['datasets']
    require({'direct', 'final', 'three-engine'} <= datasets.keys() <=
            {'direct', 'final', 'three-engine', 'confirmation'}, 'formal dataset coverage differs')
    expected_counts = {'direct': 72, 'final': 72, 'three-engine': 36, 'confirmation': 14}
    require(all(data and data['derived_products'] == expected_counts[label]
                for label, data in datasets.items()), 'formal product count differs')
    queue = audit['queue_states']
    require(set(queue) == ({'direct', 'final', 'confirmation'} if 'confirmation' in datasets else {'direct', 'final'}),
            'formal queue coverage differs')
    formal_windows, heads = [], set()
    for stage, record in queue.items():
        before, after = record['source_before'], record['source_after']
        require({key: value for key, value in before.items() if key != 'utc'} ==
                {key: value for key, value in after.items() if key != 'utc'}, 'formal source snapshots differ')
        require(before['production_tree'] == identities['joint']['production_tree'] and before['schema'] == 78,
                'formal source/schema differs')
        heads.add(before['head'])
        span = window(before['utc'], after['utc'])
        formal_windows.append({'stage': stage, 'start_utc': before['utc'], 'end_utc': after['utc']})
        require(all(disjoint(span, window(command['start_utc'], command['end_utc'])) for command in commands),
                f'profile overlaps formal {stage} queue')
    require(len(heads) == 1, 'formal harness revisions differ')
    expected_head = args.expected_harness_revision or next(iter(heads))
    require(heads == {expected_head}, 'explicit formal harness revision differs')
    if not args.raw_only:
        require(git(args.repo, 'rev-parse', expected_head + ':src') == identities['joint']['production_tree'],
                'formal harness source differs from joint')
    return {'file': str(args.formal_audit), 'sha256': sha(args.formal_audit), 'mode': audit['mode'],
            'strict_identity_verified': audit['strict_identity_verified'], 'harness_revision': expected_head,
            'products': sum(data['derived_products'] for data in datasets.values()), 'windows': formal_windows,
            'scope': 'Accepted formal report identity/windows are checked; formal raw arithmetic belongs to audit-joint.py.'}


def column_windows(args, formal, profile_commands):
    path = args.root / 'columns-commands.json'
    if not path.exists():
        return {'verified': False, 'reason': 'No columns-commands.json retained; phase order alone does not prove wall-clock isolation.'}
    records = load(path)
    require([record['name'] for record in records] == ['columns-baseline', 'columns-joint'],
            'column command order/count differs')
    spans, scripts = [], {}
    for record in records:
        require(record['status'] == 'complete' and record['exit'] == 0, 'column command failed')
        command = record['command']
        require(len(command) == 2 and command[0] == 'python3' and
                Path(command[1]).name == record['name'] + '.py', 'column producer command differs')
        script_hash = sha(args.root / Path(command[1]).name)
        if 'producer_sha256' in record:
            require(record['producer_sha256'] == script_hash, 'column producer hash differs')
        scripts[record['name']] = {'retained_sha256': script_hash,
                                  'execution_hash_recorded': 'producer_sha256' in record}
        spans.append(window(record['start_utc'], record['end_utc']))
    require(spans[0][1] <= spans[1][0], 'column command windows overlap/out of order')
    initial = [record for record in formal['windows'] if record['stage'] in ('direct', 'final')]
    confirmation = [record for record in formal['windows'] if record['stage'] == 'confirmation']
    require({record['stage'] for record in initial} == {'direct', 'final'} and len(initial) == 2
            and len(confirmation) <= 1 and len(initial) + len(confirmation) == len(formal['windows']),
            'unexpected formal queue windows')
    require(all(window(record['start_utc'], record['end_utc'])[1] <= spans[0][0]
                for record in initial), 'columns do not follow initial direct/final queues')
    profile_spans = [window(record['start_utc'], record['end_utc']) for record in profile_commands]
    require(spans[-1][1] <= min(span[0] for span in profile_spans),
            'columns overlap/follow profile commands')
    for record in confirmation:
        span = window(record['start_utc'], record['end_utc'])
        require(span[0] > max(profile[1] for profile in profile_spans),
                'post-hoc confirmation does not strictly follow all profiles')
        require(all(disjoint(span, other) for other in spans + profile_spans),
                'post-hoc confirmation overlaps column/profile diagnostics')
    return {'verified': True, 'file': str(path), 'sha256': sha(path), 'commands': records,
            'producer_scripts': scripts, 'confirmation_after_profiles': bool(confirmation),
            'scope': 'Initial direct/final queues precede both sequential two-case column producers; '
                     'columns precede all profiles. Any post-hoc confirmation strictly follows all profiles '
                     'and is disjoint from every column/profile interval.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HERE)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--baseline-identity', type=Path)
    parser.add_argument('--candidate-identity', type=Path)
    parser.add_argument('--formal-audit', type=Path)
    parser.add_argument('--expected-harness-revision')
    parser.add_argument('--expect-rust-sha256')
    parser.add_argument('--raw-only', action='store_true')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    args.baseline_identity = args.baseline_identity or args.root / 'baseline-build/identity.json'
    args.candidate_identity = args.candidate_identity or args.root / 'candidate-joint-build/identity.json'
    args.formal_audit = args.formal_audit or args.root / 'joint-audit.json'
    output = args.output or args.root / ('diagnostic-raw-audit.json' if args.raw_only else 'diagnostic-audit.json')
    report = {'accepted': False, 'mode': 'raw-only' if args.raw_only else 'strict',
              'script_sha256': sha(__file__), 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'recorded_build_identity_verified': False, 'actual_binary_and_preload_verified': False,
              'strict_identity_verified': False, 'errors': [], 'profiles': [], 'columns': [],
              'column_comparison': [], 'profile_comparison': [], 'identities': None, 'formal_audit': None,
              'column_timing_isolation': None}

    def check(label, fn):
        try:
            return fn()
        except Exception as error:
            report['errors'].append(f'{label}: {type(error).__name__}: {error}')
            return None

    builds = check('build identities', lambda: verify_builds(args, load(args.root / 'plan.json')))
    commands = check('profile commands', lambda: load(args.root / 'profile-commands.json'))
    records = check('CPU counts', lambda: load(args.root / 'cpu-counts.json'))
    counts = None
    if records is not None:
        def counts_check():
            expected = {name for name in PROFILE_NAMES if name.endswith('-cpu')}
            require(len(records) == 2 and {record['name'] for record in records} == expected,
                    'CPU count record inventory differs')
            return {record['name']: record for record in records}
        counts = check('CPU count inventory', counts_check)
        report['cpu_counts_sha256'] = sha(args.root / 'cpu-counts.json')
    if commands is not None:
        def commands_check():
            require([command['name'] for command in commands] == PROFILE_NAMES, 'profile command order/count differs')
            spans = [window(command['start_utc'], command['end_utc']) for command in commands]
            require(all(left[1] <= right[0] for left, right in zip(spans, spans[1:])), 'profile command overlap/order differs')
            require(commands[1]['preload_sha256'] == commands[3]['preload_sha256'],
                    'baseline/joint CPU preload identities differ')
            return True
        check('profile command windows', commands_check)
        report['profile_commands_sha256'] = sha(args.root / 'profile-commands.json')
    if builds is not None:
        identities, receipts = builds
        report['recorded_build_identity_verified'] = True
        report['build_receipts'] = receipts
        report['identities'] = {revision: {key: build.get(key) for key in
                               ('head', 'production_tree', 'sha256', 'harness', 'rustc')}
                               for revision, build in identities.items()}
        if commands is not None and counts is not None:
            for command in commands:
                row = check(command.get('name', 'unnamed profile'), lambda: profile(args, command, identities, counts))
                if row is not None:
                    report['profiles'].append(row)
            report['formal_audit'] = check('formal identity/timing isolation', lambda: formal_binding(args, identities, commands))
            if report['formal_audit'] is not None:
                report['column_timing_isolation'] = check('column command timing isolation',
                    lambda: column_windows(args, report['formal_audit'], commands))
        for revision in ('baseline', 'joint'):
            for case in ('short-small', 'short-large'):
                row = check(f'columns-{revision}-{case}', lambda: columns(args, revision, case, identities))
                if row is not None:
                    if report['column_timing_isolation'] and report['column_timing_isolation']['verified']:
                        record = next(record for record in report['column_timing_isolation']['commands']
                                      if record['name'] == 'columns-' + revision)
                        row['timing_isolation'] = {'verified': True,
                            'producer_window': {key: record[key] for key in ('start_utc', 'end_utc')},
                            'scope': 'One command window covers this revision\'s two serial cases; see column_timing_isolation.'}
                    report['columns'].append(row)
    comparisons = check('column comparison', lambda: column_comparisons(report['columns']))
    if comparisons is not None:
        report['column_comparison'] = comparisons
    for revision in ('baseline', 'joint'):
        pair = {row['mode']: row for row in report['profiles'] if row['revision'] == revision}
        if pair.keys() == {'control', 'cpu'}:
            report['profile_comparison'].append({'revision': revision, 'metrics': {
                key: {'control': pair['control']['product'][key], 'cpu': pair['cpu']['product'][key],
                      'cpu_over_control': None if pair['control']['product'][key] == 0 else
                      pair['cpu']['product'][key] / pair['control']['product'][key]}
                for key in ('mean_measured_turn_ms', 'measured_phase_self_cpu_ticks',
                            'measured_phase_process_write_bytes', 'full_self_cpu_ticks', 'full_process_write_bytes')}})
    check('complete diagnostic coverage', lambda: require(len(report['profiles']) == len(report['columns']) == 4
          and len(report['column_comparison']) == len(report['profile_comparison']) == 2
          and report['formal_audit'] is not None, 'incomplete diagnostic evidence'))
    report['limits'] = [
        'One diagnostic execution per revision/mode. CPU signal samples are not elapsed timings or call counts; inclusive stacks overlap and must not be summed as independent costs.',
        'CPU sampling sees on-CPU work across all product threads, including driver/control overhead; it cannot diagnose off-CPU waits or formal long tails.',
        'No individual causal attribution for the combined optimization. Missing sampled symbols mean zero observed samples, not proof that the operation never executes.',
        'Retained symbolized reports are count/hash checked, not independently re-symbolized. Text output shortens Rust generics and truncates at 200 nodes; only unambiguous matching inclusive rows are checked against collapsed stacks.',
        'Profiles have phase-named raw files and lifecycle counters, not independent phase UTC timestamps. Profile command windows are checked against accepted formal queue windows.',
        'Columns use synchronized SQL snapshots and perturb product execution. Optional columns-commands.json proves producer-level isolation when verified; per-case UTC timestamps are not recorded.',
        'Logical bytes are SUM length(CAST(value AS BLOB)) retained column values, including textual numeric values. Net changes exclude overwritten/deleted intermediate states and are neither serialized rows, WAL frames, process write_bytes nor device traffic.',
        'Shared request configuration retained before/after totals and measured deltas are reported separately; a payload already inserted during seed is not a new measured-turn write.',
        'Product semantic oracle admissions are verified from retained records, not independently reimplemented. Diagnostic metrics are never pooled with formal products.',
        'Strict mode checks current binaries/preloads and pinned source/harness against retained build logs. Build identity is not independent reproducible-build attestation.',
        'Raw-only never follows host binary/preload/database/workspace paths and makes no actual-file/source verification claim.',
    ]
    report['accepted'] = not report['errors']
    report['actual_binary_and_preload_verified'] = report['accepted'] and not args.raw_only
    report['strict_identity_verified'] = report['accepted'] and not args.raw_only
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(output), 'accepted': report['accepted'], 'mode': report['mode'],
                      'errors': report['errors'], 'profiles': len(report['profiles']),
                      'columns': len(report['columns']), 'column_comparison': report['column_comparison']}, indent=2))
    return 0 if report['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
