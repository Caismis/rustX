import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
records=[]
for revision in ('baseline','joint'):
 name='columns-'+revision
 command=['python3',str(root/(name+'.py'))]
 record=dict(name=name,command=command,producer_sha256=hashlib.sha256((root/(name+'.py')).read_bytes()).hexdigest(),start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');records.append(record)
 (root/'columns-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 assert record['producer_sha256']==hashlib.sha256((root/(name+'.py')).read_bytes()).hexdigest()
 record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete' if result.returncode==0 else 'failed',exit=result.returncode)
 (root/'columns-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
for name in ('run-profiles.py','profile-reports.py'):
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
  result=subprocess.run(['python3',str(root/name)],cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 print(name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
