# Remaining publication work after the joint candidate

The new profile is consistent with less repeated checkpoint capture and fit work, while checkpoint materialization and exact structural length calculation remain visible. It does not establish a causal speedup for any individual change or overall parity with Pi.

The table was independently recounted from the retained collapsed stacks. Each stack contributes its sample weight once when its symbol substring matches. Capture, fit, length, and other are disjoint **within** `PublicationDraft::encode`; their sum equals that row. Other rows are inclusive and must not be added to this partition.

| Sample bucket | Earlier GH diagnostic | Fresh GH baseline | Joint candidate |
| --- | ---: | ---: | ---: |
| All measured-interval CPU samples | 496 | 360 | 328 |
| `PublicationDraft::encode` | 160 | 124 | 75 |
| Checkpoint capture inside publication | 90 | 82 | 40 |
| `fit_checkpoint` inside publication | 27 | 14 | 0 |
| `bounded_structural_len` inside publication | 35 | 26 | 32 |
| Publication outside those three buckets | 8 | 2 | 3 |
| `capture_working_seed`, outside publication encoding | 17 | 16 | 12 |
| `sqlite3LockAndPrepare`, separate path | 95 | 61 | 56 |

The two GH capture buckets match `CheckpointSeed>::checkpoint_unfitted`; joint matches `CheckpointSeed>::checkpoint_prepared`. There are no sampled stacks overlapping the three publication sub-buckets. Zero fit samples means none observed, not that the function or boundary path never executes. Separate exact-name searches found no `PreparedCaptures>::inherit` or `encoding_equal` stack in the joint sample; inlining and sampling prevent interpreting that as zero work.

Fresh raw CPU files independently total 360 and 328 samples with header `(0,3,0,4000,0)`, matching collapsed totals. These are single 250 Hz diagnostic runs of 32 measured `short-large` turns with a live subscriber, including all product threads and between-turn measurement/control overhead. They do not measure off-CPU waits. The older 496-sample profile is historical context, not another paired observation. In particular, the former 160-sample publication bucket was never exclusively final structural encoding; only 35 samples belonged to that length path. The fresh 26-to-32 length counts do not prove that length calculation became slower.

Sources: [fresh baseline stacks](profile-baseline-live-large-cpu/steady-collapsed.txt), [joint stacks](profile-joint-live-large-cpu/steady-collapsed.txt), their sibling `before_measured_turns.cpu` files, and the earlier `rustx-pr485-highvalue/profile-gh-live-large-cpu/steady-collapsed.txt`. Fresh raw SHA256 values are `44a198559189dbded0dd1dda1ccd5e6e3cb2a5ffc2ee91f81e311db197afe44c` and `9817e7597fc7836522eb71456e363b2d1110c165d546d808e7cf7cbf46d09d29`. This note is a recount, not a replacement for the separate strict diagnostic audit.

## What still runs, including without a live subscriber

`projection.rs:6054,6406–6444` still freezes a full snapshot on each publication. The snapshot clone predates this change. The new inheritance step additionally clones a 19-entry owner map and compares 17 domains using typed equality followed, on equality, by a serialization ambiguity visitor (`projection/prepared_capture.rs:51,167`). Immutable trace/capability heads use owner identity. Float-bearing or nonempty map-bearing generic values cannot reuse this witness because signed zero and object insertion order must remain exact.

A capture miss now builds and retains a normalized domain, scans it for a fit certificate, then clones the value into the candidate. Hits avoid normalization but still clone domain values and replay content/collection descriptors (`checkpoint.rs:615–662`). The attempt, evidence resolution, metadata budgets, and final exact event length remain per-publication work. `projection.rs:535–556` constructs an owned full checkpoint even when the resulting ordinary delta only needs its metadata. There is no subscriber-count shortcut: late readers and replay still require correct published cuts.

These are plausible added costs in a smaller no-live workset, not a measured explanation of the regression. The accepted [direct audit](joint-direct-audit.json) retains all three no-live `short-large` wall-time ratios above one: `1.200010`, `1.021466`, `1.011819`. The median measured-turn CPU ratio is `1.009615`; the separate through-cleanup CPU median is `1.015625`. The live-only CPU diagnostic cannot attribute this no-live result to equality, cloning, or any single joint change.

## Next substantial local design to assess

Use the existing prepared captures as borrowed admission/evidence fragments for ordinary deltas. Replay the same residual-budget decisions, produce the same content/collections and summed sufficient fit certificate, and materialize an owned full checkpoint only when replacement is requested, capture evicts, the proof is unavailable/over budget, or a reader explicitly requests a checkpoint. This targets unnecessary whole-checkpoint materialization rather than another small lookup cache. It is a proposal; no code or performance result for it is claimed here.

The implementation must preserve capture order, exact optional-body admission, sorted metadata, cut/frontier refresh, full-fit eviction order and failures, historical held cuts, and replay byte accounting. Existing full fitting remains necessary when the sufficient proof cannot decide. Attempt admission and transcript-source readiness explicitly require replacements (`projection.rs:3773,2621`), so replacement frequency limits savings; this diagnostic does not record that frequency.

Safe-integer proof does **not** permit ordinary serde to replace the structural codec. `structural_json.rs:173–193` encodes unconstrained native `u64` as decimal strings even for `1`, while constrained quantities and opaque JSON have different rules. Conservative fit charges also cannot replace exact event length: that length controls replay expiration. The normal successful delta already performs only one exact length encode (`projection.rs:557–589`, `checkpoint.rs:390–407`). Reusing actual encoded bytes would require a separate retained representation and consumption changes; it is not a drop-in simplification.
