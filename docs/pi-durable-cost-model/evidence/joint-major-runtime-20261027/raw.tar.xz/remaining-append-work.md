# Remaining append work after the joint candidate

Read-only source review, 2026-10-27. RustX checkout: `/home/capi/.codex/worktrees/pr485-pi-performance/rustX`, joint working-tree candidate atop `326380ae14d78b8003a2ce05587290a7de7be707`. Pi checkout: `/home/capi/Documents/codes/pi-rustx-benchmark`, pinned `90d863f7c1183b965f099855715d6e88c7b8a52c`. Line numbers below describe the frozen candidate inspected after the Clippy-only helper extraction.

**Conclusion:** the next credible structural target is repeated construction, persistence, and immediate re-reading of event-derived facts. Removing it substantially requires an explicit append-path and fault-isolation design. This review did not identify a small, clearly major, safe deletion to add to the frozen round. In particular, smaller aggregate JSON does not establish a corresponding reduction in physical writes, and the current changes do not establish overall parity with Pi.

## What still happens for a native event

`persist_event_tx_internal` validates identity/references, probes lifecycle state, records lifecycle facts, and inserts the native event with missing-evidence flags. It then runs independent derived-layout stages. Depending on the event variant, these update readiness, trace total, statistics, membership, assistant/tool coordinates, execution, occupancy/request terminal state, inline source, witness, trace fact, observation JSON, transcript coordinates, and turn layout. A final optional update clears the unavailable marker only when the required stages succeeded. Most of this remains even without a live subscriber.

Exact source: [sqlite.rs:11300](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:11300), especially lifecycle probes `:11344–11383`, native insertion `:11386–11405`, layout stages `:11411–11538`, and final marker/receipt `:11555–11579`. Independent optional savepoints are implemented at [sqlite.rs:21594](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:21594).

The repeated work includes more than SQL preparation:

| Source path | Concrete repeated work still present |
|---|---|
| [observation_statistics.rs:156](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_statistics.rs:156), `:302`, `:317` | Select/decode the previous aggregate, resolve native facts, fold, encode, and update the current event. A trace anchor reads the previous trace total and stores its successor. Compact encoding and shared local/global folding already reduce this work; its row frequency remains. |
| [observation_turn.rs:137](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_turn.rs:137) | A new turn reads the statistics that were just persisted for the same event to obtain its ordinal. Terminal layout also reads the current event's transcript coordinate at `:123`. |
| [observation_event.rs:402](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_event.rs:402) | Encode a structural source, build its seekable layout, persist inline bytes or segmented fields, derive previews, read trace total and result ledger position, then encode/persist a witness. This is additional representation work beyond native `event_json`. |
| [read_layout.rs:528](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/runtime/read_layout.rs:528), `:560` | Structural serialization is followed by parsing/index construction. Schema lookup is cached in `structural_json.rs:662`; this is not a claim that the schema itself is rebuilt every time. |
| [observation_event/inline.rs:82](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_event/inline.rs:82), `:108`; [observation_event.rs:758](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_event.rs:758) | Each selected preview performs a geometry traversal and a preview traversal, then is decoded for the witness. Common closed variants already have a reduced allowlist, so removing another traversal cannot be assumed to dominate the short benchmark. |
| [observation_trace/event.rs:559](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_trace/event.rs:559), `:678` | Trace construction resolves ownership/location and other SQL evidence; failure trace data reads the execution header produced earlier in the same append. It stores another bounded header. |
| [observation_receipt.rs:11](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_receipt.rs:11), `:19–76` | Receipt construction re-reads witness and, for relevant terminals, execution summary; it separately checks unavailable evidence, captures a read cut, queries journal/transcript readiness frontiers, and reads trace total again. These are current transaction reads, not an unsafe cache. |

Statistics rows that look unchanged at the total-counter level are not automatically removable. `record_duration` updates the local active interval's observed timestamp for the same attempt ([observation_statistics.rs:489](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_statistics.rs:489)). Historical cuts and duration semantics must be checked before omitting such rows.

## Declared schema amplification is not measured WAL amplification

A static count of current source finds **32 observation columns** in `events`, **28 directly declared event indexes**, and **12 additional presentation indexes**, with no overlap between the two index-name sets: **40 explicitly declared event indexes**, excluding SQLite's primary-key/unique autoindexes. Source locations are [sqlite.rs:8738](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:8738) for the event table, `:8779–8827` for direct declarations, and [sqlite.rs:8327](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:8327) for `PRESENTATION_INDEXES`.

The count was computed by reading the source only:

```python
from pathlib import Path
import re

s = Path('src/durable/sqlite.rs').read_text()
a = s.index('CREATE TABLE IF NOT EXISTS events (')
b = s.index(');', a)
columns = set(re.findall(
    r'\b(observation_[a-z_]+)\s+(?:BLOB|INTEGER|TEXT)', s[a:b]))
direct = set(re.findall(
    r'CREATE (?:UNIQUE )?INDEX IF NOT EXISTS (\w+) ON events\(', s))
a = s.index('const PRESENTATION_INDEXES:')
b = s.index('\n];', a)
presentation = set(re.findall(r'"(events_[a-z_]+_idx)"', s[a:b]))
# len(columns)=32; len(direct)=28; len(presentation)=12;
# direct & presentation == set()
```

These are **declared indexes**, not 40 index writes per event. Partial predicates, changed columns, event variants, page occupancy and transaction boundaries determine which B-trees are actually affected. Likewise, multiple UPDATE statements in one transaction do not imply the same number of WAL page images. Page reuse, cached dirty pages, spills, indexes and checkpointing affect physical write accounting. The statement/column count establishes structural work to investigate, not a measured physical-write multiplier. Retaining commit cadence and most index/page structures is consistent with logical-byte savings yielding a much smaller physical-write reduction; that remains an explanation to test against diagnostics, not a derived percentage.

## Difference from the pinned Pi append path

Pi prepares a write batch, validates it, applies final record writes, and updates sequence metadata inside one database transaction: local `packages/durable/src/storage/sqlite/storage.ts:187–207` ([pinned source](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/storage.ts#L187-L207)). An entry write claims its global ID and inserts one encoded entry record: `:807–816`, with ID claim at `:858–861` ([pinned source](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/storage.ts#L807-L816)). The entry table declares two secondary indexes, one partial: local `packages/durable/src/storage/sqlite/migrations.ts:32–40` ([pinned source](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/migrations.ts#L32-L40)).

Pi also writes tasks, submissions, documents/revisions, and metadata. Comparing only its entry table against all RustX storage would undercount Pi. Nevertheless, the inspected Pi path does not perform RustX's chain of same-event observation-column enrichment and immediate readback. That is a concrete source-level difference. It does not prove the two engines expose identical durable historical field/range, corruption, publication or recovery contracts.

## Bounded next target and its constraints

The architectural candidate is an append-scoped typed set of derived facts: resolve shared native identities once, construct each bounded layout once, pass proven producer facts to dependent layout builders, and persist finalized representations with fewer row reconstructions. Scope it to the append transaction; do not introduce a cross-cut or cross-transaction cache. Keep existing historical readers and their cut/ownership checks as the correctness oracle.

There are two material barriers to simply replacing the chain with one UPDATE:

1. **Independent failure survival.** Current optional savepoints allow successful unrelated facts to survive a different layout's encoding, SQL, constraint or trigger failure. One combined UPDATE makes all columns share one failure boundary. It can therefore lose evidence that survives today, even if the normal success path matches.
2. **Stored-evidence validation.** Supplying a just-computed value directly to a receipt can hide corruption introduced by the actual SQL write or triggers. Earlier layout outputs also have deliberate ordering dependencies, including current sequence, current statistics and transcript assignment. A refactor needs an explicit final stored-evidence validation design, not an assumption that constructed values equal persisted values.

This is substantial modular work, not a codec adjustment. The safe immediate follow-up is to attribute the remaining CPU/SQL work and touched database/WAL pages using the already planned diagnostics, then choose whether to invest in that refactor. Combining final receipt reads without changing storage shape is narrower, but this review has no measurement showing it is a major cost. Duplicate lifecycle probes, another small tuple conversion, or removing only `observation_json` should not displace the larger investigation without such evidence.

No production source changes, builds, or benchmark product runs were performed for this review.
