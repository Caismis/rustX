# PR485 joint major-cost round: source comparison

Source audit: 2026-10-27. This document describes the candidate implementation, not measured performance results or a claim of cross-engine equivalence. Build, behavioral oracle, and paired performance results belong in the accompanying validation report.

The candidate contains four grouped changes: shared native request configuration, compact event-derived aggregates with shared folding, incremental checkpoint captures, and reuse of fixed SQL statements. These remove identifiable repeated work. They do not remove RustX's entire observation plane or establish that it has caught Pi Durable.

## Source identity and reference convention

| Label | Local checkout | Pinned revision |
|---|---|---|
| RustX candidate | `/home/capi/.codex/worktrees/pr485-pi-performance/rustX` | `123accb38fd8cf1e8f88583c1858d514cb453870`, source tree `65d050f7f3c72007309e2e61b0324dc52227ba40`. |
| Pi Durable | `/home/capi/Documents/codes/pi-rustx-benchmark` | `90d863f7c1183b965f099855715d6e88c7b8a52c` |
| DeepSeek Harness | `/home/capi/.cache/rustx-pr485-next/deepseek-checkout` | `687f282e8625c6b8d11ff58211a90524be2e4317` |

All paths and line numbers below are relative to these exact checkouts. The source-reference table includes local locations and pinned GitHub links for the reference engines. RustX links point to the inspected candidate files at the committed candidate revision.

## 1. Share native frozen request configuration

**Pi and DeepSeek:** Pi plans system-section and tool deltas. Unchanged sections/tools produce no system entry; order changes can require a new baseline or remove/re-add operations. Its request checkpoint still records attempt, model, thinking level, stream options, and selected-entry cutoff. DeepSeek records a request header initially, on resume, on change, or at a new request series; unchanged ordinary requests do not append another header. Its request context is likewise appended on relevant changes. These engines still compare configuration: Pi serializes tool declarations for equality, and DeepSeek serializes tool schemas for equality. Neither source supports a claim of zero configuration CPU. [P1–P3, D1–D2]

**Actual RustX change:** `request_configurations` holds one exact serialized value per SHA-256 digest. Only `effective_system_prompt`, `system_sections`, and `tool_definitions` move into that shared value. Per-request metadata retains the other snapshot fields, a configuration digest, and empty placeholders; selected input remains in its existing immutable manifest. A borrowed serializer avoids cloning configuration/history merely to form storage metadata. The write path checks reconstructed full-record size, reads the existing configuration row, compares exact bytes, and inserts only on a miss. A fresh request validates the stored metadata/configuration and selected root without deserializing the shared configuration back into typed values. [R1–R2]

**Remaining work:** Every request still serializes and hashes those three configuration fields and reads/compares the shared bytes. Per-request identity, invocation/options and other metadata still serialize and persist. Fresh authentication still reads and hashes the stored configuration. Historical materialization fetches, authenticates, and deserializes it. The existing optional indexed inspection representation remains separate, with field/range geometry and source-node hashes. Native recovery data and inspection data have distinct contracts; this round has not unified them. [R1–R3]

**Bounds and integrity:** The full reconstructed native record remains subject to the 64 MiB storage bound, rather than charging only its short reference. Missing, oversized, malformed, or digest-mismatching shared rows fail. Exact metadata and immutable selected-root checks remain in the caller's transaction. There is no unchecked process-local configuration cache. [R1–R2]

## 2. Compact event-derived storage and fold shared statistics once

**Reference pattern:** Pi's context reader keeps an immutable previous range, scans only an appended suffix while the head is unchanged, and returns fresh outer arrays. A changed head or historical rewind still requires derivation. DeepSeek incrementally folds its header and message surface and reuses frozen message values; its projection service advances each cell through new events and invalidates views when state identity changes. This supports reusing unchanged derived values, not a claim that either engine has no reads or projection cost. [P4–P5, D3–D4]

**Actual RustX change:** Statistics and execution headers now use private fixed-position JSON tuples instead of repeatedly encoding descriptive object keys. Execution retains all owner coordinates, optional fields, request/terminal/failure data, and timing validity flags. Statistics stores only the six activity fields used by this aggregate and stores identical conversation/local totals once. Local duration and active-start state remain independent. Distinct lineage totals retain separate values. When the previous totals are equal, the event fold runs once and its result is reused; otherwise both folds use one shared set of native facts, including the completed-assistant check or tool-span lookup. [R4–R5]

**Remaining work:** Every event requiring these derived layouts still reads its previous bounded aggregate and writes its current aggregate into the event row. This is not a reduction in event count or transaction count. Native event JSON, membership, witness, trace, turn, readiness and other layouts remain. The append path still performs lifecycle updates, partial-index maintenance, and optional-layout savepoints. Historical-cut readers still select the correct row and enforce ownership and missing-evidence checks. [R4–R6]

**Admission nuance:** Execution continues to apply the former public-shaped structural admission before emitting its smaller private tuple, followed by the capped tuple encoder and existing trimming behavior. Statistics instead applies the existing 16 KiB cap to the new smaller private representation. It does **not** simulate the old duplicated-object byte cost, so the private statistics admission domain can be larger. This is an intentional storage-format change; it must not be described as identical private byte-budget acceptance. Public output bounds are unchanged. Both tuple decoders require the current tuple shape; old object encodings have no compatibility decoder. [R4–R5]

## 3. Reuse immutable checkpoint captures and sufficient fit charges

**Reference pattern:** Pi retains immutable context ranges and extends them with suffix entries. DeepSeek retains incrementally folded state and frozen derived messages, and avoids invalidating an unchanged projection view. Both still allocate outer arrays or validate requested wire views. This motivates avoiding repeated normalization and admission of unchanged values, rather than claiming publication can become constant-time. [P4, D3–D4]

**Actual RustX change:** A checkpoint seed can inherit prepared captures for 19 named domains. Each capture owns its normalized DTO, content descriptors, collection descriptors, and a sufficient fit charge. Reuse is tied to an exact domain value or an immutable native owner. Typed equality is accepted only when serialization contains neither floats nor nonempty maps: this conservatively excludes signed-zero and ordered-map cases where equality would not establish identical encoding. Attempt state and other cut-dependent fields are captured afresh. [R7–R8]

The capture records the maximum budget required by its admission decisions, including rejected items. It is replayed only when the current remaining budget can reproduce those decisions; otherwise ordinary capture runs at the current budget. Replayed collection descriptors receive the current revision. Additive fit charges can skip a whole-checkpoint admission walk when they prove sufficient space; unknown or excessive charges use the ordinary structural checks and eviction order. Historical domain hydration clears the prepared owners. [R8–R9]

**Remaining work:** New or changed domains still normalize and capture. Conservative float/map cases rebuild. Equality inspection itself costs CPU. Replay still clones DTO/descriptors; checkpoint construction, sorting, current content metadata/frontier resolution, cut binding, and actual wire encoding remain. The certificate does not authorize a read cut: `capture_evidence`, collection-frontier binding, and current checkpoint metadata are recomputed. [R7–R9]

## 4. Reuse fixed SQL plans in hot readers and aggregate paths

Pi's Node SQLite executor already caches prepared statements by SQL text on the connection; its transaction handles share the cache. [P6]

RustX now uses `prepare_cached` for targeted response ownership/provenance queries and statistics/execution queries. Occupancy prepares one fixed latest-event query and rebinds it for the three relevant event kinds. The connection's existing statement-cache capacity is 64. These changes reuse compilation work. They do not cache query results or replace current transaction/cut bindings with older results. [R4–R5, R10]

Response membership/ownership, inherited provenance, lifecycle and hole checks still execute as applicable. Occupancy still executes three probes and selects the latest qualifying row. Its behavior under missing or corrupt evidence is retained. DeepSeek's in-memory session projections are useful as an architectural reference, but they are not evidence that RustX can remove these SQL checks while preserving its current durable historical-read API. [R10, D4]

## Durability and comparison boundaries

RustX and the pinned Pi Node backend both configure SQLite WAL with `synchronous=NORMAL`. Pi commits using `BEGIN IMMEDIATE`/`COMMIT` and checkpoints WAL on close. This round does not change RustX's synchronous setting or merge native commit boundaries. Matching pragmas do not prove matching transaction counts, WAL traffic, failure behavior, or recovery contracts. [R11, P6]

DeepSeek's JSONL persistence performs a real `handle.sync()` after appending a batch. Live session events first enter a persistence-owned cloned buffer and a timer-driven drain; an explicit session flush drains that buffer and waits for the handle barrier. Its checkpoint policy awaits flush before model dispatch, before top-level tools, and before the next step. The core session flush propagates listener failure after all listeners settle. [D5–D7]

The native SDK agent appends `turn/end` and emits idle without awaiting that final flush. Therefore the SDK idle boundary is not a final fsync acknowledgment. This is entry-point-specific: the shipped **headless** path explicitly awaits `sessions.flush(agent.session)` after idle before completing. A benchmark ending at SDK idle must not be presented as the same durability window as one ending after that explicit flush. Close/reopen checks also do not establish power-loss guarantees. [D8–D9]

RustX schema is **78**, with exact version validation. No migration or old-codec fallback is included. This is consistent with the repository's no-backward-compatibility requirement, but an older store is rejected rather than silently upgraded. [R11]

The preserved prior fixture offers RustX seven tools, Pi four, and DeepSeek 25. Its cross-engine request oracle checks common core semantics, not identical complete native prompts or tool surfaces. Same-engine baseline/candidate comparison uses the full request oracle and is the appropriate place to isolate this round's changes. The DeepSeek reference uses native SDK source through TSX with the recorded generated-Typer-loader profile adjustment, not built CLI startup; it does not expose partial-token text publication like RustX's stream surface. These constraints come from the pinned prior report, not new measurements in this audit. [F1]

## What the source establishes—and what still needs measurement

The four mechanisms remove repeated native configuration storage, repeated aggregate field names/shared totals, duplicate aggregate folding/fact resolution, repeated unchanged checkpoint capture/admission, and repeated preparation of selected SQL statements. They preserve substantial RustX-specific work: normalized request authentication, native plus indexed observation representations, per-event aggregate writes, historical-cut validation, and current checkpoint metadata/wire generation.

The source alone does not establish which remaining cost dominates or a speedup percentage. Report logical stored bytes, physical database/WAL bytes, process write accounting, SQL operation counts, CPU, and wall time separately. Pair measurements by fixture, iteration, and completion boundary, and retain the full same-engine request/recovery/publication oracles. Neither lower logical bytes nor fewer serialization passes alone proves lower end-to-end latency.

## Source references

### Candidate RustX

| ID | Exact local source locations |
|---|---|
| R1 | [native_request.rs:23](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/native_request.rs:23): shared fields/borrowed metadata; `:131` digest; `:154` persist; `:200` read and reconstructed bound; `:252` authenticate; `:265` full decode. |
| R2 | [sqlite.rs:6087](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:6087): exact fresh binding; `:8629` configuration table; `:8633` request table; `:13808` normalized request manifest digest. |
| R3 | [observation_request/composed.rs:186](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_request/composed.rs:186): indexed selected request; [composed/nodes.rs:7](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_request/composed/nodes.rs:7): source-node lookup/hash validation. |
| R4 | [observation_statistics.rs:20](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_statistics.rs:20): tuple fields/shared values; `:100` encode/bound; `:119` decode; `:156` historical layout; `:317` event fold/write; `:369` shared native facts. |
| R5 | [observation_execution/storage.rs:7](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_execution/storage.rs:7): exact tuple fields; `:40` original admission and encoding; `:93` decode. [observation_execution.rs:25](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_execution.rs:25): layout query; `:90` hole/owner checks; `:217` event update. |
| R6 | [sqlite.rs:11389](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:11389): event insertion and required flags; `:11411` readiness/statistics/membership; `:11454` execution; `:11486` witness; `:11537` turns; `:21594` optional savepoint. |
| R7 | [projection/prepared_capture.rs:19](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/runtime_client/projection/prepared_capture.rs:19): 19 domains; `:51` inheritance; `:138` additive fit budget; `:163` encoding-equality restriction. |
| R8 | [checkpoint.rs:95](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/runtime_client/checkpoint.rs:95): sufficient-budget/ordinary fit; `:605` required admission budget; `:615` prepared replay/fallback. [preflight.rs:45](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/runtime_client/preflight.rs:45): sufficient safe-integer charge. |
| R9 | [projection.rs:748](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/runtime_client/projection.rs:748): hydration invalidation; `:802` checkpoint capture; `:951` current evidence/cut/final fit fields; `:1132` evidence; `:1187` collection frontiers; `:6406` seed inheritance. |
| R10 | [observation_response.rs:51](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_response.rs:51): cached hole query; `:127` inherited provenance; `:139` owner lookup; `:155` ledger lookup. [observation_occupancy.rs:174](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite/observation_occupancy.rs:174): one statement/three probes. `sqlite.rs:883`: cache capacity. |
| R11 | [sqlite.rs:338](/home/capi/.codex/worktrees/pr485-pi-performance/rustX/src/durable/sqlite.rs:338): schema 78; `:8118` NORMAL; `:8124` WAL; `:8204` and `:8861` exact-version rejection. |

### Pi Durable, pinned `90d863f7c1183b965f099855715d6e88c7b8a52c`

| ID | Local path and pinned GitHub source |
|---|---|
| P1 | `packages/durable/src/harness/prompt.ts:66–141` — [configuration delta planner](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/harness/prompt.ts#L66-L141). |
| P2 | `packages/durable/src/harness/generation.ts:64–72,161–194` — [request checkpoint fields](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/harness/generation.ts#L64-L72), [append deltas and commit request](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/harness/generation.ts#L161-L194). |
| P3 | `packages/ai/src/utils/transcript.ts:58–65,135–141` — [tool replay](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/ai/src/utils/transcript.ts#L58-L65), [serialized declaration equality](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/ai/src/utils/transcript.ts#L135-L141). |
| P4 | `packages/durable/src/harness/context.ts:73–108` — [incremental context range](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/harness/context.ts#L73-L108). |
| P5 | `packages/durable/src/storage/sqlite/storage.ts:348–382` — [entry query, JSON decode, parent traversal](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/storage.ts#L348-L382). |
| P6 | `packages/durable/src/storage/sqlite/node.ts:76–118,144–197` — [statement cache](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/node.ts#L76-L118), [transaction/close/open boundaries](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/node.ts#L144-L197). |

### DeepSeek Harness, pinned `687f282e8625c6b8d11ff58211a90524be2e4317`

| ID | Local path and pinned GitHub source |
|---|---|
| D1 | `packages/core/agent-loop/src/agent.ts:626–703` — [header/context change detection and frozen request assembly](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/agent-loop/src/agent.ts#L626-L703). |
| D2 | `packages/core/session/src/request-header.ts:21–51` — [normalization and serialized tool equality](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/session/src/request-header.ts#L21-L51). |
| D3 | `packages/core/session/src/index.ts:912–921,984–1004` — [header suffix fold](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/session/src/index.ts#L912-L921), [message suffix derivation](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/session/src/index.ts#L984-L1004). |
| D4 | `packages/session/session-projection/src/index.ts:633–711` — [incremental cells, eager drive and explicit view validation](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-projection/src/index.ts#L633-L711). |
| D5 | `packages/session/session-checkpoint-policy/src/index.ts:29–36,63–81` — [flush before model stream](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-checkpoint-policy/src/index.ts#L29-L36), [tool and next-step barriers](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-checkpoint-policy/src/index.ts#L63-L81). |
| D6 | `packages/session/session-persistence-jsonl/src/index.ts:1411–1438` — [append and fsync](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-persistence-jsonl/src/index.ts#L1411-L1438). |
| D7 | `packages/session/session-persistence-jsonl/src/storage.ts:203–211,274–308,549–560` — [handle barrier](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-persistence-jsonl/src/storage.ts#L203-L211), [buffered clone/drain](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-persistence-jsonl/src/storage.ts#L274-L308), [event/flush listeners](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-persistence-jsonl/src/storage.ts#L549-L560). `packages/core/session/src/index.ts:1319–1335` — [flush failure propagation](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/session/src/index.ts#L1319-L1335). |
| D8 | `packages/core/agent-loop/src/agent.ts:144–151,252–264,384–391` — [synchronous status emission](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/agent-loop/src/agent.ts#L144-L151), [idle transition](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/agent-loop/src/agent.ts#L252-L264), [turn-end append](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/core/agent-loop/src/agent.ts#L384-L391). |
| D9 | `packages/bundle/headless/src/index.ts:379–398` — [headless idle followed by explicit flush](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/bundle/headless/src/index.ts#L379-L398). |

### Preserved fixture scope

| ID | Local path and pinned GitHub source |
|---|---|
| F1 | RustX `docs/pi-durable-cost-model/2026-10-27-shared-request-response.md:210–234` — [prior fixture/oracle and native DeepSeek scope](https://github.com/Caismis/rustX/blob/326380ae14d78b8003a2ce05587290a7de7be707/docs/pi-durable-cost-model/2026-10-27-shared-request-response.md#L210-L234). Old measurement numbers are deliberately not reused as evidence for this candidate. |
