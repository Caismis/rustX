#!/usr/bin/env python3
"""Run one predeclared post-hoc cell; keep all results separate from the initial matrix."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
BEFORE = Path('/home/capi/.cache/rustx-pr485-highvalue/candidate-gh-build/conformance')
AFTER = ROOT / 'candidate-joint-build/conformance'
HEAD = '123accb38fd8cf1e8f88583c1858d514cb453870'
PINS = {
    'before': ('063ef7a9b713e76efad6dc4e6b7122454023c67f',
               'cce30715eed4b1700c5b3c5fee2a93db1fb4ca49c8847cf36dfe995e4470e9b0'),
    'after': (HEAD, '6899c8fad1fc85e8ffd36a33b92e85cec877cda3689bb26a03c6f07c658a3d43'),
}


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def identity(name, binary):
    data = json.loads((binary.parent / 'identity.json').read_text())
    assert data['verified'] is True and data['clean_exit'] == data['build_exit'] == 0
    assert data['binary'] == str(binary)
    assert (data['head'], data['sha256']) == PINS[name]
    assert data['sha256'] == sha(binary)
    assert data['production_tree'] == git('rev-parse', data['head'] + ':src')
    for path, digest in data['harness'].items():
        assert sha(REPO / path) == digest
    return data


def source_snapshot(identities):
    paths = ['src', 'Cargo.toml', 'Cargo.lock', 'benchmarks/runtime',
             'tests/common/provider_emulator.rs', 'tests/conformance/agent_loop/runtime_benchmark.rs',
             'tests/conformance/agent_loop/runtime_benchmark']
    assert not git('status', '--porcelain', '--', *paths)
    head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD:src')
    assert head == HEAD and tree == identities['after']['production_tree']
    assert 'pub const SQLITE_SCHEMA_VERSION: i64 = 78;' in (REPO / 'src/durable/sqlite.rs').read_text()
    for name, binary in [('before', BEFORE), ('after', AFTER)]:
        assert identity(name, binary) == identities[name]
    fixtures = {str(path.relative_to(REPO)): sha(path)
                for path in sorted((REPO / 'benchmarks/runtime').rglob('*'))
                if path.is_file() and '__pycache__' not in path.parts}
    files = {str(path.relative_to(REPO)): sha(path)
             for path in sorted((REPO / 'src').rglob('*')) if path.is_file()}
    files.update({path: sha(REPO / path) for path in ('Cargo.toml', 'Cargo.lock')})
    return dict(head=head, production_tree=tree, schema=78, fixtures=fixtures,
                files=files, utc=utc())


def main():
    identities = {name: identity(name, binary) for name, binary in [('before', BEFORE), ('after', AFTER)]}
    assert identities['before']['harness'] == identities['after']['harness']
    assert identities['before']['rustc'] == identities['after']['rustc']
    profiles = json.loads((ROOT / 'profile-commands.json').read_text())
    assert len(profiles) == 4 and all(row['status'] == 'complete' and row['exit'] == 0 for row in profiles)
    columns = json.loads((ROOT / 'columns-commands.json').read_text())
    assert len(columns) == 2 and all(row['status'] == 'complete' and row['exit'] == 0 for row in columns)
    initial = source_snapshot(identities)
    assert max(row['end_utc'] for row in profiles + columns) < initial['utc']
    base = ROOT / 'confirmation-cohorts'
    base.mkdir(exist_ok=False)
    command = [sys.executable, 'benchmarks/runtime/compare-revisions.py',
               '--before', str(BEFORE), '--after', str(AFTER),
               '--output', str(base / 'direct-no-live'), '--pairs', '7', '--pair-offset', '3',
               '--observer-mode', 'no-live-subscriber', '--case', 'short-large']
    record = dict(
        reason='Post-hoc confirmation selected because all three initial no-live short-large wall ratios '
               'regressed (median approximately +2.15%, maximum approximately +20%). '
               'Run only this predeclared cell after completed formal matrices and diagnostics. '
               'Retain every original and confirmation sample separately; do not trim, pool, replace '
               'the initial matrix, or treat one selected cell as the complete nonregression/parity gate.',
        identities=identities, source_before=initial, command=command,
        explicit_environment={'UV_OFFLINE': '1'}, runner_sha256=sha(__file__),
        status='running', start_utc=utc())

    def save():
        (base / 'commands.json').write_text(json.dumps(record, indent=2) + '\n')

    save()
    with (base / 'cohort.stdout').open('w') as out, (base / 'cohort.stderr').open('w') as err:
        result = subprocess.run(command, cwd=REPO, env=os.environ | {'UV_OFFLINE': '1'}, stdout=out, stderr=err)
    record.update(status='complete' if result.returncode == 0 else 'failed',
                  exit=result.returncode, end_utc=utc())
    save()
    record['source_after'] = source_snapshot(identities)
    save()
    assert {key: value for key, value in initial.items() if key != 'utc'} == {
        key: value for key, value in record['source_after'].items() if key != 'utc'}
    result.check_returncode()
    print('confirmation', result.returncode, flush=True)


if __name__ == '__main__':
    main()
