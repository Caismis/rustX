#!/usr/bin/env python3
"""Independently extract and verify a completed joint evidence archive.

Runs only the two retained raw-only auditors, never products/builds/profilers.
All audit outputs and logs stay outside the extracted raw tree. Nothing runs on
import; invoke after packaging has finished. A new work directory is required.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import tarfile

DEFAULT_EVIDENCE = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/evidence/joint-major-runtime-20261027')
DEFAULT_WORK = Path('/home/capi/.cache/rustx-pr485-joint-portable-verification')
FORMAT = 'rustx-joint-runtime-raw-evidence-v1'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_text())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def integer(value, name):
    require(type(value) is int and value >= 0, f'invalid nonnegative integer: {name}')
    return value


def safe_name(name):
    require(isinstance(name, str) and name and '\\' not in name and '\x00' not in name,
            f'invalid member name: {name!r}')
    path = PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and name == str(path)
            and name != '.', f'unsafe/noncanonical member path: {name!r}')
    return path


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f'duplicate manifest JSON key: {key}')
        result[key] = value
    return result


def fingerprint(path):
    item = path.lstat()
    require(stat.S_ISREG(item.st_mode), f'expected regular file: {path}')
    return item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns


def verify_tree(root, expected):
    files, directories = set(), set()
    expected_directories = {str(parent) for name in expected for parent in PurePosixPath(name).parents
                            if str(parent) != '.'}
    for directory, folders, names in os.walk(root, followlinks=False):
        directory = Path(directory)
        for name in folders:
            path = directory / name
            require(stat.S_ISDIR(path.lstat().st_mode), f'non-directory/symlink in extraction: {path}')
            directories.add(path.relative_to(root).as_posix())
        for name in names:
            path = directory / name
            relative = path.relative_to(root).as_posix()
            require(relative in expected and stat.S_ISREG(path.lstat().st_mode),
                    f'unexpected/nonregular extracted file: {relative}')
            record = expected[relative]
            require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'],
                    f'extracted hash/size differs: {relative}')
            files.add(relative)
    require(files == set(expected) and directories == expected_directories,
            'missing/extra extracted files or directories')


def extract_and_verify(archive_path, summary, root):
    observed, manifest_bytes = {}, None
    size_limit = summary['raw_bytes'] + summary['manifest_bytes']
    total = 0
    root.mkdir(mode=0o700)
    # No extractall: explicitly accept regular files only and create every
    # destination exclusively beneath a newly created directory.
    with tarfile.open(archive_path, 'r|xz') as archive:
        for member in archive:
            safe_name(member.name)
            require(member.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not member.issparse(),
                    f'nonregular archive member: {member.name}')
            require(member.name not in observed, f'duplicate archive member: {member.name}')
            integer(member.size, 'member size')
            total += member.size
            require(total <= size_limit and len(observed) < summary['raw_files'] + 1,
                    'archive exceeds declared payload size/count')
            source = archive.extractfile(member)
            require(source is not None, f'missing member bytes: {member.name}')
            destination = root / member.name
            destination.parent.mkdir(parents=True, exist_ok=True)
            digest, length = hashlib.sha256(), 0
            with destination.open('xb') as output:
                while block := source.read(1024 * 1024):
                    output.write(block)
                    digest.update(block)
                    length += len(block)
            require(length == member.size, f'truncated member: {member.name}')
            observed[member.name] = {'bytes': length, 'sha256': digest.hexdigest()}
            if member.name == 'MANIFEST.json':
                manifest_bytes = destination.read_bytes()
    require(manifest_bytes is not None, 'MANIFEST.json missing')
    require(observed['MANIFEST.json'] == {'bytes': summary['manifest_bytes'],
                                        'sha256': summary['manifest_sha256']},
            'manifest differs from external summary')
    manifest = json.loads(manifest_bytes, object_pairs_hook=unique_object)
    require(manifest['format'] == summary['format'] == FORMAT, 'archive format differs')
    entries = manifest['files']
    require(isinstance(entries, dict) and len(entries) == summary['raw_files'], 'manifest file count differs')
    expected = {}
    for name, record in entries.items():
        safe_name(name)
        require(name != 'MANIFEST.json', 'manifest recursively lists itself')
        integer(record['bytes'], 'manifest file bytes')
        require(re.fullmatch('[0-9a-f]{64}', record['sha256']), f'invalid file hash: {name}')
        expected[name] = {'bytes': record['bytes'], 'sha256': record['sha256']}
    require(sum(record['bytes'] for record in expected.values()) == summary['raw_bytes'],
            'manifest total payload bytes differ')
    expected['MANIFEST.json'] = {'bytes': summary['manifest_bytes'], 'sha256': summary['manifest_sha256']}
    require(observed == expected, 'stream member set/hash/size differs from complete manifest')
    verify_tree(root, expected)
    return manifest, expected


def audit_command(summary, manifest, label, destination):
    key = 'raw_only_audit_command' if label == 'formal' else 'raw_only_diagnostic_audit_command'
    command = summary[key]
    require(command == manifest[key] and isinstance(command, list)
            and all(isinstance(value, str) for value in command), f'{label} summary/manifest argv differs')
    if label == 'formal':
        expected = ['python3', 'audit-joint.py', '--root', '.', '--raw-only', '--stage', 'all',
                    '--baseline-identity', 'baseline-build/identity.json',
                    '--candidate-identity', 'candidate-joint-build/identity.json',
                    '--freeze', 'deepseek-setup/final-source-identity.json',
                    '--expected-harness-revision', summary['harness_revision'],
                    '--expect-rust-sha256', summary['candidate_sha256'],
                    '--output', '../archive-joint-audit.json']
    else:
        expected = ['python3', 'audit-diagnostics.py', '--root', '.', '--raw-only',
                    '--baseline-identity', 'baseline-build/identity.json',
                    '--candidate-identity', 'candidate-joint-build/identity.json',
                    '--formal-audit', 'joint-audit.json',
                    '--expected-harness-revision', summary['harness_revision'],
                    '--expect-rust-sha256', summary['candidate_sha256'],
                    '--output', '../diagnostic-raw-audit.json']
    require(command == expected, f'{label} command is not the expected portable raw-only audit')
    # Only relocate the intended output, keeping every identity input inside raw.
    command = command.copy()
    command[-1] = str(destination)
    return command


def strict_reports(root):
    formal, diagnostic = load(root / 'joint-audit.json'), load(root / 'diagnostic-audit.json')
    for label, report, script in [('formal', formal, 'audit-joint.py'),
                                  ('diagnostic', diagnostic, 'audit-diagnostics.py')]:
        require(report['accepted'] is True and report['mode'] == 'strict'
                and report['strict_identity_verified'] is True and report['errors'] == [],
                f'preserved {label} strict report is not accepted')
        require(report['script_sha256'] == sha(root / script), f'{label} auditor changed after strict report')
    require(diagnostic['formal_audit']['sha256'] == sha(root / 'joint-audit.json'),
            'strict diagnostic report is not bound to strict formal report')
    return formal, diagnostic


def product_metrics_from_pairs(dataset, stage):
    products = {}
    numerator, denominator = ('after', 'before') if stage == 'direct' else ('rust', 'pi')
    for group in dataset['groups']:
        for pair in group['pairs']:
            for engine, field in [(numerator, 'numerator'), (denominator, 'denominator')]:
                key = (group['cohort'], group['case'], pair['pair'], engine)
                metrics = products.setdefault(key, {})
                require(group['metric'] not in metrics, 'duplicate per-product metric in paired report')
                metrics[group['metric']] = pair[field]
    require(len(products) == dataset['derived_products'], 'paired per-product metric coverage differs')
    return products


def compare_formal(raw, strict):
    require(raw['accepted'] is True and raw['errors'] == [] and raw['mode'] == 'raw-only'
            and raw['strict_identity_verified'] is False and raw['actual_build_identity_verified'] is False
            and raw['recorded_build_identity_verified'] is True, 'formal raw-only acceptance/identity mode invalid')
    require(raw['identities'] == strict['identities'], 'formal recorded build identities differ')
    require(raw['datasets'].keys() == strict['datasets'].keys(), 'formal dataset inventory differs')
    result = {}
    for stage, actual in raw['datasets'].items():
        expected = strict['datasets'][stage]
        fields = ['derived_products', 'valid_comparisons', 'groups']
        fields += [key for key in ('checked_requests', 'product_inventory', 'products', 'comparisons',
                                  'admissions', 'records_sha256', 'original_audit_sha256', 'command_record_sha256')
                   if key in expected]
        require(all(actual[key] == expected[key] for key in fields),
                f'{stage} formal numerical/admission records differ')
        if stage in ('direct', 'final'):
            require(product_metrics_from_pairs(actual, stage) == product_metrics_from_pairs(expected, stage),
                    f'{stage} per-product paired values differ')
        if stage == 'three-engine':
            require(actual['mode'] == 'raw-only' and actual['strict_identity_verified'] is False,
                    'nested three-engine audit claimed actual identity verification')
        result[stage] = {'equal_fields': fields, 'products': actual['derived_products'],
                         'comparisons': actual['valid_comparisons'], 'checked_requests': actual.get('checked_requests'),
                         'per_product_values': 'Compared from every metric pair' if stage in ('direct', 'final') else
                         'Compared explicit products' if 'products' in actual else
                         'Recomputed and compared to retained three-engine rows by accepted audit-joint.py'}
    return result


def compare_diagnostic(raw, strict):
    require(raw['accepted'] is True and raw['errors'] == [] and raw['mode'] == 'raw-only'
            and raw['strict_identity_verified'] is False and raw['actual_binary_and_preload_verified'] is False
            and raw['recorded_build_identity_verified'] is True, 'diagnostic raw-only acceptance/identity mode invalid')
    fields = ['identities', 'profiles', 'columns', 'column_comparison', 'profile_comparison',
              'cpu_counts_sha256', 'profile_commands_sha256']
    require(all(raw[key] == strict[key] for key in fields), 'diagnostic columns/profile/count records differ')
    for revision in ('baseline', 'joint'):
        for key in ('sha256', 'cargo_stdout_sha256'):
            require(raw['build_receipts'][revision][key] == strict['build_receipts'][revision][key],
                    'diagnostic archived build receipt differs')
    for key in ('sha256', 'mode', 'strict_identity_verified', 'harness_revision', 'products', 'windows'):
        require(raw['formal_audit'][key] == strict['formal_audit'][key], 'diagnostic formal binding differs')
    left, right = raw['column_timing_isolation'], strict['column_timing_isolation']
    require(left['verified'] is True and right['verified'] is True, 'column timing isolation unavailable')
    require({key: value for key, value in left.items() if key != 'file'} ==
            {key: value for key, value in right.items() if key != 'file'}, 'column timing ledger differs')
    require(len(raw['profiles']) == len(raw['columns']) == 4, 'diagnostic product inventory differs')
    return {'equal_fields': fields, 'profile_products': len(raw['profiles']), 'column_products': len(raw['columns']),
            'recorded_build_and_formal_hashes_equal': True, 'column_timing_ledger_equal': True,
            'allowed_path_differences': 'Relocated build receipt, formal audit, and column ledger file paths only.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--evidence', type=Path, default=DEFAULT_EVIDENCE)
    parser.add_argument('--work-dir', type=Path, default=DEFAULT_WORK)
    parser.add_argument('--expect-archive-sha256')
    parser.add_argument('--output', type=Path, help='Defaults to EVIDENCE/portable-verification.json')
    args = parser.parse_args()
    evidence, work = args.evidence.resolve(), args.work_dir.resolve()
    output = (args.output or evidence / 'portable-verification.json').resolve()
    require(not work.exists(), f'work directory already exists: {work}')
    require(not work.is_relative_to(evidence), 'work directory must be outside archived evidence directory')
    require(not output.exists(), f'refusing to overwrite verification report: {output}')
    require(not output.is_relative_to(work / 'raw'), 'verification report must be outside extracted raw')
    report = {'accepted': False, 'started_utc': now(), 'errors': [], 'commands': [],
              'verification_script_sha256': sha(Path(__file__)), 'actual_host_binaries_reverified': False,
              'actual_host_sources_reverified': False, 'external_verification_directory': str(work)}
    work.mkdir(mode=0o700, parents=True)
    try:
        summary_path = evidence / 'summary.json'
        summary_before = fingerprint(summary_path)
        summary = load(summary_path)
        require(summary['format'] == FORMAT and summary['archive'] == 'raw.tar.xz', 'unexpected archive summary')
        for key in ('archive_bytes', 'manifest_bytes', 'raw_files', 'raw_bytes'):
            integer(summary[key], key)
        for key in ('archive_sha256', 'manifest_sha256', 'candidate_sha256'):
            require(re.fullmatch('[0-9a-f]{64}', summary[key]), f'invalid summary digest: {key}')
        require(re.fullmatch('[0-9a-f]{40}', summary['harness_revision']), 'invalid summary harness revision')
        require(summary['raw_files'] > 0 and summary['manifest_bytes'] > 0, 'empty declared archive')
        archive = evidence / summary['archive']
        archive_before = fingerprint(archive)
        actual_digest = sha(archive)
        require(actual_digest == summary['archive_sha256'], 'archive SHA differs from external summary')
        if args.expect_archive_sha256:
            require(actual_digest == args.expect_archive_sha256, 'archive SHA differs from explicit expected identity')
        require(archive.stat().st_size == summary['archive_bytes'], 'archive size differs from summary')
        available = shutil.disk_usage(work).free
        require(available > (summary['raw_bytes'] + summary['manifest_bytes']) * 2,
                'insufficient free space for verification workspace')
        report.update(archive=archive.name, archive_sha256=actual_digest, archive_bytes=summary['archive_bytes'],
                      summary_sha256=sha(summary_path), available_bytes_before=available)
        root = work / 'raw'
        manifest, expected = extract_and_verify(archive, summary, root)
        require('verify-archive.py' in expected and sha(root / 'verify-archive.py') == report['verification_script_sha256'],
                'archive does not contain this exact verification script')
        report.update(manifest_sha256=summary['manifest_sha256'], verified_payload_files=summary['raw_files'],
                      verified_payload_bytes=summary['raw_bytes'], all_payload_stream_and_extracted_hashes_match=True,
                      no_extra_members=True, manifest_matches_external_summary=True)
        print(f"Verified all {summary['raw_files']} payload files; starting retained raw-only auditors.", flush=True)
        preserved_formal, preserved_diagnostic = strict_reports(root)
        outputs = {label: work / filename for label, filename in
                   [('formal', 'archive-joint-audit.json'), ('diagnostic', 'diagnostic-raw-audit.json')]}
        environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1')
        environment.pop('PYTHONPATH', None)
        environment.pop('PYTHONHOME', None)
        for label in ('formal', 'diagnostic'):
            command = audit_command(summary, manifest, label, outputs[label])
            record = {'label': label, 'argv': command, 'cwd': str(root), 'start_utc': now()}
            report['commands'].append(record)
            with (work / (label + '.stdout')).open('x') as stdout, (work / (label + '.stderr')).open('x') as stderr:
                result = subprocess.run(command, cwd=root, env=environment, stdout=stdout, stderr=stderr)
            record.update(end_utc=now(), exit=result.returncode,
                          stdout_sha256=sha(work / (label + '.stdout')), stderr_sha256=sha(work / (label + '.stderr')))
            require(result.returncode == 0, f'{label} raw-only audit failed; see retained external logs')
        formal, diagnostic = load(outputs['formal']), load(outputs['diagnostic'])
        report['formal_numerics_and_admissions_identical'] = compare_formal(formal, preserved_formal)
        report['diagnostic_numerics_and_identity_records_identical'] = compare_diagnostic(diagnostic, preserved_diagnostic)
        report['raw_only_audits_accepted'] = True
        report['formal_products'] = sum(row['derived_products'] for row in formal['datasets'].values())
        report['strict_source_report_sha256'] = sha(root / 'joint-audit.json')
        report['strict_diagnostic_report_sha256'] = sha(root / 'diagnostic-audit.json')
        report['portable_report_sha256'] = {label: sha(path) for label, path in outputs.items()}
        # The auditors must leave every raw byte and the complete inventory intact.
        verify_tree(root, expected)
        require(fingerprint(archive) == archive_before and fingerprint(summary_path) == summary_before,
                'archive or external summary changed during verification')
        report['post_audit_raw_inventory_and_hashes_unchanged'] = True
        report['accepted'] = True
    except Exception as error:
        report['errors'].append(f'{type(error).__name__}: {error}')
    report['finished_utc'] = now()
    report['scope'] = ('Archive integrity and retained evidence arithmetic only. No products, builds, tests, profiler '
                       'sampling or native SDK invoked; no native session decompression. Raw-only auditors do not '
                       'follow historical executable/Git paths or claim actual host identity verification. Preserved '
                       'strict-report claims remain prior evidence, not fresh actual-file verification.')
    encoded = json.dumps(report, indent=2, allow_nan=False) + '\n'
    (work / 'verification-result.json').write_text(encoded)
    with output.open('x') as stream:
        stream.write(encoded)
    print(json.dumps({'accepted': report['accepted'], 'errors': report['errors'],
                      'external': str(work), 'sidecar': str(output)}, indent=2), flush=True)
    return 0 if report['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
