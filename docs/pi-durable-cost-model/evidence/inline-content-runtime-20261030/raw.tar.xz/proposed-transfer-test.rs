#[test]
fn audit_transfer_preserves_large_text_raw_and_completed_json_across_chunk_boundaries() {
    let connection = connection();
    let stream = PublicationStreamId::new("transfer-boundaries");
    let text_parts = [
        "水🙂".repeat(9_000),
        "tailλ".repeat(14_000),
        "end🙂".repeat(1_000),
    ];
    let text = text_parts.concat().into_bytes();
    let text_key = ("live", stream.as_str(), 0, Rep::Utf8Text);
    for (index, part) in text_parts.iter().enumerate() {
        put(
            &connection,
            text_key,
            index as u64 + 1,
            part.as_bytes(),
            true,
        )
        .unwrap();
    }
    assert_eq!(
        range_bytes_at(&connection, text_key, 1, 0, text_parts[0].len() as u64).unwrap(),
        text_parts[0].as_bytes(),
        "later suffixes do not alter the retained prefix"
    );

    let raw_parts = [
        " { \"body\" : \"".to_owned(),
        "arg水".repeat(25_000),
        "\", \"n\": 1e+003 } \n".to_owned(),
    ];
    let raw = raw_parts.concat().into_bytes();
    let raw_key = ("live", stream.as_str(), 1, Rep::RawJsonUtf8);
    for (index, part) in raw_parts.iter().enumerate() {
        put(
            &connection,
            raw_key,
            index as u64 + 1,
            part.as_bytes(),
            true,
        )
        .unwrap();
    }
    let arguments: serde_json::Value = serde_json::from_slice(&raw).unwrap();
    let mut canonical = Vec::new();
    crate::runtime::read_layout::canonical::to_writer(&mut canonical, &arguments).unwrap();
    super::super::content_encoding::put_json(
        &connection,
        ("live", stream.as_str(), 1, Rep::CanonicalJsonV1),
        4,
        &arguments,
        false,
    )
    .unwrap();
    assert_ne!(
        raw, canonical,
        "lexical original and completed JSON stay distinct"
    );
    assert!(text.len() > 131_072 && raw.len() > 131_072 && canonical.len() > 131_072);
    let source_rows = stored_rows(&connection, stream.as_str());
    assert_eq!(source_rows.0, 7);
    let overflow_rows = text.len().div_ceil(SEGMENT_BYTES) - 1
        + raw.len().div_ceil(SEGMENT_BYTES)
        + canonical.len().div_ceil(SEGMENT_BYTES)
        - 1;

    connection
        .execute_batch("SAVEPOINT audit_transfer")
        .unwrap();
    transfer(&connection, &stream, "live", "audit", "rolled-back-audit").unwrap();
    assert_eq!(
        stored_rows(&connection, "rolled-back-audit"),
        (3, overflow_rows as u64)
    );
    connection
        .execute_batch("ROLLBACK TO audit_transfer; RELEASE audit_transfer")
        .unwrap();
    assert_eq!(stored_rows(&connection, "rolled-back-audit"), (0, 0));
    assert_eq!(stored_rows(&connection, stream.as_str()), source_rows);

    transfer(&connection, &stream, "live", "audit", "retained-audit").unwrap();
    clear_live(&connection, &stream).unwrap();
    assert_eq!(stored_rows(&connection, stream.as_str()), (0, 0));
    assert_eq!(
        stored_rows(&connection, "retained-audit"),
        (3, overflow_rows as u64)
    );
    let first_chunks: Vec<String> = connection
        .prepare("SELECT representation FROM content_segments WHERE source_kind='audit' AND source_id='retained-audit' AND segment=0 ORDER BY representation")
        .unwrap()
        .query_map([], |row| row.get(0))
        .unwrap()
        .collect::<Result<_, _>>()
        .unwrap();
    assert_eq!(first_chunks, ["raw_json_utf8"]);
    let inline: Vec<(String, bool)> = connection
        .prepare("SELECT representation,bytes IS NOT NULL FROM content_frontiers WHERE source_kind='audit' AND source_id='retained-audit' ORDER BY representation")
        .unwrap()
        .query_map([], |row| Ok((row.get(0)?, row.get(1)?)))
        .unwrap()
        .collect::<Result<_, _>>()
        .unwrap();
    assert_eq!(
        inline,
        [
            ("canonical_json_v1".into(), true),
            ("raw_json_utf8".into(), false),
            ("utf8_text".into(), true),
        ]
    );
    for (block, representation, expected) in [
        (0, Rep::Utf8Text, text.as_slice()),
        (1, Rep::RawJsonUtf8, raw.as_slice()),
        (1, Rep::CanonicalJsonV1, canonical.as_slice()),
    ] {
        for start in [
            0,
            1,
            65_530,
            65_535,
            65_536,
            65_537,
            131_065,
            expected.len() - 1,
            expected.len(),
        ] {
            let end = (start + SEGMENT_BYTES).min(expected.len());
            assert_eq!(
                range_bytes(
                    &connection,
                    ("audit", "retained-audit", block, representation),
                    start as u64,
                    end as u64,
                )
                .unwrap(),
                expected[start..end],
            );
            let (rows, bytes) = last_read_work();
            assert!(rows <= 2 && bytes == end - start && bytes <= SEGMENT_BYTES);
        }
    }
}
