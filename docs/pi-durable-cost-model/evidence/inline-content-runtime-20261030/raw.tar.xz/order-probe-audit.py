#!/usr/bin/env python3
"""Audit the separately predeclared 24-product Rust order/affinity investigation.

Only retained data and identities are read. No product, provider, benchmark, or
compiler is executed. --raw-only works after portable archive extraction and
does not access recorded executable or source paths. The two arms are never
pooled with one another or with the original formal performance cohort.
"""
import argparse
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
ARMS = ['unpinned', 'same-class']
CASE = 'short-small'
MODE = 'live-subscriber'
PAIRS = 6
DIRECT_SHA = 'b8e268efca4cbff767c5076c26d82b034bb31e19889201be75f80eabdee98c3d'
MATH_SHA = 'e2879454bd2c6ed1add046dd55d6ceaa3c7451087ee92e6e008afcbf7a7e1ac3'
EXPECTED_AFTER = ('ef63fb2cd35d18fb0223d0729d2ab98191f2838b',
                  '7add77966c0baf0bdcb4cddd8615d9f1f8029859',
                  '09dd30e83fc942eb6a630f9fe070f60b5c18523243bd07f63a5ad959fbeec6ee')


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def imported(name, path, digest):
    require(sha(path) == digest, 'frozen auditor digest differs: ' + path.name)
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def descriptive(values):
    available = [value for value in values if value is not None]
    return {'values': values, 'n': len(values), 'available': len(available),
            'missing': len(values) - len(available),
            'median': statistics.median(available) if available else None,
            'minimum': min(available) if available else None,
            'maximum': max(available) if available else None,
            'state': 'complete' if len(available) == len(values) else 'missing_values_retained',
            'interval': None,
            'interval_unavailable_reason': 'Descriptive six-pair investigation; no confidence or parity claim.'}


def paired_value(numerator, denominator):
    ratio, reason = A.MATH.paired_ratio(numerator, denominator)
    difference = None if numerator is None or denominator is None else numerator - denominator
    return {'numerator': numerator, 'denominator': denominator,
            'difference': difference, 'ratio': ratio,
            'percent_change': None if ratio is None else 100 * (ratio - 1),
            'ratio_unavailable_reason': reason,
            'direction': 'unavailable' if difference is None else
                         'lower' if difference < 0 else 'higher' if difference > 0 else 'equal'}


def paired_summary(rows):
    return {'pairs': rows,
            'ratio': descriptive([row['ratio'] for row in rows]),
            'percent_change': descriptive([row['percent_change'] for row in rows]),
            'difference': descriptive([row['difference'] for row in rows]),
            'directions': {direction: sum(row['direction'] == direction for row in rows)
                           for direction in ('lower', 'equal', 'higher', 'unavailable')}}


def order():
    return [(pair, engine, position) for pair in range(PAIRS)
            for position, engine in enumerate(('before', 'after') if pair % 2 == 0
                                               else ('after', 'before'), start=1)]


def binding(args, before, after):
    # Reuse the original strict/raw build, toolchain, source, and harness checks.
    original = A.identity_and_plan(args, before, after)
    require(tuple(after[key] for key in ('head', 'production_tree', 'sha256')) == EXPECTED_AFTER,
            'supplementary candidate is not the final frozen candidate')
    base = args.root / 'order-probe'
    protocol, commands, final = (load(base / name) for name in
                                 ('protocol.json', 'commands.json', 'source-after.json'))
    require(protocol['kind'] == 'supplementary_order_and_affinity_probe' and
            protocol['case'] == CASE and protocol['observer_mode'] == MODE and
            protocol['pairs_per_arm'] == PAIRS and protocol['products_per_arm'] == 12 and
            protocol['arms_run_order'] == ARMS and
            protocol['order'] == 'even before then after; odd after then before',
            'predeclared scope/order differs')
    require(protocol['runner_sha256'] == sha(args.root / 'run-order-probe.py'),
            'predeclared runner bytes changed')
    for name, field in [('direct-audit.json', 'formal_audit_sha256'),
                        ('diagnostic-audit.json', 'diagnostic_audit_sha256')]:
        receipt = load(args.root / name)
        require(protocol[field] == sha(args.root / name) and receipt['accepted'] is True and
                receipt['errors'] == [] and receipt['mode'] == 'strict',
                'original accepted strict receipt differs: ' + name)
        prerequisite_times = ([receipt['created_utc']] if name == 'direct-audit.json' else
                              [row['end_utc'] for row in receipt['producer_windows']['wrappers']])
        require(prerequisite_times and all(A.instant(value) <= A.instant(protocol['predeclared_utc'])
                                          for value in prerequisite_times),
                'supplementary protocol predates prerequisite evidence')
    require(protocol['builds'] == {'before': before, 'after': after}, 'protocol builds differ')
    source = protocol['source_before']
    require(source == final and source['head'] == after['head'] and
            source['source_files'] == after['source_files'] and
            source['fixtures'] == load(args.root / 'premeasurement.json')['fixtures'],
            'probe source or fixture inventory changed')
    require(protocol['inherited_affinity'] == list(range(32)), 'inherited affinity differs')
    topology = protocol['selected_cpu_topology']
    require(topology == {'2': {'core_id': '4', 'thread_siblings_list': '2-3', 'cpuinfo_max_freq': '5700000'},
                         '8': {'core_id': '16', 'thread_siblings_list': '8-9', 'cpuinfo_max_freq': '5700000'}},
            'predeclared physical-core/frequency-class evidence differs')
    require(len(commands) == len(protocol['steps']) == 2, 'missing or extra arms')
    original_base = Path(after['binary']).parent.parent / 'order-probe'
    previous = A.instant(protocol['predeclared_utc'])
    windows = []
    for label, declared, row in zip(ARMS, protocol['steps'], commands):
        prefix = [] if label == 'unpinned' else ['taskset', '--cpu-list', '2,8']
        expected_tail = ['-B', 'benchmarks/runtime/compare-revisions.py',
                         '--before', before['binary'], '--after', after['binary'],
                         '--output', str(original_base / label), '--pairs', '6',
                         '--case', CASE, '--observer-mode', MODE]
        command = declared['command']
        require(command[:len(prefix)] == prefix and
                Path(command[len(prefix)]).name in ('python3', 'python') and
                command[len(prefix) + 1:] == expected_tail,
                'predeclared command differs: ' + label)
        require(declared['name'] == label and declared['status'] == 'pending' and
                declared['expected_affinity'] == (list(range(32)) if label == 'unpinned' else [2, 8]),
                'predeclared arm identity differs')
        require({key: row[key] for key in declared if key != 'status'} ==
                {key: value for key, value in declared.items() if key != 'status'} and
                row['status'] == 'complete' and row['exit'] == 0,
                'executed arm differs or failed: ' + label)
        start, end = A.instant(row['start_utc']), A.instant(row['end_utc'])
        require(previous <= start <= end, 'protocol not before all arms or arm overlap')
        previous = end
        require(all((base / (label + suffix)).is_file() for suffix in ('.stdout', '.stderr')),
                'missing arm output logs')
        windows.append({'arm': label, 'start_utc': row['start_utc'], 'end_utc': row['end_utc'],
                        'protocol_precedes_start': True, 'command': command,
                        'expected_affinity': declared['expected_affinity']})
    return {'original_build_binding': original, 'protocol_sha256': sha(base / 'protocol.json'),
            'commands_sha256': sha(base / 'commands.json'),
            'source_after_sha256': sha(base / 'source-after.json'),
            'runner_sha256': protocol['runner_sha256'], 'predeclared_utc': protocol['predeclared_utc'],
            'source_unchanged': True, 'arms': windows, 'limits': protocol['limits']}


def check_manifest(manifest, before, after):
    require(manifest['cases'] == [CASE] and manifest['pairs'] == PAIRS and
            manifest.get('pair_offset', 0) == 0 and manifest['observer_mode'] == MODE and
            type(manifest['clock_ticks']) is int and manifest['clock_ticks'] == 100 and
            manifest['head'] == after['head'] and manifest['comparison_kind'] == 'production-revision',
            'probe matrix, clock, mode, or source identity differs')
    require(manifest['executables'] == {engine: {'path': identity['binary'], 'sha256': identity['sha256']}
                                      for engine, identity in [('before', before), ('after', after)]},
            'probe executable identity differs')


def check_order(directory, stdout_path):
    lines = [json.loads(line) for line in stdout_path.read_text().splitlines() if line.startswith('{')]
    require(len(lines) == 12, 'missing or extra product execution records')
    starts, records = [], []
    for row, (pair, engine, position) in zip(lines, order()):
        stem = f'{pair}-{CASE}-{engine}'
        process = load(directory / (stem + '.process.json'))
        require(row['case'] == CASE and row['accepted'] is True and row['observer_mode'] == MODE and
                row['argv'] == process['argv'] and
                all(key in process and value == process[key] for key, value in row.items()),
                'stdout/process order or admission mismatch: ' + stem)
        raw = load(directory / (stem + '.json'))
        identities = set()
        for point in raw['samples'] + raw['lifecycle']:
            stat = point['process']['stat']
            if stat is not None:
                identities.add((int(stat.split('(', 1)[0]), int(stat.rsplit(')', 1)[1].split()[19])))
        require(len(identities) <= 1, 'product counter identity changed: ' + stem)
        identity = next(iter(identities)) if identities else None
        if identity is not None:
            starts.append(identity[1])
        records.append({'pair': pair, 'engine': engine, 'position': position,
                        'process_identity': identity,
                        'process_start_counter_state': 'available' if identity else 'unavailable'})
    require(all(a < b for a, b in zip(starts, starts[1:])), 'product start ticks disagree with execution order')
    return records


def verify_request_pair(before, after, comparison):
    # This fixed short-small fixture has no path normalization: require actual
    # captured requests to match, in addition to the existing semantic oracle.
    require(before['wire_requests'] == after['wire_requests'], 'actual pair wire requests differ')
    for request, row in zip(before['wire_requests'], comparison['checked']):
        tools = request['body']['tools']
        digest = hashlib.sha256(json.dumps(tools, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
        require(row['rustToolsSha256'] == row['piToolsSha256'] == digest and
                row['rustToolNames'] == row['piToolNames'] == [tool['function']['name'] for tool in tools],
                'comparison schema digest/roster does not match actual request')


def distribution(raw):
    measured = raw['samples'][raw['history']:]
    values = [row['settled_us'] / 1000 for row in measured]
    quartiles = statistics.quantiles(values, n=4, method='inclusive')
    records = [A.MATH.integer(row['notification_records']) for row in raw['samples']]
    require(records == sorted(records), 'cumulative observer records decreased')
    return {'measured_turn_ms': descriptive(values), 'q25_ms': quartiles[0], 'q75_ms': quartiles[2],
            'first_half_median_ms': statistics.median(values[:16]),
            'second_half_median_ms': statistics.median(values[16:]),
            'accepted_us': descriptive([row['accepted_us'] for row in measured]),
            'first_consumed_publication_us': descriptive([row['first_consumed_publication_us'] for row in measured]),
            'observer_records_after_warmup': records[raw['history'] - 1],
            'observer_records_after_measured': records[-1],
            'observer_records_during_measured': records[-1] - records[raw['history'] - 1]}


def arm_dataset(args, audit, label, before, after):
    directory = args.root / 'order-probe' / label
    manifest = audit.attempt(label + '/manifest', lambda: load(directory / 'manifest.json'))
    if manifest is None:
        return {'arm': label, 'products': [], 'comparisons': [], 'pairs': [], 'groups': []}
    audit.attempt(label + '/manifest identity', lambda: check_manifest(manifest, before, after))
    expected = {f'{pair}-{CASE}-{engine}' for pair, engine, _ in order()}
    observed = {path.name.removesuffix('.process.json') for path in directory.glob('*.process.json')}
    raw_names = {path.stem for engine in ('before', 'after') for path in directory.glob(f'*-{engine}.json')}
    expected_comparisons = {f'{pair}-{CASE}-comparison.json' for pair in range(PAIRS)}
    audit.attempt(label + '/complete inventory', lambda: require(
        expected == observed == raw_names and
        {path.name for path in directory.glob('*-comparison.json')} == expected_comparisons and
        not list(directory.glob('*-comparison-error.log')), 'missing/extra product or comparison, or recorded failure'))
    execution = audit.attempt(label + '/execution order', lambda: check_order(
        directory, args.root / 'order-probe' / (label + '.stdout')))
    products, comparisons, pairs, groups = [], [], [], []
    inventory = [{'stem': stem, 'expected': stem in expected,
                  'raw_exists': (directory / (stem + '.json')).is_file(),
                  'process_exists': (directory / (stem + '.process.json')).is_file()}
                 for stem in sorted(expected | observed | raw_names)]
    for pair in range(PAIRS):
        values, raws = {}, {}
        first, second = ('before', 'after') if pair % 2 == 0 else ('after', 'before')
        for engine in ('before', 'after'):
            stem = f'{pair}-{CASE}-{engine}'
            path, process_path = directory / (stem + '.json'), directory / (stem + '.process.json')
            def derive():
                raw, process = load(path), load(process_path)
                require(raw['schema'] == (84 if engine == 'before' else 85), 'database schema differs')
                result = A.derived_product(raw, process, CASE, MODE, engine, manifest)
                result['distribution'] = distribution(raw)
                return raw, result
            result = audit.attempt(label + '/' + stem, derive)
            if result is not None:
                raw, result = result
                raws[engine], values[engine] = raw, result['metrics']
                products.append({'pair': pair, 'engine': engine, 'position': 1 if engine == first else 2,
                                 'file': str(path.relative_to(args.root)), 'raw_sha256': sha(path),
                                 'process_sha256': sha(process_path), **result})
        path = directory / f'{pair}-{CASE}-comparison.json'
        def compare():
            count = A.comparison(path, CASE, MODE, True)
            verify_request_pair(raws['before'], raws['after'], load(path))
            return count
        count = audit.attempt(label + '/' + path.name, compare)
        if count is not None:
            comparisons.append({'pair': pair, 'file': str(path.relative_to(args.root)),
                                'sha256': sha(path), 'requests': count, 'actual_wire_requests_equal': True})
        metric_names = sorted({name for metrics in values.values() for name in metrics})
        pairs.append({'pair': pair, 'first': first, 'second': second,
                      'metrics': {name: {'after_vs_before': paired_value(values.get('after', {}).get(name), values.get('before', {}).get(name)),
                                         'second_vs_first': paired_value(values.get(second, {}).get(name), values.get(first, {}).get(name))}
                                  for name in metric_names}})
    metric_names = sorted({name for product in products for name in product['metrics']})
    by_key = {(product['pair'], product['engine']): product for product in products}
    for name in metric_names:
        def values_for(engine=None, position=None):
            return [by_key.get((pair, current), {}).get('metrics', {}).get(name)
                    for pair, current, current_position in order()
                    if (engine is None or engine == current) and (position is None or position == current_position)]
        groups.append({'metric': name,
                       'by_engine': {engine: descriptive(values_for(engine=engine)) for engine in ('before', 'after')},
                       'by_position': {str(position): descriptive(values_for(position=position)) for position in (1, 2)},
                       'by_engine_and_position': {engine: {str(position): descriptive(values_for(engine, position)) for position in (1, 2)} for engine in ('before', 'after')},
                       'after_vs_before': paired_summary([pair['metrics'].get(name, {}).get('after_vs_before', paired_value(None, None)) for pair in pairs]),
                       'second_vs_first': paired_summary([pair['metrics'].get(name, {}).get('second_vs_first', paired_value(None, None)) for pair in pairs])})
    audit.attempt(label + '/coverage', lambda: require(len(products) == 12 and len(comparisons) == 6 and
                  sum(row['requests'] for row in comparisons) == 240, 'expected 12 products, 6 comparisons, 240 requests'))
    return {'arm': label, 'products': products, 'comparisons': comparisons, 'pairs': pairs, 'groups': groups,
            'inventory': inventory, 'execution_order': execution,
            'manifest': {'file': str((directory / 'manifest.json').relative_to(args.root)),
                         'sha256': sha(directory / 'manifest.json')}}


def main():
    global A
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HERE)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--raw-only', action='store_true')
    args = parser.parse_args()
    require(not args.output.exists(), 'retain previous audit; choose another output')
    A = imported('inline_content_direct_audit', HERE / 'direct-audit.py', DIRECT_SHA)
    A.MATH = imported('inline_content_independent_math', HERE / 'recompute-pi.py', MATH_SHA)
    audit = A.Audit()
    before = load(args.root / 'baseline-build/identity.json')
    after = load(args.root / 'candidate-complete-build/identity.json')
    args.expected_harness_revision = after['head']
    identity = audit.attempt('protocol/source/build binding', lambda: binding(args, before, after))
    arms = [arm_dataset(args, audit, label, before, after) for label in ARMS]
    totals = {'products': sum(len(arm['products']) for arm in arms),
              'comparisons': sum(len(arm['comparisons']) for arm in arms),
              'checked_requests': sum(row['requests'] for arm in arms for row in arm['comparisons'])}
    audit.attempt('total coverage', lambda: require(totals == {'products': 24, 'comparisons': 12, 'checked_requests': 480},
                                                   'supplementary coverage incomplete'))
    report = {'accepted': not audit.errors, 'errors': audit.errors,
              'mode': 'raw-only' if args.raw_only else 'strict', 'raw_only': args.raw_only,
              'strict_identity_verified': not audit.errors and not args.raw_only,
              'binding': identity, 'totals': totals, 'arms': arms, 'script_sha256': sha(__file__),
              'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'scope': 'Separately predeclared supplementary investigation. Every favorable, unfavorable, zero and unavailable value retained. Arms, positions, and versions are reported separately; original formal results are not replaced or pooled.',
              'limitations': ['Recorded oracle checks plus actual matching short-small requests; no replayed products or independently reimplemented observer semantics.',
                              'Each arm has six adjacent pairs and three executions of each order. No confidence interval or parity claim.',
                              'Arms run sequentially in different environments. Cross-arm differences do not isolate affinity causally.',
                              'CPU affinity is recorded as inherited command policy; no per-thread residency trace proves which cores executed original formal work.',
                              'Process self CPU includes runtime, observer, verification and harness work. Provider runs as a sibling and is not included.',
                              'Proc CPU ticks are 10ms; missing counters remain null. Notification records are cumulative, so measured counts use endpoint differences.',
                              'Prior Pi/DeepSeek references are untouched and are not paired or compared under this new affinity.']}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'accepted': report['accepted'], 'errors': report['errors'], **totals}))
    raise SystemExit(int(bool(audit.errors)))


if __name__ == '__main__':
    main()
