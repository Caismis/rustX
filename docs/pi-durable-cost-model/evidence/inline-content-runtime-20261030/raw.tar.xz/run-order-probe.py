#!/usr/bin/env python3
"""Predeclared supplementary investigation; never replaces the formal cohort."""
import datetime,hashlib,json,os,pathlib,subprocess,sys
sys.dont_write_bytecode=True
from fixture_binding import capture
ROOT=pathlib.Path(__file__).resolve().parent
REPO=pathlib.Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
OUT=ROOT/'order-probe'
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot():
 assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime','test-support/fake-provider'],cwd=REPO,text=True).strip()
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'fixtures':capture(REPO),'source_files':{str(p.relative_to(REPO)):sha(p) for p in sorted([*(REPO/'src').rglob('*'),*(REPO/'tests').rglob('*'),REPO/'Cargo.toml',REPO/'Cargo.lock']) if p.is_file()}}
OUT.mkdir(exist_ok=False)
builds={label:json.loads((ROOT/folder/'identity.json').read_text()) for label,folder in [('before','baseline-build'),('after','candidate-complete-build')]}
assert all(b['verified'] and sha(b['binary'])==b['sha256'] for b in builds.values())
initial=snapshot();assert initial['source_files']==builds['after']['source_files']
assert initial['head']==builds['after']['head']
assert json.loads((ROOT/'diagnostic-audit.json').read_text())['accepted']
affinity=sorted(os.sched_getaffinity(0));assert affinity==list(range(32))
cpus=[2,8];topology={}
for cpu in cpus:
 base=pathlib.Path(f'/sys/devices/system/cpu/cpu{cpu}')
 topology[str(cpu)]={key:(base/path).read_text().strip() for key,path in [('core_id','topology/core_id'),('thread_siblings_list','topology/thread_siblings_list'),('cpuinfo_max_freq','cpufreq/cpuinfo_max_freq')]}
assert topology['2']['core_id']!=topology['8']['core_id'] and topology['2']['cpuinfo_max_freq']==topology['8']['cpuinfo_max_freq']=='5700000'
steps=[]
for label,prefix in [('unpinned',[]),('same-class',['taskset','--cpu-list','2,8'])]:
 cmd=prefix+[sys.executable,'-B','benchmarks/runtime/compare-revisions.py','--before',builds['before']['binary'],'--after',builds['after']['binary'],'--output',str(OUT/label),'--pairs','6','--case','short-small','--observer-mode','live-subscriber']
 steps.append({'name':label,'command':cmd,'expected_affinity':affinity if label=='unpinned' else cpus,'status':'pending'})
protocol={'kind':'supplementary_order_and_affinity_probe','predeclared_utc':now(),'case':'short-small','observer_mode':'live-subscriber','pairs_per_arm':6,'products_per_arm':12,'order':'even before then after; odd after then before','arms_run_order':['unpinned','same-class'],'runner_sha256':sha(__file__),'formal_audit_sha256':sha(ROOT/'direct-audit.json'),'diagnostic_audit_sha256':sha(ROOT/'diagnostic-audit.json'),'builds':builds,'source_before':initial,'inherited_affinity':affinity,'selected_cpu_topology':topology,'hardware':json.loads(subprocess.check_output(['lscpu','-J'],text=True)),'steps':steps,'limits':['A separate hypothesis-driven investigation prompted by the original five-pair ordering association. Does not replace or pool with the 120 formal products.','Two arms run sequentially; each contains three orders of each type. Arm differences are not a randomized causal estimate of CPU affinity.','Affinity is inherited by controller, product and provider and restricts execution to two physical cores in the second arm, changing the environment. No original per-thread CPU residency was recorded.','Pi/DeepSeek are not executed or compared under the new affinity.']}
(OUT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
ledger=[]
for step in steps:
 assert snapshot()==initial
 record=dict(step,start_utc=now(),status='running');ledger.append(record)
 (OUT/'commands.json').write_text(json.dumps(ledger,indent=2)+'\n')
 with (OUT/(step['name']+'.stdout')).open('x') as stdout,(OUT/(step['name']+'.stderr')).open('x') as stderr:
  result=subprocess.run(step['command'],cwd=REPO,env=os.environ|{'UV_OFFLINE':'1'},stdout=stdout,stderr=stderr)
 record.update(exit=result.returncode,end_utc=now(),status='complete' if result.returncode==0 else 'failed')
 (OUT/'commands.json').write_text(json.dumps(ledger,indent=2)+'\n')
 print(step['name'],result.returncode,flush=True)
 assert result.returncode==0
 assert all(sha(b['binary'])==b['sha256'] for b in builds.values())
final=snapshot();assert final==initial
(OUT/'source-after.json').write_text(json.dumps(final,indent=2)+'\n')
