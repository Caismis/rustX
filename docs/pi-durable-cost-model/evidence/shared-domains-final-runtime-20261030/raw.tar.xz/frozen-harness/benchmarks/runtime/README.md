# Fair local-provider benchmark (issue 481)

For current source, use the external sibling-process controller:

```sh
python3 benchmarks/runtime/build-revision.py --repo /absolute/checkout \
  --target /absolute/shared-target --output /absolute/new-build-evidence
python3 benchmarks/runtime/controller.py --rust /absolute/preserved-conformance \
  --pi /absolute/pinned-pi --output /absolute/new-evidence --pairs 3
node --test benchmarks/runtime/pi-oracle.test.mjs
```

See [the issue 481 checkpoint](../../docs/issue-481/progress.md) for the exact Pi
revision, offline build commands, ownership, oracle and measurement scopes.
Never run formal samples concurrently with a build. Preserve the executable,
its hash, and the exact source commit before rebuilding. Profile in separate runs.

`build-revision.py` cleans the root crate release artifacts before building and
requires `fresh:false` for both the product library and conformance target.
A shared Cargo target can otherwise return a newer checkout's cached executable
when an older checkout has older source mtimes. Source paths and Git labels alone
do not prove binary identity. The builder records all benchmark fixture hashes,
commands, root artifacts and executable/library SHA-256 values; originals remain
in the new evidence directory. Set the same Cargo/Rust environment for every
revision. The revision controllers reject identical executable hashes before
starting either product or provider.

Current workload version 3 supplies the same model-facing Agent Status time,
`2026-10-19 00:00:00`, to both engines. Rust uses the supported composition-owned
`AgentStatusClock`; Pi authors that exact reminder through its native entry API.
Runtime event time, deadlines, provider pacing and performance clocks remain real.
Request comparison preserves time text exactly; only transport argument spelling
and the one fixture workspace path are normalized. Old archives remain unchanged:
their timestamp-normalized equality does not prove identical model-facing input.
The live consumer oracle retains and independently checks every observed assistant
and tool-output version, including cancelled prefixes and replacement/resync paths.
Rust distinguishes checkpoint terminal sightings from explicit settlement events.

The provider is the same Python HTTP/SSE implementation and scenario for both
engines. Pi uses its production `openAICompletionsApi()` with actual Durable
SQLite, not its faux provider. Each paired run compares complete core requests
and separately records the intentionally different native tool schemas.
Neither full request equality nor product/durability equivalence is claimed.

`measure_canonical_append` separately measures 32 canonical acceptances after
0, 64, 512 or 2,048 retained messages, using `RUSTX_BENCH_HISTORY` and
`RUSTX_BENCH_OUTPUT`. Run each size in a fresh process, interleave preserved
checkpoint executables at least three times, and retain failures. It performs
no request/context construction. Seed, append, close, reopened validation and
cleanup counters are separate; evidence output follows the cleanup endpoint.

For the staged revision comparisons and summaries:

```sh
python3 benchmarks/runtime/compare-revisions.py --before /absolute/before \
  --after /absolute/after --output /absolute/new-runtime-evidence --pairs 3
python3 benchmarks/runtime/compare-append.py --before /absolute/before \
  --after /absolute/after --output /absolute/new-append-evidence --pairs 3
python3 benchmarks/runtime/summarize-comparisons.py /absolute/new-runtime-evidence
python3 benchmarks/runtime/summarize-comparisons.py --append /absolute/new-append-evidence
python3 benchmarks/runtime/summarize-http.py /absolute/new-pi-evidence
```

For the structural stages after `5457e1c3`, build both checkpoints with the
identical updated conformance fixture and also run:

```sh
python3 benchmarks/runtime/compare-append.py --before /absolute/before \
  --after /absolute/after --output /absolute/new-cold-append-evidence --pairs 3 --cold
python3 benchmarks/runtime/summarize-comparisons.py --append /absolute/new-cold-append-evidence
```

Cold mode closes/reopens before each measured append. Per-operation wall excludes
reopen; CPU/write brackets include counter-sampling overhead and retain raw values
for all 32 appends. Whole-phase and lifecycle counters include reopen, checkpoint,
verification and sampling costs. They are not derived by subtracting medians.
Normal mode retains the existing steady sequence after seeding. Report both;
10 ms CPU resolution can produce zero denominators, which have no invented ratio.
Summaries also expose sampled anonymous PSS, with unavailable counters as null.

`pack-evidence.py --root /absolute/evidence --output evidence.tar.xz 'run/*'`
copies selected raw files, records lengths/SHA-256 in `MANIFEST.json`, and
verifies every archive member. It does not delete original evidence. Perform
compression after formal samples finish. `profile-footprints.py` separately samples product-owned Source temporary-file
logical/allocated bytes from the external controller; it is never a formal timing
run and does not claim a true peak. The reports under `docs/issue-481`
separate baseline, Source-only, canonical incremental and combined comparisons.

For the additional real native SDK reference, see [DeepSeek Harness](deepseek-reference.md). Its idle completion differs from Rust/Pi durable settlement; the rotating three-engine report therefore keeps absolute native costs and does not claim equal-durability speedups. The [write/compute reduction report](../../docs/pi-durable-cost-model/2026-10-27-write-compute-reduction.md) contains current measured results; the [D/E continuation](../../docs/pi-durable-cost-model/2026-10-27-continuation.md) retains historical comparisons and rejected trials.

The remaining documentation describes the **historical issue 480 harness**.
Its `run.py` expects the old measurement executable and must not be used with
the new controller-handshake executable. Old Pi in-process timings are not an
equivalent HTTP comparison and must never be reused as issue 481 baselines.

---

# Offline runtime durability measurements

The ignored `conformance` measurement reuses its real Session/App Server driver,
production provider adapter, HTTP/SSE parser, Agent Loop, tool runtime, SQLite
store and exact historical request reader. Only the external Python provider is
scripted. The fake key is fixture text; the driver injects no real credentials.
The Python runner also strips credential-like environment variables.

Build ordinary optimized code (no instrumentation feature):

```sh
cargo test --release --locked --test conformance --no-run --message-format=json > build.jsonl
```

Keep the `conformance` executable named in Cargo's compiler-artifact output,
its SHA-256, and the benchmark revision before rebuilding. This executable links
the ordinary library, not the `cfg(test)` library with process-death/profile hooks.
All samples use fresh native stores under the output directory (choose the same
real filesystem for both revisions), a new runtime/driver process and a new
provider process. Do not run builds or other task-owned benchmarks concurrently.

```sh
python3 benchmarks/runtime/run.py --before /absolute/before-conformance \
  --output /absolute/evidence/before --pairs 1
# After implementation: three paired, interleaved repeats, every case.
python3 benchmarks/runtime/run.py --before /absolute/before-conformance \
  --after /absolute/after-conformance --output /absolute/evidence/paired --pairs 3
# Separate instrumentation; never mix these times with headline results.
python3 benchmarks/runtime/run.py --before /absolute/before-conformance \
  --after /absolute/after-conformance --output /absolute/evidence/trace \
  --pairs 1 --case short-small --trace
```

`short-small` seeds 8 ordinary turns and measures the next 32; `short-large`
seeds 64 and measures the next 32. Both include all seed costs separately.
`stream` delivers 128 chunks with explicit provider gates and 10 ms workload
pacing between them. `large` returns 32,768 text bytes in 128 chunks. `tool`
executes native Read and verifies the real result in request two. `cancel`
cancels at an observed provider gate and proves the connection closes and the
attempt settles without another request. No timing threshold judges correctness.

Every case asserts terminal ownership/uniqueness/order, exact output and request
count. Oracle version 2 independently constructs the **complete ordered input**
for every request from the bounded workload: all prior user/reply pairs, the
first generated time context, and the Read call/result when present. The pinned
`expected_tools.json` is a normative fixture for the seven declared native tool
definitions, rather than an expected value learned from the current run.

The oracle compares captured HTTP bodies with an independent projection of the
reconstructed provider-neutral request, without calling the production adapter
translator. Wire/frozen equality preserves timestamps and workspace paths exactly;
only JSON argument spelling is canonicalized. Comparison to the independent
workload normalizes the strictly parsed generated UTC time and the one exact
fixture workspace path. It never drops history, messages, roles, tool schemas,
call/result linkage, model configuration or other semantic content. The bounded
workload expects one initial time contribution (the product refresh interval is
30 minutes). A second contribution fails rather than being silently removed.

Each frozen snapshot's identity, provisional Assistant ID, semantic fingerprint,
ordered Original references and Journal request-start fact must agree. After all
runtime owners close, reopening repeats the complete wire/expected/frozen checks
and compares the exact serialized snapshots and reconstructed requests with the
live values. Five negative regressions prove omitted/reordered old history,
frozen-content/time mismatch, changed tool schemas and wrong identity/reference
linkage fail. The server's cheap per-step substring guards are not the acceptance
oracle. All providers remain local scripted/faux processes.

The runner requires exactly one passing named measurement test plus a valid
version-2 sample, successful live/reopened oracle counts and every lifecycle
endpoint. Exit zero with no matching test, missing/malformed output or an invalid
oracle is a failed run. Logs, exit codes and validation errors are retained.
Run focused Python regressions with:

```sh
python3 -m unittest discover -s benchmarks/runtime -p 'test_*.py' -v
cargo test --test conformance --all-features --locked request_oracle
```

Recorded wall windows include initialization, per-turn acceptance/publication/
settlement, unload, driver drop, final writable open/close, reopened validation,
and cleanup. Ordinary process CPU/I/O endpoints now start **before fixture/runtime
initialization** and follow initialization, all turns, exact verification, shutdown,
driver drop, final writer open/close, reopened verification, cleanup and provider
teardown. Product lifecycle and product post-turn totals end at **after_cleanup**,
including shutdown, final writer checkpoint/close, reopened verification and cleanup.
Provider teardown is separate: Linux [`/proc/self/io`](https://man7.org/linux/man-pages/man5/proc_pid_io.5.html)
includes waited-for children, so that phase's I/O delta can include the provider's
entire lifetime I/O, not merely teardown work. Product I/O stops before this provider
reap (and still includes any other children already waited for). CPU uses self
`utime+stime` throughout and excludes child CPU; it does not share the I/O scope.
Product wall ends at cleanup; the separate teardown wall includes waiting for the
provider. OS/test-runtime startup and final result serialization/writing are outside
these endpoints. Missing counters remain null, not zero. Turn-only counters remain
separately labeled. Summary accounting version 3 derives these scopes from unchanged
version-2 raw samples; historical through-teardown summaries remain retained.


The earlier Stage C CPU/I/O window began after initialization and ended before
shutdown. It did **not** cover the whole lifecycle. Its wall windows and separate
short-small syscall trace already included deferred close/checkpoint work; the
version-2 correction supplies the missing ordinary phase CPU/I/O across all cases.
Old evidence is retained and identified as pre-review, not relabeled as complete.

The relay is joined after abort before driver drop. A read-only owner can leave
WAL frames after the writer closes, so a measured final writable open/close
completes checkpointing before cleanup; the harness asserts no WAL frames remain.
The same harness, oracle module and pinned tool fixture overlay both revisions.
Stream/cancel gates are controlled before notification draining, so their first-
consumed-publication figure is not first emission latency. RSS/PSS are sampled,
not peaks. Inventories record both logical length and allocated blocks.

Strace observes OS system calls, not physical-media traffic. `pwrite64` arguments
and filenames distinguish SQLite, WAL and other files; `fsync`/`fdatasync` distinguish
barriers. `/proc/io` reports OS process accounting, not disk-device latency.
Owner counts, SQLite operations and syscall counts must never be conflated.
SQL statement and allocation counts are unavailable in this ordinary runner.
Existing opt-in in-crate request attribution can separately investigate inclusive
Source phases; those times overlap and are not independent CPU shares.

## Pi Durable

`pi.mjs` refuses a checkout other than
`90d863f7c1183b965f099855715d6e88c7b8a52c`. It uses the original Pi Durable Harness,
SQLite backend and local faux provider, checks ordered requests, completion,
answers and reopen. It never runs the coding-agent or JSONL backend.

```sh
node --conditions=source benchmarks/runtime/pi.mjs \
  /absolute/pinned-pi-checkout short-small /absolute/evidence/pi.json
```

Run `short-small`, `short-large`, `large`, and `stream` in fresh processes three
times. Dependencies come from the pinned checkout's lockfile. Pi's provider is
in-process and its streaming token pacing differs from rustX's explicit HTTP
gates. Pi also has a different retained-fact/Source/inspection contract. Thus the
comparison measures each product's actual work, not interchangeable execution or
proof of durability/feature parity. Pi's SQLite defaults are WAL/NORMAL, 1,000-page
autocheckpoint and a 5-second busy timeout; its close explicitly truncates the WAL.

File inventories are sequential observations, not atomic filesystem snapshots.
A temporary journal removed between `read_dir` and `metadata` is retained as
`vanished_during_scan` with null sizes; totals include only observed files. The
initial trace exposed this legitimate race and its failure is retained.
Hardware `perf` counters are probed without changing host permissions; refusal
is recorded, not bypassed. No allocation profiler is installed on the measurement
host. Neither unavailable metric is reported as zero.

The corrected Pi fixture (version 2) fixes faux chunk sizes: 256 characters with
microtask scheduling for unpaced replies, and 16 characters at 425 tokens/second
for streaming (Pi counts four characters per token). RustX streaming uses
17-character numbered chunks gated every 10 ms. The original Pi preliminary
runs used random default chunk lengths and a timer per unpaced chunk; retain them
as fixture evidence, but use only version 2 repeats for the final comparison.

`trace_summary.py` joins unfinished/resumed syscall records by PID and reports
completed calls, failures, successful returned write bytes and sync calls by path.
An unresolved count must be reported, not silently treated as complete accounting.
`summarize.py` derives CPU from `/proc/stat` user+system ticks and reports sampled
RSS/PSS, process write-byte deltas and all per-run values. CPU per turn is the
measured-window total divided by turn count, including driver/sample overhead;
it is not an exclusive runtime profile or an allocation count.

Fresh structural-stage results and binary identities: [Source metadata reuse](../../docs/issue-481/source-metadata.md).
The next isolated stage is [append certificate measurements](../../docs/issue-481/append-certificate-results.md), including warm/cold regressions and complete lifecycle counters.
