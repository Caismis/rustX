"""The Agent Loop conformance scenarios driven from `tests/issue47_conformance.rs`.

Each scenario fixes the provider half of one interaction. The rustX half —
the user input, the workspace fixture, the runtime action, and every
assertion about runtime state — belongs to the Rust driver. The two halves
meet only through real HTTP.

The literals below are the contract between the two sides. The Rust driver
mirrors them as constants, and a mismatch fails the scenario rather than
passing quietly, because every expectation here is asserted by default.
"""

from __future__ import annotations

from fake_provider.scenario import (
    ANTHROPIC_MESSAGES,
    OPENAI_CHAT_COMPLETIONS,
    OPENAI_RESPONSES,
    Expect,
    Finish,
    Gate,
    HttpError,
    Reasoning,
    Scenario,
    Step,
    Stream,
    Text,
    ToolCall,
    Usage,
)

# -- the catalog the Rust driver publishes ---------------------------------

CHAT_MODEL = "chat-model"
WORKFLOW_MODEL = "workflow-model"
RESPONSES_MODEL = "responses-model"
ANTHROPIC_MODEL = "anthropic-model"
SUMMARY_MODEL = "summary-model"
SECOND_MODEL = "second-model"

# -- fixed user inputs -----------------------------------------------------

TURN_ONE = "conformance: turn one"
READ_PROMPT = "conformance: read the note"
SKILL_PROMPT = "conformance: follow the conformance skill"
TURN_TWO = "conformance: turn two"
FIRST_ATTEMPT = "conformance: first attempt"
SECOND_ATTEMPT = "conformance: second attempt"

# -- workspace fixtures the Rust driver writes -----------------------------

# Conformance calls use absolute host paths so the provider-side script can
# address the fixture independently of the process cwd. A Skill package is an
# ordinary host directory, so its SKILL.md is addressed exactly the same way —
# the path rustX publishes in its Skill catalog.
NOTE_PATH = "{workspace}/note.txt"
NOTE_MARKER = "deterministic-note-payload-6d41"
SKILL_NAME = "conformance-skill"
SKILL_DESCRIPTION = "The deterministic workspace Skill of the issue 47 conformance harness."
SKILL_PATH = f"{{workspace}}/.agents/skills/{SKILL_NAME}/SKILL.md"
SKILL_BODY_MARKER = "skill-body-marker-a17c"

# -- compaction ------------------------------------------------------------

COMPACTION_MARKER = "compaction-filler-marker-93be"


def _filler(marker: str) -> str:
    """~200 KB of deterministic filler, worth roughly 51k estimated tokens.

    The Rust driver configures a 56k-token window with a 1.5k reserve and a
    1k output budget. Both the soft input limit and the summary input limit
    carry the reserve, so both are 53.4k, which sits above this span's
    estimate and below the whole next-turn request estimate: the next turn
    provably crosses the soft input limit while the complete-message
    compaction span provably still fits the summary model's own request
    budget. Both bounds are crossed by construction, never by hoping a random
    amount of text happens to be enough.
    """
    return (marker + " ") + " ".join(
        f"compaction filler block {index:05d}." for index in range(6800)
    )


FILLER = _filler(COMPACTION_MARKER)
SUMMARY_TEXT = "conformance summary: the assistant produced one long report."
#: The exact deterministic prefix `ModelBackedSummarizer` sends. A summary
#: request is identified structurally, never by guessing at its content.
SUMMARY_INSTRUCTION = "Summarize the following retired conversation history"

# -- repeated compaction ---------------------------------------------------

TURN_THREE = "conformance: turn three"
#: Two distinct filler markers: the wire assertions below prove the first
#: compaction's retired span never reaches the provider again, including
#: inside the second compaction's own summary input.
FILLER_ONE_MARKER = "compaction-filler-one-marker-51f0"
FILLER_TWO_MARKER = "compaction-filler-two-marker-b27d"
FILLER_ONE = _filler(FILLER_ONE_MARKER)
FILLER_TWO = _filler(FILLER_TWO_MARKER)
SUMMARY_ONE_TEXT = "conformance summary one: the assistant produced filler report one."
SUMMARY_TWO_TEXT = "conformance summary two: the assistant produced filler report two."


def _text_turn(name: str, protocol: str, model: str, prompt: str) -> Scenario:
    """One streamed assistant turn over the given protocol.

    The script leads with a reasoning block so the protocol's full normal
    lifecycle — not just its text subset — is exercised against the real
    rustX stream parser.
    """
    return Scenario(
        name,
        Step(
            Expect(
                protocol=protocol,
                model=model,
                json_subset={"stream": True},
                body_contains=(prompt,),
                tools_include=("read", "bash"),
            ),
            Stream(
                Reasoning("the conformance plan"),
                Text("Hello world", pieces=2),
                Finish("stop"),
                Usage(41, 3),
            ),
        ),
    )


def openai_chat_streamed_turn() -> Scenario:
    return _text_turn(
        "openai_chat_streamed_turn", OPENAI_CHAT_COMPLETIONS, CHAT_MODEL, TURN_ONE
    )


def openai_responses_streamed_turn() -> Scenario:
    return _text_turn(
        "openai_responses_streamed_turn", OPENAI_RESPONSES, RESPONSES_MODEL, TURN_ONE
    )


def anthropic_streamed_turn() -> Scenario:
    return _text_turn(
        "anthropic_streamed_turn", ANTHROPIC_MESSAGES, ANTHROPIC_MODEL, TURN_ONE
    )


def tool_call_continuation() -> Scenario:
    """Provider tool call -> real rustX Read -> provider continuation.

    The emulator requests the call and inspects the continuation. It never
    reads the file, never fabricates the result, and never knows what rustX's
    Read tool does.
    """
    return Scenario(
        "tool_call_continuation",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(READ_PROMPT,),
                tools_include=("read",),
            ),
            Stream(
                ToolCall("call-read-1", "read", f'{{"path":"{NOTE_PATH}"}}', pieces=2),
                Finish("tool_calls"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                # The continuation carries the *real* tool result, produced
                # by rustX's own Read through ConversationToolRuntime.
                body_contains=(READ_PROMPT, "call-read-1", NOTE_MARKER),
            ),
            Stream(Text(f"the note says {NOTE_MARKER}"), Finish("stop")),
        ),
    )


def skill_read_turn() -> Scenario:
    """A real workspace Skill, discovered and projected by rustX alone."""
    return Scenario(
        "skill_read_turn",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                # The Skill catalog reached the provider through the normal
                # request-time Effective System Prompt path; the Rust driver
                # also asserts the final wire role.
                body_contains=(SKILL_PROMPT, SKILL_NAME, SKILL_DESCRIPTION),
                tools_include=("read",),
            ),
            Stream(
                ToolCall("call-skill-1", "read", f'{{"path":"{SKILL_PATH}"}}'),
                Finish("tool_calls"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=("call-skill-1", SKILL_BODY_MARKER),
            ),
            Stream(Text("the skill instructions were read"), Finish("stop")),
        ),
    )


def workflow_output() -> Scenario:
    """A concrete Workflow Tool runs one native Workflow Agent child.

    The first request is the parent selecting the independently model-visible
    Workflow Tool. The second request is the child, which receives only the
    frozen named profile and the reserved ``workflow_output`` protocol. The
    final request is the parent's ordinary continuation over one bounded
    Workflow ToolResult.
    """
    return Scenario(
        "workflow_output",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=WORKFLOW_MODEL,
                body_contains=("workflow conformance request",),
                tools_include=("review_pr",),
            ),
            Stream(
                ToolCall(
                    "call-review-pr",
                    "review_pr",
                    '{"task":"workflow conformance request"}',
                ),
                Finish("tool_calls"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=WORKFLOW_MODEL,
                body_contains=("workflow conformance request", "Review the request"),
                body_excludes=("review_pr",),
                tools_include=("workflow_output",),
            ),
            Stream(
                Gate("workflow-child-admitted"),
                ToolCall(
                    "call-workflow-output",
                    "workflow_output",
                    '{"passed":true,"summary":"native workflow child committed"}',
                ),
                Finish("tool_calls"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=WORKFLOW_MODEL,
                body_contains=("native workflow child committed",),
                tools_include=("review_pr",),
                body_excludes=("workflow_output",),
            ),
            Stream(Text("workflow conformance complete"), Finish("stop")),
        ),
    )


def workflow_tool() -> Scenario:
    """Tool-only Workflow adds no provider request and exposes no leaf tool."""
    return Scenario(
        "workflow_tool",
        Step(
            Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                   body_contains=("workflow conformance request",),
                   tools_include=("review_pr",), body_excludes=('"name":"glob"',)),
            Stream(ToolCall("call-review-pr", "review_pr",
                            '{"task":"workflow conformance request"}'), Finish("tool_calls")),
        ),
        Step(
            Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                   body_contains=("review_pr.yaml",), tools_include=("review_pr",),
                   body_excludes=("workflow_output",)),
            Stream(Text("workflow conformance complete"), Finish("stop")),
        ),
    )


def workflow_reference_parallel() -> Scenario:
    import json
    steps = [Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                         tools_include=("parallel_review",)),
                  Stream(ToolCall("outer", "parallel_review", '{"proposal":"PRIVATE PROPOSAL"}'), Finish("tool_calls")))]
    for index in range(3):
        steps.append(Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                                 tools_include=("workflow_output",),
                                 body_excludes=("workflow conformance request",)),
                          Stream(Gate(f"parallel-child-{index}"),
                                 ToolCall(f"output-{index}", "workflow_output", json.dumps({"summary": f"Assessment {index}", "acceptable": True})), Finish("tool_calls"))))
    steps.append(Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                             tools_include=("parallel_review",), body_contains=("ready",)),
                      Stream(Text("Reviews ready."), Finish("stop"))))
    return Scenario("workflow_reference_parallel", *steps)


def workflow_reference_repair(exhausted: bool = False, tampered: bool = False) -> Scenario:
    """Real native writes/checks in the shared Session workspace.

    The provider never supplies check findings: the frozen Bash checker runs
    natively and its structured result alone drives the repair Loop.
    """
    import json
    plan = {"summary": "Fix greeting.py", "steps": ["Implement the two fixed cases"]}
    def terminal():
        return Stream(ToolCall("output", "workflow_output", json.dumps({"plan": plan})), Finish("tool_calls"))
    steps = [
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                    tools_include=("implement_and_review",)),
             Stream(ToolCall("outer", "implement_and_review", '{"requirement":""}'), Finish("tool_calls"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                    tools_include=("workflow_output",), body_contains=("Produce a concise implementation plan",)),
             Stream(ToolCall("plan", "workflow_output", json.dumps(plan)), Finish("tool_calls"))),
    ]
    sources = [
        'def greeting(name):\n    return "wrong"\n',
        "def greeting(name):\n    return 'Hello, ' + (name or 'friend') + '!'\n",
    ]
    if exhausted:
        sources = [sources[0]] * 3
    for iteration, source in enumerate(sources, 1):
        if iteration == 1:
            steps.append(Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                                     tools_include=("ask_user", "workflow_output")),
                              Stream(ToolCall("child-question", "ask_user", json.dumps({"questions":[{"question":"PRIVATE CHILD QUESTION: confirm the implementation priority", "header":"Priority", "options":[{"label":"Minimal change","description":"Small patch"},{"label":"Clarity","description":"Explicit code"}]}]})), Finish("tool_calls"))))
        tampering = ([ToolCall("fake-checker", "write", json.dumps({"path": "checks/verify_greeting.py", "content": 'print("passed", end="")\n'}))]
                     if tampered and iteration == 1 else [])
        steps.extend([
            Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                        tools_include=("write", "workflow_output"),
                        body_contains=(("Implement or repair greeting.py", "The checker ran successfully but greeting.py failed")
                                       if tampered and iteration == 2 else ("Implement or repair greeting.py",))),
                 Stream(Gate(f"reference-writer-{iteration}"),
                        Text("PRIVATE CLAIM: all tests passed"),
                        ToolCall(f"write-{iteration}", "write", json.dumps({"path": "greeting.py", "content": source})), *tampering, Finish("tool_calls"))),
            Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                        tools_include=("workflow_output",)), terminal()),
        ])
    steps.append(Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                             tools_include=("implement_and_review",),
                             body_contains=(("needs_revision" if exhausted else "implemented"),), body_excludes=("PRIVATE CLAIM", "PRIVATE CHILD QUESTION")),
                      Stream(Text("Implementation finished."), Finish("stop"))))
    return Scenario("workflow_reference_tampering" if tampered else "workflow_reference_exhaustion" if exhausted else "workflow_reference_repair", *steps)


def workflow_retention() -> Scenario:
    """Nine sequential native Workflow calls exceed the eight-run detail cap."""
    return Scenario(
        "workflow_retention",
        *(Step(
            Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                   body_contains=("workflow conformance request",), tools_include=("review_pr",)),
            Stream(Gate(f"workflow-{i}"),
                   ToolCall(f"call-review-pr-{i}", "review_pr",
                            '{"task":"workflow conformance request"}'),
                   Finish("tool_calls")),
        ) for i in range(9)),
        Step(
            Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=WORKFLOW_MODEL,
                   body_contains=("review_pr.yaml",), tools_include=("review_pr",),
                   body_excludes=("program_digest",)),
            Stream(Gate("workflow-complete"), Text("workflow conformance complete"), Finish("stop")),
        ),
    )


def provider_http_error() -> Scenario:
    """A deterministic permanent provider failure with no retry or extra turn."""
    return Scenario(
        "provider_http_error",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(TURN_ONE,),
            ),
            HttpError(
                400,
                {
                    "error": {
                        "message": "the scripted request is invalid",
                        "type": "invalid_request_error",
                        "code": "invalid_request",
                    }
                },
            ),
        ),
    )


def gated_stream_cancellation() -> Scenario:
    """A stream suspended at an explicit gate for a cancellation test.

    The driver waits for the gate, cancels, and waits for the provider to
    observe the disconnect. Nothing sleeps, and the cancellation provably
    lands after the first delta and before anything the gate holds back.
    """
    return Scenario(
        "gated_stream_cancellation",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(TURN_ONE,),
            ),
            Stream(
                Text("partial"),
                Gate("before-remaining-text"),
                Text(" remainder that cancellation must prevent"),
                Finish("stop"),
            ),
            allow_disconnect=True,
        ),
    )


def restart_after_request_start() -> Scenario:
    """One request, suspended at a gate, whose client then dies (Issue #12).

    The scenario declares **exactly one** step. That is the whole point: the
    driver kills the first runtime while this response is still suspended,
    reopens the same durable conversation, and recovers a second runtime. If
    recovery resent the ambiguous request, a second request would arrive here
    and the scenario would fail as unexpected rather than pass quietly.
    """
    return Scenario(
        "restart_after_request_start",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(TURN_ONE,),
            ),
            Stream(
                Text("partial"),
                Gate("before-remaining-text"),
                Text(" remainder the crash must prevent"),
                Finish("stop"),
            ),
            allow_disconnect=True,
        ),
    )


def _compaction(name: str, summary_model: str) -> Scenario:
    """Turn one fills the window, turn two must compact through the provider."""
    return Scenario(
        name,
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(TURN_ONE,),
            ),
            Stream(Text(FILLER), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=summary_model,
                # A summary invocation is structurally distinct: no tools, no
                # Agent Status, no Skill catalog, and the runtime's own
                # deterministic instruction.
                no_direct_tools=True,
                body_contains=(SUMMARY_INSTRUCTION, COMPACTION_MARKER),
            ),
            Stream(Text(SUMMARY_TEXT), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                tools_include=("read",),
                # The compacted projection reached the primary model: the
                # summary is present and the retired filler is gone.
                body_contains=(SUMMARY_TEXT, TURN_TWO),
                body_excludes=(COMPACTION_MARKER,),
            ),
            Stream(Text("continuing from the summary"), Finish("stop")),
        ),
    )


def compaction_session_summary() -> Scenario:
    return _compaction("compaction_session_summary", CHAT_MODEL)


def compaction_explicit_summary() -> Scenario:
    return _compaction("compaction_explicit_summary", SUMMARY_MODEL)


def _compaction_twice(name: str, summary_model: str) -> Scenario:
    """Two committed compactions through the real provider boundary.

    Turn one's answer fills the window; turn two's baseline crosses the soft
    input limit and compacts; turn two's answer refills the window; turn
    three's baseline crosses again, and the second compaction's span is the
    already-compacted surface — the still-active first summary plus the
    second filler. Every `body_excludes` below is the wire proof that a
    retired span never reaches the provider again, never resurrects beside
    its successor summary, and never appears twice.
    """
    return Scenario(
        name,
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(TURN_ONE,),
            ),
            Stream(Text(FILLER_ONE), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=summary_model,
                no_direct_tools=True,
                body_contains=(SUMMARY_INSTRUCTION, FILLER_ONE_MARKER),
                body_excludes=(FILLER_TWO_MARKER,),
            ),
            Stream(Text(SUMMARY_ONE_TEXT), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                tools_include=("read",),
                # The first rewritten surface: summary present, filler gone.
                body_contains=(SUMMARY_ONE_TEXT, TURN_TWO),
                body_excludes=(FILLER_ONE_MARKER,),
            ),
            Stream(Text(FILLER_TWO), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=summary_model,
                no_direct_tools=True,
                # The second compaction's span is the already-compacted
                # surface: the first summary and the second filler, never
                # the first filler's retired bytes.
                body_contains=(SUMMARY_INSTRUCTION, SUMMARY_ONE_TEXT, FILLER_TWO_MARKER),
                body_excludes=(FILLER_ONE_MARKER,),
            ),
            Stream(Text(SUMMARY_TWO_TEXT), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                tools_include=("read",),
                # The second rewritten surface carries exactly the second
                # summary: no filler, and no resurrected first summary.
                body_contains=(SUMMARY_TWO_TEXT, TURN_THREE),
                body_excludes=(FILLER_ONE_MARKER, FILLER_TWO_MARKER, SUMMARY_ONE_TEXT),
            ),
            Stream(Text("continuing from the second summary"), Finish("stop")),
        ),
    )


def compaction_twice_session_summary() -> Scenario:
    return _compaction_twice("compaction_twice_session_summary", CHAT_MODEL)


def compaction_twice_explicit_summary() -> Scenario:
    return _compaction_twice("compaction_twice_explicit_summary", SUMMARY_MODEL)


def frozen_attempt_model() -> Scenario:
    """The immutable attempt model snapshot, observed from outside rustX.

    The provider suspends the first attempt at a gate; the driver switches
    the session model while that attempt is in flight. The frozen model is
    externally observable because the emulator asserts the `model` field of
    each request.
    """
    return Scenario(
        "frozen_attempt_model",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=CHAT_MODEL,
                body_contains=(FIRST_ATTEMPT,),
            ),
            Stream(
                Text("frozen"),
                Gate("session-model-updated"),
                Text(" attempt"),
                Finish("stop"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=SECOND_MODEL,
                body_contains=(SECOND_ATTEMPT,),
            ),
            Stream(Text("second attempt"), Finish("stop")),
        ),
    )


def app_server_user(marker: str) -> Scenario:
    """Host-supplied environment/cwd and a committed side effect before death."""
    import json
    return Scenario(
        f"app_server_user_{marker}",
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=f"user-{marker}",
                    body_contains=(f"host user {marker}",)),
             Stream(ToolCall(f"host-{marker}", "bash", json.dumps({
                 "command": "printf '%s:%s\\n' \"$RUSTX_HOST_MARKER\" \"${TEST_KEY-unset}\"; pwd; printf x >> host-effect",
                 "execution_mode": "foreground",
             })), Finish("tool_calls"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=f"user-{marker}",
                    body_contains=(f"{marker}:unset",)),
             Stream(Gate("host-result"), Text(f"result-{marker}"), Finish()),
             allow_disconnect=marker == "b"),
    )


def image_tool_round_trip() -> Scenario:
    return Scenario(
        "image_tool_round_trip",
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, tools_include=("read_image",)),
             Stream(Gate("image-admitted"), ToolCall("call-image", "read_image", '{"path":"{workspace}/sample.png"}'), Finish("tool_calls"))),
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, body_contains=("image/png", "base64", "call-image")),
             Stream(Text("image received"), Finish("stop"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=CHAT_MODEL, body_contains=("Image artifact", "call-image")),
             Stream(Gate("text-admitted"), Text("text continuation"), Finish("stop"))),
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, tools_include=("read_image",), body_contains=("image/png", "call-image")),
             Stream(Text("image history restored"), Finish("stop"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=CHAT_MODEL,
                    body_contains=("Image artifact", "call-image"), tools_include=("image_review",),
                    body_excludes=("image/png", "image_url")),
             Stream(ToolCall("call-image-review", "image_review", '{"task":"Review the retained image context as text."}'), Finish("tool_calls"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=CHAT_MODEL,
                    tools_include=("workflow_output",), body_contains=("Review the delegated text.",),
                    body_excludes=("image/png", "image_url", "call-image", "read_image")),
             Stream(ToolCall("child-output", "workflow_output", '{"summary":"text-safe child completed"}'), Finish("tool_calls"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=CHAT_MODEL,
                    body_contains=("text-safe child completed", "call-image"),
                    body_excludes=("image/png", "image_url")),
             Stream(Text("text-safe delegation complete"), Finish("stop"))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=CHAT_MODEL, no_direct_tools=True,
                    body_contains=("retired-conversation", "artifact_1"),
                    body_excludes=("image/png", "image_url")),
             Stream(Text("Image read and text-only delegation completed."), Finish("stop"))),
    )


def image_budget_continuation(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, name="image_budget_continuation") -> Scenario:
    steps = [
        Step(Expect(protocol=protocol, model=model, tools_include=("read_image",)),
             Stream(Gate("image-budget-admitted"), *(ToolCall(f"parallel-image-{i}", "read_image", '{"path":"{workspace}/sample.png"}') for i in range(17)), Finish("tool_calls"))),
        Step(Expect(protocol=protocol, model=model, body_contains=("image/png", "Image artifact")),
             Stream(Text("seventeen successful images continue"), Finish("stop"))),
    ]
    if protocol != ANTHROPIC_MESSAGES:
        text_model = CHAT_MODEL if protocol == OPENAI_CHAT_COMPLETIONS else RESPONSES_MODEL
        steps.extend([
            Step(Expect(protocol=protocol, model=text_model, body_contains=("Image artifact",), body_excludes=("image/png",)),
                 Stream(Text("text projection"), Finish("stop"))),
            Step(Expect(protocol=protocol, model=model, tools_include=("read_image",), body_contains=("image/png", "Image artifact")),
                 Stream(Text("images restored"), Finish("stop"))),
        ])
    return Scenario(name, *steps)


def image_coverage_growth(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, name="image_coverage_growth") -> Scenario:
    return Scenario(name,
        Step(Expect(protocol=protocol, model=model, tools_include=("read_image",)),
             Stream(*(ToolCall(f"first-image-{i}", "read_image", '{"path":"{workspace}/sample.png"}') for i in range(16)), Finish("tool_calls"))),
        Step(Expect(protocol=protocol, model=model, body_contains=("image/png",)),
             Stream(*([Reasoning("complete signed native thinking")] if protocol == ANTHROPIC_MESSAGES else []), ToolCall("seventeenth-image", "read_image", '{"path":"{workspace}/sample.png"}'), Finish("tool_calls"))),
        Step(Expect(protocol=protocol, model=model, body_contains=("image/png", "Image artifact")),
             HttpError(503, {"error": {"message": "temporary unavailable", "type": "server_error"}})),
        Step(Expect(protocol=protocol, model=model, body_contains=("image/png", "Image artifact")),
             Stream(Text("coverage reconciled"), Finish("stop"))))


def image_coverage_missing_replay() -> Scenario:
    return Scenario("image_coverage_missing_replay",
        Step(Expect(protocol=OPENAI_RESPONSES, model="responses-image", tools_include=("read_image",)),
             Stream(*(ToolCall(f"first-image-{i}", "read_image", '{"path":"{workspace}/sample.png"}') for i in range(16)), Finish("tool_calls"))),
        Step(Expect(protocol=OPENAI_RESPONSES, model="responses-image", body_contains=("image/png",)),
             Stream(Reasoning("stored reasoning requires unavailable native replay"), ToolCall("seventeenth-image", "read_image", '{"path":"{workspace}/sample.png"}'), Finish("tool_calls"))))


def image_coverage_overflow_retry() -> Scenario:
    return Scenario("image_coverage_overflow_retry",
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, tools_include=("read_image",)),
             Stream(Reasoning("first signed native thinking"), *(ToolCall(f"first-image-{i}", "read_image", '{"path":"{workspace}/sample.png"}') for i in range(16)), Finish("tool_calls"), Usage(16, 1))),
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, body_contains=("image/png",)),
             Stream(Reasoning("complete signed native thinking"), ToolCall("seventeenth-image", "read_image", '{"path":"{workspace}/sample.png"}'), Finish("tool_calls"), Usage(17, 1))),
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, body_contains=("image/png", "Image artifact")),
             HttpError(400, {"error": {"type": "invalid_request_error", "message": "prompt is too long: context window exceeded"}})),
        # With no continuation anchor, keep-recent selects the first legal
        # prefix. A stale owner instead forces retirement through image #17.
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=SUMMARY_MODEL, body_contains=(SUMMARY_INSTRUCTION,), body_excludes=("seventeenth-image", "complete signed native thinking")),
             Stream(Text("coverage retirement summary"), Finish("stop"))),
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, body_contains=("coverage retirement summary", "image/png", "Image artifact")),
             HttpError(503, {"error": {"type": "server_error", "message": "temporary unavailable"}})),
        Step(Expect(protocol=ANTHROPIC_MESSAGES, model=ANTHROPIC_MODEL, body_contains=("coverage retirement summary", "image/png", "Image artifact")),
             Stream(Text("coverage overflow recovered"), Finish("stop"))))


SCENARIOS = {
    "image_coverage_overflow_retry": image_coverage_overflow_retry,
    "image_coverage_missing_replay": image_coverage_missing_replay,
    "image_coverage_growth": image_coverage_growth,
    "image_coverage_growth_responses": lambda: image_coverage_growth(OPENAI_RESPONSES, "responses-image", "image_coverage_growth_responses"),
    "image_budget_chat": lambda: image_budget_continuation(OPENAI_CHAT_COMPLETIONS, "chat-image", "image_budget_chat"),
    "image_budget_responses": lambda: image_budget_continuation(OPENAI_RESPONSES, "responses-image", "image_budget_responses"),
    "image_budget_continuation": image_budget_continuation,
    "image_tool_round_trip": image_tool_round_trip,
    "app_server_user_a": lambda: app_server_user("a"),
    "app_server_user_b": lambda: app_server_user("b"),
    "openai_chat_streamed_turn": openai_chat_streamed_turn,
    "openai_responses_streamed_turn": openai_responses_streamed_turn,
    "anthropic_streamed_turn": anthropic_streamed_turn,
    "tool_call_continuation": tool_call_continuation,
    "skill_read_turn": skill_read_turn,
    "workflow_output": workflow_output,
    "workflow_tool": workflow_tool,
    "workflow_reference_repair": workflow_reference_repair,
    "workflow_reference_tampering": lambda: workflow_reference_repair(tampered=True),
    "workflow_reference_exhaustion": lambda: workflow_reference_repair(True),
    "workflow_reference_cancel": lambda: Scenario("workflow_reference_cancel", *workflow_reference_repair().steps[:5]),
    "workflow_reference_parallel": workflow_reference_parallel,
    "workflow_retention": workflow_retention,
    "provider_http_error": provider_http_error,
    "gated_stream_cancellation": gated_stream_cancellation,
    "restart_after_request_start": restart_after_request_start,
    "compaction_session_summary": compaction_session_summary,
    "compaction_explicit_summary": compaction_explicit_summary,
    "compaction_twice_session_summary": compaction_twice_session_summary,
    "compaction_twice_explicit_summary": compaction_twice_explicit_summary,
    "frozen_attempt_model": frozen_attempt_model,
}
