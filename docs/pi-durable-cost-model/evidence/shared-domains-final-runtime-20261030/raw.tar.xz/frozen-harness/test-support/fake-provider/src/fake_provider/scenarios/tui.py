"""The scenario driven by the TUI real-child integration suite.

The TUI owns process mechanics and client assertions. It owns no provider
protocol: the wire bytes below are the same codec every Rust conformance
scenario uses, so there is exactly one provider-emulation implementation in
the repository.
"""

from __future__ import annotations

import json

from fake_provider.scenario import (
    OPENAI_CHAT_COMPLETIONS,
    Expect,
    Finish,
    Gate,
    Scenario,
    Step,
    Stream,
    ToolCall,
    Text,
    Usage,
)
from fake_provider.scenarios.conformance import SUMMARY_INSTRUCTION

INTEGRATION_MODEL = "integration-model"
PROMPT = "hello from the tui"
REPLY = "Hello world"

# -- repeated compaction over stdio ----------------------------------------

TURN_ONE = "tui compaction: turn one"
TURN_TWO = "tui compaction: turn two"
TURN_THREE = "tui compaction: turn three"
FILLER_ONE_MARKER = "tui-compaction-filler-one-marker-39c1"
FILLER_TWO_MARKER = "tui-compaction-filler-two-marker-84e2"
SUMMARY_ONE_TEXT = "tui summary one: the assistant produced filler report one."
SUMMARY_TWO_TEXT = "tui summary two: the assistant produced filler report two."


def _filler(marker: str) -> str:
    """~200 KB of deterministic filler, worth roughly 51k estimated tokens.

    The compaction describe block publishes a 56k-token window with a 1.5k
    reserve and a 1k output budget. Both the soft input limit and the summary
    input limit carry the reserve, so both are 53.4k: above this span's
    estimate and below the whole next-turn request estimate. The block text is
    byte-identical to the Rust conformance scenarios' so the same proven
    margins hold.
    """
    return (marker + " ") + " ".join(
        f"compaction filler block {index:05d}." for index in range(6800)
    )


FILLER_ONE = _filler(FILLER_ONE_MARKER)
FILLER_TWO = _filler(FILLER_TWO_MARKER)


def tui_integration() -> Scenario:
    return Scenario(
        "tui_integration",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                # The catalog's own request parameters were assembled by the
                # runtime, not by the client.
                json_subset={"stream": True, "temperature": 0.25},
                body_contains=(PROMPT,),
                headers_present=("content-type",),
            ),
            Stream(Text(REPLY, pieces=2), Finish("stop"), Usage(12, 3)),
        ),
    )


QUESTIONNAIRE_PROMPT = "choose the visual direction"
QUESTIONNAIRE_ARGUMENTS = json.dumps(
    {
        "questions": [
            {
                "question": "Which visual direction should I use?",
                "header": "Visual style",
                "options": [
                    {
                        "label": "Swiss / Klein blue",
                        "description": "Information-first typography with strong hierarchy.",
                        "preview": "## Swiss preview\n\nBlue hierarchy.",
                    },
                    {
                        "label": "Electronic magazine",
                        "description": "A warmer editorial composition with serif typography.",
                    },
                ],
                "multi_select": False,
            },
            {
                "question": "Which elements should be enabled?",
                "header": "Elements",
                "options": [
                    {"label": "Charts", "description": "Show quantitative charts."},
                    {"label": "Comments", "description": "Show reviewer comments."},
                ],
                "multi_select": True,
            },
        ]
    },
    separators=(",", ":"),
)


def tui_ask_user_questionnaire() -> Scenario:
    """One structured ask_user call, then the model's next turn."""
    return Scenario(
        "tui_ask_user_questionnaire",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(QUESTIONNAIRE_PROMPT, "multi_select", "description"),
                tools_include=("ask_user",),
                headers_present=("content-type",),
            ),
            Stream(
                ToolCall(
                    "call-ask-user-1",
                    "ask_user",
                    QUESTIONNAIRE_ARGUMENTS,
                ),
                Finish("tool_calls"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(
                    r'\"cancelled\":false',
                    r'\"question_index\":0',
                    r'\"header\":\"Visual style\"',
                    r'\"kind\":\"option\"',
                    "Swiss / Klein blue",
                ),
                tools_include=("ask_user",),
            ),
            Stream(Text("Questionnaire continued"), Finish("stop")),
        ),
    )


BEFORE_START_PROMPT = "cancel before executor start"
BEFORE_START_ARGUMENTS = json.dumps(
    {"command": "printf never-started", "execution_mode": "foreground"},
    separators=(",", ":"),
)


def tui_before_start_cancellation() -> Scenario:
    """One real tool proposal for the Runtime Client/TUI repair regression.

    The TUI config requires approval for Bash. The client cancels while the
    runtime is waiting at that pre-tool boundary, so the executor must never
    be invoked and no continuation request can occur.
    """
    return Scenario(
        "tui_before_start_cancellation",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(BEFORE_START_PROMPT,),
                tools_include=("bash",),
                headers_present=("content-type",),
            ),
            Stream(
                ToolCall(
                    "call-tui-before-start",
                    "bash",
                    BEFORE_START_ARGUMENTS,
                ),
                Finish("tool_calls"),
            ),
        ),
    )


def tui_compaction() -> Scenario:
    """Two committed compactions, observed by the real TUI child over stdio.

    The construction mirrors the Rust conformance scenario: turn one fills
    the window, turn two compacts, turn two's answer refills the window, and
    turn three's compaction retires the still-active first summary. Every
    `body_excludes` is the wire proof that retired bytes never reach the
    provider again.
    """
    return Scenario(
        "tui_compaction",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(TURN_ONE,),
            ),
            Stream(Text(FILLER_ONE), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                no_direct_tools=True,
                body_contains=(SUMMARY_INSTRUCTION, FILLER_ONE_MARKER),
                body_excludes=(FILLER_TWO_MARKER,),
            ),
            Stream(Text(SUMMARY_ONE_TEXT), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(SUMMARY_ONE_TEXT, TURN_TWO),
                body_excludes=(FILLER_ONE_MARKER,),
            ),
            Stream(Text(FILLER_TWO), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                no_direct_tools=True,
                body_contains=(SUMMARY_INSTRUCTION, SUMMARY_ONE_TEXT, FILLER_TWO_MARKER),
                body_excludes=(FILLER_ONE_MARKER,),
            ),
            Stream(Text(SUMMARY_TWO_TEXT), Finish("stop")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(SUMMARY_TWO_TEXT, TURN_THREE),
                body_excludes=(FILLER_ONE_MARKER, FILLER_TWO_MARKER, SUMMARY_ONE_TEXT),
            ),
            Stream(Text("tui: continuing from the second summary"), Finish("stop")),
        ),
    )


#: Two Sessions, each holding one gated response.
#:
#: The TUI multi-Session suite starts a turn on Session A, holds it at its
#: gate, changes focus to Session B, and drives B to completion. A's request
#: is provably still open across that whole focus change, which is exactly the
#: fact "switching focus never stops another Session" needs.
SESSION_A_PROMPT = "tui multi-session: session A long task"
SESSION_B_PROMPT = "tui multi-session: session B quick task"


def tui_multi_session(hold_b: bool = False) -> Scenario:
    return Scenario(
        "app_server_replacement" if hold_b else "tui_multi_session",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(SESSION_A_PROMPT,),
            ),
            Stream(
                Text("A is working"),
                Gate("session-a-holding"),
                Text(" and has now finished"),
                Finish("stop"),
            ),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(SESSION_B_PROMPT,),
            ),
            Stream(Text("B answered while A was still working"),
                   *((Gate("session-b-holding"),) if hold_b else ()), Finish("stop")),
        ),
    )


def app_server_lifecycle() -> Scenario:
    return Scenario("app_server_lifecycle", *(Step(
        Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL,
               body_contains=("lifecycle small turn",)),
        Stream(Text("lifecycle result"), Finish()),
    ) for _ in range(3)))


def tui_subagent_inspection() -> Scenario:
    # Parent continuation and child admission may arrive in either order.
    # Identical read-only question proposals park both native owners. The test
    # answers the exact child-routed InteractionRef first, then the parent.
    question = json.dumps({"questions": [{"question": "Inspection checkpoint?", "header": "Inspect", "options": [{"label": "Continue", "description": "Continue inspection"}, {"label": "Stop", "description": "Stop inspection"}]}]})
    return Scenario("tui_subagent_inspection",
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL, tools_include=("subagent",)),
             Stream(ToolCall("spawn-child", "subagent", '{"agent":"researcher","title":"Research canonical history","task":"Inspect canonical child history"}'), Finish("tool_calls"))),
        *(Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL, tools_include=("ask_user",)),
               Stream(Gate(f"inspection-request-{index}"), ToolCall(f"inspection-question-{index}", "ask_user", question), Finish("tool_calls"), Usage(10, 2))) for index in range(2)),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL, tools_include=("ask_user",)),
             Stream(Gate("child-completion"), Text("Canonical child answer"), Finish("stop"), Usage(100, 20))),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL, tools_include=("subagent",)),
             Stream(Text("Parent inspected child"), Finish("stop"))),
    )


PRESENT_PROMPT = "tui present: deliver the report"
PRESENT_ARGUMENTS = json.dumps(
    {
        "files": [
            {"path": "报告 final file.md", "description": "Final report"},
            {"path": "./data set.csv"},
            # A normalized duplicate is validated and then discarded.
            {"path": "报告 final file.md", "description": "Duplicate discarded"},
        ]
    },
    separators=(",", ":"),
    ensure_ascii=False,
)


def tui_present_delivery() -> Scenario:
    """One ordinary `present` call, then the model's closing turn.

    The TUI reads, saves and locates the delivered files afterwards. None of
    that may reach the provider: the scenario has exactly these two steps.
    """
    return Scenario(
        "tui_present_delivery",
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=(PRESENT_PROMPT,),
                tools_include=("present",),
            ),
            Stream(ToolCall("call-tui-present", "present", PRESENT_ARGUMENTS), Finish("tool_calls")),
        ),
        Step(
            Expect(
                protocol=OPENAI_CHAT_COMPLETIONS,
                model=INTEGRATION_MODEL,
                body_contains=("Declared 2 deliverable(s)",),
            ),
            Stream(Text("Delivered the report."), Finish("stop")),
        ),
    )


SCENARIOS = {
    "tui_present_delivery": tui_present_delivery,
    "tui_subagent_inspection": tui_subagent_inspection,
    "app_server_lifecycle": app_server_lifecycle,
    "tui_integration": tui_integration,
    "tui_multi_session": tui_multi_session,
    "app_server_replacement": lambda: tui_multi_session(hold_b=True),
    "tui_ask_user_questionnaire": tui_ask_user_questionnaire,
    "tui_before_start_cancellation": tui_before_start_cancellation,
    "tui_compaction": tui_compaction,
}


def tui_agent_interrupt() -> Scenario:
    """Native interruption followed by one activation under the same Agent."""
    return Scenario("tui_agent_interrupt",
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL,
                    body_contains=("TUI_AGENT_PARENT",), tools_include=("subagent",)),
             Stream(ToolCall("tui-agent-create", "subagent", json.dumps({
                 "agent": "reviewer", "title": "Review workspace", "task": "TUI_AGENT_CHILD: inspect the workspace",
             })), Finish("tool_calls"))),
        *(Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL),
               Stream(Gate(f"interrupt-initial-{index}"), Text("Initial request complete."), Finish()),
               allow_disconnect=True) for index in range(2)),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL,
                    body_contains=("TUI_AGENT_PARENT",)),
             Stream(Gate("interrupt-parent-notice"), Text("Parent observed interruption."), Finish())),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL,
                    body_contains=("TUI_AGENT_RESUME",), body_excludes=("TUI_AGENT_PARENT",)),
             Stream(Gate("interrupt-resumed"), Text("Resumed child report."), Finish())),
        Step(Expect(protocol=OPENAI_CHAT_COMPLETIONS, model=INTEGRATION_MODEL,
                    body_contains=("TUI_AGENT_PARENT", "Resumed child report.")),
             Stream(Text("Parent received resumed report."), Finish())),
    )


SCENARIOS["tui_agent_interrupt"] = tui_agent_interrupt
