#!/usr/bin/env python3
"""Pure audited arithmetic: fresh pinned Rust pairs; historical references separate."""
import argparse, collections, hashlib, json, math, statistics, sys
from pathlib import Path
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
CASES = ['short-small', 'short-large', 'stream', 'large', 'tool', 'cancel']
MODES = ['no-live-subscriber', 'live-subscriber']
PRIMARY = ['median_measured_turn_ms', 'through_cleanup_self_cpu_ms', 'through_cleanup_process_write_bytes', 'max_sampled_anon_pss_mib', 'max_sampled_rss_mib']
POLICY = 'Only fresh CPU-2,8 Rust baseline/candidate products are compared. Fixed Pi/DeepSeek measurements used unrestricted CPUs in an earlier batch; their original values are retained separately and no ratio combines those batches.'


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def distribution(values):
    require(all(v is None or type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in values), 'invalid metric')
    valid = [v for v in values if v is not None]
    return {'values': values, 'available': len(valid), 'missing': len(values)-len(valid),
            'median': statistics.median(valid) if valid else None,
            'minimum': min(valid) if valid else None, 'maximum': max(valid) if valid else None}


def derive(formal, previous):
    require(formal['accepted'] is True and formal['errors'] == [], 'current direct audit incomplete')
    data = formal['datasets']['direct']
    require((data['derived_products'], data['valid_comparisons'], data['checked_requests']) == (144, 72, 1692), 'fresh matrix differs')
    require(len(data['products']) == 144 and collections.Counter(r['engine'] for r in data['products']) == {'before': 72, 'after': 72}, 'fresh product inventory differs')
    index = collections.defaultdict(list)
    for row in data['products']:
        index[row['mode'], row['case'], row['engine']].append(row)
    require(set(index) == {(m, c, e) for m in MODES for c in CASES for e in ('before', 'after')}, 'fresh matrix cells differ')
    require(all(len(rows) == 6 and {r['pair'] for r in rows} == set(range(6)) for rows in index.values()), 'fresh cell repetition inventory differs')
    require(previous['accepted'] is True and previous['mode'] == 'strict' and previous['strict_identity_verified'] is True and not previous['errors'], 'fixed reference audit was not strict accepted')
    paired, adverse, unavailable = [], [], []
    for mode in MODES:
        for case in CASES:
            groups = [g for g in data['groups'] if g['mode'] == mode and g['case'] == case]
            require(groups and len({g['metric'] for g in groups}) == len(groups), 'duplicate/missing direct metrics')
            require(set(PRIMARY) <= {g['metric'] for g in groups}, 'primary metrics absent')
            for group in groups:
                require(len(group['pairs']) == 6 and {r['pair'] for r in group['pairs']} == set(range(6)), 'paired metric inventory differs')
                bad = [r for r in group['pairs'] if r['percent_change'] is not None and r['percent_change'] > 0]
                if bad:
                    adverse.append({'comparison': 'fresh_paired_rust', 'mode': mode, 'case': case, 'metric': group['metric'], 'paired_median_percent': group['percent_change']['median'], 'adverse_pairs': bad, 'adverse_count': len(bad), 'all_pairs': 6})
                for pair in group['pairs']:
                    if pair['ratio'] is None:
                        unavailable.append({'comparison': 'fresh_paired_rust', 'mode': mode, 'case': case, 'metric': group['metric'], 'pair': pair['pair'], 'reason': pair['ratio_unavailable_reason']})
            paired.append({'mode': mode, 'case': case, 'metrics': {g['metric']: {'fresh_before': g['denominator_values'], 'fresh_after': g['numerator_values'], 'paired_percent': g['percent_change'], 'pairs': g['pairs']} for g in groups}})
    direction = {}
    for metric in PRIMARY:
        values = [p['difference'] for g in data['groups'] if g['metric'] == metric for p in g['pairs']]
        require(len(values) == 72, 'primary pair inventory differs')
        direction[metric] = {'lower': sum(v is not None and v < 0 for v in values), 'equal': sum(v == 0 for v in values), 'higher': sum(v is not None and v > 0 for v in values), 'unavailable': sum(v is None for v in values)}
    prior_pi = [r for r in previous['datasets']['final']['products'] if r['engine'] == 'pi']
    require(len(prior_pi) == 60, 'fixed Pi inventory differs')
    pi = []
    for mode in MODES:
        for case in CASES:
            rows = sorted((r for r in prior_pi if r['mode'] == mode and r['case'] == case), key=lambda r: r['pair'])
            require(len(rows) == 5 and {r['pair'] for r in rows} == set(range(5)), 'fixed Pi cell repetition differs')
            metrics = sorted(set.intersection(*(set(r['metrics']) for r in rows)))
            pi.append({'mode': mode, 'case': case, 'scope': 'historical_unrestricted_cpu_reference_only', 'metrics': {key: distribution([r['metrics'][key] for r in rows]) for key in metrics}, 'sources': [{'file': r['file'], 'raw_sha256': r['raw_sha256'], 'pair': r['pair']} for r in rows]})
    ds = previous['datasets']['three-engine']
    supplement = {(r['case'], r['repetition']): r for r in ds['supplementary_products'] if r['engine'] == 'deepseek'}
    raw = [r for r in ds['rows'] if r['engine'] == 'deepseek']
    require(len(raw) == len(supplement) == 12 and {r['case'] for r in raw} == {'short-small', 'short-large', 'stream', 'large'}, 'fixed DeepSeek inventory differs')
    dsrows = []
    for row in raw:
        extra = supplement[row['case'], row['repetition']]
        require(extra['raw_sha256'] == row['raw_result_sha256'], 'DeepSeek source binding differs')
        dsrows.append({'case': row['case'], 'repetition': row['repetition'], 'metrics': dict(row, **extra['metrics']), 'source': extra['file'], 'raw_sha256': row['raw_result_sha256'], 'limits': extra['limits']})
    deepseek = []
    for case in ['short-small', 'short-large', 'stream', 'large']:
        rows = sorted((r for r in dsrows if r['case'] == case), key=lambda r: r['repetition'])
        require(len(rows) == 3 and {r['repetition'] for r in rows} == set(range(3)), 'DeepSeek repetition differs')
        keys = ('mean_turn_ms', 'median_measured_turn_ms', 'turn_cpu_ms_per_turn', 'max_sampled_turn_rss_mib', 'turn_write_mib_per_turn')
        exit_keys = ('first_native_runtime_wait4_cpu_ms', 'verification_native_runtime_wait4_cpu_ms', 'both_native_runtimes_wait4_cpu_ms', 'through_cleanup_process_write_bytes', 'closed_logical_bytes', 'closed_allocated_bytes')
        deepseek.append({'mode': 'live-subscriber', 'case': case, 'scope': 'historical_unrestricted_cpu_reference_only', 'metrics': {key: distribution([r['metrics'].get(key) for r in rows]) for key in keys}, 'separate_deepseek_native_flush_exit_metrics': {key: distribution([r['metrics'].get(key) for r in rows]) for key in exit_keys}, 'sources': [{'file': r['source'], 'raw_sha256': r['raw_sha256'], 'repetition': r['repetition']} for r in rows], 'limits': rows[0]['limits']})
    return {'accepted': True, 'current_rust_products': 72, 'fresh_paired_products': 144, 'fixed_pi_products': 60, 'fixed_deepseek_products': 12, 'comparison_policy': POLICY, 'fresh_paired': paired, 'fresh_direction_counts': direction, 'fixed_pi': pi, 'fixed_deepseek': deepseek, 'all_adverse_metrics': adverse, 'all_unavailable_ratios': unavailable, 'limits': [POLICY, 'Six balanced-order pairs per cell: three baseline-first and three candidate-first. All reversals and unavailable counters remain visible; no confidence interval or parity claim.', '/proc CPU counters use 100 ticks/s: cumulative CPU endpoints have 10 ms granularity, not profiler samples.', 'Product measured-turn medians and means are different estimands. Across products report median and range of those statistics; never pool turns.', 'DeepSeek SDK idle does not await native flush/fsync. Native wait4 exit/flush and verification CPU remain separate; full process write_bytes is unavailable, not zero.']}


def fmt(value):
    return 'N/A' if value is None else f'{value:.3f}'


def markdown(data):
    lines = ['# Shared domain and native content read performance evidence', '', POLICY, '', 'Fresh Rust: six interleaved pairs per cell, CPU affinity 2,8, with three pairs in each execution order.', '', '| Mode | Case | Paired wall median % [min,max] | Full CPU % | Full write bytes % | Sample anon PSS % | Sample RSS % |', '|---|---|---:|---:|---:|---:|---:|']
    for row in data['fresh_paired']:
        cells = []
        for metric in PRIMARY:
            d = row['metrics'][metric]['paired_percent']
            cells.append(f"{fmt(d['median'])} [{fmt(d['minimum'])},{fmt(d['maximum'])}]" if metric == PRIMARY[0] else fmt(d['median']))
        lines.append('| ' + ' | '.join([row['mode'], row['case'], *cells]) + ' |')
    lines += ['', 'Fresh Rust absolute warm-request windows, each product contributing 32 measured turns:', '', '| Mode | History | Revision | Mean ms/turn median [min,max] | Median ms/turn median [min,max] | CPU ms/turn | Write bytes/turn |', '|---|---:|---|---:|---:|---:|---:|']
    for row in data['fresh_paired']:
        if row['case'] not in ('short-small', 'short-large'):
            continue
        for label, revision in [('fresh_before', 'baseline'), ('fresh_after', 'candidate')]:
            cells = []
            for metric in ('mean_turn_ms', 'median_measured_turn_ms', 'turn_cpu_ms_per_turn', 'turn_write_bytes_per_turn'):
                d = row['metrics'][metric][label]
                cells.append(f"{fmt(d['median'])} [{fmt(d['minimum'])},{fmt(d['maximum'])}]")
            lines.append('| ' + ' | '.join([row['mode'], str(8 if row['case'] == 'short-small' else 64), revision, *cells]) + ' |')
    lines += ['', 'Fixed historical references below were measured with unrestricted CPUs. They are not denominators for this round.', '', '| Historical engine | Mode | Case | Mean ms/turn | Median ms/turn | CPU ms/turn |', '|---|---|---|---:|---:|---:|']
    for engine, rows in [('Pi', data['fixed_pi']), ('DeepSeek harness', data['fixed_deepseek'])]:
        for row in rows:
            lines.append('| ' + ' | '.join([engine, row['mode'], row['case'], *[fmt(row['metrics'][key]['median']) for key in ('mean_turn_ms', 'median_measured_turn_ms', 'turn_cpu_ms_per_turn')]]) + ' |')
    lines += ['', 'All adverse fresh paired metrics, including individual reversals:', '', '| Mode | Case | Metric | Paired median % | Adverse pair IDs and % |', '|---|---|---|---:|---|']
    for row in data['all_adverse_metrics']:
        lines.append('| ' + ' | '.join([row['mode'], row['case'], row['metric'], fmt(row['paired_median_percent']), ','.join(f"{p['pair']}:{p['percent_change']:+.3f}%" for p in row['adverse_pairs'])]) + ' |')
    lines += ['', *['- ' + value for value in data['limits']], '', 'Full per-product values, raw source hashes, separate DeepSeek exit metrics and unavailable ratios are retained in report-data.json.']
    return '\n'.join(lines) + '\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=HERE)
    parser.add_argument('--audit', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--markdown', type=Path)
    args = parser.parse_args()
    audit = args.audit or args.root / 'direct-audit.json'
    output = args.output or args.root / 'report-data.json'
    md = args.markdown or args.root / 'report-tables.md'
    require(not output.exists() and not md.exists(), 'retain prior report attempt')
    pinpath = args.root / 'reference-pins/fixed-references.json'
    pin = load(pinpath)
    reference = args.root / 'reference-pins' / pin['reference_audit']
    require(reference.parent == pinpath.parent and sha(reference) == pin['reference_audit_sha256'], 'fixed reference audit changed')
    formal, previous = load(audit), load(reference)
    require(formal['script_sha256'] == sha(args.root / 'direct-audit.py'), 'current formal auditor changed')
    require(previous['identities']['complete']['sha256'] == pin['prior_rust_sha256'] and previous['identities']['complete']['head'] == pin['prior_source'], 'fixed reference source differs')
    result = derive(formal, previous)
    result.update(script_sha256=sha(__file__), current_audit_sha256=sha(audit), reference_pin_sha256=sha(pinpath), references=pin, current_identity=formal['identities'])
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    md.write_text(markdown(result))
    print(json.dumps({'accepted': True, 'cells': len(result['fresh_paired']), 'adverse_metrics': len(result['all_adverse_metrics']), 'output': str(output)}))


if __name__ == '__main__':
    main()
