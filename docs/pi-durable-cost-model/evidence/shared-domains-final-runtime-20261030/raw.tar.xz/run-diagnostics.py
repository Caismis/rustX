"""Eight isolated Rust products: four columns and four WAL; no CPU profiles."""
import datetime, hashlib, json, os, subprocess, sys, traceback
from pathlib import Path
from fixture_binding import capture as capture_fixtures, CPU_AFFINITY, FORMAL_PROTOCOL, affinity_snapshot, validate_affinity
root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
binaries = {'baseline': root/'baseline-build/conformance', 'complete': root/'candidate-complete-build/conformance'}
def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
os.sched_setaffinity(0, CPU_AFFINITY)
builds = {label: json.loads((binary.parent/'identity.json').read_text()) for label, binary in binaries.items()}
assert all(build['verified'] and sha(binaries[label]) == build['sha256'] for label, build in builds.items())
assert builds['baseline']['harness'] == builds['complete']['harness']
premeasurement = json.loads((root/'premeasurement.json').read_text())
assert premeasurement['accepted'] is True and not premeasurement['errors'] and premeasurement['protocol'] == FORMAL_PROTOCOL
def source():
    assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime','test-support/fake-provider'], cwd=repo, text=True).strip()
    files = {str(p.relative_to(repo)): sha(p) for folder in ('src','tests') for p in sorted((repo/folder).rglob('*')) if p.is_file()}
    files.update({p: sha(repo/p) for p in ('Cargo.toml','Cargo.lock')})
    assert files == builds['complete']['source_files']
    fixtures = capture_fixtures(repo)
    assert fixtures == premeasurement['fixtures']
    assert all(sha(repo/p) == digest for p, digest in builds['complete']['harness'].items())
    assert all(sha(root/name) == digest for name, digest in premeasurement['scripts'].items())
    affinity = affinity_snapshot(); validate_affinity(affinity)
    assert affinity['topology'] == premeasurement['host_affinity']['topology']
    return {'utc': now(), 'head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip(), 'files': files, 'fixtures': fixtures, 'runner_sha256': sha(__file__), 'affinity': affinity, 'protocol': FORMAL_PROTOCOL}
def stable(snapshot):
    return {k: v for k, v in snapshot.items() if k not in ('utc', 'affinity')}
steps = []
for label, binary in binaries.items():
    steps.append((f'columns-{label}', 'columns-complete.py', ['--binary', str(binary), '--label', label]))
for label, binary in binaries.items():
    steps.extend([(f'wal-{label}', 'run-wal-rust.py', ['--binary', str(binary), '--label', label]), (f'wal-summary-{label}', 'analyze-wal-verified.py', ['--label', label])])
ledger = root/'diagnostic-commands.json'
assert not ledger.exists(), 'retain previous attempt; choose a new evidence root instead of overwriting'
initial = source(); write(root/'diagnostic-source-before.json', initial)
records = [dict(name=name, command=['taskset','-c','2,8',sys.executable,str(root/script),*args], producer_sha256=sha(root/script), status='pending') for name,script,args in steps]
def save():
    write(ledger, records)
save()
try:
    for record in records:
        source(); assert all(sha(binary) == builds[label]['sha256'] for label,binary in binaries.items())
        record.update(start_utc=now(), status='running', runner_affinity_before=affinity_snapshot()); save()
        try:
            with (root/(record['name']+'.stdout')).open('x') as stdout, (root/(record['name']+'.stderr')).open('x') as stderr:
                result = subprocess.run(record['command'], cwd=repo, env=os.environ|{'UV_OFFLINE':'1'}, stdout=stdout, stderr=stderr)
            record.update(exit=result.returncode, status='complete' if result.returncode == 0 else 'failed')
            assert result.returncode == 0, f"diagnostic producer failed: {record['name']}"
            assert sha(record['command'][4]) == record['producer_sha256']
            current = source(); assert stable(current) == stable(initial)
            assert all(sha(binary) == builds[label]['sha256'] for label,binary in binaries.items())
        except BaseException:
            record.update(status='failed', error=traceback.format_exc()); raise
        finally:
            record.update(end_utc=now(), runner_affinity_after=affinity_snapshot()); save()
            print(record['name'], record['status'], flush=True)
finally:
    for record in records:
        if record['status'] == 'pending':
            record.update(status='not_run', reason='prior diagnostic failed')
    save()
    try:
        final = source(); assert stable(final) == stable(initial)
        assert final['affinity']['topology'] == initial['affinity']['topology'] and final['affinity']['online_cpus'] == initial['affinity']['online_cpus']
        write(root/'diagnostic-source-after.json', final)
    except BaseException:
        write(root/'diagnostic-source-after-error.json', {'utc': now(), 'error': traceback.format_exc()}); raise
