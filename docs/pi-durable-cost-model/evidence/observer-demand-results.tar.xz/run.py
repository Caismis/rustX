from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
paths={'before':Path('/workspace/issue-481-evidence/pi-observer-before-repaired-build/conformance'),'after':Path('/workspace/issue-481-evidence/pi-observer-repaired-build/conformance')}
expected={'before':'fbe6ae0ca05d4b11966efd0747f72b8a4ba63383','after':'c01f28f9fac63a6af2efa4387a02123830fd0a3a'}
identities={}
for name,binary in paths.items():
 identity=json.loads((binary.parent/'identity.json').read_text());assert identity['verified'] and identity['head']==expected[name]
 assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==identity['sha256'];identities[name]=identity
assert identities['before']['harness']==identities['after']['harness']
assert all(hashlib.file_digest((repo/path).open('rb'),'sha256').hexdigest()==expected for path,expected in identities['after']['harness'].items())
(root/'build-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
failed=False
for mode in ['no-live-subscriber','live-subscriber']:
 command=['python3','benchmarks/runtime/compare-revisions.py','--before',str(paths['before']),'--after',str(paths['after']),'--output',str(root/mode),'--pairs','3','--observer-mode',mode]
 with (root/f'{mode}.log').open('w') as log:
  result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=False)
 failed|=result.returncode!=0
 print(mode,'exit',result.returncode,flush=True)
 if result.returncode==0:
  command=['python3','benchmarks/runtime/summarize-comparisons.py',str(root/mode)]
  with (root/f'{mode}-summary.json').open('w') as summary, (root/f'{mode}-summary.stderr').open('w') as err:
   result=subprocess.run(command,cwd=repo,stdout=summary,stderr=err,check=False)
  failed|=result.returncode!=0
raise SystemExit(int(failed))
