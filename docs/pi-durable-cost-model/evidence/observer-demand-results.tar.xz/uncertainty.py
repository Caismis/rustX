from pathlib import Path
import json,math,statistics
root=Path(__file__).resolve().parent
metrics=['mean_turn_ms','turn_cpu_ms_per_turn','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib','max_sampled_anon_pss_mib']
result={'scope':'Three interleaved pairs per case/mode. Geometric mean and two-sided 90% Student-t interval on log paired ratios, equivalent to a one-sided 95% upper limit; df2 critical2.919985580355516. Small independent approximately normal log-ratio assumption; exploratory only, not a seven-pair Pi parity test. Tick CPU and sampled memory limitations retained. No unrelated median subtraction.','modes':{}}
for mode in ['no-live-subscriber','live-subscriber']:
 summary=json.loads((root/f'{mode}-summary.json').read_text());cases={}
 for case,samples in summary['samples'].items():
  values={}
  for metric in metrics:
   ratios=[s['after_over_before'][metric] for s in samples]
   if not all(r is not None and r>0 for r in ratios):
    values[metric]={'n':len(ratios),'indeterminate':True,'ratios':ratios};continue
   assert len(ratios)==3
   logs=list(map(math.log,ratios));mean=statistics.mean(logs);width=2.919985580355516*statistics.stdev(logs)/math.sqrt(3)
   values[metric]={'n':3,'ratios':ratios,'geometric_mean':math.exp(mean),'two_sided_90_lower':math.exp(mean-width),'one_sided_95_upper':math.exp(mean+width),'paired_median':statistics.median(ratios),'min':min(ratios),'max':max(ratios)}
  cases[case]=values
 result['modes'][mode]=cases
(root/'paired-uncertainty.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({mode:{case:values['mean_turn_ms'] for case,values in cases.items()} for mode,cases in result['modes'].items()},indent=2))
