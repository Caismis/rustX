from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
binary=Path('/workspace/issue-481-evidence/pi-observer-repaired-build/conformance')
identity=json.loads((binary.parent/'identity.json').read_text())
assert identity['verified'] and identity['head']=='c01f28f9fac63a6af2efa4387a02123830fd0a3a'
assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==identity['sha256']
for observer in ['no-live-subscriber','live-subscriber']:
    for case in ['short-small','short-large']:
        for mode in ['control','cpu']:
            destination=root/f'{observer}-{case}-{mode}'
            command=['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(destination),'--mode',mode,'--case',case,'--observer-mode',observer]
            with (root/f'{observer}-{case}-{mode}.log').open('w') as log:
                subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
            print(observer,case,mode,'passed',flush=True)
            if mode=='cpu':
                for name,flags in [('steady-flat.txt',['--text']),('steady-cumulative.txt',['--text','--cum']),('steady-stacks.txt',['--collapsed'])]:
                    command=['/workspace/issue-481-profilers/unpacked/usr/bin/google-pprof',*flags,'--no_strip_temp','--nodecount=200',str(binary),str(destination/'before_measured_turns.cpu')]
                    with (destination/name).open('w') as out,(destination/(name+'.stderr')).open('w') as err:
                        subprocess.run(command,stdout=out,stderr=err,check=True)
print('Profile/control diagnostics complete; no formal timing inference or overhead subtraction.',flush=True)
