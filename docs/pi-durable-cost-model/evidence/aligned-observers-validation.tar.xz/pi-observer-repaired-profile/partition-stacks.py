from pathlib import Path
from collections import Counter
import json,re
root=Path(__file__).resolve().parent;records=[]
for observer in ['no-live-subscriber','live-subscriber']:
 for case in ['short-small','short-large']:
  p=root/f'{observer}-{case}-cpu';groups=Counter();operations=Counter();total=0
  for line in (p/'steady-stacks.txt').read_text().splitlines():
   stack,count=line.rsplit(' ',1);count=int(count);total+=count
   if 'runtime_benchmark::process_sample' in stack or 'runtime_benchmark::footprint' in stack:owner='benchmark_counters_and_footprints'
   elif any(x in stack for x in ['aligned::Display>::','aligned::read_content','aligned::hydrate_display_value']):owner='native_live_consumer'
   elif 'request_oracle::' in stack or 'aligned::verify_ordered_messages' in stack:owner='benchmark_ordered_verification'
   elif 'PublicationDraft>::encode' in stack:owner='publication_encoding'
   elif 'ReadDomainCut>::read' in stack:owner='publication_read_domains'
   elif 'CheckpointSeed>::' in stack or 'materialize_checkpoint' in stack:owner='checkpoint_materialization'
   elif any(x in stack for x in ['runtime_client::host::','runtime_client::projection::','runtime_client::trace::']):owner='other_runtime_client_publication'
   elif any(x in stack for x in ['rustx::agent::execution::','rustx::runtime::conversation_runtime::','rustx::durable::','rustx::runtime::read_layout::']):owner='native_engine_and_coordinator'
   elif 'rustx::app_server::' in stack:owner='app_server_wire'
   elif 'conformance::agent_loop::' in stack:owner='benchmark_driver'
   elif 'hyper::' in stack or 'reqwest::' in stack:owner='http_transport_unassigned'
   else:owner='scheduler_native_or_unassigned'
   groups[owner]+=count
   if 'sqlite3_prepare' in stack or 'sqlite3Prepare' in stack or 'sqlite3LockAndPrepare' in stack:operation='sql_prepare'
   elif 'sqlite3_step' in stack or 'sqlite3VdbeExec' in stack:operation='sql_execute'
   elif 'structural_json::' in stack:operation='structural_encoding'
   elif 'read_layout::' in stack:operation='source_navigation'
   else:operation='other'
   operations[operation]+=count
  expected=int(re.search(r'Total: (\d+) samples',(p/'steady-flat.txt').read_text())[1]);assert total==expected
  assert sum(groups.values())==sum(operations.values())==total
  records.append({'observer_mode':observer,'case':case,'samples':total,'ownership_partition':dict(groups),'operation_partition':dict(operations)})
result={'scope':'Diagnostic all-product-thread CPU signal samples, including driver and useful native observer work, excluding sibling provider. Each stack assigned exactly once within each partition; ownership and operation are separate axes, never added. Optimized/unknown frames remain unassigned. Signal samples are not overlapping elapsed-scope percentages. Separate single control/profile pairs describe overhead; no subtraction or headline inference. Phase is before_measured_turns through after_turns, excluding late full verification/reopen/cleanup which remain in complete lifecycle counters.','profiles':records}
(root/'disjoint-cpu-attribution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(records,indent=2))
