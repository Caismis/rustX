import json,subprocess,sys,datetime,os,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
previous=Path('/home/capi/.cache/rustx-pr485-incremental-attempt-20261102')
plan=json.loads((root/'plan.json').read_text()); records=[]
binaries={'baseline':previous/'baseline-build/conformance','candidate':previous/'candidate-complete-build/conformance'}
for i,(mode,label) in enumerate(plan['order']):
 name=f'{i}-{mode}-{label}';binary=binaries[label]
 cmd=['taskset','-c','2,8',sys.executable,'benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/home/capi/.cache/rustx-pr485-profilers','--output',str(root/name),'--mode',mode,'--case','short-large','--observer-mode','live-subscriber']
 row={'name':name,'command':cmd,'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'};records.append(row)
 (root/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(name+'.stdout')).open('x') as out,(root/(name+'.stderr')).open('x') as err:r=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 row.update(exit=r.returncode,status='complete' if r.returncode==0 else 'failed',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(root/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
