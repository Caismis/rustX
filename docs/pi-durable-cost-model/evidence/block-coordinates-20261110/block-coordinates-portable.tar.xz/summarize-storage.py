from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());before=load(r/'baseline-write-ledger.json');after=load(r/'candidate-write-ledger.json');targets=['sqlite_autoindex_observation_block_headers_2','observation_block_kind_idx'];rows=[]
for a,b in zip(before,after):
 assert a['history']==b['history'] and a['schema']==105 and b['schema']==106
 assert all(a[k]==b[k] for k in ['native_nodes','source_nodes','native_events','request_catalogs','request_catalog_definitions'])
 commits=lambda x:{k:v['commits'] for k,v in x['phase_commits'].items()};assert commits(a)==commits(b) and sum(commits(a).values())==160
 row={'history':a['history'],'hot_turns':32,'commits':commits(a),'sides':{}}
 for side,x in [('before',a),('after',b)]:
  p=r/f'traced/{side}/h{a["history"]}/phases.json';phases={v['phase']:v for v in load(p)};io=lambda name:{k.strip():int(v) for line in phases[name]['io'].splitlines() for k,v in [line.split(':')]};target_frames=sum(x['authenticated_wal_owners'].get(k,0) for k in targets);target_main=sum(x['authenticated_main_owners'].get(k,0) for k in targets)
  if side=='after':assert target_frames==0 and target_main==0
  row['sides'][side]={'wal_frames':x['wal_frames'],'wal_bytes':x['wal_bytes'],'main_bytes':x['main_bytes'],'wal_plus_main_kib_per_turn':(x['wal_bytes']+x['main_bytes'])/32/1024,'wal_epochs':x['wal_epochs'],'main_syncs':x['checkpoint_main_syncs'],'wal_syncs':x['wal_syncs'],'target_index_wal_frames':target_frames,'target_index_wal_plus_main_kib_per_turn':(target_frames*2072+target_main)/32/1024,'hot_process_write_kib_per_turn':x['process_hot']['write_bytes']/32/1024,'process_mib_through_final_close':x['process_through_close']['write_bytes']/2**20,'hot_verification_close_process_write_kib_per_turn':(io('after_final_writer_close')['write_bytes']-io('before_measured_turns')['write_bytes'])/32/1024,'group_ledger':x['group_ledger'],'native_nodes':x['native_nodes'],'source_nodes':x['source_nodes'],'event_count':x['native_events'],'request_catalogs':x['request_catalogs'],'definition_rows':x['request_catalog_definitions']}
 row['paired_percent']={k:(row['sides']['after'][k]/row['sides']['before'][k]-1)*100 for k in ['wal_plus_main_kib_per_turn','hot_process_write_kib_per_turn','process_mib_through_final_close','hot_verification_close_process_write_kib_per_turn']};rows.append(row)
report={'scope':'One structural product per side/history. WAL ownership authenticated at commit images; main-file pages matched to WAL versions. WAL frame payload includes 24-byte headers and 2 KiB pages. Syscall payload, process write_bytes, retained layout and device writes are different units. No headline timing or significance claim. The hot-verification-close window is not the hot-only window or full initialized lifecycle.','inputs':{p.name:hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [r/'baseline-write-ledger.json',r/'candidate-write-ledger.json']},'rows':rows}
(r/'storage-summary.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:print(row['history'],row['paired_percent'])
