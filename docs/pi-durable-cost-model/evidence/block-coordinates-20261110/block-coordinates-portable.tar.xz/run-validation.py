from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
identity=json.loads((root/'build/identity.json').read_text());head=identity['head'];assert identity['verified']
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def check():
 assert git('rev-parse','HEAD')==head and not git('status','--porcelain','--','src','Cargo.toml','Cargo.lock')
 assert all(hashlib.file_digest((repo/p).open('rb'),'sha256').hexdigest()==value for p,value in identity['harness'].items())
helpers=['run-traces.py','trace_products.py','replay_wal.py','ledger_summary.py','run-threeway.py','compare-three-revisions.py','summarize-threeway.py','run-memory.py','audit-memory.py','run-native.py','audit-native.py']
frozen={name:hashlib.file_digest((root/name).open('rb'),'sha256').hexdigest() for name in helpers}
(root/'validation-inputs.json').write_text(json.dumps({'head':head,'helpers':frozen},indent=2)+'\n')
jobs=[(name,[sys.executable,str(root/name)]) for name in ['run-traces.py','run-threeway.py','summarize-threeway.py','run-memory.py','audit-memory.py','run-native.py','audit-native.py']]
jobs.append(('functional',[sys.executable,str(repo/'benchmarks/runtime/compare-revisions.py'),'--before','/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/conformance','--after',str(root/'build/conformance'),'--observer-mode','live-subscriber','--output',str(root/'functional'),'--pairs','1','--case','tool','--case','cancel']))
records=[]
for name,command in jobs:
 check();assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
 with (root/('validation-'+name+'.log')).open('x') as log:result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':command,'exit':result.returncode});(root/'validation-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,result.returncode,flush=True);result.check_returncode();check()
 assert all(hashlib.file_digest((root/name).open('rb'),'sha256').hexdigest()==value for name,value in frozen.items())
