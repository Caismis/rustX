from pathlib import Path
import csv,importlib,json,math,statistics,sys
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');sys.path.insert(0,str(repo/'benchmarks/runtime'))
from controller import validate_sample
metrics=importlib.import_module('summarize-http');load=lambda p:json.loads(p.read_text());directory=root/'ordinary-threeway'
ledger={s:load(root/f'{s}-write-ledger.json') for s in ['baseline','candidate']}
empty={s:ledger['candidate' if s=='coordinate' else 'baseline'][0]['empty_opened_conversation']['page_count']*2048 for s in ['original','reference','coordinate']}
rows=[];checks=0
for case in ['short-small','short-large','large','stream']:
 for rep in range(4):
  for contrast in ['reference','storage','combined']:
   c=load(directory/f'{rep}-{case}-{contrast}-comparison.json');assert all(v['coreSemanticEqual'] and v['fullSemanticRequestEqual'] for v in c['checked']);checks+=len(c['checked'])
  for side in ['original','reference','coordinate']:
   stem=directory/f'{rep}-{case}-{side}';p=stem.with_suffix('.json');raw=load(p);validate_sample(load(stem.with_suffix('.process.json')),raw,case,stem.with_suffix('.log').read_text());phases=metrics.validate_lifecycle(raw);window=metrics.sample(p);samples=raw['samples'];hot=[v for v in samples if v['measured']];n=len(hot);history=raw['history'];times=sorted(v['settled_us']/1000 for v in hot);first=[v['first_consumed_publication_us']/1000 for v in hot if v['first_consumed_publication_us'] is not None];closed=sum(v['logical'] for v in raw['checkpoint_footprint'] if v['path'].endswith('/conversation.sqlite'));assert closed>=empty[side]
   rows.append({'case':case,'rep':rep,'side':side,'history':history,'measured':n,'p50_ms':statistics.median(times),'p95_ms':times[math.ceil(.95*n)-1],'first_consumed_ms':statistics.median(first) if first else None,'cpu_ms_per_turn':window['turn_cpu_ms_per_turn'],'process_write_kib_per_turn':window['turn_write_mib_per_turn']*1024,'process_write_mib_through_close':metrics.delta(phases['before_initialization'],phases['after_final_writer_close'],'write_bytes')/2**20,'max_sampled_hot_pss_mib':max(metrics.counters(v)['pss_kib'] for v in hot)/1024,'closed_main_kib_above_empty':(closed-empty[side])/1024,'hot_notification_records':samples[-1]['notification_records']-(samples[history-1]['notification_records'] if history else 0),'final_journal_through':raw['late_snapshot']['checkpoint']['read_cut']['source_cut']['read']['journal'],'canonical_records_total':len(raw['canonical']),'requests_total':raw['requests']})
assert len(rows)==48
keys=['p50_ms','p95_ms','first_consumed_ms','cpu_ms_per_turn','process_write_kib_per_turn','process_write_mib_through_close','max_sampled_hot_pss_mib','closed_main_kib_above_empty']
report={'scope':'48 actual products; three pairwise contrasts reuse the same coordinate/reference runs. Four independent runs per product/case, not three independent experiments. CPU includes the conformance driver. Semantic comparison count includes repeated contrasts, not distinct provider requests. Per-run P50/P95 retained; no pooled pseudo-sample or statistical-significance claim.','semantic_contrast_checks':checks,'empty_main_bytes':empty,'samples':rows,'contrasts':{}}
for contrast,(a,b) in {'storage':('reference','coordinate'),'combined':('original','coordinate'),'reference':('original','reference')}.items():
 groups={}
 for case in ['short-small','short-large','large','stream']:
  group={s:{k:{'median':statistics.median(vs),'range':[min(vs),max(vs)]} for k in keys if (vs:=[v[k] for v in rows if v['side']==s and v['case']==case and v[k] is not None])} for s in [a,b]};paired={}
  for k in keys:
   changes=[]
   for rep in range(4):
    x,y=[next(v[k] for v in rows if v['side']==s and v['case']==case and v['rep']==rep) for s in [a,b]]
    if x and y is not None:changes.append((y-x)/x*100)
   if changes:paired[k]={'values':changes,'median':statistics.median(changes)}
  group['paired_percent_changes']=paired;groups[case]=group
 report['contrasts'][contrast]={'before':a,'after':b,'summary':groups}
(root/'threeway-summary.json').write_text(json.dumps(report,indent=2)+'\n')
with (root/'threeway-per-run.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0],lineterminator='\n');w.writeheader();w.writerows(rows)
for c,v in report['contrasts'].items():
 print(c)
 for case,g in v['summary'].items():print(case,{k:round(x['median'],3) for k,x in g['paired_percent_changes'].items()})
