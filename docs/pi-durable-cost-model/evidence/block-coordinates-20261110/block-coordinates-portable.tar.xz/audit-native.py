"""Authenticate native products and keep PSS, file residency and I/O distinct."""
from pathlib import Path
import hashlib
import importlib
import json
import sqlite3
import statistics
import sys

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0, str(repo / 'benchmarks/runtime'))
metrics = importlib.import_module('summarize-http')
commands = json.loads((root / 'native-commands.json').read_text())
assert len(commands) == 4
rows = []
for command in commands:
    directory = Path(command['command'][command['command'].index('--output') + 1])
    completed = json.loads((directory / 'completed.json').read_text())
    assert completed['accepted'] and completed['requests'] == 1283 and command['exit'] == 0
    phases = {point['phase']: point for point in json.loads((directory / 'phases.json').read_text())}
    active = json.loads((directory / 'active-4.json').read_text())
    all_turns = [turn for row in active['rows'] for turn in row['turns']]
    observed = [turn for row in active['rows'] if not row['held'] for turn in row['turns']]
    assert len(all_turns) == 256
    before, after = active['before'], active['after']
    io = lambda point: {key: int(value) for line in point['io'].splitlines() for key, value in [line.split(':')]}
    times = sorted(turn['settled_us'] / 1000 for turn in observed)
    first = min(turn['began_monotonic_ns'] for turn in all_turns)
    host = json.loads((root / (directory.name + '-host.json')).read_text())
    overlaps = [point for point in host if first <= point['monotonic_ns'] <= phases['active_finished_4']['monotonic_ns'] and point['compiler_pids']]
    native = json.loads((directory / 'native-closed.json').read_text())
    assert len(native) == 128
    for backup in native:
        index = backup['session_index']
        path = directory / 'native-snapshots' / f'{index:04}.sqlite'
        assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == backup['consistent_backup_sha256']
        with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as connection:
            assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
            assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
            assert connection.execute('SELECT schema_version FROM rustx_store WHERE id=1').fetchone()[0] == (105 if command['side']=='before' else 106)
            messages = [json.loads(value) for value, in connection.execute('SELECT message_json FROM message_ledger ORDER BY position')]
        assert len(messages) == backup['messages']
        users = [message for message in messages if message['role'] == 'user']
        answers = [message for message in messages if message['role'] == 'assistant']
        expected = completed['turn_counts'][str(index)]
        assert len(users) == expected and len(answers) == expected - int(index == 0)
        for turn, user in enumerate(users):
            assert user['content'] == [{'type': 'text', 'text': f'capacity turn session={index:04} turn={turn:04}'}]
        for turn, answer in enumerate(answers):
            text = 'S' * 32768 if index == 127 and turn == len(answers) - 1 else 'capacity response'
            assert answer['content'] == [{'type': 'text', 'text': text}]
    row = {key: command[key] for key in ['family', 'side', 'binary_sha256', 'fixture_sha256']}
    row.update(directory=directory.name, cpu_ms_per_turn=metrics.delta({'process': before}, {'process': after}, 'cpu_ms') / 256,
               write_kib_per_turn=(io(after)['write_bytes'] - io(before)['write_bytes']) / 1024 / 256,
               rchar_kib_per_turn=(io(after)['rchar'] - io(before)['rchar']) / 1024 / 256,
               reads_per_turn=(io(after)['syscr'] - io(before)['syscr']) / 256,
               p50_ms=statistics.median(times), p95_ms=times[int(.95 * len(times))],
               active_compiler_samples=overlaps, verified_backups=len(native), requests=completed['requests'])
    for name in ['empty_server', 'all_subscribed_empty', 'seeded_history_8', 'active_finished_4', 'all_unloaded']:
        point = phases[name]
        row[name] = {'anon_pss_mib': metrics.counters(point)['anon_pss_kib'] / 1024,
                     'retained_files': point['retained_files'], 'notifications': point['notifications']}
    rows.append(row)
paired = {}
for family in ['fixed', 'rotating']:
    a, b = [next(row for row in rows if row['family'] == family and row['side'] == side) for side in ['before', 'after']]
    paired[family] = {key: (b[key] - a[key]) / a[key] * 100 for key in ['cpu_ms_per_turn', 'write_kib_per_turn', 'rchar_kib_per_turn', 'reads_per_turn', 'p50_ms', 'p95_ms']}
report = {'scope': 'One supplementary pair per fixed/rotating pattern. 128x8 seed and 256 active turns. Native PID CPU/I/O only; includes native-idle retirement reads. Terminal delivery defines turn latency. All native backup hashes, exact content/order/counts and integrity/FKs independently checked. File residency is an endpoint, not cumulative output. No significance or PSS equivalence claim from two samples per side.', 'rows': rows, 'paired_percent': paired}
(root / 'native-summary.json').write_text(json.dumps(report, indent=2) + '\n')
for row in rows:
    endpoint = row['seeded_history_8']
    print(row['directory'], 'PSS', round(endpoint['anon_pss_mib'], 2), 'WAL MiB', round(endpoint['retained_files']['wal']['logical_bytes'] / 2**20, 2), 'CPU', round(row['cpu_ms_per_turn'], 2), 'writeKiB', round(row['write_kib_per_turn'], 2), 'compiler active samples', len(row['active_compiler_samples']))
print(json.dumps(paired, indent=2))
