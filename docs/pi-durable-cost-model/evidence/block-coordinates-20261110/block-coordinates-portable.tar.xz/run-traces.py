"""Balanced structural products; no elapsed-time claim from tracing."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0, str(root))
from trace_products import trace_product

binaries = {'before': Path('/home/capi/.cache/rustx-pr485-cut-owners-20261110/reference-build/conformance'),
            'after': root / 'build/conformance'}
records = []
for index, history in enumerate([8, 32, 64, 96]):
    for side in (['before', 'after'] if index % 2 == 0 else ['after', 'before']):
        directory = root / 'traced' / side / f'h{history}'
        binary = binaries[side]
        identity = {'side': side, 'history': history, 'binary': str(binary),
                    'sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
                    'begin_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    'affinity': sorted(os.sched_getaffinity(0)), 'directory': str(directory)}
        try:
            trace_product(binary, 'short-large' if history == 64 else 'short-small',
                          None if history in [8, 64] else history, directory,
                          repo / 'test-support/fake-provider')
            identity['accepted'] = True
        finally:
            identity['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            records.append(identity)
            (root / 'trace-products.json').write_text(json.dumps(records, indent=2) + '\n')
        subprocess.run([sys.executable, str(root / 'replay_wal.py'), str(directory)], check=True, cwd=repo)
for side in ['before', 'after']:
    products = [str(root / 'traced' / side / f'h{history}') for history in [8, 32, 64, 96]]
    with (root / f'{"baseline" if side == "before" else "candidate"}-write-ledger.json').open('w') as output:
        subprocess.run([sys.executable, str(root / 'ledger_summary.py'), *products], check=True, cwd=repo, stdout=output)
