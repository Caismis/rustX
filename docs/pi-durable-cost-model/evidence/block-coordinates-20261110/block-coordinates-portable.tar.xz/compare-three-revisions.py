"""Four pairwise-balanced orders; 48 actual products, not 64 independent runs."""
from pathlib import Path
import hashlib,json,os,subprocess,sys
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');sys.path.insert(0,str(repo/'benchmarks/runtime'))
from controller import run,TEST
binaries={'original':Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/conformance'),'reference':Path('/home/capi/.cache/rustx-pr485-cut-owners-20261110/reference-build/conformance'),'coordinate':root/'build/conformance'}
orders=[['original','reference','coordinate'],['coordinate','reference','original'],['original','coordinate','reference'],['reference','coordinate','original']]
out=root/'ordinary-threeway';out.mkdir(exist_ok=False)
identity={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'orders':orders,'executables':{k:{'path':str(v),'sha256':hashlib.file_digest(v.open('rb'),'sha256').hexdigest()} for k,v in binaries.items()},'scope':'48 actual ordinary products: four independent runs per product/scenario, pairwise-balanced order. Coordinate products are shared between the isolated-storage and combined contrasts. Do not count them as two independent experiments.'};assert len({x['sha256'] for x in identity['executables'].values()})==3
(out/'manifest.json').write_text(json.dumps(identity,indent=2)+'\n')
for pair in range(4):
 for case in ['short-small','short-large','large','stream']:
  for name in orders[pair]:
   stem=out/f'{pair}-{case}-{name}'
   env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])};env.update(RUSTX_BENCH_OBSERVER_MODE='live-subscriber',RUSTX_BENCH_CASE=case,RUSTX_BENCH_OUTPUT=str(stem.with_suffix('.json')))
   result=run([str(binaries[name]),TEST,'--exact','--ignored','--nocapture'],stem,case,env,repo/'test-support/fake-provider');print(pair,case,name,result['accepted'],flush=True);assert result['accepted']
  for contrast,before in [('storage','reference'),('combined','original'),('reference','original')]:
   after='reference' if contrast=='reference' else 'coordinate'
   subprocess.run(['node',str(repo/'benchmarks/runtime/compare-http.mjs'),str(out/f'{pair}-{case}-{before}.json'),str(out/f'{pair}-{case}-{after}.json'),str(out/f'{pair}-{case}-{contrast}-comparison.json')],cwd=repo,check=True,capture_output=True)
