from pathlib import Path
import hashlib,json,os,subprocess
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
out=root/'composite-correctness';out.mkdir(exist_ok=False)
env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-main-integration-target','CARGO_BUILD_JOBS':'8'}
identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'commands':[]}
patch=subprocess.check_output(['git','diff','--binary'],cwd=repo);(out/'source.patch').write_bytes(patch);identity['patch_sha256']=hashlib.sha256(patch).hexdigest()
def run(name,command):
 with (out/(name+'.stdout')).open('x') as stdout,(out/(name+'.stderr')).open('x') as stderr:
  result=subprocess.run(command,cwd=repo,env=env,stdout=stdout,stderr=stderr)
 identity['commands'].append({'name':name,'command':command,'exit':result.returncode});(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(name,result.returncode,flush=True);result.check_returncode()
run('fmt',['cargo','fmt','--all','--','--check'])
run('unit-build',['cargo','test','--locked','--all-features','--lib','--no-run','--message-format=json'])
rows=[json.loads(x) for x in (out/'unit-build.stdout').read_text().splitlines() if x.startswith('{')]
a=next(x for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('src_path')==str(repo/'src/lib.rs') and x.get('executable'));assert not a['fresh'];binary=Path(a['executable']);identity['unit_binary']={'path':str(binary),'sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()}
for group in ['observation_source_read_tests','publication_header::tests','message_keyed_block_layout']:
 run(group,[str(binary),group,'--test-threads=8'])
run('debug-bins',['cargo','build','--locked','--all-features','--bins','--message-format=json'])
for group in ['observation::','runtime_client::','durable::sqlite::','agent::execution::','app_server::schema::','app_server::wire::']:
 run(group.replace('::','-').strip('-'),[str(binary),group,'--test-threads=8'])
run('clippy',['cargo','clippy','--locked','--all-targets','--all-features','--','-D','warnings'])
assert subprocess.check_output(['git','diff','--binary'],cwd=repo)==patch
identity['verified_unchanged_patch']=True;(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
