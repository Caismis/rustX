from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
command=[sys.executable,str(root/'compare-three-revisions.py')];host=[]
with (root/'threeway.log').open('x') as log:
 process=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 while process.poll() is None:
  host.append({'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'compiler_pids':subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True).stdout.split()});time.sleep(.5)
(root/'threeway-host.json').write_text(json.dumps(host,indent=2)+'\n');(root/'threeway-command.json').write_text(json.dumps({'command':command,'exit':process.returncode,'compiler_overlap_samples':sum(bool(x['compiler_pids']) for x in host)},indent=2)+'\n');assert process.returncode==0
