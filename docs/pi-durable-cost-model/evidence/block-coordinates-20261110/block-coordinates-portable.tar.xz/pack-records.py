from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');packed=r/'packed';packed.mkdir(exist_ok=True)
patterns=['*.py','*.json','*.jsonl','*.log','*.patch','*.csv','ordinary-threeway/*','functional/*','build/*.json','build/*.jsonl','build/*.stdout','build/*.stderr','composite-correctness/*','traced/*/*/*.json','traced/*/*/*.log','traced/*/*/*.stdout','traced/*/*/*.strace']
for family in ['memory-*','native-*','deep-*']:
 patterns += [family+'/'+suffix for suffix in ['*.json','*.log','*.stdout','*.stderr','native-snapshots/0000.sqlite','native-snapshots/0127.sqlite','native-snapshots/0015.sqlite']]
full=patterns+['memory-*/native-snapshots/*.sqlite','native-*/native-snapshots/*.sqlite','deep-*/native-snapshots/*.sqlite']
index={'root':str(r),'scope':'Both archives retain every raw measurement, per-turn/process counter, provider request, negative/failed result, build identity, script, verification record and backup hash. Full archive additionally retains every consistent native backup DB. Portable archive includes first/last representative native DBs; it does not include every DB image. Product ELF/dependency trees and private/live runtime/workspace roots are excluded. Originals remain in this root.','archives':{}}
(r/'archive-scope.json').write_text(json.dumps(index,indent=2)+'\n')
for name,selected in [('full',full),('portable',patterns)]:
 out=packed/f'block-coordinates-{name}.tar.xz';command=[sys.executable,str(repo/'benchmarks/runtime/pack-evidence.py'),'--root',str(r),'--output',str(out),*selected]
 subprocess.run(command,cwd=repo,check=True)
 manifest=out.with_suffix('.manifest.json');index['archives'][name]={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'manifest':str(manifest),'files':len(json.loads(manifest.read_text())),'verified':True}
 (r/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
