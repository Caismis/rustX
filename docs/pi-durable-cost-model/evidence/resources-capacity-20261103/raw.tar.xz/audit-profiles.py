"""Audit raw profile denominators; symbol classifications are descriptive, never exclusive phase timing."""
import collections,hashlib,json,re,struct
from pathlib import Path
r=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cpu=[];heap=[]
for rel in ['capacity-cpu-long','refined/capacity-cpu-final']:
 d=r/rel;p=d/'active.cpu.0';body=p.read_bytes();header=struct.unpack_from('<5Q',body);assert header==(0,3,0,4000,0);i=40;total=records=0
 while True:
  count,depth=struct.unpack_from('<2Q',body,i);i+=16;assert depth<4096;pcs=struct.unpack_from('<'+'Q'*depth,body,i);i+=8*depth
  if count==0 and depth==1 and pcs[0]==0:break
  assert count>0;total+=count;records+=1
 assert b'r-xp' in body[i:]
 stacks=[]
 for line in (d/'cpu-stacks.txt').read_text().splitlines():
  if line.strip():stack,n=line.rsplit(' ',1);stacks.append((stack,int(n)))
 assert sum(n for _,n in stacks)==total
 assert int(re.search(r'Total: (\d+) samples',(d/'cpu-flat.txt').read_text())[1])==total
 def leaf_kind(stack):
  leaf=stack.rsplit(';',1)[-1]
  if re.search(r'(?:sqlite3|sqlite3[A-Z])',leaf):return 'sqlite_leaf'
  if re.search(r'memcpy|memmove|memcmp|memset|bcmp',leaf):return 'copy_compare_leaf'
  if re.search(r'malloc|calloc|realloc|(?:^|_)free|alloc::alloc',leaf):return 'allocation_leaf'
  if 'serde' in leaf:return 'serde_leaf'
  return 'other_leaf'
 leaves=collections.Counter()
 for stack,n in stacks:leaves[leaf_kind(stack)]+=n
 inclusive={name:sum(n for stack,n in stacks if pattern in stack) for name,pattern in [('sqlite3_any','sqlite3'),('request_source_any','observation_request'),('statistics_any','observation_statistics'),('execution_any','observation_execution'),('app_server_any','rustx::app_server')]}
 cpu.append({'directory':rel,'profile_sha256':sha(p),'period_us':header[3],'raw_samples':total,'raw_records':records,'collapsed_samples':sum(n for _,n in stacks),'exclusive_leaf_counts':dict(leaves),'overlapping_stack_presence':inclusive,'scope':'Leaf partitions sum to raw samples. Stack-presence groups overlap and can include generic type names; no exclusive operation/phase cost. Optimized/inlined/ICF symbols may alias. 250Hz diagnostic only; provider and driver excluded.'})
for p in sorted((r/'capacity-heap-bounded').glob('*.heap')):
 lines=p.read_text().splitlines();m=re.match(r'heap profile:\s+(\d+):\s+(\d+)\s+\[(\d+):\s+(\d+)\]',lines[0]);assert m;global_counts=list(map(int,m.groups()));represented=[0]*4;rows=0
 for line in lines[1:]:
  m=re.match(r'\s*(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\]\s+@',line)
  if m:
   rows+=1;represented=[x+int(y) for x,y in zip(represented,m.groups())]
 assert all(x<=y for x,y in zip(represented,global_counts))
 heap.append({'file':p.name,'sha256':sha(p),'bytes':p.stat().st_size,'rows':rows,'global_header':dict(zip(['live_objects','live_bytes','allocated_objects','allocated_bytes'],global_counts)),'serialized_buckets':dict(zip(['live_objects','live_bytes','allocated_objects','allocated_bytes'],represented)),'live_byte_coverage':represented[1]/global_counts[1],'unrepresented_live_bytes':global_counts[1]-represented[1]})
result={'accepted':True,'cpu':cpu,'heap':heap,'heap_limit':'Installed gperftools 2.15-3build1 caps heap profile serialization at 1MiB. Global header and serialized buckets differ; pprof attribution covers only serialized rows. Heap uses tcmalloc replacement in a bounded 8-session diagnostic, not ordinary allocator memory/latency or exact 128-session attribution.'}
(r/'profile-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'cpu_samples':[p['raw_samples'] for p in cpu],'heap_products':len(heap)}))
