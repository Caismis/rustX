"""Serial ordinary resource products, followed by an explicitly separate CPU diagnostic."""
import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');before=r/'before-app-server/rustx';after=r/'candidate-build/rustx';rows=[]
assert json.loads((r/'candidate-build/identity.json').read_text())['verified']
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
def run(label,cmd):
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(label+'.stdout')).open('x') as so,(r/(label+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'resource-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,done.returncode,flush=True);assert done.returncode==0
def capacity(label,binary,sessions,history,widths,rounds,profile=False):
 cmd=[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(binary),'--output',str(r/label),'--sessions',str(sessions),'--history',str(history),'--widths',*map(str,widths),'--rounds',str(rounds)]
 if profile:cmd+=['--cpu-profiler','/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0']
 run(label,cmd)
capacity('capacity-multiowner-smoke-refined',before,34,0,[1,4,8],2)
capacity('capacity-profiler-smoke',before,2,0,[1,2],2,True)
run('commit-capacity-fixtures',['git','add','benchmarks/runtime/app-server-capacity.py','benchmarks/runtime/app-server-capacity-provider.py'])
run('commit-capacity-fixtures-record',['git','commit','-m','Measure native App Server residency and active capacity over WebSocket'])
capacity('capacity-before-refined',before,128,8,[1,4,8],16)
capacity('capacity-after',after,128,8,[1,4,8],16)
run('ordinary-pairs',[sys.executable,str(r/'run-pairs.py')])
for script in ['columns-complete.py','run-wal-rust.py']:
 for label,binary in [('baseline',Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/candidate-build/conformance')),('complete',r/'candidate-build/conformance')]:
  run(script.removesuffix('.py')+'-'+label,[sys.executable,str(r/script),'--binary',str(binary),'--label',label])
  if script=='run-wal-rust.py':run('wal-analysis-'+label,[sys.executable,str(r/'analyze-wal.py'),'--label',label])
capacity('capacity-cpu-long',after,128,8,[8],64,True)
(r/'resource-completed.json').write_text(json.dumps({'accepted':True,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
