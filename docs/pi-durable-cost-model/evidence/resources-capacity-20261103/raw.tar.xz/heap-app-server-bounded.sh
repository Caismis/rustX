#!/bin/sh
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4.5.16
export HEAPPROFILE=/home/capi/.cache/rustx-pr485-resources-20261103/capacity-heap-bounded/heap
export HEAPPROFILESIGNAL=12
export HEAP_PROFILE_ALLOCATION_INTERVAL=1152921504606846976
export HEAP_PROFILE_INUSE_INTERVAL=1152921504606846976
exec /home/capi/.cache/rustx-pr485-resources-20261103/before-app-server/rustx "$@"
