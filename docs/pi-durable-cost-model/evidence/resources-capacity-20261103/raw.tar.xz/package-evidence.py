"""Package regular evidence only, excluding executables, live runtime copies and duplicated provider stdout."""
import hashlib,json,tarfile,time,shutil
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=repo/'docs/pi-durable-cost-model/evidence/resources-capacity-20261103';dest=out/'raw.tar.xz';assert not dest.exists()
for name in ['package-uris.txt','SHA256SUMS']:
 p=Path('/home/capi/.cache/rustx-pr485-profilers')/name
 if p.exists():t=r/'profiler-package-provenance'/name;t.parent.mkdir(exist_ok=True);shutil.copy2(p,t)
files=[];omitted={}
for p in sorted(r.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(r);reason=None
 if p.name=='archive-selection.json':continue
 if rel.parts[0]!='fixture-sources' and any(v in {'runtime','workspaces','__pycache__','.git','.venv'} for v in rel.parts):reason='live-runtime-or-cache-copy'
 elif p.name in {'conformance','rustx','librustx.rlib','WORK-IN-PROGRESS.txt'} or p.suffix in {'.rlib','.pyc'}:reason='binary-or-working-note'
 elif p.name=='provider.stdout' or p.name.endswith('.provider.stdout'):reason='duplicate-provider-log-request-bodies-retained-in-raw-product-or-report'
 elif p.name.startswith('.env'):reason='environment'
 if reason:omitted[reason]=omitted.get(reason,0)+1
 else:files.append((p,str(rel)))
selection={'included_regular_files':len(files)+1,'omitted_counts':omitted,'scope':'Closed native snapshots and WAL consistent backups retained; live runtime/workspace copies omitted. Provider stdout duplicates requests already retained in raw products/reports and is omitted. Executables/rlibs/environment files excluded; their recorded identities retained. Failed setup outputs and source variants included.'}
(r/'archive-selection.json').write_text(json.dumps(selection,indent=2)+'\n');files.append((r/'archive-selection.json','archive-selection.json'));files.sort(key=lambda v:v[1]);members=[]
with tarfile.open(dest,'w:xz',preset=3) as tar:
 for p,name in files:
  body=p.read_bytes();members.append({'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()});info=tar.gettarinfo(str(p),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0;tar.addfile(info,__import__('io').BytesIO(body))
b=dest.read_bytes();manifest={'archive':{'file':'raw.tar.xz','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},'members':members,'selection':selection,'scope':'Original raw product paths are labels, not replay dependencies. Regular files only. No executable bytes included.'};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'members':len(members),'bytes':len(b),'sha256':manifest['archive']['sha256']}))
