import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');records=[]
for label,cmd in [
 ('capacity-before',[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(r/'before-app-server/rustx'),'--output',str(r/'capacity-before'),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16']),
 ('candidate-build',[sys.executable,str(r/'build.py'),'candidate',str(repo)])]:
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(label+'.stdout')).open('x') as so,(r/(label+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
 row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);(r/'capacity-build-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,done.returncode,flush=True);assert done.returncode==0
