"""Read existing immutable formal records only; no product execution."""
import hashlib,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;old=Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/final-triads')
def mem(point):
 raw=point['process']['smaps_rollup'];fields=dict(v.split(':',1) for v in raw.splitlines() if ':' in v)
 return {k:int(fields[k].split()[0])/1024 for k in ['Rss','Pss','Pss_Anon']}
products=[];cells=[]
for mode in ['no-live-subscriber','live-subscriber']:
 for case in ['short-small','short-large']:
  for engine in ['after','pi']:
   local=[]
   for pair in range(4):
    path=old/mode/f'{pair}-{case}-{engine}.json';data=json.loads(path.read_text());series=[{'phase':p['phase'],**mem(p)} for p in data['lifecycle']]
    turns=[{'phase':'warm' if p['measured'] else 'seed','turn':p['turn'],**mem(p)} for p in data['samples']]
    row={'file':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'mode':mode,'case':case,'engine':engine,'pair':pair,'lifecycle':series,'turns':turns,'sampled_anon_peak':max(series+turns,key=lambda v:v['Pss_Anon'])};products.append(row);local.append(row)
   cells.append({'mode':mode,'case':case,'engine':engine,
    'lifecycle_medians':{p['phase']:{k:statistics.median(v['lifecycle'][i][k] for v in local) for k in ['Rss','Pss','Pss_Anon']} for i,p in enumerate(local[0]['lifecycle'])},
    'peak_phases':[v['sampled_anon_peak']['phase'] for v in local],
    'sampled_anon_peak_mib':statistics.median(v['sampled_anon_peak']['Pss_Anon'] for v in local),
    'warm_sampled_anon_peak_mib':statistics.median(max(p['Pss_Anon'] for p in v['turns'] if p['phase']=='warm') for v in local)})
(r/'prior-memory-phases.json').write_text(json.dumps({'accepted':True,'scope':'Existing final fceaf/Pi records, four products per cell. Endpoint samples do not prove continuous peaks or retained object ownership. They include benchmark oracles; no new Pi execution or cross-batch ratio.','products':products,'cells':cells},indent=2)+'\n')
print(json.dumps({'accepted':True,'products':len(products)}))
