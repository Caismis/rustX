import json
from pathlib import Path
r=Path(__file__).resolve().parent;out=[]
load=lambda p:json.loads((r/p).read_text())
def line(s=''):out.append(s)
def table(headers,rows):
 line('| '+' | '.join(headers)+' |');line('| '+' | '.join(['---']*len(headers))+' |')
 for row in rows:line('| '+' | '.join(map(str,row))+' |')
 line()
line('# Resource and capacity values');line();line('All changes are descriptive. Four paired products per ordinary cell; one process per capacity scenario. Negative change means lower. The initial two-table trial and final one-table trial are separate cohorts.');line()
for title,path in [('Initial two-table trial, schema 92','storage-audit.json'),('Final model-only layout, schema 93','refined/storage-audit.json')]:
 a=load(path);line('## '+title);line()
 for key,title2 in [('absolute','Absolute ordinary product medians'),('paired_change_percent','Paired percentage changes')]:
  line('### '+title2);line()
  if key=='absolute':
   table(['Observer / history','Side','Warm median wall ms','CPU ms/turn','Write KiB/turn','Full-cycle write MiB'],[[f"{c['mode']} / {8 if c['case']=='short-small' else 64}",e,*[f"{c[key][e][k]['median']/scale:.4f}" for k,scale in [('median_measured_turn_ms',1),('turn_cpu_ms_per_turn',1),('turn_write_bytes_per_turn',1024),('through_cleanup_process_write_mib',1)]]] for c in a['cells'] for e in ['before','after']])
  else:
   table(['Observer / history','Metric','Pair 0','Pair 1','Pair 2','Pair 3','Median %'],[[f"{c['mode']} / {8 if c['case']=='short-small' else 64}",k,*[f'{v:+.5f}' for v in c[key][k]['values']],f"{c[key][k]['median']:+.5f}"] for c in a['cells'] for k in ['median_measured_turn_ms','mean_turn_ms','turn_cpu_ms_per_turn','turn_write_bytes_per_turn','through_cleanup_process_write_bytes']])
 line('### Single diagnostic products');line();table(['History','Side','Logical column bytes','WAL frames','Write commits','Consistent image growth bytes','Used-page growth bytes'],[[8 if s['case']=='short-small' else 64,s['engine'],s['logical_bytes'],s['wal']['wal_frames'],s['wal']['wal_write_commits'],s['net_main_image_bytes'],s['net_used_page_bytes']] for s in a['storage']])
 line('The complete owner breakdown, all 160 transaction page counts, and before/after consistent images are in the raw audit. Owner attribution uses endpoint `dbstat`, with intermediate page reuse not excluded.');line()
a=load('capacity-audit.json');line('## Native App Server scenarios');line()
for p in a['products']:
 line('### '+p['directory']);line();line(f"Sessions {p['sessions']}, seed turns per session {p['history']}, requests {p['requests']}, schema {p['schema']}, diagnostic {p['diagnostic']}.");line()
 table(['Phase','Anon PSS MiB','RSS MiB','Loaded/loading/unloading','Active','Attachments'],[[x['phase'],f"{x['counters']['anon_pss_mib']:.4f}",f"{x['counters']['rss_mib']:.4f}",f"{x['loaded']}/{x['loading']}/{x['unloading']}",x['active'],x['attachments']] for x in p['points']])
 table(['Width','Nonheld n','Accepted median ms','Settled median ms','Settled P95 ms','Settled P99 ms','Burst service turns/s','CPU ms/all turns','Write KiB/all turns'],[[x['width'],x['free_turns'],*[f'{v:.4f}' for v in [x['latency']['accepted_us']['median_ms'],x['latency']['settled_us']['median_ms'],x['latency']['settled_us']['p95_ms'],x['latency']['settled_us']['p99_ms'],x['burst_completed_per_service_second'],x['server_cpu_ms_per_all_turns'],x['server_write_bytes_per_all_turns']/1024]]] for x in p['activity']])
 native=load(p['directory']+'/native-closed.json');line(f"Consistent used-page bytes: {sum(v['used_page_bytes'] for v in p['native_proofs'])}; free pages: {sum(v['free_pages'] for v in native)}; post-exit main bytes: {sum(v['post_process_exit_files']['main'] for v in native)}; WAL bytes: {sum(v['post_process_exit_files']['-wal'] for v in native)}; SHM bytes: {sum(v['post_process_exit_files']['-shm'] for v in native)}; cancel-to-settled {p['cancel_to_settled_us']/1000:.4f} ms.");line()
 if p['unload_sampling_note']:line(p['unload_sampling_note']);line()
line('Latency/burst service windows exclude the deliberately held first round. CPU/write windows include all rounds and driver orchestration gaps, although the counters belong only to the native process. Burst service throughput excludes gate setup gaps and is not sustained service capacity. P99 has only 15/60/120 ordinary observations at widths 1/4/8. Raw per-turn values remain in `active-*.json` and the audit.');line()
p=load('profile-audit.json');line('## Native CPU and bounded heap diagnostics');line()
for c in p['cpu']:
 line(c['directory']+f": {c['raw_samples']} raw / {c['collapsed_samples']} collapsed samples, period {c['period_us']} us.");line();table(['Exclusive leaf class','Samples','Percent'],[[k,v,f"{100*v/c['raw_samples']:.3f}"] for k,v in c['exclusive_leaf_counts'].items()]);table(['Overlapping stack presence','Samples'],list(c['overlapping_stack_presence'].items()))
table(['Heap file','Global live bytes','Serialized live bytes','Coverage %','Missing live bytes','Global allocated bytes','Serialized allocated bytes'],[[h['file'],h['global_header']['live_bytes'],h['serialized_buckets']['live_bytes'],f"{100*h['live_byte_coverage']:.4f}",h['unrepresented_live_bytes'],h['global_header']['allocated_bytes'],h['serialized_buckets']['allocated_bytes']] for h in p['heap']]);line(p['heap_limit']);line()
m=load('prior-memory-phases.json');line('## Previous archived phase memory, no new Pi execution');line();table(['Observer','History','Engine','Warm sampled anon maximum MiB','Whole sampled anon maximum MiB','Peak phases, four products'],[[c['mode'],8 if c['case']=='short-small' else 64,c['engine'],f"{c['warm_sampled_anon_peak_mib']:.4f}",f"{c['sampled_anon_peak_mib']:.4f}",', '.join(c['peak_phases'])] for c in m['cells']]);line('Per-phase medians and all raw counter projections are archived, linked by SHA to the previous immutable archive. Endpoints cannot prove continuous peaks.');line()
(r/'resource-tables.md').write_text('\n'.join(out)+'\n')
