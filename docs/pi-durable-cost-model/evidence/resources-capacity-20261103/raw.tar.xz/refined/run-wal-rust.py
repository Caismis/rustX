"""Synchronous read-only wal diagnostics; ordinary Rust binaries only."""
import sys, os, json, threading, socket, sqlite3, subprocess, time, hashlib, tempfile, argparse, traceback
from pathlib import Path
from fixture_binding import CPU_AFFINITY, affinity_snapshot, validate_affinity
repo = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
out = Path(__file__).resolve().parent
sys.path.insert(0, str(repo/'benchmarks/runtime'))
from controller import run, TEST

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
def snapshot(paths, directory, phase):
    snapshots=[]
    for path in sorted(paths):
     c=sqlite3.connect(f'file:{path}?mode=ro',uri=True);tables=c.execute("SELECT name,sql,rootpage FROM sqlite_schema WHERE type='table'").fetchall();s={'path':path,'tables':tables,'counts':{name:c.execute('SELECT count(*) FROM "'+name.replace('"','""')+'"').fetchone()[0] for name,_,_ in tables},'pages':c.execute('SELECT name,pageno,pagetype,ncell,payload FROM dbstat').fetchall()}
     if any(t[0]=='request_source_nodes' for t in tables):s['source_nodes']=[{'id':i,'metadata_bytes':len(m if isinstance(m,bytes) else m.encode()),'metadata_sha256':hashlib.sha256(m if isinstance(m,bytes) else m.encode()).hexdigest()} for i,m in c.execute('SELECT native_id,metadata FROM request_source_nodes')]
     if any(t[0]=='events' for t in tables):
      image=directory/(phase+'-image.sqlite');dest=sqlite3.connect(image);c.backup(dest);dest.close();s['storage']={'page_count':c.execute('PRAGMA page_count').fetchone()[0],'free_pages':c.execute('PRAGMA freelist_count').fetchone()[0],'page_size':c.execute('PRAGMA page_size').fetchone()[0],'backup_bytes':image.stat().st_size,'backup_sha256':sha(image),'main_bytes':Path(path).stat().st_size,'wal_bytes':Path(path+'-wal').stat().st_size if Path(path+'-wal').exists() else 0}
     c.close()
     if path.endswith('conversation.db') or any(t[0]=='events' for t in tables):snapshots.append(s)
    assert len(snapshots)==1,[s['path'] for s in snapshots]
    (directory/(phase+'-database.json')).write_text(json.dumps(snapshots,indent=2))

parser = argparse.ArgumentParser()
parser.add_argument('--binary', type=Path, required=True)
parser.add_argument('--label', choices=['baseline','complete'], required=True)
args = parser.parse_args()
binary = args.binary.resolve(); label = args.label
build = json.loads((binary.parent/'identity.json').read_text())
assert build['verified'] and sha(binary) == build['sha256']
os.sched_setaffinity(0, CPU_AFFINITY)
validate_affinity(affinity_snapshot())
records_path = out/f'wal-records-{label}.json'
assert not records_path.exists(), 'retain previous attempt; do not overwrite evidence'
original = subprocess.Popen
records = []
for case in ('short-small','short-large'):
    directory = out/f'wal-{label}-{case}-rust'
    directory.mkdir(exist_ok=False)
    sock = Path(tempfile.mkdtemp(prefix='rxwal-'))/'control.sock'
    server = socket.socket(socket.AF_UNIX); server.bind(str(sock)); server.listen(1); server.settimeout(0.25)
    ready = threading.Event(); stopped = threading.Event(); state = {}; phases = []; failures = []
    def serve():
        conn = None
        try:
            while not ready.wait(0.25):
                if stopped.is_set():
                    return
            while not stopped.is_set():
                try:
                    conn, _ = server.accept()
                except socket.timeout:
                    continue
                conn.settimeout(30)
                line = b''
                while not line.endswith(b'\n'):
                    chunk = conn.recv(128)
                    if not chunk:
                        raise RuntimeError('EOF before phase newline')
                    line += chunk
                phase = line.decode().strip()
                phases.append({'phase': phase, 'monotonic_ns': time.monotonic_ns()})
                if phase in ('before_measured_turns','after_turns'):
                    children = Path(f'/proc/{state["pid"]}/task/{state["pid"]}/children').read_text().split()
                    assert len(children) == 1, children
                    pid = children[0]
                    paths = set()
                    for fd in Path(f'/proc/{pid}/fd').iterdir():
                        try:
                            path = os.readlink(fd)
                        except OSError:
                            continue
                        if path.endswith(('.sqlite','.db')) and Path(path).exists():
                            paths.add(path)
                    snapshot(paths, directory, phase)
                conn.sendall(b'K'); conn.close(); conn = None
                if phase == 'after_cleanup':
                    return
        except BaseException:
            failures.append(traceback.format_exc())
        finally:
            if conn is not None:
                conn.close()
    argv = [str(binary), TEST, '--exact','--ignored','--nocapture']
    exec_argv = ['strace','-f','-yy','-s','96','-e','trace=pwrite64,write,writev,sendto,sendmsg,fsync,fdatasync','-o',str(directory/'calls.strace'),'--',*argv]
    def start(command, *a, **kw):
        if command == argv:
            product = original(exec_argv, *a, **kw)
            state['pid'] = product.pid; ready.set()
            return product
        return original(command, *a, **kw)
    before = {'build': build, 'binary_sha256': sha(binary), 'runner_sha256': sha(__file__), 'argv': argv, 'executed_argv': exec_argv, 'affinity': affinity_snapshot(), 'scope': 'Rust-only diagnostic WAL counts. No timing claims. External strace parent, sibling provider; dbstat snapshots at synchronous boundaries. Unmodified production binary. Controller calling-thread pinned; descendants inherit CPU 2,8; no independent child-thread sampling.'}
    validate_affinity(before['affinity']); write(directory/'identity-before.json', before)
    thread = threading.Thread(target=serve, daemon=True); thread.start()
    env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
    env.update(UV_OFFLINE='1', RUSTX_BENCH_CASE=case, RUSTX_BENCH_OBSERVER_MODE='no-live-subscriber', RUSTX_BENCH_OUTPUT=str(directory/'sample.json'), RUSTX_BENCH_PROFILE_SOCKET=str(sock))
    result = {'accepted': False, 'error': 'controller did not return'}
    start_ns = time.monotonic_ns()
    subprocess.Popen = start
    try:
        result = run(argv, directory/'sample', case, env, repo/'test-support/fake-provider')
    except BaseException:
        result['error'] = traceback.format_exc()
        write(directory/'runner-error.json', result)
        raise
    finally:
        subprocess.Popen = original
        stopped.set(); ready.set(); thread.join(5); server.close()
        if thread.is_alive():
            failures.append('phase collector thread did not stop')
        sock.unlink(missing_ok=True); sock.parent.rmdir()
        write(directory/'phases.json', phases)
        after = {'binary_sha256': sha(binary), 'runner_sha256': sha(__file__), 'affinity': affinity_snapshot()}
        write(directory/'identity-after.json', after)
        records.append({'engine': 'rust', 'case': case, 'accepted': result['accepted'], 'error': result.get('error'), 'diagnostic_error': failures, 'start_ns': start_ns, 'end_ns': time.monotonic_ns()})
        write(records_path, records); print(records[-1], flush=True)
    assert not failures, failures
    assert result['accepted'], result.get('error')
    assert after['binary_sha256'] == build['sha256'] and after['runner_sha256'] == before['runner_sha256']
    validate_affinity(after['affinity'])
    assert before['affinity']['topology'] == after['affinity']['topology'] and before['affinity']['online_cpus'] == after['affinity']['online_cpus']
write(out/f'wal-identity-{label}.json', {'rust_sha256': sha(binary), 'rust_source': build['head'], 'scope': 'Four WAL products across both revisions; no CPU profile/control or timing claims.'})
