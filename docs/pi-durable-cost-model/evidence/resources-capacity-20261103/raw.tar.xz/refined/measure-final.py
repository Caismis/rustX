"""One targeted refinement; initial adverse batch stays separate."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;parent=r.parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');before=parent/'before-app-server/rustx';after=r/'candidate-build/rustx';rows=[]
identity=json.loads((r/'candidate-build/identity.json').read_text());assert identity['verified'];assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
rows_build=[json.loads(v) for v in (r/'candidate-build/build.stdout').read_text().splitlines() if v.startswith('{')];main=next(v for v in rows_build if v.get('reason')=='compiler-artifact' and v['target']['kind']==['bin'] and v['target']['name']=='rustx' and v.get('executable'));sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();assert sha(main['executable'])==sha(after)
(r/'candidate-build/app-server-identity.json').write_text(json.dumps({'head':identity['head'],'production_tree':identity['production_tree'],'binary':str(after),'sha256':sha(after),'artifact':main},indent=2)+'\n')
def run(label,cmd):
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(label+'.stdout')).open('x') as so,(r/(label+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'measurement-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,done.returncode,flush=True);assert done.returncode==0
def capacity(label,binary,sessions,history,widths,rounds,profile=False):
 cmd=[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(binary),'--output',str(r/label),'--sessions',str(sessions),'--history',str(history),'--widths',*map(str,widths),'--rounds',str(rounds)]
 if profile:cmd+=['--cpu-profiler','/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0']
 run(label,cmd)
capacity('capacity-final',after,128,8,[1,4,8],16)
capacity('history-512-before',before,2,512,[1,2],16)
capacity('history-512-final',after,2,512,[1,2],16)
run('ordinary-pairs',[sys.executable,str(r/'run-pairs.py')])
for script in ['columns-complete.py','run-wal-rust.py']:
 for label,binary in [('baseline',Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/candidate-build/conformance')),('complete',r/'candidate-build/conformance')]:
  run(script.removesuffix('.py')+'-'+label,[sys.executable,str(r/script),'--binary',str(binary),'--label',label])
  if script=='run-wal-rust.py':run('wal-analysis-'+label,[sys.executable,str(r/'analyze-wal.py'),'--label',label])
capacity('capacity-cpu-final',after,128,8,[8],64,True)
run('raw-audit',[sys.executable,str(r/'audit-storage-trial.py'),'--schema','93'])
(r/'completed.json').write_text(json.dumps({'accepted':True,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
