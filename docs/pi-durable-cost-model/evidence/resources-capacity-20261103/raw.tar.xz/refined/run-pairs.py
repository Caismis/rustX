"""Ordinary before/after product pairs; Pi/DeepSeek are never executed."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run,TEST
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n');now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
os.sched_setaffinity(0,[2,8]);assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
out=r/'ordinary-pairs';out.mkdir(exist_ok=False)
binaries={'before':Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/candidate-build/conformance'),'after':r/'candidate-build/conformance'}
builds={k:json.loads((p.parent/'identity.json').read_text()) for k,p in binaries.items()};assert all(v['verified'] and sha(binaries[k])==v['sha256'] for k,v in builds.items())
names=subprocess.check_output(['git','ls-files','--','benchmarks/runtime','test-support/fake-provider'],cwd=repo,text=True).splitlines();fixtures={n:sha(repo/n) for n in names if (repo/n).is_file()};assert {'benchmarks/runtime/app-server-capacity.py','benchmarks/runtime/app-server-capacity-provider.py'}<=fixtures.keys(),'commit final capacity fixtures before freezing ordinary pairs'
pre={'utc':now(),'clock_ticks':os.sysconf('SC_CLK_TCK'),'affinity':sorted(os.sched_getaffinity(0)),'builds':builds,'fixtures':fixtures,'cases':['short-small','short-large'],'modes':['no-live-subscriber','live-subscriber'],'pairs':4,'products':32,'scope':'Descriptive balanced adjacent before/after Rust only; no Pi/DSH rerun or cross-batch ratio.'};write(out/'premeasurement.json',pre);records=[]
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])}
for mode in pre['modes']:
 d=out/mode;d.mkdir();write(d/'manifest.json',{'observer_mode':mode,'clock_ticks':pre['clock_ticks'],'executables':{e:{'path':str(p),'sha256':builds[e]['sha256']} for e,p in binaries.items()},'pairs':4,'cases':pre['cases']})
 for pair in range(4):
  for case in pre['cases']:
   for engine in (['before','after'] if pair%2==0 else ['after','before']):
    stem=d/f'{pair}-{case}-{engine}';at=now();value=run([str(binaries[engine]),TEST,'--exact','--ignored','--nocapture'],stem,case,env|{'UV_OFFLINE':'1','RUSTX_BENCH_CASE':case,'RUSTX_BENCH_OBSERVER_MODE':mode,'RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json'))},repo/'test-support/fake-provider')
    row={'mode':mode,'pair':pair,'case':case,'engine':engine,'start_utc':at,'end_utc':now(),'accepted':value['accepted']};records.append(row);write(out/'commands.json',records);print(row,flush=True);assert value['accepted'],value.get('error')
   done=subprocess.run(['node','benchmarks/runtime/compare-http.mjs',str(d/f'{pair}-{case}-before.json'),str(d/f'{pair}-{case}-after.json'),str(d/f'{pair}-{case}-comparison.json')],cwd=repo,capture_output=True,text=True);(d/f'{pair}-{case}-comparison.stderr').write_text(done.stderr);assert done.returncode==0,done.stderr
assert all(sha(repo/n)==v for n,v in fixtures.items());assert all(sha(p)==builds[e]['sha256'] for e,p in binaries.items());write(out/'completed.json',{'accepted':True,'products':32,'paired_requests':1088,'end_utc':now()})
