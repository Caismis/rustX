"""Diagnostic allocator replacement on the native child only, with documented signal dumps."""
import datetime,hashlib,json,os,shlex,signal,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=r/'capacity-heap-bounded';wrapper=r/'heap-app-server-bounded.sh';actual=r/'before-app-server/rustx';lib=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4').resolve();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (r/'resource-completed.json').exists(),'ordinary and CPU products must finish first';assert not out.exists();os.sched_setaffinity(0,[2,8])
wrapper.write_text('#!/bin/sh\n'+'\n'.join('export '+k+'='+shlex.quote(v) for k,v in {'LD_PRELOAD':str(lib),'HEAPPROFILE':str(out/'heap'),'HEAPPROFILESIGNAL':str(int(signal.SIGUSR2)),'HEAP_PROFILE_ALLOCATION_INTERVAL':str(2**60),'HEAP_PROFILE_INUSE_INTERVAL':str(2**60)}.items())+'\nexec '+shlex.quote(str(actual))+' "$@"\n');wrapper.chmod(0o755)
cmd=[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(wrapper),'--output',str(out),'--sessions','8','--history','1','--widths','1','4','8','--rounds','2']
pre={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wrapper_sha256':sha(wrapper),'actual_binary':str(actual),'actual_sha256':sha(actual),'allocator':str(lib),'allocator_sha256':sha(lib),'scope':'Diagnostic only. Only native exec child replaces malloc with tcmalloc and profiles every allocation/free. Never compare these timings or PSS/RSS to ordinary glibc products. Signal snapshots are shortly after the observed phase, not an exact synchronized barrier.'};(r/'heap-bounded-premeasurement.json').write_text(json.dumps(pre,indent=2)+'\n');seen=set();records=[]
with (r/'capacity-heap-bounded.stdout').open('x') as so,(r/'capacity-heap-bounded.stderr').open('x') as se:
 process=subprocess.Popen(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 while process.poll() is None:
  try:phases=json.loads((out/'phases.json').read_text())
  except (OSError,json.JSONDecodeError):phases=[]
  for point in phases:
   name=point['phase']
   if name not in ['empty_attached_8','seeded_history_1','active_held_8','all_unloaded','reload_unload_cycle_2'] or name in seen:continue
   pid=int(point['process']['stat'].split('(',1)[0]);assert str(actual).encode() in Path(f'/proc/{pid}/cmdline').read_bytes();before={p.name for p in out.glob('heap.*.heap')};at=time.monotonic_ns();os.kill(pid,signal.SIGUSR2);seen.add(name)
   deadline=time.monotonic()+10
   while time.monotonic()<deadline and not ({p.name for p in out.glob('heap.*.heap')}-before):time.sleep(.01)
   new=sorted({p.name for p in out.glob('heap.*.heap')}-before);assert len(new)==1,(name,new)
   records.append({'phase':name,'pid':pid,'phase_monotonic_ns':point['monotonic_ns'],'signal_monotonic_ns':at,'profile':new[0]});(r/'heap-bounded-signals.json').write_text(json.dumps(records,indent=2)+'\n')
  time.sleep(.01)
 exit_code=process.wait()
assert exit_code==0,exit_code
assert seen=={'empty_attached_8','seeded_history_1','active_held_8','all_unloaded','reload_unload_cycle_2'},seen
pre.update(exit=exit_code,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),profiles=records);(r/'heap-bounded-completed.json').write_text(json.dumps(pre,indent=2)+'\n');print(json.dumps({'accepted':True,'profiles':len(records)}))
