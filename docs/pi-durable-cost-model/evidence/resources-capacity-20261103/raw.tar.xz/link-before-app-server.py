"""O3 entrypoint link against the explicitly reused immutable ordinary library."""
import datetime,hashlib,json,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');old=Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/candidate-build');out=r/'before-app-server';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();identity=json.loads((old/'identity.json').read_text());lib=old/'librustx.rlib'
rows=[json.loads(v) for v in (old/'build.stdout').read_text().splitlines() if v.startswith('{')]
tokio=next(Path(f) for v in rows if v.get('reason')=='compiler-artifact' and v['target']['name']=='tokio' for f in v['filenames'] if f.endswith('.rlib'))
native=sorted(set(v for row in rows if row.get('reason')=='build-script-executed' for v in row.get('linked_paths',[])))
assert all(sha(repo/n)==v for n,v in identity['source_files'].items())
cmd=['rustc','--crate-name','rustx','--edition=2024','src/main.rs','-C','opt-level=3','-C','embed-bitcode=no','-C','strip=debuginfo','--extern','rustx='+str(lib),'--extern','tokio='+str(tokio),'-L','dependency='+str(tokio.parent)]
for v in native:cmd+=['-L',v]
cmd+=['-o',str(out/'rustx')]
pre={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'library_build':identity,'library_sha256':sha(lib),'tokio_sha256':sha(tokio),'main_sha256':sha(repo/'src/main.rs'),'compiler':subprocess.check_output(['rustc','-Vv'],text=True),'scope':'Explicit O3 main.rs relink against the previously saved clean O3/default-feature fceaf library and its recorded Tokio/native dependencies. Not a new Cargo library rebuild. No source edits or diagnostic feature.'}
(out/'identity-before.json').write_text(json.dumps(pre,indent=2)+'\n')
with (out/'link.stdout').open('x') as so,(out/'link.stderr').open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
pre.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());assert done.returncode==0
assert all(sha(repo/n)==v for n,v in identity['source_files'].items());pre.update(binary=str(out/'rustx'),sha256=sha(out/'rustx'),verified=True)
(out/'identity.json').write_text(json.dumps(pre,indent=2)+'\n');print(pre['sha256'])
