import datetime,json,subprocess,os
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
rows=[json.loads(l) for l in (root/'checks/tests-build.stdout').read_text().splitlines() if l.startswith('{')]
exe=next(r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['target']['kind']==['lib'])
records=[]
for name,selector in [('client','runtime_client::'),('app-server','app_server::')]:
 cmd=[exe,selector,'--skip','::scale::','--test-threads=2']
 record=dict(name=name,command=cmd,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope='Exploratory tests of the first built correction; not final source-bound correctness validation')
 with (root/('exploratory-'+name+'.stdout')).open('w') as out,(root/('exploratory-'+name+'.stderr')).open('w') as err:
  r=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'},stdout=out,stderr=err)
 record.update(exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record)
 (root/'exploratory-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
