import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');checks=r/'checks-final'
while not (checks/'source-after.json').exists():time.sleep(2)
load=lambda p:json.loads(p.read_text());rows=load(checks/'check-build-commands.json');assert len(rows)==16 and all(v['exit']==0 for v in rows),[(v['label'],v['exit']) for v in rows]
a=load(checks/'source-before.json')['files'];assert a==load(checks/'source-after.json')['files'];assert all(hashlib.sha256((repo/k).read_bytes()).hexdigest()==v for k,v in a.items())
counts={'ok':0,'ignored':0};names=set()
for row in rows:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (checks/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in names,key;names.add(key);counts[m[2]]+=1
summary={'accepted':True,'tests':counts,'commands':len(rows),'source_inputs':len(a)};(r/'checks-final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
files=['src/runtime_client/event.rs','src/runtime_client/projection.rs','src/runtime_client/projection/cached_trace_tests.rs','src/runtime_client/projection/metadata_root_tests.rs'];subprocess.run(['git','add','--',*files],cwd=repo,check=True);subprocess.run(['git','commit','-m','Keep large read heads out of every replay event layout'],cwd=repo,check=True)
with (r/'final-build.stdout').open('x') as so,(r/'final-build.stderr').open('x') as se:p=subprocess.run([sys.executable,str(r/'build.py'),'final',str(repo)],cwd=repo,stdout=so,stderr=se)
print('candidate-build',p.returncode,flush=True);assert p.returncode==0
(r/'ready-final.json').write_text(json.dumps({'accepted':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
