"""Rust-only final ordinary/resource cohorts, strictly serial and compiler-free."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');old=Path('/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build');rows=[]
while not (r/'ready-final.json').exists():
 if (r/'final-build/identity.json').exists() and any(x.get('exit',0)!=0 for x in json.loads((r/'final-build/identity.json').read_text()).get('commands',[])):raise RuntimeError('candidate build failed')
 time.sleep(2)
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
identity=json.loads((r/'final-build/identity.json').read_text());assert identity['verified'];buildrows=[json.loads(s) for s in (r/'final-build/build.stdout').read_text().splitlines() if s.startswith('{')];artifact=next(v for v in buildrows if v.get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['kind']==['bin']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(r/'final-build/app-server-identity.json').write_text(json.dumps({'head':identity['head'],'binary':str(r/'final-build/rustx'),'sha256':sha(r/'final-build/rustx'),'artifact':artifact},indent=2)+'\n')
def run(label,cmd):
 assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(label+'.stdout')).open('x') as so,(r/(label+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'measurement-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True);assert p.returncode==0
binaries={'before':old/'rustx','after':r/'final-build/rustx'}
for pair in range(2):
 for side in (['before','after'] if pair==0 else ['after','before']):
  label=f'native-{pair}-{side}';run(label,[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(binaries[side]),'--output',str(r/label),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16'])
run('ordinary-pairs',[sys.executable,str(r/'run-pairs.py')])
for side in ['before','after']:
 label='history-512-'+side;run(label,[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(binaries[side]),'--output',str(r/label),'--sessions','2','--history','512','--widths','1','2','--rounds','16'])
for script in ['columns-complete.py','run-wal-rust.py']:
 for label,binary in [('baseline',old/'conformance'),('complete',r/'final-build/conformance')]:
  run(script.removesuffix('.py')+'-'+label,[sys.executable,str(r/script),'--binary',str(binary),'--label',label])
  if script=='run-wal-rust.py':run('wal-analysis-'+label,[sys.executable,str(r/'analyze-wal.py'),'--label',label])
run('storage-audit',[sys.executable,str(r/'audit-storage-trial.py'),'--schema','93'])
wrapper=r/'sampling-after-wrapper.sh';wrapper.write_text((r/'sampling-before-wrapper.sh').read_text().replace(str(old/'rustx'),str(r/'final-build/rustx')).replace('sampling-128-before','sampling-128-after'));wrapper.chmod(0o755)
run('sampling-128-after',[sys.executable,str(r/'sampling-capacity.py'),'--binary',str(wrapper),'--output',str(r/'sampling-128-after'),'--sessions','128','--history','8','--widths','1','4','8','--rounds','2'])
(r/'measurement-completed.json').write_text(json.dumps({'accepted':True,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
