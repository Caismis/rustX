"""Low-rate host compiler observations; no env or other-project source reads."""
import datetime,json,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent
while not (r/'refinement/measurement-completed.json').exists():
 p=subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True);ids=p.stdout.split();items=[]
 for pid in ids:
  try:items.append({'pid':int(pid),'cwd':str((Path('/proc')/pid/'cwd').resolve()),'stat':(Path('/proc')/pid/'stat').read_text()})
  except OSError:pass
 with (r/'host-compiler-observations.jsonl').open('a') as h:h.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'rustc':items})+'\n')
 time.sleep(2)
