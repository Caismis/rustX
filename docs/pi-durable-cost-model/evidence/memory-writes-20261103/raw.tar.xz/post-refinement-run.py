"""Post ordinary workloads: symbolize diagnostics, then build/run private after counters."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');old=Path('/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build')
while not (r/'refinement/functional-products/completed.json').exists():time.sleep(2)
assert json.loads((r/'refinement/measurement-completed.json').read_text())['accepted']
# Keep every original diagnostic source/patch. Final probes contain identical production changes plus the same counters.
dtree=r/'diagnostic-tree';original=(dtree/'src/runtime_client/projection.rs').read_text();start=original.index('fn drop_replay_part<');end=original.index('fn canonical_locator_position',start);block=original[start:end]
s=(repo/'src/runtime_client/projection.rs').read_text();at=s.index('fn canonical_locator_position');(dtree/'src/runtime_client/projection.rs').write_text(s[:at]+block+s[at:])
for name in ['src/durable/sqlite/observation.rs','src/durable/sqlite/compact_lookup_tests.rs','src/runtime_client/event.rs','src/runtime_client/projection/cached_trace_tests.rs','src/runtime_client/projection/metadata_root_tests.rs','src/durable/sqlite/content_encoding.rs']:(dtree/name).write_bytes((repo/name).read_bytes())
s=(repo/'src/durable/sqlite.rs').read_text().replace("struct ConnectionLease<'a> {","pub(crate) mod memory_profile;\n\nstruct ConnectionLease<'a> {").replace("impl Drop for ConnectionLease<'_> {\n    fn drop(&mut self) {", "impl Drop for ConnectionLease<'_> {\n    fn drop(&mut self) {\n        if let Some(connection) = self.connection.as_ref() { memory_profile::capture(connection); }");(dtree/'src/durable/sqlite.rs').write_text(s)
cmd=['cargo','rustc','--release','--locked','--lib','--message-format=json','--','-C','opt-level=0']
with (r/'diagnostic-refined-build.stdout').open('x') as so,(r/'diagnostic-refined-build.stderr').open('x') as se:p=subprocess.run(cmd,cwd=dtree,env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2'},stdout=so,stderr=se)
assert p.returncode==0
s=(r/'link-diagnostic-fields.py').read_text().replace('diagnostic-fields-build','diagnostic-refined-build').replace('diagnostic-fields.patch','diagnostic-refined.patch').replace('memory_profile-fields.rs','memory_profile-refined.rs');(r/'link-diagnostic-refined.py').write_text(s);subprocess.run([sys.executable,str(r/'link-diagnostic-refined.py')],check=True)
wrapper=r/'sql-refined-wrapper.sh';wrapper.write_text((r/'sql-fields-wrapper.sh').read_text().replace('diagnostic-fields-build','diagnostic-refined-build'));wrapper.chmod(0o755)
cmd=[sys.executable,str(r/'diagnostic-capacity.py'),'--binary',str(wrapper),'--output',str(r/'sql-fields-eight-refined'),'--sessions','8','--history','8','--widths','1','4','8','--rounds','2']
with (r/'sql-fields-eight-refined.stdout').open('x') as so,(r/'sql-fields-eight-refined.stderr').open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
assert p.returncode==0
# Symbolization uses the saved immutable O3 final executable, not overwritten target artifacts.
pp=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof');d=r/'refinement/sampling-128-after';rows=[]
for index in [1,2,3]:
 for label,flags in [('cum',['--text','--cum']),('stacks',['--collapsed'])]:
  cmd=[str(pp),*flags,'--no_strip_temp','--nodecount=5000','--nodefraction=0','--edgefraction=0',str(r/'refinement/final-build/rustx'),str(d/f'native-sample-{index}.heap')]
  with (d/f'sample-{index}-{label}.txt').open('x') as so,(d/f'sample-{index}-{label}.stderr').open('x') as se:p=subprocess.run(cmd,stdout=so,stderr=se)
  rows.append({'command':cmd,'exit':p.returncode});assert p.returncode==0
(r/'sampling-refined-symbolization.json').write_text(json.dumps(rows,indent=2)+'\n');subprocess.run([sys.executable,str(r/'audit-sampling.py'),'--after','refinement/sampling-128-after','--output','sampling-refined-audit.json'],check=True)
# Frozen final O3 type layout, only after all ordinary products finished.
cmd=json.loads((r/'type-sizes-build.json').read_text())['command'];cmd=[s.replace(str(old/'librustx.rlib'),str(r/'refinement/final-build/librustx.rlib')) for s in cmd];cmd[1:1]=['-Zprint-type-sizes'];cmd[cmd.index('-o')+1]=str(r/'type-layout-refined')
p=subprocess.run(cmd,capture_output=True,text=True,env=os.environ|{'RUSTC_BOOTSTRAP':'1'});(r/'type-layout-refined.stdout').write_text(p.stdout);(r/'type-layout-refined.stderr').write_text(p.stderr);assert p.returncode==0
(r/'type-sizes-refined.txt').write_text(subprocess.check_output([str(r/'type-layout-refined')],text=True));(r/'post-refinement-completed.json').write_text(json.dumps({'accepted':True})+'\n')
