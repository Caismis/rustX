//! Local diagnostic-only patch; not a production change.
#[allow(unsafe_code)]
pub(super) fn capture(connection: &rusqlite::Connection) {
    use std::{collections::HashMap, ffi::CStr, sync::{Mutex, OnceLock}};
    use rusqlite::ffi;
    static LAST: OnceLock<Mutex<HashMap<String, i64>>> = OnceLock::new();
    let sequence: i64 = connection.query_row("SELECT next_event_sequence FROM rustx_store WHERE id=1", [], |row| row.get(0)).unwrap_or(-1);
    unsafe {
        let db=connection.handle();
        let filename=ffi::sqlite3_db_filename(db, c"main".as_ptr());
        if filename.is_null() { return; }
        let file=CStr::from_ptr(filename).to_string_lossy().into_owned();
        if file.is_empty() { return; }
        let mut last=LAST.get_or_init(Mutex::default).lock().unwrap();
        if last.get(&file)==Some(&sequence) { return; }
        last.insert(file.clone(),sequence);
        drop(last);
        let status=|kind| { let mut now=0;let mut high=0; assert_eq!(ffi::sqlite3_db_status(db,kind,&mut now,&mut high,0),ffi::SQLITE_OK);now };
        let cache=status(ffi::SQLITE_DBSTATUS_CACHE_USED);
        let schema=status(ffi::SQLITE_DBSTATUS_SCHEMA_USED);
        let statements=status(ffi::SQLITE_DBSTATUS_STMT_USED);
        let mut plans=Vec::new();let mut stmt=ffi::sqlite3_next_stmt(db,std::ptr::null_mut());
        while !stmt.is_null() {
            let sql=ffi::sqlite3_sql(stmt);
            let sql=if sql.is_null() { String::new() } else { CStr::from_ptr(sql).to_string_lossy().into_owned() };
            plans.push((ffi::sqlite3_stmt_status(stmt,ffi::SQLITE_STMTSTATUS_MEMUSED,0),sql));
            stmt=ffi::sqlite3_next_stmt(db,stmt);
        }
        plans.sort_by(|a,b|b.0.cmp(&a.0));
        eprintln!("{}",serde_json::json!({"kind":"sqlite_memory","file":file,"sequence":sequence,"cache":cache,"schema":schema,"statements":statements,"plan_count":plans.len(),"top_plans":plans.into_iter().take(12).collect::<Vec<_>>()}));
    }
}

#[allow(unsafe_code)]
pub(crate) fn allocated() -> usize {
    unsafe {
        let symbol = libc::dlsym(libc::RTLD_DEFAULT, c"MallocExtension_GetNumericProperty".as_ptr());
        assert!(!symbol.is_null(), "diagnostic requires tcmalloc numeric properties");
        let get: unsafe extern "C" fn(*const libc::c_char, *mut usize) -> libc::c_int = std::mem::transmute(symbol);
        let mut bytes=0;assert_ne!(get(c"generic.current_allocated_bytes".as_ptr(), &mut bytes),0);bytes
    }
}
