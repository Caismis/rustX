"""Describe recorded shared-host compiler activity; no performance adjustment or exclusions."""
import datetime,json
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads((r/p).read_text());observations=[json.loads(v) for v in (r/'host-compiler-observations.jsonl').read_text().splitlines()];at=lambda s:datetime.datetime.fromisoformat(s);out=[]
for file in ['refinement/measurement-commands.json','refinement/ordinary-pairs/commands.json']:
 for v in load(file):
  inside=[x for x in observations if at(v['start_utc'])<=at(x['utc'])<=at(v['end_utc'])];comp=[x for x in inside if x['rustc']]
  out.append({'commands':file,'label':v.get('label',str((v.get('mode'),v.get('pair'),v.get('case'),v.get('engine')))),'observations':len(inside),'observations_with_compilers':len(comp),'observed_compiler_worktrees':sorted({p['cwd'] for x in comp for p in x['rustc']})})
(r/'host-audit.json').write_text(json.dumps({'accepted':True,'first_observation':observations[0]['utc'],'last_observation':observations[-1]['utc'],'products':out,'scope':'Two-second observations begin after the first final native product, not a continuous whole-run CPU activity proof. Compiler-quiet gates before top-level products do not exclude new unrelated compilers during a block. No timing outlier, product, or unfavorable cell is excluded or adjusted. Memory and write counters remain native-PID measures on a shared host.'},indent=2)+'\n');print(json.dumps({'accepted':True,'observed_windows':len(out),'with_compiler_samples':sum(v['observations_with_compilers']>0 for v in out)}))
