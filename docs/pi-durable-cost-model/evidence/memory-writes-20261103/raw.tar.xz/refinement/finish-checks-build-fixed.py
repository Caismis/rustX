import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');checks=r/'checks-fixed'
while not (checks/'source-after.json').exists():time.sleep(2)
load=lambda p:json.loads(p.read_text());rows=load(checks/'check-build-commands.json');assert len(rows)==16 and all(v['exit']==0 for v in rows),[(v['label'],v['exit']) for v in rows]
a=load(checks/'source-before.json')['files'];assert a==load(checks/'source-after.json')['files'];assert all(hashlib.sha256((repo/k).read_bytes()).hexdigest()==v for k,v in a.items())
counts={'ok':0,'ignored':0};names=set()
for row in rows:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (checks/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in names,key;names.add(key);counts[m[2]]+=1
summary={'accepted':True,'tests':counts,'commands':len(rows),'source_inputs':len(a)};(r/'checks-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(summary,flush=True)
files=['src/durable/sqlite/observation.rs','src/durable/sqlite.rs','src/durable/sqlite/compact_lookup_tests.rs','src/durable/sqlite/reading_tests.rs','src/durable/sqlite/observation_request/composed/scalar_tests.rs','src/durable/sqlite/observation_event_probe_tests.rs'];subprocess.run(['git','add','--',*files],cwd=repo,check=True);subprocess.run(['git','commit','-m','Keep block header bodies local on compact SQLite pages'],cwd=repo,check=True)
with (r/'final-build.stdout').open('x') as so,(r/'final-build.stderr').open('x') as se:p=subprocess.run([sys.executable,str(r/'build.py'),'final',str(repo)],cwd=repo,stdout=so,stderr=se)
print('candidate-build',p.returncode,flush=True);assert p.returncode==0
(r/'ready-final.json').write_text(json.dumps({'accepted':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
