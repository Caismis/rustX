"""Raw-only arithmetic for one explicitly identified storage candidate; never pools trials."""
import argparse,collections,hashlib,importlib.util,json,math,re,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--schema',type=int,required=True);p.add_argument('--raw-only',action='store_true');p.add_argument('--output',type=Path);a=p.parse_args();r=a.root.resolve();sys.path.insert(0,str(r));load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mod(name,file):
 s=importlib.util.spec_from_file_location(name,r/file);v=importlib.util.module_from_spec(s);s.loader.exec_module(v);return v
m=mod('resource_math','recompute-pi.py');d=mod('resource_direct','direct-audit.py');d.MATH=m;require=m.require
pre=load(r/'ordinary-pairs/premeasurement.json');commands=load(r/'ordinary-pairs/commands.json');require(len(commands)==32,'missing ordinary products');products=[];cells=[];comparisons=[]
expected=[(mode,pair,case,e) for mode in pre['modes'] for pair in range(4) for case in pre['cases'] for e in (['before','after'] if pair%2==0 else ['after','before'])]
require([(v['mode'],v['pair'],v['case'],v['engine']) for v in commands]==expected,'order differs');require(all(v['accepted'] for v in commands),'unaccepted product')
for left,right in zip(commands,commands[1:]):require(left['end_utc']<=right['start_utc'],'overlapping ordinary products')
for e,b in pre['builds'].items():
 require(b['verified'] and b['commands'][-1]['exit']==0,'invalid build')
 if not a.raw_only:require(sha(Path(b['binary']))==b['sha256'],'executable changed')
for mode in pre['modes']:
 directory=r/'ordinary-pairs'/mode;manifest=load(directory/'manifest.json');require(len(list(directory.glob('*.process.json')))==16,'unexpected products')
 for case in pre['cases']:
  values={e:[] for e in ['before','after']}
  for pair in range(4):
   for e in values:
    path=directory/f'{pair}-{case}-{e}.json';raw=load(path);proc=load(path.with_suffix('.process.json'));require(raw['schema']==(93 if e=='before' else a.schema),'schema identity')
    v=d.derived_product(raw,proc,case,mode,e,manifest);values[e].append(v['metrics']);products.append({'file':str(path.relative_to(r)),'sha256':sha(path),'process_sha256':sha(path.with_suffix('.process.json')),'mode':mode,'case':case,'pair':pair,'engine':e,**v})
   path=directory/f'{pair}-{case}-comparison.json';comparisons.append({'file':str(path.relative_to(r)),'requests':d.comparison(path,case,mode,True),'sha256':sha(path)})
  cells.append({'mode':mode,'case':case,'absolute':{e:{k:d.descriptive([v[k] for v in rows]) for k in rows[0]} for e,rows in values.items()},'paired_change_percent':{k:d.descriptive([None if (z:=m.paired_ratio(x[k],y[k])[0]) is None else 100*(z-1) for x,y in zip(values['after'],values['before'])]) for k in values['after'][0]}})
require(sum(v['requests'] for v in comparisons)==1088,'request count')
storage=[]
for case in pre['cases']:
 for label in ['baseline','complete']:
  directory=r/f'columns-{label}-{case}';before=load(directory/'before_measured_turns.json');after=load(directory/'after_turns.json');wal=load(r/f'wal-summary-{label}-corrected.json')[case+'-rust'];image=r/f'wal-{label}-{case}-rust';lo=load(image/'before_measured_turns-database.json')[0]['storage'];hi=load(image/'after_turns-database.json')[0]['storage']
  require(wal['steady_turns']==32 and wal['wal_write_commits']==160,'commit contract');logical=lambda s:sum(sum(v['column_value_bytes'].values()) for v in s['tables'].values())
  for name,proof in [('before_measured_turns',lo),('after_turns',hi)]:
   path=image/(name+'-image.sqlite');require(path.stat().st_size==proof['backup_bytes'] and sha(path)==proof['backup_sha256'],'consistent image identity')
  storage.append({'case':case,'engine':label,'logical_bytes':logical(after)-logical(before),'page_size':hi['page_size'],'wal':wal,'before_storage':lo,'after_storage':hi,'net_main_image_bytes':hi['backup_bytes']-lo['backup_bytes'],'net_used_page_bytes':((hi['page_count']-hi['free_pages'])-(lo['page_count']-lo['free_pages']))*hi['page_size']})
result={'accepted':True,'raw_only':a.raw_only,'candidate_schema':a.schema,'script_sha256':sha(Path(__file__)),'premeasurement_sha256':sha(r/'ordinary-pairs/premeasurement.json'),'products':products,'comparisons':comparisons,'cells':cells,'storage':storage,'scope':'One candidate only, four descriptive pairs per cell. Logical bytes, process writes, WAL and consistent database growth remain distinct; no Pi/DSH execution or parity ratio.'}
(a.output or r/'storage-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'products':32,'requests':1088,'schema':a.schema}))
