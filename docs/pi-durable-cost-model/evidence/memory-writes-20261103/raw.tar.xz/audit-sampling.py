"""Audit complete sampled exports, Poisson correction and separate allocator totals."""
import argparse,hashlib,json,math,re
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');p.add_argument('--after',default='sampling-128-after');p.add_argument('--output');a=p.parse_args();r=Path(__file__).resolve().parent;products=[];pending=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for side in ['before','after']:
 d=r/(a.after if side=='after' else 'sampling-128-before')
 if not (d/'sample-3-stacks.txt').exists():pending.append(side);continue
 for index in [1,2,3]:
  raw=d/f'native-sample-{index}.heap';lines=raw.read_text().splitlines();match=re.match(r'heap profile:\s+(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\] @ heap_v2/(\d+)',lines[0]);assert match;header=list(map(int,match.groups()));sums=[0]*4;weighted=0.;records=0
  for line in lines[1:]:
   m=re.match(r'\s*(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\]\s+@',line)
   if not m:continue
   v=list(map(int,m.groups()));records+=1;sums=[x+y for x,y in zip(sums,v)];assert v[0]>0;weighted+=v[1]/(-math.expm1(-v[1]/v[0]/header[4]))
  assert sums==header[:4],(side,index,sums,header)
  stacks=[]
  for line in (d/f'sample-{index}-stacks.txt').read_text().splitlines():
   if line.strip():stack,n=line.rsplit(' ',1);stacks.append((stack,int(n)))
  collapsed=sum(n for _,n in stacks);assert abs(collapsed-weighted)<len(stacks)+1
  text=(d/f'sample-{index}-cum.txt').read_text();text_total=float(re.search(r'Total: ([\d.]+) MB',text)[1]);assert abs(text_total-weighted/1048576)<=.051
  presence={name:sum(n for stack,n in stacks if token in stack) for name,token in [('sqlite_malloc','sqlite3MemMalloc'),('sqlite_page_cache','pcache1Alloc'),('schema_compilation','jsonschema::compiler::compile'),('checkpoint_materialization','capture_checkpoint::{closure#6}'),('publication_encoding','PublicationDraft>::encode'),('replay_deque_growth','VecDeque<>>::grow')]}
  presence['replay_deque_growth']=sum(n for stack,n in stacks if 'vec_deque::VecDeque<(' in stack and 'RuntimeClientEvent)>>::grow' in stack)
  binding=json.loads((d/f'sample-{index}-binding.json').read_text());products.append({'side':side,'index':index,'phase':binding['phase'],'profile_sha256':sha(raw),'profile_bytes':raw.stat().st_size,'raw_records':records,'raw_header':header,'raw_sums':sums,'weighted_requested_bytes':weighted,'collapsed_weighted_requested_bytes':collapsed,'rounding_difference_bytes':weighted-collapsed,'overlapping_stack_presence_bytes':presence,'allocator_numeric_properties':binding['stats']})
assert a.partial or not pending,pending
result={'accepted':not pending,'pending':pending,'products':products,'scope':'Raw sampled counts/bytes exactly cover exported header. Independent Poisson correction agrees with pprof collapsed integer weights within per-stack rounding. Requested-byte estimates differ from allocator class-charged totals and ordinary glibc PSS. Stack-presence groups overlap, optimized aliases/inlining limit attribution; never normalize them to925MiB or add inclusive groups.'}
(r/(a.output or ('sampling-audit-partial.json' if a.partial else 'sampling-audit.json'))).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':not pending,'profiles':len(products),'pending':pending}))
