import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads((r/p).read_text());audit=load('native-audit.json');products={v['directory']:v for v in audit['products']};phases={};activity=[]
for phase in ['empty_server','metadata_only','empty_attached_128','seeded_history_8','all_unloaded','reload_unload_cycle_2']:
 sides={}
 for side in ['before','after']:
  values=[]
  for pair in range(2):
   p=products[f'refinement/native-{pair}-{side}'];point=next(v for v in p['points'] if v['phase']==phase);values.append(point['counters'])
  sides[side]={key:{'values':[v[key] for v in values],'median':statistics.median(v[key] for v in values)} for key in ['anon_pss_mib','rss_mib']}
 phases[phase]=sides
for width in [1,4,8]:
 pairs=[]
 for pair in range(2):
  sides={}
  for side in ['before','after']:
   v=next(x for x in products[f'refinement/native-{pair}-{side}']['activity'] if x['width']==width)
   sides[side]={'settled_median_ms':v['latency']['settled_us']['median_ms'],'p95_ms':v['latency']['settled_us']['p95_ms'],'cpu_ms':v['server_cpu_ms_per_all_turns'],'write_bytes':v['server_write_bytes_per_all_turns']}
  pairs.append({'sides':sides,'changes_percent':{key:(sides['after'][key]/sides['before'][key]-1)*100 for key in sides['before']}})
 activity.append({'width':width,'pairs':pairs,'absolute_medians':{side:{key:statistics.median(p['sides'][side][key] for p in pairs) for key in pairs[0]['sides'][side]} for side in ['before','after']},'paired_change_medians':{key:statistics.median(p['changes_percent'][key] for p in pairs) for key in pairs[0]['changes_percent']}})
result={'phases':phases,'activity':activity,'production_build':load('refinement/final-build/identity.json')['head'],'checks':load('refinement/checks-summary.json'),'scope':'Final94 cohort only. Phase anonymous PSS/RSS medians of two ordinary native128-session processes per side; active latency excludes held first wave, resource windows include all rounds. Descriptive small cohorts, no production capacity or exact heap partition claim.'}
(r/'final-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
