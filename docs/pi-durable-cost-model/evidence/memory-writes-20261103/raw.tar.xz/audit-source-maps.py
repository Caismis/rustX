"""Recheck recorded check/build source identities without rebuilding or network."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());proofs=[]
for checks,build,summary in [('checks-initial','candidate-build','checks-summary.json'),('checks-final','final-build','checks-final-summary.json'),('refinement/checks-corrected','refinement/final-build','refinement/checks-summary.json')]:
 directory=r/checks;a=load(directory/'source-before.json')['files'];b=load(directory/'source-after.json')['files'];identity=load(r/build/'identity.json');rows=load(directory/'check-build-commands.json');assert a==b==identity['source_files'] and len(a)==971
 assert len(rows)==16 and all(v['exit']==0 for v in rows);assert identity['verified'] and all(v['exit']==0 for v in identity['commands'])
 names=set();counts={'ok':0,'ignored':0}
 for row in rows:
  if row['label'].startswith('tests-') and row['label']!='tests-build':
   for line in (directory/(row['label']+'.stdout')).read_text().splitlines():
    m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
    if m:
     key=(row['command'][0],m[1]);assert key not in names;names.add(key);counts[m[2]]+=1
 stored=load(r/summary);assert counts==stored['tests'] and len(rows)==stored['commands'] and len(a)==stored['source_inputs']
 proofs.append({'checks':checks,'build':build,'head':identity['head'],'tests':counts,'commands':len(rows),'source_inputs':len(a),'source_map_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest(),'conformance_sha256':identity['sha256']})
result={'accepted':True,'proofs':proofs,'scope':'Stored 971-input before/after check maps exactly match each fresh O3/default production build. Full suite uses separate root-O0/all-feature artifacts. Does not freshly authenticate excluded executables or claim all repository CI/browser E2E.'}
(r/'source-map-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'stages':len(proofs)}))
