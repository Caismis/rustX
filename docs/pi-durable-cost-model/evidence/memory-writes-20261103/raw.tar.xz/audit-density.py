"""Recompute dbstat physical header density from authenticated consistent backups."""
import hashlib,json,sqlite3
from pathlib import Path
r=Path(__file__).resolve().parent;rows=[]
for cohort in ['', 'refinement/']:
 for label in ['baseline','complete']:
  for case in ['short-small','short-large']:
   counts=[]
   for point in ['before_measured_turns','after_turns']:
    d=r/cohort/f'wal-{label}-{case}-rust';image=d/(point+'-image.sqlite');meta=json.loads((d/(point+'-database.json')).read_text())[0];assert hashlib.sha256(image.read_bytes()).hexdigest()==meta['storage']['backup_sha256'];c=sqlite3.connect(f'file:{image}?mode=ro',uri=True)
    pages=[list(v) for v in c.execute('SELECT name,pageno,pagetype,ncell,payload FROM dbstat ORDER BY name,pageno')];assert sorted(pages)==sorted(meta['pages']);counts.append(sum(v[0]=='observation_block_headers' and v[2]=='overflow' for v in pages));c.close()
   rows.append({'cohort':cohort or 'initial','side':label,'case':case,'header_overflow_pages_before':counts[0],'header_overflow_pages_after':counts[1],'growth':counts[1]-counts[0]})
(r/'density-audit.json').write_text(json.dumps({'accepted':True,'products':rows,'scope':'dbstat rows freshly queried from the16 consistent SQLite backup images exactly match recorded physical-page metadata. Header overflow counts are physical pages, not logical byte or timing shares.'},indent=2)+'\n');print(json.dumps({'accepted':True,'images':16}))
