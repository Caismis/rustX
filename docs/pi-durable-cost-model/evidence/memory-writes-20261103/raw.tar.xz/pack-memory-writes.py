"""Archive raw products/consistent images and provenance; omit executables and live workspaces."""
import argparse,hashlib,json,os,tarfile,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=Path(__file__).resolve().parent;out=a.output;out.mkdir(parents=True,exist_ok=True)
archive=out/'raw.tar.xz';assert not archive.exists();members=[];excluded=[]
pruned={'diagnostic-tree','.git','runtime','workspaces','__pycache__'}
for directory,dirs,files in os.walk(r):
 base=Path(directory)
 for name in sorted(list(dirs)):
  if name in pruned:
   excluded.append({'path':str((base/name).relative_to(r)),'reason':'Live workspace/runtime, private diagnostic checkout or generated Python cache'});dirs.remove(name)
 for name in sorted(files):
  path=base/name;relative=path.relative_to(r)
  reason=None
  if path.is_symlink():reason='Symlink excluded'
  elif name in {'token','transport-token','product-host-token','delivery-token','WORK-IN-PROGRESS.txt'} or name.startswith('.env'):reason='Ephemeral credentials or agent scratch notes'
  elif path.suffix in {'.rlib','.rmeta','.so','.o','.pyc','.a'}:reason='Compiled artifact excluded; source, command and identity retained'
  elif name=='provider.stdout' or name.endswith('.provider.stdout'):reason='Duplicate provider stdout; full provider reports/process oracles retained'
  else:
   with path.open('rb') as handle:magic=handle.read(4)
   if magic==b'\x7fELF':reason='Executable excluded; source/build/hash evidence retained'
  if reason:excluded.append({'path':str(relative),'reason':reason});continue
  members.append((str(relative),path))
members.sort();selection={'included_regular_files':len(members),'omissions':excluded,'policy':'All remaining regular raw reports/logs/profiles, consistent SQLite backups, failed attempts, source patches, frozen measurement inputs and build/check records. No product executable or live runtime/token artifact.'}
(r/'archive-selection.json').write_text(json.dumps(selection,indent=2)+'\n');members.append(('archive-selection.json',r/'archive-selection.json'));members=[v for v in members if v[0]!='archive-selection.json']+[('archive-selection.json',r/'archive-selection.json')];members.sort()
manifest=[];started=time.time()
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for name,path in members:
  before=path.stat();digest=hashlib.sha256(path.read_bytes()).hexdigest();tar.add(path,arcname=name,recursive=False);after=path.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns),name
  manifest.append({'path':name,'bytes':before.st_size,'sha256':digest})
value={'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'members':manifest,'scope':'Hashes authenticate archived bytes. Recorded prearchive checks authenticate excluded executable identities; offline replay does not execute or freshly verify them.'}
(out/'manifest.json').write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({'members':len(manifest),'bytes':archive.stat().st_size,'sha256':value['archive']['sha256'],'elapsed_seconds':time.time()-started}),flush=True)
