import json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
while not (r/'post-refinement-completed.json').exists():time.sleep(2)
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
cmd=[sys.executable,str(r/'diagnostic-capacity.py'),'--binary',str(r/'sql-after-wrapper.sh').replace('sql-after-wrapper','sql-refined-wrapper'),'--output',str(r/'sql-fields-128-refined'),'--sessions','128','--history','8','--widths','1','4','8','--rounds','2']
# The refined postprocess creates the wrapper under its distinct name.
wrapper=r/'sql-refined-wrapper.sh';wrapper.write_text((r/'sql-after-wrapper.sh').read_text().replace('diagnostic-after-build','diagnostic-refined-build'));wrapper.chmod(0o755)
with (r/'sql-fields-128-refined.stdout').open('x') as so,(r/'sql-fields-128-refined.stderr').open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
assert p.returncode==0
(r/'final-replay-capacity-completed.json').write_text(json.dumps({'accepted':True})+'\n')
