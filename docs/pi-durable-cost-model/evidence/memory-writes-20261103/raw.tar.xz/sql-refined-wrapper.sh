#!/bin/sh
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4.5.16
exec /home/capi/.cache/rustx-pr485-memory-writes-20261103/diagnostic-refined-build/rustx "$@"
