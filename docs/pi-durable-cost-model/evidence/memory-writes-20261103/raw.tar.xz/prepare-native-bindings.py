import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');names=['native-0-before','native-0-after','native-1-after','native-1-before','history-512-before','history-512-after','sampling-128-before','sampling-128-after','sql-memory-before','sql-replay-128-before','sql-replay-serial-before','sql-fields-eight-before','heap-eight-history','sql-fields-eight-after','refinement/native-0-before','refinement/native-0-after','refinement/native-1-after','refinement/native-1-before','refinement/history-512-before','refinement/history-512-after','refinement/sampling-128-after','sql-fields-eight-refined','sql-fields-128-refined'];rows={};sources=r/'frozen-inputs';sources.mkdir(exist_ok=True);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in names:
 d=r/name
 if not (d/'completed.json').exists():continue
 identity=json.loads((d/'identity.json').read_text());binary=Path(identity['binary']);assert sha(binary)==identity['sha256'];bindings={}
 for path,digest in identity['inputs'].items():
  source=Path(path) if Path(path).is_absolute() else repo/path;assert sha(source)==digest,(name,path)
  dest=sources/digest
  if not dest.exists():dest.write_bytes(source.read_bytes())
  bindings[path]=digest
 rows[name]={'binary_sha256':identity['sha256'],'inputs':bindings,'scope':'Frozen original sources and actual executable/wrapper bytes verified before archiving; raw replay checks recorded identities without executable bytes.'}
(r/'native-product-bindings.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps({'products':len(rows),'frozen_sources':len(list(sources.iterdir()))}))
