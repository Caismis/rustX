fn main() {
 macro_rules! size {($t:ty)=>{println!("{} {}",stringify!($t),std::mem::size_of::<$t>());}}
 size!(rustx::runtime_client::event::RuntimeClientEvent);
 size!(rustx::runtime_client::checkpoint::RuntimeClientCheckpoint);
 size!(rustx::runtime_client::snapshot::RuntimeClientSnapshot);
 size!(rustx::runtime_client::occupancy::RuntimeClientContextOccupancy);
 size!(rustx::runtime_client::types::RuntimeClientProtocolEvent);
 size!(rustx::runtime::identity::ObservationCollectionCut);
}
