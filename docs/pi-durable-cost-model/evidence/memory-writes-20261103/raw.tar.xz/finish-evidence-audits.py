"""Finish raw audits only after every ordinary and private product has ended."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
while not (r/'final-replay-capacity-completed.json').exists():time.sleep(2)
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
rows=[]
for script in ['prepare-native-bindings.py','audit-native.py','audit-ownership.py','audit-functional.py','audit-source-maps.py','summarize-final.py','make-tables.py']:
 p=subprocess.run([sys.executable,str(r/script)],cwd=r,capture_output=True,text=True);(r/(script+'.stdout')).write_text(p.stdout);(r/(script+'.stderr')).write_text(p.stderr);rows.append({'script':script,'exit':p.returncode});print(script,p.returncode,flush=True);assert p.returncode==0,p.stdout+p.stderr
identity=json.loads((r/'refinement/final-build/identity.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(repo/name)==digest for name,digest in identity['source_files'].items())
proofs=[]
for directory in ['baseline-provenance','candidate-build','final-build','refinement/final-build','diagnostic-build','diagnostic-replay-build','diagnostic-fields-build','diagnostic-after-build','diagnostic-refined-build']:
 for name in ['identity.json','app-server-identity.json']:
  path=r/directory/name
  if not path.exists():continue
  value=json.loads(path.read_text());binary=Path(value['binary']);digest=sha(binary);assert digest==value['sha256'];proofs.append({'identity':str(path.relative_to(r)),'binary':str(binary),'sha256':digest})
(r/'prearchive-identities.json').write_text(json.dumps({'accepted':True,'source_inputs':len(identity['source_files']),'head':identity['head'],'executable_proofs':proofs,'scope':'Actual preserved executable/wrapper bytes and971current inputs verified before archive selection. Excluded executable bytes cannot be freshly authenticated by offline replay.'},indent=2)+'\n')
(r/'all-audits-completed.json').write_text(json.dumps({'accepted':True,'commands':rows},indent=2)+'\n')
