"""Direct SQLite category counters and explicitly approximate replay-release measurements."""
import collections,hashlib,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;sql=[];replays=[];fields=[]
def rows(directory,kind):
 result=[]
 for line in (directory/'server.stderr').read_text().splitlines():
  try:value=json.loads(line)
  except json.JSONDecodeError:continue
  if value.get('kind')==kind:result.append(value)
 return result
for relative in ['sql-replay-serial-before','sql-fields-128-refined']:
 directory=r/relative;records=rows(directory,'sqlite_memory');exact={v['file']:v for v in records if v['sequence']==64};assert len(exact)==128
 medians={k:statistics.median(v[k] for v in exact.values()) for k in ['cache','statements','schema','plan_count']};sql.append({'directory':relative,'seq64_connections':len(exact),'seq64_medians':medians,'seq64_records':list(exact.values()),'stderr_sha256':hashlib.sha256((directory/'server.stderr').read_bytes()).hexdigest()})
 ids={v['conversation_id']:i for i,v in enumerate(json.loads((directory/'routing.json').read_text()))};chosen={}
 for v in rows(directory,'replay_memory_drop'):
  index=ids[v['conversation']]
  if 32<=index<127 and v['items']>32 and index not in chosen:chosen[index]=v
 assert len(chosen)==95
 selected=list(chosen.values());replays.append({'directory':relative,'n':len(selected),'medians':{k:statistics.median(v[k] for v in selected) for k in ['freed','items','wire_bytes','inline_storage_bytes']},'minimum_freed':min(v['freed'] for v in selected),'maximum_freed':max(v['freed'] for v in selected),'values':selected})
for relative in ['sql-fields-eight-before','sql-fields-eight-refined']:
 items=[v for v in rows(r/relative,'replay_memory_drop') if v.get('domains') and v['items']>32];assert items
 grouped=collections.defaultdict(list)
 for v in items:
  for key,(count,amount) in v['domains'].items():
   if count:grouped[key].append(amount/count)
 fields.append({'directory':relative,'per_part_release_median_bytes':{k:statistics.median(v) for k,v in grouped.items()},'scope':'Exploratory root-O0/replacement-allocator release groups. Teardown can overlap other native work; do not interpret them as exact additive heap ownership.'})
result={'accepted':True,'sqlite':sql,'replay':replays,'fields':fields,'scope':'Private root-O0/default-feature diagnostic binaries, separate from ordinary O3 native results. SQLite db_status gives approximate per-connection pager/schema/statement counters. Normal8-history replay uses95untouched sessions32..126, excluding active prefixes, transferred observers and slow-last-session. Global allocator before/after differences retain all outliers and can overlap asynchronous teardown; report medians/ranges, not an exact total925MiB partition. Shared owners can survive replay release.'}
(r/'ownership-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'sqlite_products':len(sql),'release_products':len(replays)}))
