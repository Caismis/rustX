from pathlib import Path
import ast,collections,json,re,struct,hashlib
R=Path(__file__).resolve().parent
sha=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
audit={'script_sha256':sha(Path(__file__)),'scope':'Independent read-only recomputation of retained raw diagnostics; not formal cohort acceptance or a new product run. SQL/column/WAL no-live; profile live-large is a separate sampled instrumented run.','sql':{},'columns':{},'wal':{},'profile':{}}
for label in ['baseline','complete']:
 p=R/f'sql-{label}-tx-no-live'; phases=json.loads((p/'phases.json').read_text());ph={x['phase']:x['monotonic_ns'] for x in phases};sample=json.loads((p/'sample.json').read_text()); assert sample['measured']==32 and sample['oracle']=='passed';rows=[];first={};warm=set();warm_cached=set()
 for line in (p/'prepares.jsonl').open():
  x=json.loads(line);assert 'error' not in x
  if x.get('first_call_stack'):first.setdefault(x['sql'],x['first_call_stack'])
  if ph['after_initialization']<=x['monotonic_ns']<ph['after_turns']:warm.add(x['sql'])
  if ph['after_initialization']<=x['monotonic_ns']<ph['before_measured_turns'] and x['flags']==1:warm_cached.add(x['sql'])
  if ph['before_measured_turns']<=x['monotonic_ns']<ph['after_turns']:rows.append(x)
 c=collections.Counter(x['sql'] for x in rows);flags=collections.Counter(x['flags'] for x in rows);owners=collections.Counter()
 for x in rows:
  if x['sql']=='BEGIN IMMEDIATE':
   st=x['first_call_stack'];keys=[f for f in st if f and ('ConversationStore>::' in f or 'ConversationStore as ' in f)];assert keys;owners[keys[0]]+=1
 control={'COMMIT','ROLLBACK','BEGIN IMMEDIATE','BEGIN DEFERRED'};nc={k:v for k,v in c.items() if k not in control};ident=json.loads((p/'identity.json').read_text())['build_identity']
 audit['sql'][label]={'turns':32,'prepare_count':len(rows),'per_turn':len(rows)/32,'flags':dict(flags),'unique_sql':len(c),'control_prepares':sum(c[k] for k in control),'business_prepares':sum(nc.values()),'business_sql_count':len(nc),'begin_immediate_owners':dict(owners),'warm_plus_steady_unique_sql':len(warm),'warm_cached_unique_sql':len(warm_cached),'identity':{k:ident[k] for k in ['head','production_tree','sha256']},'phases':ph,'sha256':{f:sha(p/f) for f in ['prepares.jsonl','phases.json','identity.json','sample.json']},'queries':[{'count':n,'sql':sql,'first_stack':first.get(sql)} for sql,n in c.most_common()]}
for case in ['short-small','short-large']:
 audit['columns'][case]={}
 for label in ['baseline','complete']:
  p=R/f'columns-{label}-{case}';b=json.loads((p/'before_measured_turns.json').read_text());a=json.loads((p/'after_turns.json').read_text()); cols={t:{k:v-b['tables'][t]['column_value_bytes'].get(k,0) for k,v in row['column_value_bytes'].items()} for t,row in a['tables'].items()};totals={t:sum(v.values()) for t,v in cols.items()};n=a['tables']['events']['rows']-b['tables']['events']['rows'];assert n==256
  if label=='complete':assert 'observation_json' not in a['tables']['events']['column_value_bytes'];assert a['equal_event_observation_json']['status']=='retired_layout_absent'
  audit['columns'][case][label]={'event_rows':n,'all_column_value_bytes':sum(totals.values()),'events_column_value_bytes':totals['events'],'request_three_tables_bytes':sum(totals[k] for k in ['request_source_pages','request_source_nodes','request_source_roots']),'events_columns':cols['events'],'table_bytes':totals,'retired_layout_status':a['equal_event_observation_json'],'sha256':{f:sha(p/f) for f in ['before_measured_turns.json','after_turns.json','identity-before.json']}}
for label in ['baseline','complete']:
 for case in ['short-small','short-large']:
  for engine in ['rust','pi']:
   name=f'wal-{label}-{case}-{engine}';p=R/name;b=json.loads((p/'before_measured_turns-database.json').read_text())[0];a=json.loads((p/'after_turns-database.json').read_text())[0];owners=collections.defaultdict(set)
   for snap in [b,a]:
    for name_,pg,*_ in snap['pages']:owners[pg].add(name_)
   phase=0;pending={};commits=0;by=collections.Counter();sizes=collections.Counter();tx=0;markers=[]
   for raw in (p/'calls.strace').open():
    m=re.match(r'(\d+)\s+(.*)',raw)
    if not m:continue
    tid,call=m.groups()
    if '<unfinished ...>' in call:assert tid not in pending;pending[tid]=call.split('<unfinished ...>')[0];continue
    m=re.match(r'<\.\.\. \w+ resumed>(.*)',call)
    if m:assert tid in pending;call=pending.pop(tid)+m[1]
    if 'UNIX-STREAM' in call and 'before_measured_turns' in call:assert phase==0;phase=1;markers.append('before_measured_turns')
    if 'UNIX-STREAM' in call and 'after_turns' in call:assert phase==1;phase=2;markers.append('after_turns')
    if phase!=1:continue
    m=re.match(r'pwrite64\(\d+<([^>]+-wal)>, ("(?:\\.|[^"\\])*"(?:\.\.\.)?), (\d+), (\d+)\) = (\d+)$',call)
    if not m:continue
    fn,quoted,n,off,ret=m.groups();n,off,ret=map(int,[n,off,ret]);assert fn==b['path']+'-wal';assert n==ret;sizes[n]+=1
    if n==24:
     payload=ast.literal_eval('b'+quoted);assert len(payload)==24;pg,npages=struct.unpack('>II',payload[:8]);assert (off-32)%4120==0;by['|'.join(sorted(owners[pg])) or '<unmapped>']+=1;tx+=1
     if npages:commits+=1;tx=0
   assert not pending and phase==2 and tx==0;assert sizes[24]==sizes[4096];frames=sum(by.values());assert frames==sizes[24];j=sum(by[x] for x in ['event_observation_readiness','event_observation_readiness_holes_idx']);t=sum(by[x] for x in ['transcript_observation_readiness','transcript_observation_readiness_holes_idx'])
   audit['wal'][name]={'write_commits':commits,'write_commits_per_turn':commits/32,'frames':frames,'frames_per_turn':frames/32,'frame_bytes':frames*4120,'frame_bytes_per_turn':frames*4120/32,'journal_readiness_frames':j,'transcript_readiness_frames':t,'journal_readiness_pct':100*j/frames,'j_and_t_readiness_pct':100*(j+t)/frames,'successful_wal_pwrite_sizes':dict(sizes),'frame_objects':dict(by.most_common()),'phase_markers':markers,'sha256':{f:sha(p/f) for f in ['calls.strace','before_measured_turns-database.json','after_turns-database.json','identity-before.json','phases.json']}}
for label in ['baseline','complete']:
 p=R/f'profile-{label}-live-large-cpu/steady-collapsed.txt';total=0;prep=0;owners=collections.Counter()
 for line in p.open():
  st,n=line.rsplit(' ',1);n=int(n);total+=n
  if 'sqlite3_prepare' in st:
   prep+=n;fs=st.split(';');i=next(i for i,f in enumerate(fs) if 'sqlite3_prepare' in f);owner=next((f for f in reversed(fs[:i]) if 'rustx::' in f and not f.startswith('<rusqlite')),'unresolved');owners[re.sub(r'<[0-9a-f]{16}>','',owner)]+=n
 audit['profile'][label]={'samples':total,'prepare_inclusive_samples':prep,'prepare_nearest_owners':dict(owners.most_common()),'sha256':sha(p),'interpretation':'Sampled inclusive subtree only; not exclusive costs or a predicted improvement. Different observer mode from SQL diagnostics.'}
out=R/'independent-storage-audit.json';out.write_text(json.dumps(audit,indent=2));print(out)
