# 候选剩余计算与读取审计

## 范围与结论

本次只读审查 `688e7c3e85a72ae7d3745aff7419fdcff21c4ec8`，工作树 `/home/capi/.codex/worktrees/pr485-pi-performance/rustX`，读取时 `git status --short` 为空。没有运行产品、编译、测试或基准；候选新 CPU profile 尚未生成。根代理报告候选已通过 1,379 项测试、1 ignored、fmt/full Clippy，本文件不独立认证这些检查。

已完成的 lazy checkpoint、原子 ModelTurnSettlement family、聚合 read-domain transaction 和 SQL statement 复用覆盖了此前已证实的主要重复工作。源码仍有可优化的重复计算，最明确的是发布状态冻结时的深克隆及非 owner 域的完整相等性见证；但旧 profile 不能证明它们仍是候选的大头。没有发现可以直接删除、同时保留现有功能的另一个整块主要读取路径。不能因此声称候选已无优化空间，也不能把之前的 75 个 publication 样本当成候选仍未完成的 75 个样本。

## 使用的旧观测，不能作候选收益估计

重新读取 `joint-major/profile-{baseline,joint}-live-large-cpu/steady-collapsed.txt`，将每行最后一个整数作为样本权重、按对应栈符号出现与否计数。两个诊断均为保留的旧 live short-large 测量，不是本候选；表中 inclusive 桶可以重叠，不能相加，样本不是操作次数也不是 wall-time 占比。

| 栈中出现的路径 | 旧 baseline | 旧 joint |
| --- | ---: | ---: |
| 所有样本 | 360 | 328 |
| `PublicationDraft>::encode` | 124 | 75 |
| `bounded_structural_len` 且位于 publication 栈 | 26 | 32 |
| `capture_working_seed` | 16 | 12 |
| `ReadDomainCut>::read_with_trace` | 34 | 39 |
| `sqlite3LockAndPrepare` | 61 | 56 |
| `native_request::read` | 0 | 3 |
| `native_request::persist` | 0 | 1 |

旧 joint 的 `CheckpointSeed>::checkpoint_prepared` 在 publication 栈中为 40 个样本；该函数现已拆为借用的 `capture_checkpoint` 和按需 materialization，因此不能沿用其旧归因。旧 baseline 没有 `native_request` 命名的实现，0 仅表示该符号未出现，不表示旧版无请求读取成本。旧 SQL 诊断 `complete-costs/sql-baseline-no-live/prepare-counts.json` 的 32 measured turns 共 18,682 prepare calls、171 个 `(flags, SQL)` 形状，亦不能直接套到新增的缓存实现。

Collapsed 文件 SHA-256：

- baseline: `a83c2a93733a67079101e5e06f7656e4631c2a07ffce69fdf839e0f3d1c6bb94`
- joint: `0e5bf0fd899e5ab10a5502b95dc4e8f46c0f1357c27117785e31518b24f2b7d0`

## 仍然存在的具体路径

### 1. 发布冻结的克隆、域相等性：可优化，但尚无候选主要耗时证据

`src/runtime_client/host.rs:1034` 的 `commit_display` 在一次完整 native transition 后冻结并编码，然后安装 cursor。`src/runtime_client/projection.rs:6175` 的 `finish_publication` 每次实际发布调用 `capture_working_seed`；`projection.rs:6574` 仍 `snapshot.clone()`，并克隆 head bindings、frontiers、content metadata、cuts 等有限集合。`projection/prepared_capture.rs:51` 的 `inherit` 虽共享已经 prepared 的结果，却对 17 个非专用 owner 域做 `PartialEq`，再用 `encoding_equal`（同文件约 210）检查编码相等性是否可证明。它不会构造 JSON/hash 字节或扫描字符串内容，但仍遍历容器/字段；字符串内容仍可能被 Eq 扫描。遇到浮点或非空 map 时保守重建，是因为 `-0.0` 与 `+0.0` 及 JSON object insertion order 不能靠普通 Eq 判断 wire 字节相同。

可以保留全部功能的结构性实现是：在实际变更域时创建新的不可变域 owner，工作状态和已发布 seed 共享旧域，变更使用 copy-on-write；prepared capture 直接绑定同一个 owner。当前 `PreparedTraceHead` / `PreparedCapabilityHead` 已使用该模式。这能同时消除未变化域的深克隆与 Eq/ambiguity traversal，比再添 JSON/hash 缓存更直接。

这不是把 `RuntimeClientSnapshot` 外层套一个 Arc 就能完成：其 `Vec`/嵌套字段仍有许多独立 mutation sites，外层 `Arc::make_mut` 会继续复制整份 snapshot。要取得实质收益，必须把所有被共享域的写入口统一到 owner 更新，保证 trace cut stamp、hydration、replacement/eviction 和历史 seed 都不会原地改旧值。错误地复用 owner 会导致旧 cut 内容变化；未经证明直接跳过 Eq 会返回旧 metadata/序列化结果。此时删掉检查会损失正确性，完成按域所有权改造则无需损失功能。旧 joint seed 只有 12/328 inclusive 样本，family 又已减少发布频次，所以目前不具备“必然是下一大头”的证据。

### 2. 精确 structural JSON 计长：仍在正常发布路径，不能用普通 serde/上界替换

`projection.rs:597,630` 最终调用 `checkpoint.rs:404` 的 `bounded_structural_len_with_budget`。候选 fit certificate 已避免可证明安全时的重复 admission visitor；普通 delta 不再为此构造完整 owned checkpoint。剩余操作使用真正的 structural serializer 写入计数 sink，得到 exact wire length，而非留下一个临时 JSON byte buffer。

必要性有两部分：

- `structural_json.rs:173` 根据 schema 将无安全整数上限的 native `u64` 编成十进制字符串，即使数值是 1；受约束 native quantity 与 opaque JSON 的规则又不同。因此“当前整数都小”不代表普通 `serde_json` 字节相同。schema resolver/visitor 的简化必须保持这些规则与错误行为。
- `projection.rs:6484` 用 exact byte count 驱动 16 MiB replay ring 的 evict 和 cut 生命周期。把保守 fit 上界当实际大小，会提前淘汰、改变可重放范围与过期时点；只在传输时才编码则会延迟发现不可编码值，使 cursor/失败可见性变化。

若新 profile 仍确认这是主要成本，可研究编译后的 schema plan 或带 exact encoded-size 的不可变域/metadata片段，以复用不变部分；这仍需处理 revision 数位变化、JSON escaping、schema union/opaque fields 和 replacement。单纯保留当前计长产生的字节并不会减少该次编码工作，还会引入 replay 额外常驻字节；本轮 in-process benchmark 也不能直接假设存在下一次 transport encode 可省。没有找到可以无条件删除的第二遍正常完整 checkpoint 编码。

### 3. 无 live subscriber 仍维护发布历史：真实差异，但直接停用会改功能

`commit_display` / `finish_publication` 不以 subscriber 数量为条件跳过发布与 replay；`read_domain_candidate`（`projection.rs:7398`）才在没有 subscriber 且没有显式读请求时跳过物理 read-domain refresh。其余工作维持进程内全局 cursor、有限重放、已发布 cut、source failure 和 late reader 的一致状态。

Pi 的对照实现 `packages/durable/src/harness/view.ts:75,147,175` 则在首 observer 时 mount、最后 observer detach 后删除 mount；`advance`（同文件约 200–245）根据 commit changes 生成 ops，用 `applyImmutable` 和必要的 entries 数组复制推进视图。它也会复制受影响的 entries 数组，并非零克隆。`session/observation.ts:16,226` 的 watch 按 100 个 pending frames 限制积压，overflow 给 replacement，而不是 rustX 的全局 exact-byte replay 窗口。

因此按 Pi 模式在无人订阅时直接关掉 rustX projection，会改变 cursor-zero replay、已有 cursor 重新订阅、旧 cut/read evidence 和错误呈现；不是只降低持久性。若产品选择改变这些 API 合同才可全面删除该成本，本次用户要求保留功能，不能静默这样做。按域共享能减轻这部分成本而保留语义。

### 4. 读取域已合并，继续消除读取需要新的权威所有权证明

`projection.rs:1979` 的 live 分支现在调用一个 `observation_checkpoint_head`；`src/durable/sqlite/observation_checkpoint.rs:8` 在同一 transaction 下依次读 transcript、response facts、occupancy、trace total、projection head，复用 transcript/cut 验证，保持原错误顺序。`host.rs:1924–1966` 只允许一个 bounded read in flight，合并新的读需求；`projection.rs:7462` 只安装仍匹配当前 fence 的结果。没有 subscriber/显式请求时，该刷新已跳过。

剩余查询提供的是完整 cut 上的持久化权威事实：transcript 保留 compaction 之外的消息，response decoration 需要工具输出及 terminal 归属，occupancy/projection 受请求与 compaction 边界影响。仅以本次 observer event 代替查询，会漏掉 bootstrap/late reader、独立 durable owner、历史 cut 或失败修复。仅按 Journal 序号缓存还不足以证明 canonical/transcript/layout/source 身份未变。可以进一步由已验证 receipt 携带不可变的完整域事实，但需要各事实的所有 producer、独立 owner 和 cut 失效机制统一；当前源码没有显示另一个已准备好、可直接复用却被忽略的完整域结果。

不能用旧 39/328 的 read-with-trace 桶给这个新聚合实现估价；旧路径有多个事务/重复验证，其直接冗余本轮已经改掉。

### 5. 历史请求 typed decode 与源认证：存在，不宜在低证据下继续加缓存

`src/durable/sqlite/native_request.rs:250` 的 fresh-start `authenticate` 已用实际 stored bytes 验证既有 typed 输入，避免重新解码大 configuration；但 `metadata` / `full`（约 259–277）在独立读取时仍验证 digest 并 typed decode，共享 configuration 不意味着各读取上下文可无条件信任以前解码的对象。当前 compact composed records 仍保留 byte/hash、geometry/path/cut 的认证；这些是 bounded historical reconstruction 与错误/损坏拒绝的保证。

只省掉 typed decode 会接受 digest 一致但类型不合法的 payload；只省掉 byte compare/hash 会把内存 witness 与实际存储内容解绑。安全缓存必须绑定实际 bytes/owner 和外部写入失效范围，而非只记 request id。旧 joint 对 `native_request::read` 仅 3 个 inclusive 样本、persist 1 个，当前 fresh-start 又已减少解码，不能据此继续把此处当主要瓶颈。

## Pi / DeepSeek 源码对照与可借鉴边界

本审查 Pi 固定到 `90d863f7c1183b965f099855715d6e88c7b8a52c`，DeepSeek 固定到 `687f282e8625c6b8d11ff58211a90524be2e4317`。Pi 使用实际 benchmark `benchmarks/runtime/pi-http.mjs:21,26,66` 的 durable **SQLite** 路径，不使用其另一个 JSONL adapter 推断持久性。

Pi `storage/sqlite/node.ts:76–117` 按 SQL 文本跨 transaction 复用 statement；`storage.ts:187–206` 一次 commit 批量处理 writes 和 document actions；`node.ts:194–196` 使用 WAL/NORMAL。其 commit 仍读 metadata、校验 global ids/document actions、写多张表，不是“一次 write 无读取”。候选已采用 statement 复用和同次原子 model settlement 单 family 发布/ready 释放，不能再把旧的四次 release 成本列为尚未实施的大头。

DeepSeek `session-persistence-jsonl/src/storage.ts:274–308` 对 live events 做 structuredClone，200 ms 定时合批 drain；实际 append 会 materialize/验证批次，底层写入调用 filesystem sync。`session-checkpoint-policy/src/index.ts:35,72,80` 在 model/tool/pre-step 边界等待 flush。其 `session-projection-cache/src/index.ts:316–317` 的 turn/end flush 是 fire-and-forget；SDK `server.ts:240–256` 的 wait 等 idle/children，不等待最终 flush。其 SDK 观察表面没有 rustX/Pi 的逐 token partial publication（benchmark 的 reference contract 明确区分）。

可借鉴的是：在明确的语义边界合并事件，使用不可变增量状态，并将真实必要的持久化绑定到副作用边界。本候选已据此做 ModelTurnSettlement family；把 rustX 的所有 durable readiness/逐 delta 观察改成任意 200 ms 延后，会改变消费者看到内容与 failure 的时序，且 SDK idle 不是同一 durability completion boundary。DeepSeek 只能作补充参考，不能用其少做的功能作为同等功能加速证据。

## 下一次证据应回答什么

候选测量应先核实 publication 次数、release transaction 次数、SQL prepare miss 数量确实按设计下降，再看剩余 CPU 栈。若 `capture_working_seed`/`PreparedCaptures::inherit` 成为主要桶，则按域不可变 owner 是明确可保留功能的结构性工作；若 exact structural encoding 成为主要桶，则优化 schema/immutable encoded facts，而不是改 replay 计费口径；若 read-domain 仍大，需区分 SQL 执行、等待和验证，不能继续按旧多事务路径归因。仅存在某函数或几条样本不足以断言“还有大头没做”。本文件没有给候选性能百分比、没有声称追平 Pi，也没有批准删除上述功能合同。


## 后续观测与第二候选闭环（独立保留第一候选证据）

上述审计写成后，`complete-costs/profile-{baseline,complete}-live-large-cpu` 完成。这里 baseline 是此前 joint，complete 是 `688e7c3e85a72ae7d3745aff7419fdcff21c4ec8`；均为同一 250 Hz、32 measured short-large live turns 的诊断，包含产品线程及驱动开销。独立按 gperftools `<5Q` header / `(count, depth, PCs)` 原始记录重数为 312 与 223，采样间隔均 4,000 µs；与 collapsed 权重总和相同。没有用样本比例推导 wall-time 或因果加速。

| 观察路径 | fresh baseline | 第一候选 complete |
| --- | ---: | ---: |
| 全部 CPU 样本 | 312 | 223 |
| PublicationDraft encode | 78 | 52 |
| 其内互斥：capture | 35 | 26 |
| 其内互斥：exact length | 40 | 25 |
| 其内互斥：其余 | 3 | 1 |
| capture_working_seed，位于上述 encode 外 | 11 | 19 |
| 其内明确 RuntimeClientSnapshot clone | 8 | 14 |
| ReadDomainCut read_with_trace | 32 | 17 |
| sqlite3LockAndPrepare | 62 | 16 |

第一候选 capture 的 26 个样本进一步互斥分区为：prepared transcript 重建 12、attempt 5、messages 2、message_descriptors 1、其余未缓存 budget preflight 2、其余 4。没有把 `capture_checkpoint` 函数名当成完整 snapshot materialization；它包含借用的 admission 和 metadata。exact length 的 25 个样本中，11 个栈进入 ProjectionMetadata，另外 14 个属于事件内容或其他工作。无 `fit_checkpoint` 样本不代表该路径绝不运行。seed 的 19 个中 14 个明确包含 snapshot clone，其余 5 个未进一步推断；内联可能隐藏相等性函数名。

raw / collapsed SHA-256：

- fresh baseline raw: `d854a399958911a845b65cc5f4f86b3dd03d6c6f26a66efe971136a35ceb9664`
- fresh baseline collapsed: `1e16b40b9bfd5b46f3a12f90efc142a14713cc6eba85aa27d16184184af95c9c`
- first candidate raw: `144e06f11ecfd153ba9d57776bd8d4b15c61fcebed15e18b1911e2bceaf4b59a`
- first candidate collapsed: `89824d74284d84e1b776585312085c69500993c8c0a09e9846a8d9d939072257`

### 从新观测定位并已实施的额外优化

这次没有停在“transcript 是必要工作”的判断。`PreparedCaptures::inherit` 原先比较整个 `RuntimeClientTranscriptPage`；后台刷新即使保留完全相同的 entries，`source_cut` 或 whole-conversation statistics 改变也会废掉整页 prepared owner。随后每个旧条目重新经过 `bounded_clone` 的 JSON 序列化、Value 容器校验、typed 解析，再计长。上述 12 个 transcript 样本实际落在这些 prepared 初始化路径；不是多次显式 snapshot API 或压力 replacement 的证据。

第二候选据此已聚焦拆分为 `transcript_entries`、`transcript_deferred_entries`、`transcript_statistics` 三个 bounded prepared owner，删除旧整页 owner。entries 的身份绑定 conversation id 与完整 entries，保留原 float/map 不可证明精确相等时重建规则；deferred 和 statistics 独立失效。页 envelope 的 source_cut/content/collections/inherited_through/next_cursor 从当前 seed 取值，延迟到实际 materialization 再组装整个 page。prepared 缓存只持有规范化 entries，不同时保留另一整份 page。整个系统的 owner 数由 19 增至 21。

原 deferred→statistics→entries 的共享入场顺序不变；现有 `Capture::prepared` 在剩余预算不足时仍执行真实原构造。因此重用不会把大预算下能入场的旧条目硬塞进小预算。FitBudget 按字段组合并仅作充分上界，最终 exact structural length 与 replay 计费规则不变。该改动不尝试全面重构其他 17 域或改变无订阅 replay 语义。

已编写四个针对性差分回归，交由根代理统一运行：cut 数位增长及当前 envelope/历史 seed 稳定、statistics 与 deferred 独立仅重建一个域、前置 messages 消耗共享预算的压力、entries 内 signed zero/JSON map order/超容器/wide integer。每个变体都和保留的原 capture/fit 实现比较字节；cut-only 情况还断言零 normalized-domain rebuild、零完整 snapshot materialization。此处只记录实现和测试意图，不在测试结果返回前声称已通过或给出收益。

SQL prepare 的余下 16 个样本中有 7 个路径进入 `projection::completion_at`。该具体来源已发给根代理处理固定 SQL 缓存；事件代理独立审查剩余持久数据重复。第二候选后续检查、build 和正式矩阵写入 `complete-costs-final`，第一候选目录只读冻结，不覆盖其原始结果。
