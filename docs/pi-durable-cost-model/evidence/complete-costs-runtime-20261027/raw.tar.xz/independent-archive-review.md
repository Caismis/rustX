# Independent archive and final validation review

Read-only review of the final packer, portable verifier and formal validation bindings. No archive was packed or replayed, and no product, test binary, build, profiler or decompressor was run. Pure Python AST/parser checks below use temporary synthetic fixtures only.

Reviewed file identities:

- `pack-evidence.py`: `f6e6ec6fa302988290f92d390b6098cd4bd138f4f5c6889d604f45c226ae2ddf`
- `verify-archive.py`: `7c232c4558c0b931376da62172783e6319654d1e94357e950917dc21ee0af3ad`
- `audit-complete.py`: `b1e8d1c4a1816c2d3571c8ab345eb27cffdc358f4e14c097f63f3146af83bd8e`
- `pass1-freeze.json`: `9f87c229edd09043742140657a45cb77a01e4d63ce6acdaea5cd4d4573a2605d`

No remaining actionable integration defect was found in the inspected pack/verify paths. This is source review plus parser testing, not successful verification of the eventual real archive.

- `pack-evidence.py:303–323` compares the historical inventory and exclusions with the immutable pass1 freeze, then checks each historical payload hash/size before mounting it under `pass1/`. Lines 363–370 verify the complete produced archive and recheck source inventory/fingerprints. The whole retained pass1 input set is preserved; compiled binaries and declared dependency/cache exclusions remain deliberately excluded.
- Final formal inputs are loaded only from the final root's direct/final cohorts. The packer requires 120 + 120 + 36 products and final successful source-bound checks. `verify-archive.py:151–172` verifies every archived pass1 entry against the freeze and checks distinct candidate identities. Neither audit searches `pass1/` for final successful check queues or cohort products.
- `verify-archive.py:94–148` extracts regular non-sparse files only into a fresh tree, rejects unsafe/noncanonical paths, duplicates, and unexpected member counts/sizes, then compares all streamed file bytes against the complete manifest. `verify_tree` checks the extracted inventory and all hashes again after raw auditing, including rejecting added files/directories or symlinks.
- Portable commands are exact allowlisted relative raw-only argv at `verify-archive.py:175–199`; outputs are moved outside raw. Archived identity/freeze inputs are passed explicitly. Formal `phase_binding` only compares recorded absolute paths as provenance; raw-only `identities` and validation skip actual external binary/Git/source access. Diagnostic build/profile host checks are likewise guarded by raw-only. The verifier compares recomputed product counts, paired groups/products/admissions, profile samples, columns, SQL, WAL, command windows, and build/report hashes against the preserved strict reports without claiming fresh host identity verification.
- `audit-complete.py:520–603` requires stdout and stderr for every successful check, reconciles libtest lines with summaries, verifies exact correctness commands/artifacts, and requires identical before/after src/tests/Cargo hashes equal to the candidate O3 build input map. Strict mode also checks the current committed bytes and complete tracked src/tests set. Old successful queues with different source hashes remain historical and cannot satisfy final validation.

One coverage gap was found and reported: the required passing leaf-name set initially omitted the four second-candidate transcript tests. The author added all four, so unchanged source hashes cannot substitute for actually selecting and passing these regressions:

- `incremental_transcript_cut_changes_reuse_rows_and_keep_current_envelope`
- `incremental_transcript_statistics_and_deferred_rows_have_independent_admission`
- `incremental_transcript_split_capture_keeps_shared_budget_pressure_exact`
- `incremental_transcript_row_ownership_keeps_opaque_json_encoding_exact`

Pure parser checks passed (12): six unsafe path forms were rejected (`../escape`, `/absolute`, `a/../escape`, `a//b`, backslash-separated path, `./a`); one valid complete synthetic archive was accepted; mutation of an extracted payload was rejected; traversal, symlink and duplicate-member archives were rejected; duplicate manifest JSON keys were rejected. AST parsing passed for packer, verifier and formal auditor. No claim is made that these synthetic cases replace the required later fresh extraction and both raw-only audits of the actual finished archive.
