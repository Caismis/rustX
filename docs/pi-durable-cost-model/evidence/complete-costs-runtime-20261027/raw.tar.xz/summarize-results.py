#!/usr/bin/env python3
"""Render complete accepted audit JSON only; never runs products or re-reads raw counters."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = ('short-small', 'short-large', 'stream', 'large', 'tool', 'cancel')
MODES = ('no-live-subscriber', 'live-subscriber')
NATIVE_CASES = ('short-small', 'short-large', 'stream', 'large')
ENGINES = ('rust', 'pi', 'deepseek')
MEAN = 'mean_turn_ms'
MEDIAN = 'median_measured_turn_ms'
CPU = 'through_cleanup_self_cpu_ms'
WRITE = 'through_cleanup_process_write_bytes'
MEMORY = 'max_sampled_anon_pss_mib'
TURN_CPU = 'turn_cpu_ms_per_turn'
TURN_WRITE = 'turn_write_bytes_per_turn'
DISPLAY_METRICS = (MEAN, MEDIAN, CPU, WRITE, MEMORY, TURN_CPU, TURN_WRITE)


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def number(value, digits=3):
    if value is None:
        return '不可用'
    require(type(value) in (int, float) and math.isfinite(value), 'nonfinite/non-numeric report metric')
    return f'{value:,.{digits}f}'


def percent(value):
    return '不可用' if value is None else f'{value:+.2f}%'


def ratio_range(group):
    row = group['summary']
    return f"{number(row['median'])} [{number(row['minimum'])}, {number(row['maximum'])}] ({row['available']}/5)"


def percent_range(group):
    row = group['percent_change']
    return f"{percent(row['median'])} [{percent(row['minimum'])}, {percent(row['maximum'])}] ({row['available']}/5)"


def table(headers, rows):
    def cell(value):
        return str(value).replace('|', '\\|').replace('\n', '<br>')
    return '\n'.join(['| ' + ' | '.join(map(cell, headers)) + ' |',
                      '| ' + ' | '.join('---' for _ in headers) + ' |',
                      *('| ' + ' | '.join(map(cell, row)) + ' |' for row in rows)])


def mode_label(mode):
    return 'no-live' if mode == MODES[0] else 'live'


def paired_index(data, stage):
    expected = (120, 60, 1410)
    require(tuple(data[key] for key in ('derived_products', 'valid_comparisons', 'checked_requests')) == expected,
            stage + ' incomplete product/request coverage')
    require(len(data['products']) == 120 and len(data['table']) == 12, stage + ' product/table inventory differs')
    groups = {}
    for group in data['groups']:
        key = group['mode'], group['case'], group['metric']
        require(key not in groups and group['mode'] in MODES and group['case'] in CASES, 'duplicate/unknown paired group')
        require(len(group['pairs']) == 5 and [row['pair'] for row in group['pairs']] == list(range(5)), 'paired group must preserve all five pairs')
        require(group['summary']['n'] == group['percent_change']['n'] == 5, 'paired summary sample count differs')
        groups[key] = group
    cells = {(row['mode'], row['case']) for row in data['table']}
    require(cells == {(mode, case) for mode in MODES for case in CASES}, stage + ' incomplete twelve cells')
    for mode, case in cells:
        for metric in DISPLAY_METRICS:
            require((mode, case, metric) in groups, stage + ' missing requested metric ' + metric)
    return groups


def native_index(data):
    require(data['accepted'] is True and data['errors'] == [] and data['durability_equivalence'] is False,
            'native reference audit missing acceptance/durability boundary')
    require(tuple(data[key] for key in ('derived_products', 'valid_comparisons', 'checked_requests')) == (36, 12, 414),
            'native reference coverage differs')
    groups = {(row['case'], row['engine']): row for row in data['groups']}
    extra = {(row['case'], row['engine']): row for row in data['supplementary_table']}
    require(len(data['groups']) == len(groups) == len(data['supplementary_table']) == len(extra) == 12,
            'native reference group inventory differs')
    require(set(groups) == set(extra) == {(case, engine) for case in NATIVE_CASES for engine in ENGINES},
            'native reference case/engine inventory differs')
    require(all(row['samples'] == 3 for row in [*groups.values(), *extra.values()]), 'native reference needs all three repetitions')
    return groups, extra


def absolute_pair(group, digits=3):
    return f"{number(group['denominator_values']['median'], digits)} → {number(group['numerator_values']['median'], digits)}"


def native_measure(group, metric, factor=1, digits=3):
    value, extent = group['medians'][metric], group['ranges'][metric]
    lo, hi = (None, None) if extent is None else extent
    scale = lambda item: None if item is None else item * factor
    return f"{number(scale(value), digits)} [{number(scale(lo), digits)}, {number(scale(hi), digits)}] ({group['available_samples'][metric]}/3)"


def render(report, audit_name, audit_sha, script_sha):
    require(report['accepted'] is True and report['errors'] == [] and report['stage'] == 'all',
            'requires an accepted complete all-stage audit')
    require(report['mode'] in ('strict', 'raw-only') and report['recorded_build_identity_verified'] is True,
            'missing recorded identity verification')
    require(report['strict_identity_verified'] is (report['mode'] == 'strict'), 'audit mode/strict identity flags differ')
    require(set(report['datasets']) == {'direct', 'final', 'three-engine'}, 'unexpected dataset inventory')
    direct = paired_index(report['datasets']['direct'], 'direct')
    pi = paired_index(report['datasets']['final'], 'final')
    native, supplement = native_index(report['datasets']['three-engine'])
    candidate, baseline = report['identities']['complete'], report['identities']['baseline']
    lines = [
        '# Final complete-costs audited tables', '',
        f"来源：`{audit_name}`，SHA256 `{audit_sha}`；审计模式 `{report['mode']}`。",
        f"候选 `{candidate['head']}` / binary `{candidate['sha256']}`；基线 `{baseline['head']}` / binary `{baseline['sha256']}`。",
        f"汇总脚本 SHA256 `{script_sha}`。本文件只格式化已接受审计的派生字段，不重读原始计数、不合并探索样本、不重新选样。",
        '',
        '正式范围：direct 120、fresh Pi 120、native reference 36 个产品；每个 direct/Pi cell 固定五对，三引擎每个 case/engine 固定三次。no-live/live × 六 case 全部展示。五对仅为描述统计，不满足原七对完整追平门槛；不作跨 case 或跨 mode 的整体追平结论。',
        '',
        '## Direct：最终候选 / 上轮 joint', '',
        '百分数为审计中五个逐对百分比的中位数；负值更低。wall均值使用 `mean_turn_ms`，wall中位使用每个产品的 `median_measured_turn_ms`，两者均非跨产品混池。完整CPU/进程写入是 through-cleanup 累计值，包含初始化、历史、验证与关闭；匿名PSS为所有已采样点的最大值。', '',
    ]
    rows = []
    for mode in MODES:
        for case in CASES:
            rows.append([mode_label(mode), case, *[percent(direct[mode, case, metric]['percent_change']['median'])
                         + f" ({direct[mode, case, metric]['summary']['available']}/5)" for metric in (MEAN, MEDIAN, CPU, WRITE, MEMORY)]])
    lines += [table(['模式', 'case', 'wall均值 Δ%', 'wall中位 Δ%', '完整self CPU Δ%', '完整进程write bytes Δ%', '采样匿名PSS Δ%'], rows), '',
              '## Fresh Pi：最终 rustX / Pi Durable', '',
              '以下为逐对比值的中位数 [最小值, 最大值]；1×为相等，大于1×表示 rustX 较高。括号保留可用配对数。CPU/写入/PSS与 direct 表使用同一边界。', '']
    rows = [[mode_label(mode), case, *[ratio_range(pi[mode, case, metric]) for metric in (MEAN, MEDIAN, CPU, WRITE, MEMORY)]]
            for mode in MODES for case in CASES]
    lines += [table(['模式', 'case', 'wall均值 × [min,max]', 'wall中位 × [min,max]', '完整self CPU × [min,max]', '完整write bytes × [min,max]', '采样匿名PSS × [min,max]'], rows), '',
              '## Warm：四个 case/mode 的绝对每turn成本', '',
              '`short-small`先运行8个历史turn，`short-large`先运行64个历史turn，之后均测量32个turn。wall是每个产品32个turn延迟的中位数，再取五产品中位数；CPU和写入是测量区间计数差/32，再取五产品中位数。/proc CPU计数以100 ticks/s换算，单个累计端点粒度10ms；这不是100Hz profiler采样，真实计数零会保留。', '',
              'Direct批次：每格为上轮 joint → 最终候选；不把该批候选与 fresh Pi 批次混池。', '']
    for title, source in [('direct', direct), ('fresh Pi', pi)]:
        if title == 'fresh Pi':
            lines += ['Fresh Pi批次：每格为 Pi → 最终 rustX。', '']
        rows = [[mode_label(mode), case, str(8 if case == 'short-small' else 64),
                 absolute_pair(source[mode, case, MEDIAN]), absolute_pair(source[mode, case, TURN_CPU]),
                 absolute_pair(source[mode, case, TURN_WRITE], 1)]
                for mode in MODES for case in ('short-small', 'short-large')]
        lines += [table(['模式', 'case', '历史turn', 'wall中位 ms/turn', 'measured self CPU ms/turn', 'measured write bytes/turn'], rows), '']
    lines += ['## Native三引擎：独立参考的绝对测量成本', '',
              '此批仅live，四个case × 三引擎 × 三次。均值wall先取每产品turn均值，再取三产品中位数；CPU/写入也取每产品每turn值的三产品中位数，直接读取独立三引擎审计 `groups`。中位wall先取每产品turn中位数，再取三产品中位数，来自已审计 `supplementary_table`，均不复算原始数据。方括号为三次产品值的[min,max]，不是混池总体算术平均。DeepSeek的SDK idle不等待最终JSONL flush/fsync，不能视为durable settlement等价，也不计算跨引擎等持久性比值。', '']
    rows = []
    for case in NATIVE_CASES:
        for engine in ENGINES:
            group, extra = native[case, engine], supplement[case, engine]
            rows.append([case, engine, native_measure(group, MEAN),
                         number(extra['metrics'][MEDIAN]['median']), native_measure(group, TURN_CPU),
                         native_measure(group, 'turn_write_mib_per_turn', 2**20, 1)])
    lines += [table(['case', '引擎', '均值wall ms/turn [min,max]', '中位wall ms/turn', 'measured CPU ms/turn [min,max]', 'measured write bytes/turn [min,max]'], rows), '',
              'Rust/Pi这里的CPU为self CPU，包含同进程benchmark driver；DeepSeek为采样遍历中存活进程及已等待子进程的CPU。DeepSeek写入不涵盖已退出子进程，均非设备I/O；不能据此做等生命周期整体成本比值。', '',
              '### DeepSeek关闭与持久化边界单列', '',
              '下面CPU为首次native runtime与复验native runtime退出时wait4计数，包含完整退出过程，但不包含外部driver/provider CPU；不得用它代替上表的测量区间CPU。当前证据没有独立flush耗时计数，也没有退出后的proc write_bytes端点：完整写入量与flush/fsync延迟均记不可用，不记零。可读close/resume证据不能证明断电持久性或fsync成功；SDK disposal中的allSettled可能吞掉失败。', '']
    rows = []
    for case in NATIVE_CASES:
        metrics = supplement[case, 'deepseek']['metrics']
        require(metrics['through_cleanup_process_write_bytes']['median'] is None, 'native full writes must remain unavailable')
        rows.append([case, number(metrics['first_native_runtime_wait4_cpu_ms']['median']),
                     number(metrics['verification_native_runtime_wait4_cpu_ms']['median']),
                     number(metrics['both_native_runtimes_wait4_cpu_ms']['median']), '不可用', '不可用'])
    lines += [table(['case', '首次runtime完整CPU ms', '复验runtime完整CPU ms', '两runtime完整CPU ms', '完整write bytes', '独立flush/fsync ms'], rows), '',
              '## 全量不利项：不隐藏中位回退或单对回退', '',
              '以下扫描direct与fresh Pi审计中的所有指标，不只筛选主表指标。每个列出的cell至少一个逐对差值>0；“中位较高”表示配对百分比中位数>0，“仅部分配对较高”保留即使中位数改善也出现的不利样本。这里描述数值，不把更多功能性存储或任何差值自动解释为缺陷。无可用比值但存在正差值的cell仍列出。', '']
    adverse = []
    for label, source in [('direct', direct), ('fresh Pi', pi)]:
        for mode in MODES:
            for case in CASES:
                for metric in sorted({key[2] for key in source if key[:2] == (mode, case)}):
                    group = source[mode, case, metric]
                    higher = group['numerator_higher']
                    if not higher:
                        continue
                    change = group['percent_change']['median']
                    state = '中位较高' if change is not None and change > 0 else '比值不可用但有正差值' if change is None else '仅部分配对较高'
                    adverse.append([label, mode_label(mode), case, metric, state, percent_range(group),
                                    f"{higher}/5", '是' if group['all_five_higher'] else '否'])
    lines += [table(['比较', '模式', 'case', '审计metric', '分类', '配对 Δ% median [min,max]', '较高对数', '五对均较高'], adverse)
              if adverse else '全部审计指标均无正向逐对差值。', '',
              '### 不可用配对单列', '',
              '缺失计数与零分母保持不可用；不会用零或相邻cell补齐。', '']
    unavailable = [[label, mode_label(mode), case, metric, str(group['summary']['available']) + '/5',
                    '; '.join(f"pair {row['pair']}: {row['ratio_unavailable_reason']}" for row in group['pairs'] if row['ratio'] is None)]
                   for label, source in [('direct', direct), ('fresh Pi', pi)]
                   for (mode, case, metric), group in sorted(source.items()) if group['summary']['available'] < 5]
    lines += [table(['比较', '模式', 'case', '审计metric', '可用', '原因'], unavailable) if unavailable else 'direct与fresh Pi所有审计配对比值均可用。', '',
              '未显示为独立时延指标的DeepSeek flush仍是未测量，而非零耗时。第一轮pass1、探索筛查、SQL/WAL采集及CPU profiler数据均不进入本文件正式样本的中位数或比值。', '']
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--audit', type=Path, default=ROOT / 'complete-all-audit.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'report-tables.md')
    parser.add_argument('--expect-candidate-sha256')
    args = parser.parse_args()
    require(args.output.resolve() != args.audit.resolve() and args.output.suffix == '.md', 'output must be a separate Markdown file')
    raw = args.audit.read_bytes()
    report = json.loads(raw)
    if args.expect_candidate_sha256:
        require(report['identities']['complete']['sha256'] == args.expect_candidate_sha256, 'candidate differs from explicit expected binary')
    rendered = render(report, args.audit.name, hashlib.sha256(raw).hexdigest(), sha(Path(__file__)))
    args.output.write_text(rendered)
    print(json.dumps({'output': str(args.output), 'source_audit_sha256': hashlib.sha256(raw).hexdigest(),
                      'output_sha256': sha(args.output), 'formal_products': 276,
                      'scope': 'Accepted audit JSON only; no products or raw counter rereads.'}, indent=2))


if __name__ == '__main__':
    main()
