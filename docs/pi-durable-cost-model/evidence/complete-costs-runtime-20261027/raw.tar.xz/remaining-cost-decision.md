# 剩余主要成本：本轮取舍

本轮已经删除无现用生产调用的事件正文副本、合并同一发布边界的事务，并削减重复派生构造与回读。仍有真实的多层持久索引、7 个语义提交和6 个发布释放；这解释了为何不能仅凭缩小 JSON 就宣称追平 Pi。**13 次不是已证明的理论下限，也不是“功能更多所以不必优化”的结论。**它是当前公开读取、执行切点和故障合同下的现用实现，本轮保留这些切点，削减其中已确认的重复工作。

范围：最终冻结工作树 `/home/capi/.codex/worktrees/pr485-pi-performance/rustX`，base HEAD `688e7c3e85a72ae7d3745aff7419fdcff21c4ec8` 加本轮未提交修改，schema79。以下源码行号为当前工作树。没有为本文运行产品、构建或新测量。数值引用冻结 **pass 1** `/home/capi/.cache/rustx-pr485-complete-costs`；最终候选的事件副本删除和 transcript capture 修改不能冒用 pass 1 数据作为实测收益。

## 13 次写事务具体是什么

pass 1 的 32 个普通、无工具、no-live 测量轮次中，WAL 记录 **416 个 write-commit markers = 13/turn**；同轮 Pi 是 **160 = 5/turn**。RustX 旧基线为512 =16/turn。`sql-complete-tx-no-live/prepares.jsonl` 在 `before_measured_turns <= monotonic_ns < after_turns` 范围内的 `BEGIN IMMEDIATE` 调用栈也合计416；SQL prepare 次数本身不等于成功提交，WAL 提交标记是独立佐证。

| 普通轮次的持久 owner | 语义 TX | 释放 TX | 当前源码 |
| --- | ---: | ---: | --- |
| 接受 Pending Inbound，立即形成独立待处理 T | 1 | 1 | `sqlite.rs:3347`；`conversation_runtime.rs:7728` |
| 将待处理输入归入 canonical C / adoption J | 1 | 1 | `sqlite.rs:3562` |
| AttemptStarted | 1 | 1 | `sqlite.rs:1546,5035` |
| TurnStarted | 1 | 1 | 同一原生 event append 路径 |
| 冻结上下文、请求快照与 RequestStart family | 1 | 1 | `sqlite.rs:4764` |
| 开启 publication stream，建立输出 owner | 1 | 0 | `sqlite.rs:5675` |
| provider outcome + assistant C/J + turn/attempt settlement | 1 | 1 | `final_settlement.rs:315,484`；`observation_receipt.rs:227` |
| **合计** | **7** | **6** | **13** |

原先最后一行已有一个原子语义提交，却为 provider/canonical/turn/attempt 四个回调各释放一次；现在共享完整 `ModelTurnSettlement` receipt，在末 J 回调一次安装、一次释放。这消除了3 个重复 write TX/turn。其余6 个 release 对应6 个不同的现用安装边界；streaming、工具、重试、失败和并发输入并不承诺同样次数。

Pi 的5 次是同一普通 workload 的测量值，不是所有模式的固定常数。源码的关键区别是：Pi 把本次 entries/tasks/documents 放入同一 storage write batch，存储成功后 `tx.adopt(seq)` 和内存 listener publication 随即执行；该 publish 本身不再写一套 J/T ready/direct 状态。见 pinned [storage.ts:187–209](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/storage.ts#L187-L209)、[session.ts:690–778](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/session/session.ts#L690-L778)。其 request preparation 固定截止点与模型配置，answer 将 assistant、run 结束、下一批输入交接放在一个 commit：[generation.ts:177–194](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/harness/generation.ts#L177-L194)、[542–567](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/harness/generation.ts#L542-L567)。RustX 的独立 Pending/Attempt/Turn 和外部可见 release 状态是具体额外工作，并非更强 fsync 设置造成的差别。

## 为什么不能把 release 随手移回 native TX

现用顺序是 **语义提交成功 → CPU 投影安装成功 → 持久释放 → 唤醒读者**（`conversation_runtime.rs:7430`；`sqlite.rs:5301–5373`）。原始 Journal 可以已存在，而对应 Runtime 尚未安装、安装失败或被暂停；只读连接必须看到这一差别。提前在 native TX 标 ready 会让独立连接读到尚未安装的状态。反向把活投影先安装再提交，会在 SQLite commit 失败时泄露尚未持久的事实。只预计算投影仍不能省掉 commit 成功之后的真正安装和共享 release 变化。

这不是单靠某条测试规定：`open_existing` 创建独立连接（`sqlite.rs:773`），ready frontier 和 witness 查询读取持久 J/T 洞与 direct 标记（`observation_readiness.rs:87,178`；`observation_event.rs:588`）。普通 reopen 保留精确部分释放；只有显式 `observe_journal` 安装新 Runtime 时执行恢复并清 direct（`sqlite.rs:5216`）。因此内存 epoch、连接私有缓存、延迟到下一语义写或普通读取时补写，都会改变当前外部可观察结果或失败边界。一个 later J 可以先 direct-ready，而更早 J 仍是洞；用一个最大游标代替会错误越洞，或者错误重复 fold。direct 同时阻止已安装的原生事实被 Journal 再折叠（`runtime_client/projection.rs:2840,4762`）。

现有回归提供上述语义的可执行反例：安装期间 frontier 仍为0、独立 WAL 连接在 release commit 前后看见不同状态、失败 release 整批回滚但 native 数据保留、ordinary reopen 与 Runtime recovery 不同（`runtime/conversation_runtime/native_readiness_tests.rs:74`，`durable/sqlite/native_readiness_tests.rs:51,97`，`sqlite.rs:19666`）。更换物理实现可以重写测试注入点，但这些可观察结果不能靠删测试消失。

## 重复工作已经如何处理

| 已实施的处理 | 明确减少的工作与保留条件 |
| --- | --- |
| 删除 `events.observation_json`、`latest_observation_events`、`ObservationEventHeader` | 每 native J 少一次 bounded 编码调用、一次 UPDATE 和对应 SAVEPOINT/RELEASE；无 alias/migration。pass 1 的256新增 J 中此副本与 native 字节完全相等，共101120 B；这是被删逻辑字节，不能冒充最终 WAL 节省。保留现用 inherited provenance 的同名字段。详见 [event-body-closure.md](./event-body-closure.md)。 |
| append-scoped typed facts 和同域写合并 | Trace count/statistics/members 最多3 UPDATE→1；inline source+witness 2→1；复用只在实际存储字节与本次 capture 一致时成立，触发器改写仍可见。`append_facts.rs:11,23`；`observation_event.rs:522`。 |
| model settlement receipt/final evidence 合并 | 普通完成5份 J receipt→1；相关最终 evidence 11 SELECT→一次至多4个 key 的读取；四个 release→1。独立 source/execution/pending 缺失仍使相应证据不可用，不伪造成功。`observation_receipt.rs:171,227`；`final_settlement.rs:484`。 |
| readiness 同行重复更新 | ready、direct 两次验证/UPDATE→一次验证和联合 UPDATE，已经 ready/direct 的行不再改写。`observation_readiness.rs:32,71`。 |
| 重复配置与私有检查索引 | request configuration 按精确 bytes/digest 共用（仍验证），composed records 用有界 positional MessagePack、pages 用紧凑编码；不是再镜像整份 prompt。`native_request.rs:151`；`observation_request/composed/record.rs:1`、`page_codec.rs:1`。 |
| 重复 CPU capture/SQL compilation | checkpoint 先取得有限 admission/metadata，确需快照时再物化；复用未变 transcript 单元；固定热点 SQL 走 bounded prepared cache。`runtime_client/projection.rs:541,869,934`；`projection/prepared_capture.rs:195`；`sqlite.rs:886`；`durable/sqlite/projection.rs:909,1037`。这里列的是已改路径，不给未完成测量的 CPU 百分比。 |

## 现在留下的四层不是四份相同正文

| 层 | 当前用途、不能直接相互替代的事实 |
| --- | --- |
| Native `event_json` | 原始事件、恢复/执行与精确历史权威，包含显示层不应暴露的私有信息。普通 serde JSON；`sqlite.rs:11424` 的 native encode/INSERT。 |
| Structural source（小事件 inline，大事件分段） | 字段 seek、子项枚举、精确字节切片。schema 定义的 u64 使用十进制字符串，native `sequence:123` 与 structural `sequence:"123"` 的类型和位置不同；直接别名会改变公开读出的字节。`observation_event.rs:442`；`runtime/read_layout.rs:521`；`structural_json.rs:173`。 |
| Bounded witness | 有限预览、deferred 字段、规范化/隐藏超大ID、原生 tool/result 定位、occupancy、当前 publication/direct/missing 状态。字段源失败时仍能保存有限 own terminal facts；`observation.rs:163`；`observation_event.rs:372,608`。 |
| Trace fact | 截止于历史 J 的关系事实、owner/location、request/canonical 关联、bootstrap，支持不读无限增长正文的有限历史查询。reader 还交叉检查 sequence/kind/time/owner，不能简单删掉这些重复字段却保留同样损坏检测；`trace.rs:58`；`observation_trace/event.rs:739`；`observation_trace.rs:144`。 |

独立可选布局失败不应撤销已经承诺的执行事实：例如拒绝某 J 的 inline source 写入，native Journal 和独立 mandatory witness/Trace 仍可保留，而该 J 的字段读取明确失败；修复 readiness 也不能顺手把它改成可用。反例是缺失 Trace fact 会留下历史洞并影响后来 Trace，因此它与单事件 source 不是同一 failure domain。最终 fixture 已使用真实 inline-source 故障保护此区别（`sqlite.rs:19838`；`observation_event_probe_tests.rs:637,736`）。这说明哪些边界必须保留，不意味着现有每个字段名、SQL 形状或重复序列化都不可改。

## 为什么本轮不再押注 readiness 新格式或共享正文证书

ready/direct **已经在独立紧凑表**，普通 release 不重写宽 `events` 正文（`sqlite.rs:8821`；`observation_readiness.rs:71`）。把“从宽正文行移出 ready”当新优化会优化一个不存在的问题。旧基线 J readiness 表和洞索引各416帧，共832：假设能把这两个对象的全部帧删除，最多是 small/large **8.41% / 7.68%** 当前归属帧。这个不可实现的删除上界包括 native 插入及 release，不全是可省的 release。

pass 1 合并后两对象各320帧，共640，在9466/10397总帧中占 **6.76% / 6.16%**；连 J+T 四个对象全删也仅9.47% / 8.62%。总帧对 Pi 仍为9466/1683和10397/1688。页归属来自测量端点 dbstat，不能保证中途从不重用；以上只是“删除这些已归属对象”的量级上界，不是任意重构的数学全局上界，更不是 CPU/墙时收益。bitmap/interval 仍需保存洞/direct、后置提交和损坏验证，能省的部分更小，也没有已证明的正收益下限。

决定：保留现有语义/发布切点和独立证据，不引入另一套 release 格式或共享正文证书。按需从 native 重造 structural 会把编码转移到每次字段读取并改变物理损坏耦合；继续将 witness/Trace 改私有 tuple 只能先证明有限字段名压缩，尚不能证明是整体耗时大头。这些不是“已经优化”的结果，也不是本轮待用户批准的未完事项。当前大的无用第三份正文已直接删除；本轮选定、可在同一已存在 owner/事务内合并的重复工作已落地；不宣称所有安全优化已经穷尽，最终计数仍有下述固定 SQL 编译工作。剩余架构成本如要进一步接近 Pi 的提交模型，需要明确改变哪些可观察提交/安装协议，而不能把差别包装成一次无行为变化的小优化。

耐久性边界也明确：RustX 与此 pinned Pi backend 均为 SQLite WAL + `synchronous=NORMAL`（`sqlite.rs:8157–8163`；[Pi node.ts:193–195](https://github.com/earendil-works/pi/blob/90d863f7c1183b965f099855715d6e88c7b8a52c/packages/durable/src/storage/sqlite/node.ts#L193-L195)）。DeepSeek 是另一种参考：批量 JSONL append 后真实 `handle.sync()`，request dispatch 前显式 flush（[persistence:1411–1438](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-persistence-jsonl/src/index.ts#L1411-L1438)、[checkpoint policy:29–36](https://github.com/deepseek-ai/deepseek-harness/blob/687f282e8625c6b8d11ff58211a90524be2e4317/packages/session/session-checkpoint-policy/src/index.ts#L29-L36)），不能把它的 append batch 数当 SQLite TX 对照。跨引擎完整 native tool/prompt 不相同，正式 cross-engine oracle 覆盖共同语义；只有同引擎 baseline/candidate 的完整 oracle 能隔离本轮更改。

## 证据入口

- 冻结 pass 1 `wal-summary-baseline.json`：SHA-256 `be69e852255d6bc6c36f0c1218bc48956dd63738dd76f30208e419ab91ddc871`；`wal-summary-complete.json`：`f81ff51a15594e45ddb4fa560b81b019da4c9e78d90a086cc798e3fb0714b5d0`。正文所有物理帧/commit 数据来自这两个文件，不来自最终候选推算。
- pass 1 `sql-complete-tx-no-live/prepares.jsonl`：`5208adb6a45973b5386f2790161c48ddefc859021c57fe746d07d5afbef01d44`；`phases.json`：`d38726ee71ef5e732d261b15f516bd66b8bf2b6788e09fe73d2f6803fb1a4818`；`identity.json`：`030f0da347fac3b834be22c55c6f3e68237af087aa26efb59ab5e892d5e5d3b6`。identity 标明 build HEAD688e7c3e8。实际 BEGIN 栈分组：accept32、pending T release32、adopt32、native release160、append event64、request-start32、open stream32、settle32。
- 细项/反例在冻结 pass 1 `append-closure.md`、`readiness-cost-audit.md`，以及最终 [event-body-closure.md](./event-body-closure.md)。前两份含旧阶段的预测/行号；本文已经用真实 pass 1 WAL 更新13次与6%–7%归属份额，不改写原始历史证据。


## 最终候选完成后的独立复核（追加，不覆盖 pass 1）

最终 HEAD 为 `f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20`，production tree `09ca4b97e5f0c71f97dd53e2df87a28c4dffc3aa`，ordinary O3 binary SHA-256 `8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7`。本次从最终目录原始 `prepares.jsonl`、阶段标记、列快照、八份 strace 重新计算，未运行产品。可复算脚本 [independent-storage-audit.py](./independent-storage-audit.py) 与完整计数/原始 SHA/SQL 列表 [independent-storage-audit.json](./independent-storage-audit.json) 已保留；正式 cohort 是否接受由独立正式 auditor 确认。

| 项目（均32 measured turns） | 匹配基线 | 最终 | 降幅 |
| --- | ---: | ---: | ---: |
| SQL prepares，TX 诊断，short-large/no-live | 18738（585.5625/turn） | 4520（141.25/turn） | 75.88% |
| WAL write commits，小/大历史各自 | 512（16/turn） | 416（13/turn） | 18.75% |
| small WAL frames | 9892 | 9475 | 4.22% |
| large WAL frames | 10831 | 10406 | 3.92% |
| small WAL frame bytes/turn | 1273595 | 1219906.25 | 4.22% |
| large WAL frame bytes/turn | 1394491.25 | 1339772.50 | 3.92% |
| small 全表逻辑列值增长 B | 2564940 | 1770302 | 30.98% |
| large 全表逻辑列值增长 B | 2672096 | 1826076 | 31.66% |
| small request source 三表逻辑 B | 1369729 | 676185 | 50.63% |
| large request source 三表逻辑 B | 1465449 | 720804 | 50.81% |
| small events 逻辑 B | 798140 | 697094 | 12.66% |
| large events 逻辑 B | 800259 | 698997 | 12.65% |

SQL 必须比较 TX 版本的18738，不能换成另一个 plain baseline 的18682。最终804个 `COMMIT` prepare 含只读事务，不等于416个 WAL 写提交。独立 parser 还检查全部24字节 WAL frame header 与4096字节 payload 的成功写次数相等、文件匹配、边界成对、无残留未结束写事务。frame bytes 不含32字节 WAL headers、checkpoint DB writes、设备或文件系统额外流量，不能称总设备写入。最终同轮 Pi 仍为1683/1688 frames、160 commits，故当前 WAL frames 比是5.63×/6.16×；不是整体墙时倍数。

最终 `events.observation_json` 由实际 schema 快照证实 `retired_layout_absent`，并非伪造测量0；继承 provenance 同名字段仍在。逻辑体积变小没有相同比例物理收益：当前 events 页归属帧544/546，旧基线519/523；不能从少一个 UPDATE 或少101 KB正文推导少同等 WAL。最终 J readiness 两对象仍640帧，上界份额更新为6.75%/6.15%，J+T四对象为9.46%/8.61%。前文8%左右旧上界与6%–7%的判断仍成立；具体9466/10397是明确标注的 pass 1，最终不得引用为9475/10406。

### 仍有真实、可安全处理的固定 SQL CPU 工作

最终4520 prepares 中，**1992**是 `BEGIN IMMEDIATE`416、`BEGIN DEFERRED`580、`COMMIT`804、`ROLLBACK`192；另外 **2528 = 79/turn** 来自 **45种固定业务 SQL**，全部仍是 flags0。warm+steady 总工作集190种，小于当前256容量；steady没有 flags1编译 miss，故这批主要是未使用缓存的调用点，并非已有缓存不断淘汰。

代表性现用路径：`sqlite.rs:10301 load_pending_rows`128次、`:11841 read_request_snapshot_tx`160次、`:5985 read_publication_stream`160次、`observation_receipt.rs:57 batch_with_summary` 的区间故障谓词160次、`observation_turn.rs:43` 三组96次查询/更新与`:202 prompt`三组32次、`observation_members.rs:11` 两条64次读取。完整45条 SQL 及首次源码调用栈在独立 JSON，不把 prepare 次数当所有执行次数。

把这些固定调用改为有界 `prepare_cached` 仍是可实现的安全 CPU 优化，**尚未实施**。这是对“仍有剩余”的明确交代，不能声称所有热 SQL 都已复用。另一独立 live-large 采样运行有312个CPU样本，prepare 子树覆盖19个（nearest owner：pending读取4、turn event3、batch2、prompt2等），显示这个余项确实仍存在；这只是 inclusive 抽样，不是19个独立exclusive成本，更不是6.1%保证收益，也不能把 no-live 计数与 live profile 拼成耗时公式。

该余项不减少语义提交、SQL执行、WAL帧或多套历史索引。本轮决定保持已经严格验证的最终生产版本，不再为可能数个百分点、尚未有配对收益证据的尾部缓存转换追加另一整套未测 patch。大的物理剩余是多套事件及历史索引/内容源，当前源审查未发现另一条可直接删除的完整同字节正文副本；跨层共源需要保留结构化字节、有限读取、独立可用性和损坏检测。13次TX仍不是理论下限；改变提交/发布协议属于明确的语义设计选择。上述分类既不把安全机会说成不存在，也不把未实测的小变体包装成已完成的大头优化。
