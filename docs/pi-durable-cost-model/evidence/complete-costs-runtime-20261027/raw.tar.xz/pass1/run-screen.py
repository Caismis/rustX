import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
before=Path('/home/capi/.cache/rustx-pr485-joint-major/candidate-joint-build/conformance');after=root/'candidate-complete-build/conformance'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
ids={name:json.loads((path.parent/'identity.json').read_text()) for name,path in [('before',before),('after',after)]}
assert all(sha(path)==ids[name]['sha256'] and ids[name]['verified'] for name,path in [('before',before),('after',after)])
assert ids['before']['harness']==ids['after']['harness']
out=root/'exploratory-screen';out.mkdir(exist_ok=False)
records=[]
for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
 cmd=[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(out/label),'--pairs','1','--observer-mode',mode]
 record={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','identities':ids,'scope':'Exploratory one-pair correctness/performance screen; never pooled with final five-pair matrix.'};records.append(record)
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (out/(label+'.stdout')).open('w') as stdout,(out/(label+'.stderr')).open('w') as stderr:r=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=stdout,stderr=stderr)
 record.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
assert all(sha(path)==ids[name]['sha256'] for name,path in [('before',before),('after',after)])
