import argparse,datetime,hashlib,json,os,socket,subprocess,sys,tempfile,threading,time
from pathlib import Path
root=Path(__file__).resolve().parent; repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
sys.path.insert(0,str(repo/'benchmarks/runtime')); from controller import run, TEST
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--name',required=True);p.add_argument('--observer-mode',default='no-live-subscriber');a=p.parse_args()
binary=a.binary.resolve(); out=root/a.name;out.mkdir(exist_ok=False)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
identity=json.loads((binary.parent/'identity.json').read_text());assert identity['verified'] and identity['sha256']==sha(binary)
script=root/'sql-prepare.gdb.py'; sock=Path(tempfile.mkdtemp(prefix='rxsql-'))/'control.sock'
server=socket.socket(socket.AF_UNIX);server.bind(str(sock));server.listen(1);phases=[];errors=[]
def serve():
 try:
  while True:
   conn,_=server.accept();value=b''
   while not value.endswith(b'\n'):
    data=conn.recv(128);assert data;value+=data
   phase=value.decode().strip(); phases.append({'phase':phase,'monotonic_ns':time.monotonic_ns()});conn.sendall(b'K');conn.close()
   if phase=='after_cleanup':break
 except Exception as e:errors.append(repr(e))
thread=threading.Thread(target=serve,daemon=True);thread.start()
argv=['gdb','--quiet','--nx','--batch','-ex','set pagination off','-ex','set confirm off','-ex','set print thread-events off','-ex','handle SIGPIPE nostop noprint pass','-ex','source '+str(script),'-ex','run','--args',str(binary),TEST,'--exact','--ignored','--nocapture']
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
env.update(UV_OFFLINE='1',RUSTX_BENCH_CASE='short-large',RUSTX_BENCH_OBSERVER_MODE=a.observer_mode,RUSTX_BENCH_OUTPUT=str(out/'sample.json'),RUSTX_BENCH_PROFILE_SOCKET=str(sock),RUSTX_SQL_PREPARE_OUTPUT=str(out/'prepares.jsonl'))
record={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary':str(binary),'build_identity':identity,'runner_sha256':sha(__file__),'gdb_script_sha256':sha(script),'argv':argv,'scope':'Intrusive debugger diagnostic only. SQLite prepare calls and monotonic boundary windows. No headline latency, CPU or physical-write claims; immutable ordinary O3 binary. Provider is a controller-owned sibling.'}
(out/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
r=run(argv,out/'sample','short-large',env,repo/'test-support/fake-provider');thread.join(5);server.close();sock.unlink();sock.parent.rmdir()
(out/'phases.json').write_text(json.dumps(phases,indent=2)+'\n')
record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),accepted=r['accepted'],errors=errors,thread_finished=not thread.is_alive(),binary_unchanged=sha(binary)==identity['sha256'],runner_unchanged=sha(__file__)==record['runner_sha256'],gdb_script_unchanged=sha(script)==record['gdb_script_sha256'])
(out/'identity.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2));assert r['accepted'] and not errors and not thread.is_alive() and record['binary_unchanged']
