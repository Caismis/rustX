# Stdio initialization ordering review and fixture correction

The full process suite in `checks-retry3/tests-process.stdout` reported 61 passed / 1 failed. The failure was `app_server::app_server_stdio_protocol_errors_are_records_but_framing_is_terminal` at its former line 349: the first parsed post-initialize record's `id` was JSON null instead of 1. The failed assertion did not print the full record, so that log alone does not establish its exact notification payload.

Root reran the exact test with the same already-built process test executable. `process-repro/command.json` records exit 0, and `process-repro/stdout` reports 1 passed in 0.30 s. This single passing retry is scheduling evidence only; it does not prove there is no production bug and does not replace the retained failure.

The source review identifies an unsupported ordering assumption in the fixture:

- `docs/app-server-protocol.md` (JSON-RPC and initialization) requires responses to carry their request ID and notifications to have no ID. Its source-repair section says initialization admits the User source and owes its current level once; it does not require the response's physical bytes to precede that level.
- `AppServerConnection::dispatch` in `src/app_server/connection.rs` sets the initialized state and wakes the notification reader before returning the initialize result. `next_source_repair` gates on that initialized state and provides the admitted User source level once.
- `resolve_and_enqueue` and `enqueue_reply` in `src/app_server/transport/mod.rs` await outbound capacity after semantic dispatch. The serve loop independently polls notifications and request work, with notification priority on observation turns. A pending queue/cooperative poll can therefore permit the newly available source level before the correlated initialize reply. This is not a response-first publication barrier.
- These production transport/connection paths and the failing fixture were unchanged from reviewed base `785fff7a869943f61a97912a8e751faa2d49c32f`. The WebSocket helper in this same process test already reads by response ID; scripted transport tests separately accept the reply and initial source level without imposing their order.

Only `tests/process/app_server.rs` was changed. The test now reads until it has received both the successful initialize response (`jsonrpc=2.0`, `id=1`, initialized result, protocol version 52, no error) and exactly one repair-level notification. That notification must contain exactly User target, null receipt and sequence `"0"`; duplicates and unrelated records fail immediately. Once both arrive, the fixture closes stdin, checks successful detach/shutdown, and requires EOF with no extra record. It retains the original exact-size input, malformed JSON-RPC checks, invalid UTF-8, unterminated record, and oversized framing cases unchanged. Waiting for both before EOF also removes the old allowance to retire an undelivered level during shutdown; the old test only asserted at most one level.

Scoped rustfmt and git diff --check completed. This reviewer did not run the test, any build, or any product after the correction. Root will execute the final correctness queue and include tests in its source/build-input identity snapshots.

## Evidence identities

- `/home/capi/.cache/rustx-pr485-complete-costs/checks-retry3/tests-process.stdout`: `32348a2c9688c70ec4b12a9443aa12445544fea07c029808d734d05373ec4222`
- `/home/capi/.cache/rustx-pr485-complete-costs/process-repro/command.json`: `422c23b03d35acc8bb5a318c22fb2d7508236480cb3ca9202fecc6d6086538a1`
- `/home/capi/.cache/rustx-pr485-complete-costs/process-repro/stdout`: `9816f597c22687af973d0f4b55d2a02c017517fb0a169f84fa52fff555e49054`
- `/home/capi/.codex/worktrees/pr485-pi-performance/rustX/tests/process/app_server.rs`: `98c7459ef83454b06c035d25ee3dc1916cd7edf1a1bf603ef40f3d422245a4b5`
