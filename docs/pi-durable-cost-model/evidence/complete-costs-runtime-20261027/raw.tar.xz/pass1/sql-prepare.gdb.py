import gdb, json, os, time
out=open(os.environ['RUSTX_SQL_PREPARE_OUTPUT'],'w',buffering=1)
seen=set()
class Prepare(gdb.Breakpoint):
 def stop(self):
  try:
   frame=gdb.newest_frame(); address=int(frame.read_register('rsi')); length=int(frame.read_register('rdx')) & 0xffffffff
   if length>=0x80000000: length-=0x100000000
   if length>0:
    sql=bytes(gdb.selected_inferior().read_memory(address,length)).rstrip(b'\0').decode('utf-8')
   else:
    sql=gdb.Value(address).cast(gdb.lookup_type('char').pointer()).string()
   row={'monotonic_ns':time.monotonic_ns(),'sql':sql,'flags':int(frame.read_register('rcx')),'connection':int(frame.read_register('rdi')),'thread':gdb.selected_thread().ptid[1]}
   if sql not in seen:
    seen.add(sql); frames=[]
    for i in range(10):
     if frame is None:break
     frames.append(frame.name());frame=frame.older()
    row['first_call_stack']=frames
   out.write(json.dumps(row)+'\n')
  except Exception as error:
   out.write(json.dumps({'error':repr(error),'monotonic_ns':time.monotonic_ns()})+'\n')
  return False
Prepare('sqlite3_prepare_v3',internal=True)
