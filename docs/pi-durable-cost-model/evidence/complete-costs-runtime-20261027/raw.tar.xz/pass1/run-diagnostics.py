import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
binary=root/'candidate-complete-build/conformance'
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
build=json.loads((binary.parent/'identity.json').read_text());assert build['verified'] and sha(binary)==build['sha256']
def source():return {p:sha(repo/p) for p in build['source_files']}
assert source()==build['source_files']
steps=[('columns-complete','columns-complete.py',[]),('profiles','run-profiles.py',[]),('profile-reports','profile-reports.py',[]),('sql-complete-tx-no-live','run-sql-prepare-tx.py',['--binary',str(binary),'--name','sql-complete-tx-no-live']),('wal-complete','run-wal-compact.py',['--binary',str(binary),'--label','complete']),('wal-summary-complete','analyze-wal-verified.py',['--label','complete'])]
records=[]
for name,script,args in steps:
 command=[sys.executable,str(root/script),*args]
 record=dict(name=name,command=command,producer_sha256=sha(root/script),start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');records.append(record)
 (root/'diagnostic-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:r=subprocess.run(command,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete' if r.returncode==0 else 'failed',exit=r.returncode)
 (root/'diagnostic-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,r.returncode,flush=True)
 assert sha(root/script)==record['producer_sha256'] and source()==build['source_files'] and sha(binary)==build['sha256']
 if r.returncode:raise SystemExit(r.returncode)
