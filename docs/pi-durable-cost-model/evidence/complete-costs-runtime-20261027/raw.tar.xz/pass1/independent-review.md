# Independent source review: compact request metadata and aggregate checkpoint head

Reviewer: publication_incremental (not the author of these two changes). Reviewed the frozen working tree based on HEAD `785fff7a869943f61a97912a8e751faa2d49c32f`. This is a source review only; no build, test, benchmark, product execution, or source edit was performed during this review. Root's correctness queue is the execution authority.

No actionable correctness defect found in the reviewed changes.

## Compact request metadata

- `composed/record.rs:10` serializes only private structural records, using MessagePack tuple fields and byte containers. `Fact.header` (`composed.rs:181`) is the pre-existing bounded JSON preview bytes, passed directly through the codec. Original source chunks remain on the unchanged authenticated fragment byte path. There is no conversion of those JSON bytes through MessagePack values, so map order, negative zero, JSON escapes and opaque large integer spelling do not acquire a new normalization step. Template prefix/suffix strings are also carried unchanged.
- The removed `Fact.path`, `parent`, and `ordinal` payload copies were producer-only. `fragments.rs:251` still checks locator component/count/encoded-byte bounds before producing exact `F<encoded path>` and `C<encoded parent>:<ordinal>` keys. `fact()` retrieves by the exact F key. `child_path()` (`fragments.rs:512`) still checks canonical path encoding, parent prefix, and exactly one extra child component. The authenticated index page hashes include both key and value; path/ordinal ownership has not moved to an unchecked reader hint.
- Every production decoder entry retains its bounded source and integrity check: root metadata <=16 KiB plus root checksum and native snapshot coordinates (`composed.rs:308`); augmentation <=64 KiB plus expected hash/native identity and geometry (`nodes.rs:30`); stable scalar <=16 KiB plus checksum/identity/span (`scalar.rs:38`); template <=64 KiB authenticated blob plus header/span limits (`fragments.rs:568`); field <=40 KiB inside an authenticated <=64 KiB index page (`index.rs`). Root/source sequence, manifest digest/count/height, content frontier, and selected native node checks remain in place.
- `record.rs:45` refuses non-array roots and trailing bytes, sets depth 32, and uses `Cursor` with rmp-serde's `ReadReader`. I inspected the installed primary implementation, rmp-serde 1.3.1 `decode.rs:592-605,727-730,1042-1049`: binary data can be deserialized as a finite byte sequence; `ReadReader` grows from actual available input via `take(len).read_to_end`, rather than reserving the declared 32-bit length. `record.rs:77` caps widths/variants/templates at 80 elements and header at 16,384, checking size hints before vector reservation. Binary input is copied by the library before this visitor runs, but the SQL/index input cap bounds that copy; it does not promise zero temporary allocation.
- Schema 79 rejects older database layouts at the existing open gate; the change does not add a legacy metadata decoder. Existing corruption tests now use typed record mutation helpers, so they still modify geometry and recompute real stored hashes rather than merely failing JSON parsing.

## Aggregate checkpoint head

- `sqlite.rs:2859` creates one read transaction and keeps transcript, response facts, occupancy, trace count and projection head within it. `observation_checkpoint.rs:8` calls the original transcript path first, which validates the exact native cut, canonical provenance and page bound before reading descriptors. It then checks the decoration Journal cut, derives bounded selections, and calls `observation_response::read_validated` on the same transaction.
- `read_validated` skips only the redundant cut validation already completed in that transaction. Selection-count/cursor bounds, missing-member detection, selected native source identity checks, and per-cut response/member/execution logic remain. Its production callers are the validated ordinary wrapper and the new aggregate reader; no unchecked public store entry was introduced.
- Error-producing operations retain their old order: transcript/cut -> response decoration and statistics -> occupancy -> trace total -> projection head. `apply_page_facts` moves the prior decoration body without changing entry/deferred-entry iteration order. The number of response facts is established by the same exact selections iterator, so its existing `expect` remains internal to a paired reader/consumer invariant.
- The live route consumes the aggregate head; the explicit trace-materialization route remains separate. Historical reads continue to pass the captured Journal/native bounds, and the aggregate snapshot eliminates cross-domain observation of a concurrent writer while those reads run. This is a stronger consistency boundary without relaxing the source cut.

## Execution evidence still required

Reviewed relevant authored regressions for byte preservation, exact codec size boundary, malformed/trailing/legacy records, declared-length rejection, child references, coherent geometry corruption, historical projection/occupancy cuts, competing WAL writer and error precedence. These are meaningful checks, but this review does not claim they passed; consult the root-owned check logs. No performance gain is inferred from this source review.

## Reviewed file identities

- `src/durable/sqlite/observation_request/composed/record.rs`: `e4275d7ad9306fb0abb368767030139e140e8529f0445697a6d6ab8a210fb0e6`
- `src/durable/sqlite/observation_request/composed.rs`: `ce920cea3c95eb00f7a902169dc73475c4fb53415d102dfb34dcd72e2359ce88`
- `src/durable/sqlite/observation_request/composed/fragments.rs`: `6d6cbb78a928b714866389a1ac3500f823cc02852088445641942be158eb4ff6`
- `src/durable/sqlite/observation_request/composed/nodes.rs`: `5e2273c8a3cb4dea3dfd9f8608be075652ef148853b865a8925d26faf0605fbb`
- `src/durable/sqlite/observation_request/composed/scalar.rs`: `0dd2dcd6cb7995810f1af1fb327b9b10025880ce00aa7aefff401aba428a2a6c`
- `src/durable/sqlite/observation_request/composed/read.rs`: `fcd7d9728fe8212cecbb8a29cfe0a802145a2a1c6efa88b9ad0fee3af49b9f68`
- `src/durable/sqlite/observation_checkpoint.rs`: `d79c59284dc899700045cc7708b28b37173b666190a89bd937a2ac23b5155035`
- `src/durable/sqlite/observation_response.rs`: `8c90b08bd7c5c09afe1b73f27a1a786ba1ee1bd8ecc3b4450264bafa74d78972`
- `src/runtime_client/response.rs`: `f2983f0e27ea89e8dc891d9da20c8a6f6c24174c89a7e00d76a12ca8c24dd450`
