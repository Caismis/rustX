# Remaining-cost source audit and implemented closure, 2026-10-27

This is a source/retained-evidence audit, not a new benchmark result. Starting RustX HEAD: `785fff7a869943f61a97912a8e751faa2d49c32f`; prior measured production: `123accb38fd8cf1e8f88583c1858d514cb453870`. Pi Durable: `90d863f7c1183b965f099855715d6e88c7b8a52c`, `/home/capi/Documents/codes/pi-rustx-benchmark`. DeepSeek Harness: `687f282e8625c6b8d11ff58211a90524be2e4317`, `/home/capi/.cache/rustx-pr485-next/deepseek-checkout`. Exact prior links/line references are in `../rustx-pr485-joint-major/source-comparison.md`.

## The missed dominant logical write was inside request-inspection records

Recomputed directly from `../rustx-pr485-joint-major/columns-joint-{short-small,short-large}/{before_measured_turns,after_turns}.json`, 32 measured requests each. These are sums of SQLite logical column value sizes, not WAL bytes, filesystem writes, or exclusive physical allocation.

| Growing table | short-small bytes | short-large bytes | Meaning |
| --- | ---: | ---: | --- |
| request_source_pages | 971,839 | 972,748 | 384 new rows each, including digest and bytes |
| request_source_nodes | 358,346 | 453,016 | 285 / 351 new rows, metadata alone 339,303 / 429,499 bytes |
| request_source_roots | 39,544 | 39,685 | 32 new roots |
| three-table sum | 1,369,729 | 1,465,449 | 53.40% / 54.84% of all logical column growth |
| all events columns | 798,140 | 800,259 | 256 new event rows |
| all tables | 2,564,940 | 2,672,096 | includes integer/text-size accounting used by original collector |

Both `request_configurations` and `request_source_scalars` grew by zero rows and zero logical bytes in those windows. Thus further stable configuration write deduplication cannot remove the observed dominant per-turn growth. CPU evidence is consistent but not a causal fraction: prior joint profile has 328 samples; `index_request_read_layouts` occurs inclusively in 22, `ReadDomainCut::read_with_trace` in 39, `native_request::read` in 3 and `native_request::persist` in 1. Inclusive symbols overlap; these counts must not be added or read as exact time savings.

The outer request page (`RXSP`, `composed/page_codec.rs`) was already binary. However, F-entry values, template blobs, source-node augmentation records, and root/scalar metadata remained named JSON. Facts repeated `path`, `parent` and `ordinal`, even though F keys and C parent/ordinal keys already supply those coordinates; previews were additionally base64 encoded. Native 32-byte hashes appeared as JSON decimal integer arrays, and every node encoded all eighty width entries as named JSON metadata. This is a different remaining layer from the already completed outer page codec or stable scalar reuse.

### Implemented in this round

`src/durable/sqlite/observation_request/composed/{record,fragments,nodes,read,scalar}.rs` and `composed.rs` now use one typed MessagePack representation for private records. The already locked `rmp-serde` 1.3.1 becomes a direct dependency; no new package version or compatibility path is introduced. Root schema79 ownership rejects prior storage versions.

- Positional struct fields remove repeated metadata names; fixed hashes and u8 vectors use binary byte containers. Fact producer coordinates are skipped in storage; actual F/C index keys and the original immutable manifest retain occurrence/path authority.
- Header bytes are stored directly, avoiding base64; original opaque JSON bytes, number spelling, map order and negative zero do not pass through MessagePack `Value` conversion.
- Exact stored bytes remain hash/checksum authenticated before typed decoding. The native node coordinate/digest, eighty widths/variants, reference geometry, source byte ranges and child membership validation remain in their original readers.
- The bounded writer refuses records above the existing private limits. SQL materialization caps, public 16KiB header and 64KiB page bounds, path/key bounds and original JSON node admission are unchanged.
- Decoder input is an already bounded SQL cell. A Cursor rejects trailing bytes; nesting limit is 32. Explicit visitors reject declared vector sizes above80 (widths/variants/templates) or16384 (preview bytes) before reserving or visiting elements. Record roots require an array marker; legacy JSON and named-map root encodings are rejected.

Local exact-version dependency source was inspected: `rmp-serde-1.3.1/src/{decode,encode,config}.rs`. `ReadReader::read_slice` uses `take(length).read_to_end`, so a malicious string length alone cannot allocate that length; vector size_hint did require explicit bounds. `from_slice` alone would not enforce EOF, hence Cursor.position. Externally tagged Content avoids internally tagged Serde Content buffering. No generic JSON validator or duplicate domain schema was introduced.

Five `compact_request_*` tests cover raw byte/u64/order preservation, duplicate-coordinate removal, closed/typed/trailing decoding, hostile allocation lengths, exact caps, and root/template/leaf/branch coordinates. Existing coherent-rehash/root/template/child-chain corruptions are adapted through typed test bridges without changing their mutations or oracles. Public differential source and paging tests remain independent. No speedup or WAL reduction is claimed until root runs the new build and paired diagnostics.

## A second uncovered CPU path was repeated same-cut read transactions

At the starting source, `runtime_client/projection.rs::ReadDomainCut::read_with_trace(false)` fetched transcript headers, response decoration, occupancy, trace_total and projection_head through separate trait calls. That is five store lock acquisitions and three explicit read transactions. Transcript and response each revalidated the native cut, rereading the same current counters/provenance. All fields were already requested by one live checkpoint operation.

Implemented a required `ConversationStore::observation_checkpoint_head(cut, through, limit)` method (the only repository implementation is SQLite), returning the same bounded client-neutral DTOs. `sqlite/observation_checkpoint.rs` reads the domains under one lock/read transaction in the original error order. Transcript performs the original cut validation; response shares that proof only inside this transaction, while retaining its page limits, selected owner checks, source-hole checks, statistics and per-owner decode rules. Pure response selection/application helpers are reused, not duplicated. Explicit through equality is checked after transcript/cut as before. Historical/cancel/foreign/future cut semantics remain.

Only the live no-trace path uses this grouped operation. Explicit trace reads retain their established operation order. There is no default trait fallback, no long-lived read cache, no stored proof across transactions, and no skipped source corruption validation. Three new `checkpoint_head_*` tests compare original separate reads, force a second WAL writer to mutate selected evidence after transcript materialization, verify all domains remain in one snapshot, check failures/limits/cut error precedence, and preserve historical projection+occupancy. Existing response differential cases also compare the combined head for running/completed, mixed ordinary/deferred, inherited, distinct-owner and reopen/append histories.

## Other candidates: what was already handled, is being handled, or must remain

| Candidate | Source evidence / decision | Closure |
| --- | --- | --- |
| Fixed SQL recompile and undersized statement LRU | Pi `storage/sqlite/node.ts:77–118` shares an unbounded SQL-text Map across connection/transaction handles. Rust had many direct fixed query_row/execute calls and64 cache slots while observed hot shapes exceeded that. | Root owns fixed-statement trait/call conversion and capacity256. No dynamic user SQL is indiscriminately cached. |
| Repeated event folding / event-row SQL updates | Actual event append persisted many optional layouts separately. Shared statistics values were already compact, but append metadata extraction/writes still repeated. | Event agent owns append-scoped facts and grouped materialization, preserving optional-failure independence. |
| Full checkpoint materialization merely to prove metadata fit | `PublicationDraft::encode` could construct a full DTO before knowing the transition needed no replacement. | Publication agent owns metadata-first/Cow capture. Read-only review found fit certificates invalidated after full eviction, replacement charges conservative after inner descriptors are cleared, and original exact serializer remains. |
| Model completion, Loop/Attempt terminal and inbox boundaries | `final_settlement.rs` already combined provider outcome, canonical assistant and optional boundary, but terminal-tail event work still had distinct commits. | Root/publication agent own atomic model terminal batch; notification/release sequencing and source cuts must remain exact. |
| Stable native request configuration | Already shared by exact configuration digest, exact byte equality and decoded semantics. Measured window has no configuration growth; CPU has few samples. | Keep full typed validation of shared config on metadata reads where required. A coherent rehashed structurally invalid configuration must still fail; do not trade this for an unsupported cache/proof. |
| AttemptStarted/TurnStarted before request preparation | `execution.rs:1488,1674,3093`: lifecycle start precedes context/plugin/provider preparation. Tests explicitly require TurnStarted on preparation failure. | Preserve crash/failure lifecycle evidence; cannot blindly move across awaited preparation or provider dispatch. Atomic tail optimization is the valid scope now. |
| Retained source indexing without a live subscriber | Late replay/source inspection consumes these layouts and their readiness holes. Exact historical capture is a RustX feature beyond the references. | Compact/share/index once; do not condition persistence on current subscriber count or drop bounded original source inspection. |
| WAL/NORMAL/fsync policy | Pi `node.ts:188–197` uses WAL/NORMAL and default1000-page autockpt, matching Rust policy; both have5000ms busy timeout. | No evidence supports weakening durability pragmas further to match Pi. DeepSeek JSONL has explicit checkpoint flush barriers and must keep separate idle vs durable-flush outcomes. |
| Alleged artificial short-turn sleeps | `aligned.rs:638` enables Notify before submission; the10ms sleep at666 is restricted to stream128 gates. Rust lock contention uses Condvar/block_in_place; busy backoff mirrors SQLite's finite5000ms schedule. | No fixed short-request timer to remove. Remaining off-CPU wall time requires actual lock/scheduler/WAL diagnostics, not deleting lifecycle checks based on CPU samples. |

Pi and DeepSeek also perform work: Pi compares serialized tools and plans configuration deltas; DeepSeek normalizes/compares headers and incrementally applies suffixes. Pi generation preparation commits request/checkpoint state and then live document state before stream work; it is not one transaction per entire turn. DeepSeek checkpoint policy flushes before model/tool/next-step boundaries, while SDK idle itself is not the explicit final persistence flush. These differences preclude an overall-parity claim based only on fewer logical bytes or a selected CPU symbol.

The credible uncovered layers above have implementations in this round. Residual exact serialization, native typed integrity checks, original disclosure/read budgets, lifecycle boundaries and read-cut validation are retained for concrete functions, not postponed speculative optimization targets. Fresh correctness, CPU/control, logical-column, actual process write and full cohort measurements are still required to decide the benefit of the combined source changes.
