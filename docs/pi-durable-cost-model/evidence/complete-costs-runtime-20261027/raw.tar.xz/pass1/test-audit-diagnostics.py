#!/usr/bin/env python3
"""Read-only negative checks for the evidence auditor; never executes products."""
import importlib.util,json,tempfile,types,unittest,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnostics',ROOT/'audit-diagnostics.py')
audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)

class EvidenceAuditTests(unittest.TestCase):
    def setUp(self):
        self.load=audit.load
        self.args=types.SimpleNamespace(root=ROOT,repo=audit.REPO,raw_only=True,expect_rust_sha256=None,
            baseline_identity=ROOT/'baseline-build/identity.json',candidate_identity=ROOT/'candidate-complete-build/identity.json')
        self.build=audit.load(self.args.baseline_identity)
    def tearDown(self):audit.load=self.load
    def changed_load(self,target,mutate):
        def load(path):
            result=self.load(path)
            if Path(path)==target:mutate(result)
            return result
        audit.load=load
    def test_sql_rejects_probe_identity_change(self):
        self.changed_load(ROOT/'sql-baseline-no-live/identity.json',lambda r:r.update(gdb_script_sha256='0'*64))
        with self.assertRaisesRegex(ValueError,'probe/runner'):
            audit.sql_diagnostic(self.args,'sql-baseline-no-live',self.build,'baseline',False)
    def test_sql_recounts_raw_instead_of_trusting_summary(self):
        self.changed_load(ROOT/'sql-baseline-no-live/prepare-counts.json',lambda r:r.update(measured_prepare_calls=r['measured_prepare_calls']+1))
        with self.assertRaisesRegex(ValueError,'SQL total'):
            audit.sql_diagnostic(self.args,'sql-baseline-no-live',self.build,'baseline',False)
    def test_wal_recounts_raw_instead_of_trusting_summary(self):
        self.changed_load(ROOT/'wal-summary-baseline.json',lambda r:r['short-small-rust'].update(wal_frames=r['short-small-rust']['wal_frames']+1))
        with self.assertRaisesRegex(ValueError,'WAL arithmetic'):
            audit.wal_diagnostic(self.args,'baseline',self.build,'short-small','rust')
    def test_column_kind_totals_must_match_cells(self):
        snapshot=self.load(ROOT/'columns-baseline-short-small/after_turns.json')
        snapshot['events_by_kind'][0]['rows']+=1
        with self.assertRaisesRegex(ValueError,'rows do not sum'):audit.validate_snapshot(snapshot,'baseline')
    def test_truncated_cpu_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'bad.cpu';p.write_bytes(b'\0'*40)
            with self.assertRaisesRegex(ValueError,'CPU header'):audit.raw_cpu(p,'nonexistent')
    def test_raw_identity_does_not_follow_embedded_binary_path(self):
        with tempfile.TemporaryDirectory() as d:
            directory=Path(d);copy=dict(self.build);copy['binary']='/absent/do-not-open/product'
            (directory/'identity.json').write_text(json.dumps(copy));shutil.copy2(ROOT/'baseline-build/build.stdout',directory/'build.stdout')
            self.args.baseline_identity=directory/'identity.json'
            actual,_=audit.verify_build(self.args,'baseline');self.assertEqual(actual['binary'],copy['binary'])
            self.args.raw_only=False
            with self.assertRaises(FileNotFoundError):audit.verify_build(self.args,'baseline')

if __name__=='__main__':unittest.main()
