import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
out=root/'checks-continuation';out.mkdir(exist_ok=False)
rows=[json.loads(line) for line in (root/'checks/tests-build.stdout').read_text().splitlines() if line.startswith('{')]
a={r['target']['name']:r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and (r['target']['kind']==['lib'] or r['target']['name'] in ('durable','process'))}
records=[]
commands=[('client',[a['rustx'],'runtime_client::','--skip','::scale::','--test-threads=2']),('conversation-runtime',[a['rustx'],'runtime::conversation_runtime::','--skip','::scale::','--test-threads=2']),('read-layout',[a['rustx'],'runtime::read_layout::','--skip','::scale::','--test-threads=2']),('content',[a['rustx'],'boundary_suites::durable::content::','--skip','::scale::','--test-threads=2'])]+[(name,[a[name],'--test-threads=2']) for name in ('durable','process')]
for name,cmd in commands:
 r={'label':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_identity':'../checks/source-before.json','scope':'Diagnostic continuation of that built binary, not a new frozen final validation'}
 with (out/(name+'.stdout')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:result=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'},stdout=stdout,stderr=stderr)
 r.update(exit=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(r);(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,result.returncode,flush=True)
