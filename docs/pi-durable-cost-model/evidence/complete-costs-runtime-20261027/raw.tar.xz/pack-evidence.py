#!/usr/bin/env python3
"""Package completed complete-costs evidence without executing products, audits or builds.

Run only after root confirms that all products and evidence writers have stopped.
This script preserves raw inputs; it does not certify their experimental results.
The per-file manifest is inside raw.tar.xz, not duplicated beside the archive.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import stat
import tarfile
import tempfile


ROOT = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
PASS1 = Path('/home/capi/.cache/rustx-pr485-complete-costs')
FREEZE = Path('/home/capi/.cache/rustx-pr485-next/deepseek-setup')
DESTINATION = REPO / 'docs/pi-durable-cost-model/evidence/complete-costs-runtime-20261027'
SKIP_DIRECTORIES = {'.git', 'target', 'node_modules', '__pycache__', '.venv', '.pytest_cache',
                    'archive', 'archives', 'extract', 'extracted', 'archive-check'}
RULES = {
    'include': [
        'final complete-cost plans, source analysis, logical columns, SQL/WAL evidence and retained reports',
        'frozen pass1/ exploratory evidence, original producers, all failures, 24 screen and 11 diagnostic products; never pooled',
        'all check* success/failure logs, commands and source snapshots',
        'both cohort stages, raw counters, identities, providers, wire and process logs',
        'all exploratory screens and diagnostic retries; no pooling with final matrices',
        'DeepSeek profile.patch.json and home/sessions native logs, including .zstd',
        'CPU .cpu raw data, symbols, control runs, commands and identities',
        'build identity plus complete Cargo/clean logs for prior joint baseline and complete candidate',
        'frozen repository harness, external producers, audit scripts, reference pins and DeepSeek freeze metadata',
    ],
    'exclude': [
        'native compiled executables, object/library formats, conformance artifacts',
        '.git, target, node_modules, __pycache__, prior archive/extract directories',
        'old tar/zip/xz archives; native .zstd sessions and raw .cpu are retained',
        'symlinks and non-regular files; never follow them outside the input roots',
    ],
}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def load(path):
    return json.loads(path.read_text())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def sha_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def fingerprint(path):
    item = path.lstat()
    require(stat.S_ISREG(item.st_mode), f'not a regular file: {path}')
    return (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)


def skip_path(relative, directory=False):
    parts = relative.parts
    for part in parts if directory else parts[:-1]:
        if part in SKIP_DIRECTORIES or part.startswith(('archive-', 'extract-')):
            return 'dependency, compiled-output, or previous archive/extract directory'
    name = relative.name
    if name == 'conformance' or name.startswith('conformance-'):
        return 'compiled conformance artifact'
    if name.endswith(('.tar', '.tar.xz', '.tar.gz', '.tgz', '.zip', '.xz', '.pyc')):
        return 'previous archive or Python bytecode'
    return None


def compiled_format(path):
    # Detect executable/object formats, not arbitrary binary data. In particular,
    # gperftools .cpu and native Zstd session logs are required raw evidence.
    with path.open('rb') as stream:
        head = stream.read(64)
        if head.startswith((b'\x7fELF', b'!<arch>\n', b'\x00asm', b'BC\xc0\xde')):
            return True
        if head[:4] in (b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
                        b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
                        b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
                        b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca'):
            return True
        if head.startswith(b'MZ') and len(head) >= 64:
            stream.seek(int.from_bytes(head[60:64], 'little'))
            return stream.read(4) == b'PE\x00\x00'
    return False


def inventory(root, external):
    selected, excluded = {}, []

    def add(path, relative):
        require(not relative.is_absolute() and '..' not in relative.parts and '\\' not in relative.as_posix() and '\x00' not in relative.as_posix(), f'unsafe archive path: {relative}')
        reason = skip_path(relative)
        if path.is_symlink():
            reason = 'symlink; not followed'
        elif not path.is_file():
            reason = 'non-regular file'
        elif reason is None and compiled_format(path):
            reason = 'native compiled executable/object/library format'
        if reason:
            excluded.append({'path': relative.as_posix(), 'source': str(path), 'reason': reason})
        else:
            name = relative.as_posix()
            require(name not in selected and name != 'MANIFEST.json', f'archive name collision: {name}')
            selected[name] = path

    for directory, folders, files in os.walk(root, followlinks=False):
        directory = Path(directory)
        kept = []
        for name in sorted(folders):
            path = directory / name
            relative = path.relative_to(root)
            reason = 'symlink directory; not followed' if path.is_symlink() else skip_path(relative, directory=True)
            if reason:
                excluded.append({'path': relative.as_posix() + '/', 'source': str(path), 'reason': reason})
            else:
                kept.append(name)
        folders[:] = kept
        for name in sorted(files):
            path = directory / name
            add(path, path.relative_to(root))
    for relative, path in external.items():
        require(path.is_file(), f'missing required external evidence: {path}')
        if relative in selected:
            require(sha_file(selected[relative]) == sha_file(path), f'external mount differs from existing raw evidence: {relative}')
        else:
            add(path, Path(relative))
        require(relative in selected, f'required external evidence was excluded: {relative}')
    return dict(sorted(selected.items())), sorted(excluded, key=lambda item: item['path'])


def preflight(root, selected):
    required = [
        'plan.json', 'final-matrix-plan.json', 'stage-layout.json', 'pass1-freeze.json', 'freeze-pass1.py',
        'audit-complete.py', 'complete-all-audit.json',
        'audit-diagnostics.py', 'diagnostic-audit.json', 'verify-archive.py', 'pack-evidence.py',
        'recompute-pi.py', 'recompute-three-engine.py', 'run-cohorts.py', 'run-screen.py',
        'run-diagnostics.py', 'columns-complete.py', 'run-profiles.py', 'profile-reports.py',
        'run-sql-prepare.py', 'run-sql-prepare-tx.py', 'sql-prepare.gdb.py', 'sql-prepare-tx.gdb.py',
        'run-wal-verified.py', 'run-wal-compact.py', 'analyze-wal-verified.py',
        'baseline-archive.json', 'baseline-producers/columns-commands.json',
        'baseline-producers/columns-joint.py', 'diagnostic-commands.json',
        'profile-commands.json', 'cpu-counts.json',
        'deepseek-setup/final-source-identity.json', 'deepseek-setup/setup.json',
        'direct-cohorts/commands.json', 'final-cohorts/commands.json',
    ]
    for build in ('baseline-build', 'candidate-complete-build'):
        required.extend(f'{build}/{name}' for name in ('identity.json', 'build.stdout', 'build.stderr', 'clean.stdout', 'clean.stderr'))
    matrix = load(root / 'final-matrix-plan.json')
    pairs, cases = matrix['formal_pairs'], matrix['cases']
    require(type(pairs) is int and pairs == 5 and cases == ['short-small', 'short-large', 'stream', 'large', 'tool', 'cancel'], 'unexpected predeclared final matrix')
    require(matrix['modes'] == ['no-live-subscriber', 'live-subscriber'] and matrix['deepseek_repetitions'] == 3, 'unexpected mode/native reference matrix')
    for stage, prefix, engines in [('direct', 'direct', ('before', 'after')), ('final', 'pi', ('rust', 'pi'))]:
        for mode in ('no-live', 'live'):
            directory = f'{stage}-cohorts/{prefix}-{mode}'
            required.extend((f'{directory}/manifest.json', f'{stage}-cohorts/{prefix}-{mode}.stdout', f'{stage}-cohorts/{prefix}-{mode}.stderr'))
            for pair in range(pairs):
                for case in cases:
                    required.append(f'{directory}/{pair}-{case}-comparison.json')
                    for engine in engines:
                        stem = f'{directory}/{pair}-{case}-{engine}'
                        required.extend(stem + suffix for suffix in ('.json', '.process.json', '.log', '.provider.log', '.provider.stdout'))
    three = 'final-cohorts/three-engine'
    required.extend(f'{three}/{name}.json' for name in ('manifest', 'records', 'metrics', 'product-metrics', 'summary'))
    required.extend(('final-cohorts/three-engine.stdout', 'final-cohorts/three-engine.stderr'))
    for repetition in range(matrix['deepseek_repetitions']):
        for case in matrix['deepseek_cases']:
            required.append(f'{three}/{repetition}-{case}-rust-pi-comparison.json')
            for engine in ('rust', 'pi'):
                stem = f'{three}/{repetition}-{case}-{engine}'
                required.extend(stem + suffix for suffix in ('.json', '.process.json', '.log', '.provider.log', '.provider.stdout'))
            native = f'{three}/{repetition}-{case}-deepseek'
            required.extend(f'{native}/{name}' for name in ('result.json', 'profile.patch.json', 'sample.provider.json', 'verification.provider.json', 'sample.wire.json', 'verification.wire.json', 'sample.runtime.stderr', 'verification.runtime.stderr'))
            sessions = [name for name in selected if name.startswith(native + '/home/sessions/') and name.endswith('/session.v4.jsonl.zstd')]
            require(len(sessions) == 1, f'expected one retained native DeepSeek session: {native}')
    for revision in ('baseline', 'complete'):
        for case in ('short-small', 'short-large'):
            required.extend(f'columns-{revision}-{case}/{name}' for name in ('before_measured_turns.json', 'after_turns.json', 'sample.json', 'sample.process.json', 'phases.json', 'identity-before.json'))
            for engine in ('rust', 'pi'):
                required.extend(f'wal-{revision}-{case}-{engine}/{name}' for name in ('before_measured_turns-database.json', 'after_turns-database.json', 'sample.json', 'sample.process.json', 'phases.json', 'identity-before.json', 'calls.strace'))
            required.append(f'wal-{revision}-{case}-comparison.json')
        required.extend(f'wal-{name}-{revision}.json' for name in ('identity', 'records', 'summary'))
        required.append(f'pi-http-wal-{revision}.mjs')
        for mode in ('control', 'cpu'):
            required.extend(f'profile-{revision}-live-large-{mode}/{name}' for name in ('manifest.json', 'sample.json', 'sample.process.json'))
        required.extend(f'profile-{revision}-live-large-cpu/{name}' for name in ('before_measured_turns.cpu', 'steady-cumulative.txt', 'steady-collapsed.txt', 'steady-cumulative.txt.stderr', 'steady-collapsed.txt.stderr'))
    for name in ('sql-baseline-no-live', 'sql-baseline-tx-no-live', 'sql-complete-tx-no-live'):
        required.extend(f'{name}/{filename}' for filename in ('identity.json', 'phases.json', 'prepares.jsonl', 'sample.json', 'sample.process.json'))
    missing = [name for name in required if name not in selected]
    require(not missing, f'missing completed evidence: {missing}')

    formal, diagnostic = load(root / 'complete-all-audit.json'), load(root / 'diagnostic-audit.json')
    for report, script in [(formal, 'audit-complete.py'), (diagnostic, 'audit-diagnostics.py')]:
        require(report.get('accepted') is True and report.get('mode') == 'strict' and report.get('strict_identity_verified') is True and report.get('errors') == [], 'complete successful strict audits required before packaging')
        require(report['script_sha256'] == sha_file(root / script), f'auditor changed after strict audit: {script}')
    require(formal['stage'] == 'all' and formal['recorded_build_identity_verified'] is True and formal['actual_build_identity_verified'] is True, 'formal audit did not verify both builds/all stages')
    require(set(formal['datasets']) == {'direct', 'final', 'three-engine'}, 'formal dataset inventory differs')
    for name, products, comparisons, requests in [('direct', 120, 60, 1410), ('final', 120, 60, 1410), ('three-engine', 36, 12, 414)]:
        data = formal['datasets'][name]
        require((data['derived_products'], data['valid_comparisons'], data['checked_requests']) == (products, comparisons, requests), f'incomplete {name} matrix')
    require(diagnostic['recorded_build_identity_verified'] is True and diagnostic['actual_binary_and_preload_verified'] is True and diagnostic.get('pending') == [] and diagnostic.get('allow_pending') is False, 'diagnostic strict identity/completeness missing')
    require(diagnostic['formal_audit']['sha256'] == sha_file(root / 'complete-all-audit.json'), 'diagnostic audit not bound to retained complete formal audit')
    require({key: len(diagnostic[key]) for key in ('profiles', 'columns', 'sql', 'wal')} == {'profiles': 4, 'columns': 4, 'sql': 3, 'wal': 8}, 'diagnostic product inventory incomplete')
    require(diagnostic['producer_windows']['candidate_wrapper_recorded'] is True, 'candidate diagnostic wrappers not recorded')
    for name, digest in formal['independent_dependencies'].items():
        require(name in selected and sha_file(selected[name]) == digest, 'independent raw auditor dependency changed')
    candidate = load(selected['candidate-complete-build/identity.json'])
    require(candidate['sha256'] == formal['identities']['complete']['sha256'], 'candidate identity differs from strict formal audit')
    require(formal['validation']['successful_complete_queues'], 'no final successful source-bound correctness queue')
    require(formal['phase_binding']['pass1_freeze_sha256'] == sha_file(root / 'pass1-freeze.json') and formal['phase_binding']['layout_sha256'] == sha_file(root / 'stage-layout.json'), 'formal audit is not bound to the frozen phase records')
    require(all(not name.startswith('pass1/') for name in formal['validation']['successful_complete_queues']), 'exploratory checks cannot validate final candidate')

    # Freeze exact producer code as evidence. These copies are for inspection;
    # only the separately retained read-only auditors run during portable replay.
    fixture_maps = [formal['queue_states'][stage]['source_before']['fixtures'] for stage in ('direct', 'final')]
    require(fixture_maps[0] == fixture_maps[1], 'final fixture sets changed')
    for filename, digest in {**fixture_maps[0], **candidate['harness']}.items():
        archived = 'frozen-harness/' + filename
        require(archived in selected and sha_file(selected[archived]) == digest, f'frozen producer bytes differ: {filename}')
    for row in load(root / 'baseline-archive.json'):
        require(row['archive'] in selected and sha_file(selected[row['archive']]) == row['sha256'], 'retained baseline archive input differs')

    states = {}
    ledgers = set(root.glob('check*/check-build-commands.json')) | set(root.glob('check*/**/commands.json')) | set(root.glob('exploratory*/commands.json'))
    ledgers |= {root / 'profile-commands.json', root / 'diagnostic-commands.json'}
    for path in sorted(ledgers):
        rows = load(path)
        require(isinstance(rows, list) and rows, f'empty/non-list command ledger: {path}')
        require(all(row.get('status', 'complete' if 'exit' in row else 'pending') in ('complete', 'failed', 'not_run') for row in rows), f'nonterminal command ledger: {path}')
        require(all(row.get('status') == 'not_run' or (type(row.get('exit')) is int and row.get('end_utc')) for row in rows), f'unfinished command ledger: {path}')
        states[str(path.relative_to(root))] = [{key: row[key] for key in ('name', 'label', 'status', 'exit') if key in row} for row in rows]
    for path in sorted(set(root.glob('process-repro*/command.json')) | set(root.glob('lint-probe*/command.json'))):
        row = load(path)
        require(type(row.get('exit')) is int and row.get('end_utc'), f'unfinished diagnostic probe: {path}')
        states[str(path.relative_to(root))] = {'exit': row['exit']}
    for stage in ('direct', 'final'):
        path = root / f'{stage}-cohorts/commands.json'
        record = load(path)
        require(record.get('source_after') and all(row.get('status') == 'complete' and row.get('exit') == 0 for row in record['steps']), f'unfinished final cohort: {path}')
        states[str(path.relative_to(root))] = [{key: row[key] for key in ('name', 'status', 'exit')} for row in record['steps']]
    return states, formal['queue_states']['final']['source_before']['head'], candidate['sha256']


def verify_archive(path, manifest_bytes, entries):
    seen = set()
    with tarfile.open(path, 'r|xz') as archive:
        for member in archive:
            require(member.isfile() and member.name not in seen, f'invalid archive member: {member.name}')
            seen.add(member.name)
            stream = archive.extractfile(member)
            require(stream is not None, f'missing member data: {member.name}')
            if member.name == 'MANIFEST.json':
                require(member.size == len(manifest_bytes) and stream.read() == manifest_bytes,
                        'archived manifest differs')
            else:
                expected = entries.get(member.name)
                require(expected is not None and member.size == expected['bytes'],
                        f'archive size/name differs: {member.name}')
                require(hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256'],
                        f'archive hash differs: {member.name}')
    require(seen == set(entries) | {'MANIFEST.json'}, 'archive member set differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=DESTINATION)
    parser.add_argument('--baseline-build', type=Path, help='Defaults to ROOT/baseline-build; retained files are already mounted there')
    parser.add_argument('--freeze-dir', type=Path, default=FREEZE)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--pass1-root', type=Path, default=PASS1, help='Frozen exploratory root; retained under pass1/ without using it as final validation')
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    require(not output.is_relative_to(root), 'output must be outside the raw input tree')
    require(not output.exists() or not any(output.iterdir()), f'refusing nonempty output directory: {output}')
    baseline = args.baseline_build or root / 'baseline-build'
    external = {f'baseline-build/{name}': baseline / name for name in
                ('identity.json', 'build.stdout', 'build.stderr', 'clean.stdout', 'clean.stderr')}
    external.update({f'deepseek-setup/{name}': args.freeze_dir / name for name in
                     ('final-source-identity.json', 'setup.json')})
    candidate = load(root / 'candidate-complete-build/identity.json')
    harness_files = {str(path.relative_to(args.repo)): path for folder in ('benchmarks/runtime', 'test-support/fake-provider') for path in (args.repo / folder).rglob('*') if path.is_file() and not any(part in SKIP_DIRECTORIES for part in path.relative_to(args.repo).parts)}
    require(all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in candidate['harness']), 'unsafe frozen harness source path')
    harness_files.update({name: args.repo / name for name in candidate['harness']})
    external.update({'frozen-harness/' + name: path for name, path in harness_files.items()})
    pass1 = args.pass1_root.resolve()
    require(pass1 != root and not root.is_relative_to(pass1) and not pass1.is_relative_to(root), 'pass1 and final roots must be disjoint')
    frozen = load(root / 'pass1-freeze.json')
    require(frozen['format'] == 'rustx-complete-costs-pass1-freeze-v1' and frozen['archive_prefix'] == 'pass1', 'invalid pass1 freeze')
    historical, historical_excluded = inventory(pass1, {})
    require(set(historical) == set(frozen['files']) and historical_excluded == frozen['excluded'], 'pass1 retained inventory/exclusions changed after freeze')
    external.update({'pass1/' + name: path for name, path in historical.items()})
    selected, excluded = inventory(root, external)
    excluded += [{**item, 'path': 'pass1/' + item['path']} for item in historical_excluded]
    states, revision, binary_sha = preflight(root, selected)
    native = load(root / 'final-cohorts/three-engine/manifest.json')
    reference_pins = {'pi_revision': native['pi']['revision'], 'deepseek_revision': native['deepseek']['revision'], 'deepseek_tree': native['deepseek']['tree'], 'deepseek_node': native['deepseek']['node']}
    fingerprints, entries = {}, {}
    for name, path in selected.items():
        before = fingerprint(path)
        digest = sha_file(path)
        require(fingerprint(path) == before, f'input changed while hashing: {path}')
        fingerprints[name] = before
        entries[name] = {'source': str(path), 'bytes': before[2], 'sha256': digest}
        if name.startswith('pass1/'):
            require({'bytes': before[2], 'sha256': digest} == frozen['files'][name.removeprefix('pass1/')], f'pass1 bytes changed since freeze: {name}')
    command = ['python3', 'audit-complete.py', '--root', '.', '--raw-only', '--stage', 'all',
               '--baseline-identity', 'baseline-build/identity.json',
               '--candidate-identity', 'candidate-complete-build/identity.json',
               '--freeze', 'deepseek-setup/final-source-identity.json',
               '--expected-harness-revision', revision, '--expect-rust-sha256', binary_sha,
               '--output', '../archive-complete-audit.json']
    diagnostic_command = ['python3', 'audit-diagnostics.py', '--root', '.', '--raw-only',
                          '--baseline-identity', 'baseline-build/identity.json',
                          '--candidate-identity', 'candidate-complete-build/identity.json',
                          '--formal-audit', 'complete-all-audit.json',
                          '--expect-rust-sha256', binary_sha,
                          '--output', '../diagnostic-raw-audit.json']
    created = datetime.now(timezone.utc).isoformat()
    manifest = {'format': 'rustx-complete-costs-raw-evidence-v1', 'created_utc': created,
                'raw_root': str(root), 'rules': RULES, 'files': entries, 'reference_pins': reference_pins,
                'excluded': excluded, 'command_states': states,
                'phases': {'final_products': 276, 'pass1': {'freeze_sha256': sha_file(root / 'pass1-freeze.json'), 'archive_prefix': 'pass1', 'files': len(frozen['files']), 'screen_products': 24, 'diagnostic_products': 11, 'scope': frozen['scope']}},
                'raw_only_audit_command': command,
                'raw_only_diagnostic_audit_command': diagnostic_command,
                'scope': 'Retained-file integrity and raw recomputation; excludes executable artifacts. '
                         'Not proof of reproducible builds or equivalent DeepSeek durability.'}
    manifest_bytes = encoded(manifest)
    output.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.raw-', suffix='.tar.xz.partial', dir=output)
    os.close(fd)
    temporary = Path(temporary)
    try:
        with tarfile.open(temporary, 'w:xz', preset=0) as archive:
            for name, path in selected.items():
                require(fingerprint(path) == fingerprints[name], f'input changed before packing: {path}')
                info = tarfile.TarInfo(name)
                info.size = entries[name]['bytes']
                info.mode = 0o644
                with path.open('rb') as stream:
                    archive.addfile(info, stream)
                require(fingerprint(path) == fingerprints[name], f'input changed during packing: {path}')
            info = tarfile.TarInfo('MANIFEST.json')
            info.size, info.mode = len(manifest_bytes), 0o644
            archive.addfile(info, io.BytesIO(manifest_bytes))
        verify_archive(temporary, manifest_bytes, entries)
        current, current_excluded = inventory(root, external)
        current_history, current_history_excluded = inventory(pass1, {})
        require(current_history == historical and current_history_excluded == historical_excluded, 'pass1 inventory changed during packing')
        current_excluded += [{**item, 'path': 'pass1/' + item['path']} for item in current_history_excluded]
        require(current == selected and current_excluded == excluded, 'input file/exclusion inventory changed')
        require(all(fingerprint(path) == fingerprints[name] for name, path in selected.items()),
                'input changed after packing')
        summary = {'format': manifest['format'], 'created_utc': created, 'archive': 'raw.tar.xz',
                   'archive_bytes': temporary.stat().st_size, 'archive_sha256': sha_file(temporary),
                   'manifest_bytes': len(manifest_bytes), 'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                   'raw_files': len(entries), 'raw_bytes': sum(item['bytes'] for item in entries.values()),
                   'excluded_entries': len(excluded), 'excluded_reasons': dict(Counter(item['reason'] for item in excluded)),
                   'stream_verified_all_members': True, 'compression': 'xz preset 0',
                   'harness_revision': revision, 'candidate_sha256': binary_sha, 'reference_pins': reference_pins, 'phases': manifest['phases'],
                   'raw_only_audit_command': command,
                   'raw_only_diagnostic_audit_command': diagnostic_command}
        readme = f'''# Complete-costs runtime evidence

`raw.tar.xz` contains 120 direct revision runs, 120 fresh Pi runs and 36 native
three-engine reference runs. Each direct/Pi case and observer mode has five
predeclared pairs. Exploratory screens, logical columns, SQL preparation and
write-transaction stacks, WAL syscall evidence, and CPU/control runs are retained
separately and are never pooled with formal medians.

The original first candidate is frozen under `pass1/`, with its own original
producers, build identity, all failed/successful checks, 24 exploratory screen
products and 11 diagnostic products. `pass1-freeze.json` records its exact file
hashes and phase scope; those checks never validate the final candidate and
those measurements never enter the final 276 products. Absolute recorded paths
remain original provenance; the matching compiled binary is excluded.

All retained failed and successful correctness queues, isolated repros, lint
probes, exact commands, source snapshots and build identities are included.
`summary.json` records the archive hash and size. `MANIFEST.json` inside the
archive records every payload hash, size, provenance path and exclusion reason.
Absolute paths inside captured records are historical provenance, not replay
inputs. No compiled product, dependency cache, or Python bytecode is included.

Extract into an empty directory and run the retained read-only auditors:

```sh
mkdir raw
tar -xJf raw.tar.xz -C raw
cd raw
{shlex.join(command)}
{shlex.join(diagnostic_command)}
```

Both commands use only relative archived identity/freeze inputs. Their outputs
stay outside `raw`. Python 3.11+ and its standard library are sufficient; no
product, package install, build, profiler, SQLite database or native session
decompression is run. `verify-archive.py` provides safe fresh extraction,
manifest checks and comparisons of the recomputed results with the preserved
strict reports. Run its `--help` for an explicit fresh verification directory.

`baseline-build/` holds the prior joint candidate build receipt and Cargo logs;
`candidate-complete-build/` holds this candidate's receipt and logs. The complete
candidate src/tests/Cargo input hash map is retained in its identity and final
correctness source snapshots. `frozen-harness/` includes the exact repository
benchmark scripts, fixed harness sources and provider sources (excluding caches). Root-level producer wrappers,
pinned arithmetic helpers, `audit-complete.py`, `audit-diagnostics.py`, native
DeepSeek source/dependency freeze metadata, and every raw command output remain.
The saved strict reports are `complete-all-audit.json` and `diagnostic-audit.json`.

DeepSeek compressed native sessions, resume evidence, wire/provider logs, profile
configuration and native projection-cache state are included. All cohort stdout
and stderr are preserved. CPU `.cpu` files and their symbols are included; new
symbolization requires the matching excluded executable. SQL preparations do
not count cached statement executions; WAL commit markers omit read-only
commits. Logical column bytes are not process writes, WAL bytes or device I/O.

Raw-only acceptance verifies retained identities and recomputed arithmetic. It
explicitly does not revalidate historical host binaries/current Git checkouts.
Missing counters remain unavailable, zeros and adverse samples remain visible.
Five pairs per cell do not establish the full seven-pair parity gate. Native
DeepSeek SDK idle does not await final JSONL flush/fsync and is an additional
reference, not an equal-durability comparison.
'''
        # All evidence and archive bytes were checked before publishing the output.
        os.link(temporary, output / 'raw.tar.xz')  # Atomic, refuses an existing destination.
        temporary.unlink()
        (output / 'summary.json').write_bytes(encoded(summary))
        (output / 'README.md').write_text(readme)
        print(json.dumps({key: summary[key] for key in
                          ('archive', 'archive_bytes', 'archive_sha256', 'raw_files', 'raw_bytes',
                           'stream_verified_all_members')}, indent=2))
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
