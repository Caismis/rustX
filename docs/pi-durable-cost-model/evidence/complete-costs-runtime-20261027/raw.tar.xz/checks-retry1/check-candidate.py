import datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
target=Path('/home/capi/.cache/rustx-pr485-target')
env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2','UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'}
records=[]
def source_snapshot():
 paths=sorted(p for folder in ('src','tests') for p in (repo/folder).rglob('*') if p.is_file())+[repo/'Cargo.toml',repo/'Cargo.lock']
 return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),scope='all src/tests and Cargo inputs before/after checks',files={str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
source_before=source_snapshot()
(root/'source-before.json').write_text(json.dumps(source_before,indent=2)+'\n')

def run(label,command,log_json=False):
 record=dict(label=label,command=command,start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');records.append(record)
 (root/'check-build-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(label+'.stdout')).open('w') as out,(root/(label+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd=repo,env=env,stdout=out,stderr=err)
 record.update(exit=result.returncode,status='complete' if result.returncode==0 else 'failed',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/'check-build-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(label,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
run('fmt',['cargo','fmt','--all','--','--check'])
run('tests-build',['cargo','test','--release','--config','profile.release.package.rustx.opt-level=0','--locked','--all-features','--lib','--test','durable','--test','process','--no-run','--message-format=json'])
rows=[json.loads(line) for line in (root/'tests-build.stdout').read_text().splitlines() if line.startswith('{')]
artifacts={r['target']['name']:r['executable'] for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and (r['target']['kind']==['lib'] or r['target']['name'] in ('durable','process'))}
for label,selector in [('sqlite','durable::sqlite::'),('client','runtime_client::'),('conversation-runtime','runtime::conversation_runtime::'),('read-layout','runtime::read_layout::'),('content','boundary_suites::durable::content::')]:
 run('tests-'+label,[artifacts['rustx'],selector,'--skip','::scale::','--test-threads=2'])
for name in ['durable','process']:
 run('tests-'+name,[artifacts[name],'--test-threads=2'])
run('clippy',['cargo','clippy','--release','--locked','--all-targets','--all-features','--','-D','warnings'])

source_after=source_snapshot()
(root/'source-after.json').write_text(json.dumps(source_after,indent=2)+'\n')
assert source_before['files']==source_after['files'],'source changed during correctness checks'
