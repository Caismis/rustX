# Publication / checkpoint 优化闭环

## 本轮实际消除了什么

原发布路径的主要问题是：一次很小的 native 状态变化，也要冻结当前状态、捕获和规范化整份 checkpoint、验证其预算，再测量真实事件 wire 长度；同一次原子 model settlement 又被拆成多个观察回调，重复执行这条路径。第一候选实现了按需 checkpoint 与原子 observation family，新 CPU 证据随后定位出 transcript 因页 cut 改变而重建未变条目的剩余成本；第二候选已经进一步把这个失效边界拆开。三项都已实现，不是下一轮建议。

本文件首先说明源码与合同，文末保留最终候选 CPU 诊断的全部结果。第一候选 `688e7c3e85a72ae7d3745aff7419fdcff21c4ec8` 的所有原始证据仍冻结在 `complete-costs`，没有被第二候选覆盖。本文初稿记录的第二候选当时尚未提交；现已形成最终候选提交 `f5cf22a8fbd2b1f0b3abc7fc2082a586f1126e20`，普通 O3 基准二进制 SHA-256 为 `8d033129f343660821b5fd7cef957a424e6d769c55948011f2798c6e2f3a0cb7`，与 `candidate-complete-build/identity.json` 一致。下面八个源码文件的哈希已重新读取确认不变；检查、构建和正式产品运行均由根代理串行组织。

### 1. 普通 delta 只捕获 admission 与 metadata，整份 snapshot 按需构造

`src/runtime_client/projection.rs:513` 的 `PublicationDraft::encode` 仍在发布 cursor 之前完成预算与编码检查，但 `capture_checkpoint`（约 869）现在返回借用的 normalized 域、metadata、预算证书和一个延迟 snapshot 构造 closure。`PreparedCaptures` / `checkpoint.rs:634` 的 `Capture::prepared` 让未变域共享一次规范化结果，并按当前 revision 重放 collection frontier。

当充分预算证明通过时，普通 delta 只排序其 metadata、验证真实事件长度，不再复制规范化域去构造一个随后丢弃的完整 `RuntimeClientSnapshot`，也不再执行全 checkpoint fit 遍历或重复完整 event admission。只有显式 snapshot/历史读取、replacement，或预算无法证明时才 materialize；压力路径继续使用原有精确 fit、eviction 顺序与失败行为。这个压力分支处理同一当前格式，不是兼容旧协议的备用路径。

证书只允许跳过已被证明的遍历，不代表最终 byte count。完整 fit 改变结果后会清除旧 metadata 证书，避免在旧 charge 上继续推理。存在 unsafe native quantity、不可证明结构或临界预算时，原有精确检查仍执行。`metadata_first_publication_skips_snapshot_copies_and_repeated_preflight` 与 `assembled_publication_budget_is_conservative_at_all_admission_boundaries` 对构造次数与充分上界有专门检查；既有差分测试还逐字比较原捕获与 fit 输出。

### 2. 同一次 model settlement 作为一个闭合 family 安装与释放

旧 `settle_model_turn_native` 已将 provider completion、canonical assistant、turn completion、attempt completion 原子提交，但观察侧将其作为各自的单事件 receipt 发布；正常完成分支因此对同一结算重复构造发布，并执行四次 readiness release 事务。

现在 `src/durable/observation.rs:550` 有显式有限的 `ModelTurnSettlement` family。`final_settlement.rs:485` 保留 assistant 和 adopted canonical 的各自原始 head，只合并释放范围，并让所有 family member 指向同一个 native batch；`observation_receipt.rs:227` 用实际存储字节认证完整 family。它是有限类型的 provider/canonical/可选 completion-or-adoption 边界，不是任意增长的事件队列。

`RuntimeObserver::publish_native_batch`（`conversation_runtime.rs:7430`）仅在最后成员回调处安装整个 family，然后一次 `mark_native_observation_ready`。中间 canonical/pending 回调由显式 `native_release_sequence` 标记抑制重复 Runtime Client 安装，原始业务事件和独立 observer 回调仍存在。`projection.rs:4497` 按 provider、assistant canonical、turn、attempt/adoption 顺序 fold 完整 family，再更新一个 cut 和发布。

正常四成员 completed 分支由四次安装/释放减为一次；其他有限分支按自身完整边界处理，不宣称每种工具或 adoption 流程都是相同四成员。超过八条 adopted user 挤出 bounded canonical head 的情况仍保留独立 assistant head；missing/corrupt receipt、安装失败或 readiness 事务失败均不能静默释放某个成员。缺 receipt 的 native 入口现在明确 `source_failed`，不再用单独 JournalSourceReady 绕过 family。

这消除的是同一 durable 原子结果在观察层的重复工作，没有取消 canonical/terminal/adoption 事件、历史可见性或实际源认证，也没有将持久确认改成异步成功。

### 3. transcript 条目缓存与当前页 cut 分离

第一候选的新 profile 中，`capture_checkpoint` 仍有 26/223 个 inclusive 样本。其中 12 个属于 prepared transcript 初始化，具体栈包含每条 `bounded_clone` 的 JSON 序列化、Value 容器检查、typed 解码，再计长。不能将这个函数名误读为 lazy snapshot 没生效或完整 snapshot 被构造了 26 次。

根因是旧 owner 的相等性比较覆盖整个 `RuntimeClientTranscriptPage`：即使 entries 完全不变，`source_cut`、statistics 或其他 envelope 字段一变，也会使整页 prepared capture 失效。第二候选已删除整页 owner，改为三个独立 bounded owner：`transcript_entries`、`transcript_deferred_entries`、`transcript_statistics`（`prepared_capture.rs:25,83`；`projection.rs:937`）。entries 只绑定 conversation id 与完整 entries；浮点和非空 JSON map 仍必须满足精确编码复用规则，不能用忽略 signed zero 或 map 顺序的普通 Eq 冒充相等。

source_cut/content/collections/inherited_through/next_cursor 始终取当前 seed，直到确实 materialize 才组装 page；metadata evidence 也使用当前 transcript content。没有保留第二份完整 cached page。deferred→statistics→entries 的共享入场顺序不变，预算不足仍运行真实构造；各字段的 fit charge 合成为充分预算，不替代最终 exact length。全局 prepared owner 数从 19 增到 21，缓存仍仅绑定当前 immutable seed 可共享的有限域。

四条新增回归覆盖 cut 数位增长/当前 envelope/历史 seed 不变、statistics 与 deferred 独立失效、前置 messages 造成的共享预算压力，以及 entries 中 signed zero、map insertion order、超容器和 wide integer。每个变体与原 capture/fit 逐字比较；cut-only 额外断言零 normalization rebuild 和零 snapshot materialization。

## 还保留了哪些 CPU 工作，为什么不能直接删

**真实 structural wire 计长仍执行。** `checkpoint.rs:404` 把真实 structural serializer 写入计数 sink；`structural_json.rs:173` 对 native u64、受安全整数上限约束的 quantity 与 opaque JSON 使用不同规则。无上限 native u64 即使值为 1 也可能编码为字符串，所以“小整数”不能证明普通 serde JSON 与协议字节相同。`projection.rs:6526` 用 exact count 驱动 16 MiB replay 预算与 cut 过期；用 conservative fit 上界替换会提前淘汰、改变可重放范围，延迟到传输时才验证又会改变失败/cursor 的发布边界。

这说明当前 exact length 工作承担功能，并不说明其实现无法进一步优化。编译后的 schema 路径、带精确尺寸的不变片段仍可能减少其遍历；必须同时保留 escaping、opaque 字段、schema branch、revision 数位变化、replacement 和错误行为。单纯缓存本次输出字节不减少这次编码，还增加常驻内存；当前 in-process 基准也不能假定其后必有一次可消除的 transport 序列化。

**working state 冻结仍复制当前 bounded snapshot。** `projection.rs:6616` 的 `capture_working_seed` 使编码离开 runtime 状态锁，并让已发 seed/历史读取在后续 mutable fold 中保持不变。整份深克隆不是功能本身不可替代的要求；可用按域不可变 owner 与 copy-on-write 实现同样语义。当前 trace/capability head 已采用 owner 复用，但对其他域统一改造需要覆盖所有 mutation、hydration、trace-cut stamping 和 eviction 入口。只给外层 snapshot 加 Arc 后再 `make_mut` 仍会复制整份；漏掉任何更新会错误复用旧值或使历史 seed 被原地改变。

**当前不做 17 域全面所有权重构的依据有明确上限。** 第一候选 profile 中明确落在 snapshot clone 的是 14/223（约 6.3%）个 inclusive CPU 样本，`capture_working_seed` 总计 19/223。这个单次 live short-large profile 不是所有 workload 的比例，不是 wall-time 贡献，也不是潜在全部收益的上限；内联与采样精度限制了归因。但它尚不足以证明一次跨 17 域、多写入口的所有权重构应取代已定位且更聚焦的 transcript 失效修复。第二候选先完成后者并重新测量，保留 clone 作为已知剩余优化空间，不称其“已无可优化”或“全部必需”。若新证据显示 state freeze 在实际目标 workload 中成为主要成本，再统一域所有权有合理依据。

无 live subscriber 时已有 Runtime Client projection 仍维护全局 cursor/replay；后台 read-domain refresh 则已经在无 subscriber/显式读需求时跳过。Pi 的 mount 可随最后 observer 退出而丢弃，这部分合同不同。直接停掉 rustX 无订阅发布会改变 late reader、旧 cursor 重订阅和历史 cut，不是单纯降低到 Pi 的持久性即可安全消除。

## 检查闭环与性能证据边界

第一候选 fresh baseline / candidate 原始 250 Hz CPU samples 独立计数为 312 / 223，和 collapsed 权重一致。publication 内互斥分区为 baseline 35 capture + 40 length + 3 other = 78，candidate 26 capture + 25 length + 1 other = 52；candidate exact length 中 11 个栈进入 metadata，14 个为 events/其他。以上为有限诊断，不是该补丁单独造成的百分比，也不证明任何跨 workload 的 Pi parity。

初稿先核对了 `FINAL/checks-continuation/client.stdout` 的 547 passed、0 failed、1 ignored，以及四条新增 transcript 回归通过；这是历史 continuation，不代替最终检查。现已直接读取 `FINAL/checks-retry1/check-build-commands.json` 与对应 stdout：最终统一队列全部 exit 0，SQLite 479、Runtime Client 547、conversation runtime 95、read layout 26、content 27、durable 147、process 62，共 **1,383 passed、0 failed、1 ignored**；`cargo fmt --all -- --check` 和 release/all-targets/all-features Clippy（`-D warnings`）也均成功。源码前后快照及候选构建输入的一致性已由最终 strict 独立审计校验。

最终 O3 构建和下文 CPU/profile 已完成。已直接读取最终 `complete-all-audit.json`：`accepted=true`、`mode=strict`、`stage=all`、`strict_identity_verified=true`、`actual_build_identity_verified=true`、`errors=[]`。正式 direct/fresh Pi/三引擎分别为 120/120/36 个产品、60/60/12 个比较、1,410/1,410/414 次请求检查，共 276 产品。该报告 SHA-256 为 `7555feb0207f9289679325c9c95ca901976e32776b4e1d49fa7b109fbaa533b6`，正式性能表读取此已接受报告，不使用第一候选的有利样本代替最终候选。

同样已读取 `diagnostic-audit.json`：`accepted=true`、`mode=strict`、`strict_identity_verified=true`、`actual_binary_and_preload_verified=true`，`errors=[]`、`pending=[]`；覆盖 4 profiles、4 column snapshots 组、3 SQL probes、8 WAL traces，并以 SHA 绑定上面的正式审计。诊断报告 SHA-256 为 `9af81fd0ec13b1acacc24d809ed34c9630f4d13c944db7c7345d44a06326fd26`。此状态表示 strict 审计完成，不提前宣称尚待打包后的 portable 解包复算已经完成。

## 最终候选的本文相关源码快照

- `src/runtime_client/checkpoint.rs`: `995c2aec469f4843e668191db3bdbbacf2cc6f1c68ba2212d91ce4ab4af9ce1d`
- `src/runtime_client/projection.rs`: `eab146ae920bdd551b29d4a504c947e3674d210865ceea51495688166dd6cd4e`
- `src/runtime_client/projection/prepared_capture.rs`: `8f83f02da607917dbd1306b72b21af0facd49336d2058df4c1ca285252c4a286`
- `src/runtime_client/projection/incremental_checkpoint_tests.rs`: `d1a185557eba66469d5fbfa6040cd49b95bcf05953122ac5501e9131af83761d`
- `src/runtime/conversation_runtime.rs`: `411f67baf3bc5557e775f35b54cbf9aabd02f5fb55e5405e798fcd54d2b5da9a`
- `src/durable/sqlite/final_settlement.rs`: `f5adbeb68d5b580d99e47bf0a7c2ea876b69a5e27693727f3950256101cc7afa`
- `src/durable/sqlite/observation_receipt.rs`: `3038224a9a12b9f9c6026d3224488b501493d637075c447fbaa14c44a429410a`
- `src/durable/observation.rs`: `1458b07cab181379cd33e8a6a3073905ca1e6f5f6c9f69aa6e86143f0fd76578`

## 最终候选单次诊断补充（正式矩阵开始前）

独立重新按 `FINAL/profile-{baseline,complete}-live-large-cpu/steady-collapsed.txt` 每行末尾权重求和，baseline 为 314，最终 candidate 为 312。这次采样并未显示整体 CPU 样本或 publication 总桶下降，不能沿用第一候选的 223 样本代替最终候选结果。以下计数均为 CPU 样本命中，不是函数调用次数、重建次数或耗时节省。

| 观察路径 | baseline | 最终 candidate |
| --- | ---: | ---: |
| 全部样本 | 314 | 312 |
| PublicationDraft encode | 61 | 62 |
| 其内互斥：capture | 24 | 22 |
| 其内互斥：exact structural length | 30 | 36 |
| 其内互斥：其他 | 7 | 4 |
| length 中的 ProjectionMetadata | 15 | 16 |
| length 中的 events/其他 | 15 | 20 |
| capture_working_seed（位于上述 encode 外） | 7 | 23 |
| 其内明确 RuntimeClientSnapshot clone | 6 | 21 |
| ReadDomainCut read_with_trace | 38 | 29 |
| sqlite3LockAndPrepare | 63 | 18 |

最终 candidate 的 transcript entries prepared 路径有 8 个样本，均经过 `OnceLock::initialize`：JSON parse 3、preflight 2、Value drop 1、JSON buffer serialize 1、JSON length 1。baseline 旧整页 prepared 初始化为 7 个样本。这证明正常工作负载中仍存在真实 entries 初始化工作；并不能判断发生了几次、是否由实际条目变化、预算或不安全编码相等性引起，更不能据此推翻已通过的 cut-only 零重建及精确字节/预算差分。两份栈都没有命中 `fit_checkpoint`；零采样也不能证明该路径绝未执行或完整 materialization 次数为零。

最终 candidate seed 的 23 个样本中，21 个明确属于 snapshot clone（占全部样本约 6.7%）：capabilities 15、transcript 1、message descriptors 3、session model 1、messages 1；另 2 个可见 Eq 工作。此处 clone 是真实剩余工作，不应被称为全部必要或已消失。这份单次诊断仍不足以把 17 域所有权重构的可能收益换算成最终 wall/CPU 改善。

同一 profile 产品 `sample.json` 的累计消费通知端点提供了不同于采样的实际计数。两边均有 64 history turns 和 32 measured turns；baseline 第 63 turn 末为 1,089、第 95 turn 末为 1,635，测量区间增加 **546** 条；candidate 对应为 901→1,352，增加 **451** 条。少 95 条、约每 turn 少 3 条，与模型结算 family 减少分散通知的机制一致。但这是 consumer notification 记录数，不是所有 projection 发布次数，更不是后台 read 调用次数；记录本身不提供后两项计数，不能从 CPU 样本倒推。publication 内 read-domain `commit_display` 命中 26→31、native batch 15→11、native actor 10→7、其他 10→13，同样只是采样分区。

profile 和无 profiler control 是不同诊断运行，调度、采样扰动和消费节奏都可能不同。因此不根据这一个样本作最终变快/变慢结论，不声称已测得 publication 总降幅，也不因为 entries 的 8 对 7 命中数撤销有功能证明的复用修复。全部不利结果保留；最终性能结论使用预先固定的正式五对矩阵，诊断与探索结果不混入正式统计。本段写成后即冻结分析，正式运行期间没有追加重型解析；当前仅补充完成状态和源码复核结论。

本段 collapsed 输入 SHA-256：baseline `45aad18d956a10ebc5599b6f35f07826d264b016495ae1ce6f6396ad9c7fc1da`；candidate `96629eb729d17cefe2258a884c167ac185efa206fee45151e7a42906d7baed58`。

## 剩余工作的独立复核与本轮收尾建议

再次沿当前源码检查后，没有找到可以无条件删除、又保持现有 wire/cut/error 合同的第二次普通完整编码。`bounded_structural_len_with_budget` 对成功普通 delta 只执行一次真正的 schema-aware serializer；replacement 或 admission 失败时的追加工作有不同输出/错误语义。36/312 的 exact-length 样本说明这仍是值得关注的实现成本，不能据此把整个桶视为冗余。16 个 metadata 命中也不等于 16 个全部未变的 metadata 命中：当前 revision、read cut、content locator 与 frontier 都参与编码。利用不可变片段累计精确长度或编译 schema 路径可能保留全部功能，但现有证书只是充分上界，并没有可直接替代它的、已经证明精确的尺寸缓存。

state freeze 有更聚焦的剩余方向：21 个 snapshot clone 样本中 15 个来自 capability header。`capture_working_seed`（`projection.rs:6629–6630`）既深拷贝 `snapshot.capabilities`，又共享已有 `PreparedCapabilityHead`；普通 admission 已使用后者（约 1193），但历史 `checkpoint_page` 和 auxiliary pages（约 1690、1891–1907）仍读 seed 中原来的 capability header。这是可具体定位的重复持有/复制，单 capability 域的不可变 owner 比全面改造 17 域更有针对性。不过当前 `PreparedCapabilityHead` 存的是经过 admission 的 `PreparedPage`，初始化时的 `initial_capabilities` 则直接进入 snapshot（约 2465）；不能未经差分证明把 normalized rows 当作所有原始 page 的替身，尤其要保留 invalid/omitted rows、offset、内容字节和历史 revision。当前没有已经完成这些证明、可直接删除该复制的补丁，也没有单独的正式收益测量。

本轮建议以最终通过检查的候选、完整正式矩阵和独立审计收尾，准确称为“已落地并验证本轮主要冗余”，不要称“所有性能优化完成”或“剩余成本都不可优化”。继续优化时优先验证单 capability owner 的共享及精确结构计长的分片方案；不应仅凭一次 inclusive profile 就承诺其 wall 收益，或为了消掉该桶而改变 late-reader/replay/错误功能。此结论既承认具体剩余机会，也没有把未经实现和差分验证的结构改造伪装成已完成工作。
