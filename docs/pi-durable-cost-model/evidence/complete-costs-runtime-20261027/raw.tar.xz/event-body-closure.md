# Closure of the obsolete event body copy

This follow-up removes an obsolete persisted representation and its unused read API. It does not alias native bytes into a current observation interface, and it does not claim measured CPU, wall-time, transaction, or WAL improvement before the final candidate runs. The source is frozen for root's unified checks. This agent performed source inspection, `git diff --check`, and Rust syntax parsing only; it did not build or run the product.

## Identity and evidence boundary

The removed implementation is pinned at RustX `688e7c3e85a72ae7d3745aff7419fdcff21c4ec8`. New line references below refer to the post-format shared working tree in `/home/capi/.codex/worktrees/pr485-pi-performance/rustX`, with edited-file hashes recorded at the end. They are not GitHub links to an already committed final candidate. Root owns final compilation, tests, commit, and measurement. The frozen prior measurement root `/home/capi/.cache/rustx-pr485-complete-costs` is pass 1; this document is in the distinct final root. It does not modify or reinterpret pass 1 as final data.

Retained pass-1 evidence: `columns-complete-short-large/before_measured_turns.json` and `after_turns.json`. Their SHA-256 values are respectively `059b29636c60e3fe857898994163583b517238331cde09030b35ca04729889f6` and `de5a9c3c4862f98e46c6f54c7282bb01f39ad8004610099ce4047a7e52c3def9`. `columns-complete.py:28–42` computes column-value bytes as `sum(length(cast(column as blob)))`, not SQLite page allocation or WAL traffic. Its independent equality query is:

```sql
SELECT count(*),coalesce(sum(length(event_json)),0)
FROM events
WHERE observation_json IS NOT NULL
  AND cast(observation_json as text)=event_json;
```

The snapshots increase from 512 to 768 equal rows and from 201,884 to 303,004 equal native bytes. The measured interval has 256 added event rows. Thus all 256 added rows in this interval have equal native and old display-copy bytes, totaling 101,120 bytes. This equality is measured for this workload, not assumed for all possible events. The temporary database named in the JSON no longer exists; this analysis uses retained query results rather than pretending to re-query it.

## Removed path and exact work

Whole-repository reference inspection found `latest_observation_events` in the trait, SQLite implementation, and tests, with no current production caller. `ObservationEventHeader` existed only to return that obsolete API. The type and method now have no references in `src` or `tests`.

| Removed item | Pinned old source | Current replacement or decision |
| --- | --- | --- |
| `ConversationStore::latest_observation_events` | [inbox.rs:2118](https://github.com/Caismis/rustX/blob/688e7c3e85a72ae7d3745aff7419fdcff21c4ec8/src/durable/inbox.rs#L2118) | Deleted, no compatibility alias. Current callers use witness/field and statistics APIs. |
| SQLite trait implementation | [sqlite.rs:2626](https://github.com/Caismis/rustX/blob/688e7c3e85a72ae7d3745aff7419fdcff21c4ec8/src/durable/sqlite.rs#L2626) | Deleted. |
| Header and kind-list merge/limit reader | [observation.rs:157](https://github.com/Caismis/rustX/blob/688e7c3e85a72ae7d3745aff7419fdcff21c4ec8/src/durable/observation.rs#L157), [sqlite/observation.rs:1184](https://github.com/Caismis/rustX/blob/688e7c3e85a72ae7d3745aff7419fdcff21c4ec8/src/durable/sqlite/observation.rs#L1184) | Type, merge, lookup, and old-only schema assertion deleted. |
| Per-event duplicate body encoder and optional write | [sqlite.rs:11551–11564](https://github.com/Caismis/rustX/blob/688e7c3e85a72ae7d3745aff7419fdcff21c4ec8/src/durable/sqlite.rs#L11551-L11564) | `persist_event_tx_internal` at current `sqlite.rs:11339` goes directly through current derived owners; there is no `json_available` term. |
| `events.observation_json` cell | [sqlite.rs:8825](https://github.com/Caismis/rustX/blob/688e7c3e85a72ae7d3745aff7419fdcff21c4ec8/src/durable/sqlite.rs#L8825) | Deleted from event schema and expected-column verification. Schema remains the not-yet-pushed coordinated version 79; no migration. |

For each successfully appended native Journal event, this removes one `checkpoint::bounded_bytes(&event, 16384)` call and one optional `UPDATE events SET observation_json=? WHERE sequence=?`, including the successful `SAVEPOINT`/`RELEASE` pair around that update. The old bounded encoder performs preflight and, when admitted, a capped serde JSON serialization (`checkpoint.rs:350`); huge rejected inputs did not necessarily undergo a full second serialization, but the old UPDATE still attempted to store NULL. Under the 256-event interval, the removed healthy path is 256 bounded-encoder calls and 256 UPDATEs plus 512 savepoint-control statements. These are source-derived operation counts, not sampled timings or exclusive CPU attribution.

There is **no removed top-level semantic commit or release commit**: the optional savepoint belongs to the existing append transaction (`sqlite.rs:21669`). The native `event_json` encoding and insert remain authoritative, along with current witness, source, Trace, statistics, execution, membership, lifecycle, and readiness work. Index names used by the old reader are not automatically obsolete: `events_kind_idx` and `events_attempt_kind_idx` remain used by current fact, turn, membership, Trace, and history readers (`sqlite.rs:8328`, `observation_turn.rs:61`, `observation_members.rs:55`, `observation_trace/event.rs:34`, `reading.rs:67`). They were retained.

The similarly named **`inherited_turn_provenance.observation_json` and `observation_json_witness` remain current** (`sqlite.rs:8595–8599`, `provenance.rs:89–112`). This change removes only the events-table field. Final diagnostic scripts must report that retired layout as absent, not fabricate a measured zero, and retain the pass-1/baseline column evidence.

## Logical opportunity, without a WAL or speed claim

| Pass-1 measured interval | Logical column-value-byte increase |
| --- | ---: |
| Native `events.event_json` | 101,120 |
| Removed `events.observation_json` | 101,120 |
| Current `events.observation_source_inline` | 101,632 |
| Current `events.observation_witness` | 137,856 |
| Current `events.observation_trace_fact` | 111,040 |
| All event columns | 800,101 |
| All tables' column values | 1,927,150 |

The removed cell represents 12.64% of the measured event column-value growth and 5.25% of all-table column-value growth. Under an identical event workload those bytes have no replacement cell in the new schema. This does **not** establish corresponding physical page, WAL-frame, syscall, CPU, or wall-time savings. Fewer updates can interact with page packing and later updates; only fresh candidate WAL and performance data can quantify that. It does not establish parity with Pi Durable or DeepSeek Harness.

## Regressions kept on current interfaces

- `tests/boundary/durable/content.rs:462`, renamed **`t15_t20_journal_witness_and_statistics_use_bounded_native_evidence`**: preserves statistics-at-cut, reopen, indexed statistics lookup, giant failure normalization, and full failure-range readback. It now exercises `observation_event_witness` and exact `event_value_read` on the 2.7 MB diagnostic. It verifies deferred metadata remains at most 16 KiB, the first 64 source bytes exactly equal `serde_json::to_vec(&"diagnostic".repeat(300_000))[..64]`, the exact full `readable_end`, next offset, and rejection before the event's historical cut. SQL rejects a witness larger than 16 KiB. Assertions solely for obsolete kind-merge/limit behavior were removed with that API.
- `sqlite.rs:20243`, **`t12_t19_native_failure_receipt_and_range_preserve_public_normalization`**: giant event-ID coverage moved to the current witness lookup. A SQLite authorizer denies reading both native `events.event_id` and `events.event_json` during the witness seek. The test asserts absent giant display ID and bounded witness, while preserving public failure privacy, exact normalized source, and native private data retention.
- `observation_member_tests.rs:1122`, renamed **`t10_t14_t19_event_witness_failure_keeps_original_terminal_and_lifecycle`**: removes only the deleted-column trigger branch. Actual failure injection for current witness, transcript, and unavailable-flag writes remains, as do native terminal/lifecycle survival and subsequent healthy-append assertions. The helper at line 1089 now checks the bounded witness cell rather than the obsolete body.
- `sqlite.rs:19838`, **`t10_t19_t20_readiness_repair_preserves_independent_auxiliary_failure`**: the independent failed optional owner is the event-local inline field source, injected with `BEFORE UPDATE OF observation_source_inline`. That savepoint can roll back while an independent mandatory witness and the original Trace fact are retained. The test now explicitly checks the Trace header is valid before repair and that this event's field read still fails after readiness repair. Its original assertions that readiness repair cannot clear the independent unavailable flag and that the next healthy event succeeds are all retained.

Both renamed tests were sent to the final formal auditor owner for its required-test list. The first final SQLite group ran 479 tests: 478 passed, and the readiness-repair fixture failed at its final healthy-event assertion because its initial replacement injected a Trace-fact hole. Such a hole correctly propagates to later Trace metadata; it was not equivalent to the removed local-body owner. The fixture was therefore corrected to the current inline-source owner as described above, without changing production code or weakening that assertion. Original failed logs remain in `FINAL/checks/tests-sqlite.stdout`. Root owns the retry; this document does not predeclare its result.

## Why the other two bodies are not the same representation

`event_json` uses ordinary serde JSON encoding of the native envelope. `observation_source_inline` stores `SeekableObservationSource` structural JSON (`observation_event.rs:442–458`, `runtime/read_layout.rs:521–535`). The structural encoder intentionally emits schema-defined unrestricted u64 quantities as decimal strings (`structural_json.rs:173–187`). The native envelope sequence is u64 (`events/types.rs:146`); even a small value differs as native `"sequence":123` versus structural `"sequence":"123"`. The 512-byte measured difference between inline and native totals is consistent with two extra quotes for 256 sequence values, but the totals alone do not prove that these are the only differences for every row.

Current field reads expose structural bytes and exact byte coordinates. An alias to ordinary native JSON changes value types, offsets, and exact returned bytes. The inline reader rejects wrong types, oversized cells, and extent mismatch before materializing the body (`observation_event/inline.rs:39`), then checks JSON field geometry. That bounded current read is not interchangeable with decoding arbitrary native event JSON.

There is a real optional-domain requirement, not just a test name: a trigger that rejects the inline-source UPDATE leaves native `read_events` intact, preserves finite mandatory witness facts, marks observation unavailable, and makes source reads fail (`observation_event_probe_tests.rs:736`). Malformed or wrong-extent inline bytes fail closed while native Journal readback still succeeds (`observation_event_probe_tests.rs:637`). `index_optional` at `observation_event.rs:372` independently retains terminal witness facts when full source indexing fails. These current behaviors remain untouched.

A future design could derive structural bytes from a bounded native body on demand and retain a separate admission descriptor. That would be a new read/write tradeoff, requiring exact map/float/schema/u64/opaque-value and byte-geometry proofs, plus an explicit physical-corruption coupling policy. It introduces decode/re-encode on reads. It is not a zero-cost alias, and this round does not introduce such a descriptor or fallback. The obsolete third body could be deleted entirely; that is the simpler concrete action taken here.

## Witness and Trace overlap: concrete independent owners, not an impossibility claim

The bounded witness (`durable/observation.rs:163`) includes live publication evidence and finite previews: occupancy, native-direct status, trace total, source-unavailable state, transcript cursor, bounded IDs, native tool occurrence, canonical result position, deferred fields, and value. Trace headers (`durable/trace.rs:58`, `sqlite/observation_trace/event.rs:739`) hold historical relational facts, location/owner anchors, bootstrap facts, aliases, and canonical-field readiness. They are not two serializations of the native envelope.

Shared fields such as sequence, timestamp, and kind are duplicated. Current Trace reads compare those stored header values to independent native row coordinates and owner (`observation_trace.rs:144–170`), catching disagreement. Simply deleting them without replacing that integrity condition weakens the existing corruption check. Directly making Trace depend on the witness also couples previously independent optional owners: own RequestStart Trace evidence survives missing optional request layout (`request_span_integrity_tests.rs:85`), and Trace bounded reads work with native body reads explicitly denied (`observation_trace_tests.rs:498,573`). Similarly, a valid finite terminal witness can survive source-indexing failure. A larger common capsule is possible only with clear independent-presence/error handling and bounded identity reads; it is not proven to reduce total SQL/CPU.

A narrower remaining option is a private compact tuple codec for witness and Trace cells, preserving all values, independent cells, corruption validation, and public encodings. The outer witness JSON has 224 bytes of key names, quotes, and colons per fully populated encoding; Trace has 109. At 256 values each this identifies up to 57,344 and 27,904 removable outer-key bytes before codec overhead, **not a measured candidate saving or a bound on whole-cell savings**. Public 16 KiB admission must remain exact; `attach_transcript` currently uses JSON field patching (`observation_event.rs:404`), and every stored-evidence decode/check would need to agree on the private format. This is an actionable separate representation change, not implemented or benchmarked here. The final CPU/WAL results should determine whether it justifies another round rather than assuming logical key bytes explain overall engine differences.

## Edited-source snapshot

Base HEAD observed while recording: `688e7c3e85a72ae7d3745aff7419fdcff21c4ec8`.

| Edited file | SHA-256 at source freeze (fixture correction included) |
| --- | --- |
| `src/durable/inbox.rs` | `92f5c1ee9d5a0495e28e8111817500892472d7c3c296d54ff8ef406efb2e5180` |
| `src/durable/observation.rs` | `1458b07cab181379cd33e8a6a3073905ca1e6f5f6c9f69aa6e86143f0fd76578` |
| `src/durable/sqlite.rs` | `8f8ed41b5b69eadc418c95f65ab3cd85add8f6b2a044a3ce2c8e1e873e4a8f98` |
| `src/durable/sqlite/observation.rs` | `eadf2f1f044e4c3959f7bc5fba099aa73157d36f7e0f67d5665479abb3de7452` |
| `src/durable/sqlite/observation_member_tests.rs` | `ef8a4ab9c6616006d9ecbf243341d3b5b0900434cd17a109b045c82bc4bc165d` |
| `tests/boundary/durable/content.rs` | `88b2c925807b78fabb1cadf18a3d6bc557e4fbb8fde358e4988dd25a21534ca7` |
