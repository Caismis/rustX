#!/usr/bin/env python3
"""Freeze the exploratory first pass without moving or changing its inputs."""
import datetime,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
PASS1=Path('/home/capi/.cache/rustx-pr485-complete-costs')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def main():
 output=ROOT/'pass1-freeze.json'
 if output.exists():raise ValueError('refusing to overwrite first-pass freeze')
 spec=importlib.util.spec_from_file_location('old_pack',PASS1/'pack-evidence.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 files,excluded=module.inventory(PASS1,{})
 records={}
 for name,path in files.items():
  before=module.fingerprint(path);digest=sha(path)
  if module.fingerprint(path)!=before:raise ValueError('file changed during freeze: '+name)
  records[name]={'bytes':before[2],'sha256':digest}
 after,after_excluded=module.inventory(PASS1,{})
 if after!=files or after_excluded!=excluded:raise ValueError('first-pass inventory changed during freeze')
 identity=json.loads((PASS1/'candidate-complete-build/identity.json').read_text())
 if sha(Path(identity['binary']))!=identity['sha256']:raise ValueError('first-pass actual binary identity differs')
 ledgers={name:json.loads((PASS1/name).read_text()) for name in ('exploratory-screen/commands.json','diagnostic-commands.json','profile-commands.json')}
 for name,rows in ledgers.items():
  if not rows or any(row.get('status')!='complete' or row.get('exit')!=0 for row in rows):raise ValueError('unfinished exploratory ledger: '+name)
 if len(ledgers['exploratory-screen/commands.json'])!=2 or len(ledgers['diagnostic-commands.json'])!=6 or len(ledgers['profile-commands.json'])!=4:raise ValueError('unexpected exploratory inventory')
 record={'format':'rustx-complete-costs-pass1-freeze-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_root':str(PASS1),'archive_prefix':'pass1','scope':'Exploratory first candidate only. Preserve all raw bytes and failures as history; never pool these products with final 276 products or count these checks as final candidate validation.','candidate_identity':identity,'actual_binary_sha256_verified_at_freeze':identity['sha256'],'candidate_binary_excluded_from_archive':True,'screen_products':24,'diagnostic_products':11,'diagnostic_count_scope':'4 CPU/control products (baseline + first candidate), 2 first-candidate column products, 1 first-candidate SQL product, 4 first-candidate Rust/Pi WAL products. Retained earlier baseline evidence is additional history.','files':records,'excluded':excluded,'ledgers_sha256':{name:records[name]['sha256'] for name in ledgers},'correctness_queues':[p.relative_to(PASS1).as_posix() for p in sorted(PASS1.glob('check*/check-build-commands.json'))]}
 output.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'freeze':str(output),'files':len(records),'bytes':sum(v['bytes'] for v in records.values()),'sha256':sha(output)},indent=2))
if __name__=='__main__':main()
