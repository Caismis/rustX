from pathlib import Path
import subprocess,json,os,datetime,hashlib
repo=Path('/workspace/rustX-pi-durable');out=Path(__file__).resolve().parent
build=Path('/workspace/issue-481-evidence/pi-parity-small-nav-build')
subprocess.run(['python3',str(repo/'benchmarks/runtime/build-revision.py'),'--repo',str(repo),'--target','/workspace/issue-481-target','--output',str(build)],check=True)
identity=json.loads((build/'identity.json').read_text());assert identity['verified'];assert identity['head'].startswith('97dfdca8')
before=Path('/workspace/issue-481-evidence/pi-parity-qpsg-build/conformance');after=build/'conformance'
(out/'formal-host.json').write_text(json.dumps({'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uname':list(os.uname()),'affinity':sorted(os.sched_getaffinity(0)),'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text(),'memory_limit':Path('/sys/fs/cgroup/memory.max').read_text(),'cpu_tick_hz':os.sysconf('SC_CLK_TCK'),'scope':'Three interleaved exploratory Source-only revision pairs, all six runtime cases. Builds finished before timings; no test/profiler/compression overlap. Final Pi comparison separate.'},indent=2)+'\n')
cmd=['python3',str(repo/'benchmarks/runtime/compare-revisions.py'),'--before',str(before),'--after',str(after),'--output',str(out/'runtime'),'--pairs','3']
with (out/'runtime.log').open('w') as f:subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
with (out/'runtime-summary.json').open('w') as f:subprocess.run(['python3',str(repo/'benchmarks/runtime/summarize-comparisons.py'),str(out/'runtime')],cwd=repo,stdout=f,check=True)
print('Source stage complete',flush=True)
