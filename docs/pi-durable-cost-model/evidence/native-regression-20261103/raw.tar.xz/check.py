import sys,os,json,datetime,subprocess,hashlib
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
target=Path('/home/capi/.cache/rustx-pr485-target')
out=root/sys.argv[1];out.mkdir(exist_ok=False)
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap():
 return {'utc':now(),'files':{str(p.relative_to(repo)):sha(p) for p in sorted([p for f in ('src','tests') for p in (repo/f).rglob('*') if p.is_file()]+[repo/'Cargo.toml',repo/'Cargo.lock'])}}
(out/'source-before.json').write_text(json.dumps(snap(),indent=2)+'\n')
rows=[]; binaries={}
old=json.loads(Path('/home/capi/.cache/rustx-pr485-content-20261102/checks-third/check-build-commands.json').read_text())
old.insert(-1, {'label':'tests-artifact-lineage','command':['pending','artifact_lineage_tests::','--test-threads=2']})
old.insert(-1, {'label':'tests-local-runtime','command':['pending','local_runtime::','--skip','::scale::','--test-threads=2']})
for row in old:
 label=row['label'];cmd=row['command'].copy()
 if label.startswith('tests-') and label!='tests-build':
  key='durable' if label=='tests-durable' else 'process' if label=='tests-process' else 'rustx'
  cmd[0]=binaries[key]
 item={'label':label,'command':cmd,'start_utc':now(),'status':'running'};rows.append(item)
 with (out/(label+'.stdout')).open('x') as stdout,(out/(label+'.stderr')).open('x') as stderr:
  done=subprocess.run(cmd,cwd=repo,env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2'},stdout=stdout,stderr=stderr)
 item.update(status='complete',exit=done.returncode,end_utc=now());(out/'check-build-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,done.returncode,flush=True)
 if done.returncode:break
 if label=='tests-build':
  for line in (out/'tests-build.stdout').read_text().splitlines():
   if not line.startswith('{'):continue
   v=json.loads(line)
   if v.get('reason')=='compiler-artifact' and v.get('executable') and v['target']['name'] in ('rustx','durable','process') and v['profile']['test']:binaries[v['target']['name']]=v['executable']
(out/'source-after.json').write_text(json.dumps(snap(),indent=2)+'\n')
assert json.loads((out/'source-before.json').read_text())['files']==json.loads((out/'source-after.json').read_text())['files']
raise SystemExit(done.returncode)
