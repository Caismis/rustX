"""Verify preserved executables/current sources before deliberately excluding binaries."""
import datetime,hashlib,json,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();out=r/'baseline-build-records';out.mkdir(exist_ok=True);records=[]
for label,path in [('legacy',Path('/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build')),('previous',Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/refinement/final-build')),('clustered',Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/final-build')),('fixed',r/'candidate-build')]:
 native=load(path/'app-server-identity.json');conformance=load(path/'identity.json');assert sha(path/'rustx')==native['sha256'] and sha(path/'conformance')==conformance['sha256'];records.append({'label':label,'native':native['sha256'],'conformance':conformance['sha256'],'library':sha(path/'librustx.rlib'),'head':conformance['head']})
 if label!='fixed':
  d=out/label;d.mkdir(exist_ok=True)
  for p in path.iterdir():
   if p.suffix in ['.json','.stdout','.stderr']:shutil.copyfile(p,d/p.name)
source=load(r/'candidate-build/identity.json');assert len(source['source_files'])==972
assert all(sha(repo/p)==digest for p,digest in source['source_files'].items());assert subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip()==source['production_tree']
patch=subprocess.check_output(['git','diff','bd39adcd3','HEAD','--','src','tests'],cwd=repo);(r/'production-and-test.patch').write_bytes(patch)
wrappers=[]
for label in ['current-nodelay','baseline-nodelay']:
 body=(r/(label+'.sh')).read_text();assert body.count('LD_PRELOAD=')==1 and 'tcp-nodelay.so' in body;target=Path(body.split('\nexec ',1)[1].split(' ',1)[0]);cmd=next(x for x in load(r/'tcp-ablation-commands.json') if x['label']==label);assert sha(target)==cmd['native_binary_sha256'];fd=[json.loads(v) for v in (r/label/'server.stderr').read_text().splitlines() if 'diagnostic_tcp_nodelay_fd' in v];assert len(fd)==8 and all(v['status']==0 for v in fd);wrappers.append({'label':label,'wrapper_sha256':sha(r/(label+'.sh')),'target_sha256':sha(target),'successful_fd_settings':len(fd)})
pi=load(r/'pi128-memory/identity.json');piroot=Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/pi-1ced');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=piroot,text=True).strip()==pi['source']
for name,body in pi['source_matches_prior_runtime'].items():assert all(sha(piroot/p)==v for p,v in body.items())
for p,v in pi['inputs'].items():assert sha(Path(p))==v
result={'accepted':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_inputs':972,'source_head':source['head'],'production_tree':source['production_tree'],'executables':records,'tcp_wrappers':wrappers,'tcp_helper':{'source_sha256':sha(r/'tcp-nodelay.c'),'excluded_so_sha256':sha(r/'tcp-nodelay.so'),'compiler':subprocess.check_output(['cc','--version'],text=True).splitlines()[0],'recipe':['cc','-shared','-fPIC','-O2','-o','tcp-nodelay.so','tcp-nodelay.c','-ldl'],'scope':'Recipe identifies the small diagnostic helper, not a new product build. No compiler or product executed by offline replay.'},'pi':{'source':pi['source'],'tracked_inputs':len(pi['source_matches_prior_runtime']['pi_tracked']),'derived_inputs':len(pi['source_matches_prior_runtime']['pi_derived']),'node':pi['node'],'identity_sha256':sha(r/'pi128-memory/identity.json'),'products':1,'scope':'Exactly the authorized memory-only Pi run, no rebuild or performance cohort.'},'scope':'Actual saved executable/library/wrapper bytes and current checked sources verified before archiving; portable replay relies on this record for deliberately absent ELFs/libraries/Pi runtime.'}
(r/'prearchive-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
