"""Fresh Rust-only128×8 capacity triads with original measurement semantics."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');o=Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103')
while not (r/'ready.json').exists():time.sleep(2)
load=lambda p:json.loads(p.read_text());identity=load(r/'candidate-build/identity.json');assert identity['verified'];artifact=next(v for line in (r/'candidate-build/build.stdout').read_text().splitlines() if line.startswith('{') and (v:=json.loads(line)).get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['kind']==['bin']);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(r/'candidate-build/app-server-identity.json').write_text(json.dumps({'head':identity['head'],'binary':str(r/'candidate-build/rustx'),'sha256':sha(r/'candidate-build/rustx'),'artifact':artifact},indent=2)+'\n')
bins={'legacy':Path('/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build/rustx'),'previous':o/'refinement/final-build/rustx','fixed':r/'candidate-build/rustx'};orders=[['legacy','previous','fixed'],['fixed','previous','legacy'],['previous','legacy','fixed'],['fixed','legacy','previous']];rows=[]
(r/'premeasurement.json').write_text(json.dumps({'engines':{k:{'binary':str(v),'sha256':sha(v)} for k,v in bins.items()},'orders':orders,'sessions':128,'history':8,'rounds':16,'widths':[1,4,8],'scope':'Four descriptive triads; CPU/write windows include held waves, latency excludes first held wave. No Pi/DSH performance execution.'},indent=2)+'\n')
for pair,order in enumerate(orders):
 for side in order:
  label=f'native-{pair}-{side}';attempt=0
  while True:
   while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(2)
   suffix='' if attempt==0 else f'-attempt{attempt}';directory=r/(label+suffix);cmd=[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(bins[side]),'--output',str(directory),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16'];at=datetime.datetime.now(datetime.timezone.utc).isoformat()
   with (r/(label+suffix+'.stdout')).open('x') as so,(r/(label+suffix+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
   row={'label':label,'directory':directory.name,'side':side,'pair':pair,'command':cmd,'start_utc':at,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode};rows.append(row);(r/'formal-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
   if p.returncode==0:break
   error=(r/(label+suffix+'.stderr')).read_text();assert 'compiler overlap' in error and not (directory/'identity.json').exists(),error;attempt+=1
  catalog=directory/'runtime/sessions/catalog.json';body=catalog.read_bytes();(directory/'catalog-closed.json').write_bytes(body);(directory/'catalog-proof.json').write_text(json.dumps({'sha256':sha(catalog),'bytes':len(body),'generation':json.loads(body)['generation']},indent=2)+'\n');print(label,0,flush=True)
(r/'formal-completed.json').write_text('{"accepted":true}\n')
