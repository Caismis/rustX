import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();formal=[v['directory'] for v in load(r/'formal-commands.json') if v['exit']==0];names=formal+['profile-baseline','profile-current','profile-clustered','profile-fixed','current-plain','current-nodelay','baseline-nodelay','baseline-plain'];frozen=r/'frozen-inputs';frozen.mkdir(exist_ok=True);bindings={};reconstructed=[]
for name in names:
 d=r/name;identity=load(d/'identity.json');binary=Path(identity['binary']);assert sha(binary)==identity['sha256'];sources={}
 for key,digest in identity['inputs'].items():
  p=Path(key) if Path(key).is_absolute() else repo/key;body=p.read_bytes()
  if hashlib.sha256(body).hexdigest()!=digest:
   assert p==r/'capacity-rotating.py';body=body.decode().replace("while subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True).returncode == 0:\n        await asyncio.sleep(1)","assert subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True).returncode != 0, 'compiler overlap'").encode();assert hashlib.sha256(body).hexdigest()==digest;reconstructed.append({'product':name,'source':key,'sha256':digest,'recipe':'Reverse the later preflight-only wait-loop change to the original compiler assertion; exact recorded digest matches. No measurements or identities edited.'})
  dest=frozen/digest
  if not dest.exists():dest.write_bytes(body)
  sources[key]=digest
 bindings[name]={'binary_sha256':identity['sha256'],'inputs':sources,'scope':'Actual preserved executable or diagnostic wrapper verified before archiving; raw replay uses frozen original source hashes and recorded binary identity.'}
(r/'native-product-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');(r/'source-reconstruction.json').write_text(json.dumps(reconstructed,indent=2)+'\n');print(json.dumps({'products':len(bindings),'frozen_sources':len(list(frozen.iterdir()))}))
