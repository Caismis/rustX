import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');rows=[]
while not (r/'profile-commands.json').exists() or not (r/'profiles-completed.json').exists():time.sleep(2)
bins={'baseline':'/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build/rustx','current':'/home/capi/.cache/rustx-pr485-memory-writes-20261103/refinement/final-build/rustx'}
for label,side,enabled in [('current-plain','current',False),('current-nodelay','current',True),('baseline-nodelay','baseline',True),('baseline-plain','baseline',False)]:
 binary=Path(bins[side])
 if enabled:
  wrapper=r/(label+'.sh');wrapper.write_text('#!/bin/sh\nexport LD_PRELOAD='+str(r/'tcp-nodelay.so')+'\nexec '+str(binary)+' \"$@\"\n');wrapper.chmod(0o755);binary=wrapper
 cmd=[sys.executable,str(r/'capacity-original.py'),'--binary',str(binary),'--output',str(r/label),'--sessions','128','--history','8','--widths','1','--rounds','32']
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(label+'.stdout')).open('x') as so,(r/(label+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 rows.append({'label':label,'command':cmd,'start_utc':at,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'native_binary_sha256':hashlib.sha256(Path(bins[side]).read_bytes()).hexdigest(),'nodelay':enabled});(r/'tcp-ablation-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True);assert p.returncode==0
