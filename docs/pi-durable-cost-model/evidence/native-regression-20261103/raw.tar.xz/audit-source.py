"""Recheck the authoritative source-identical validation aggregate and O3 build."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());d=r/'checks-final';before=load(d/'source-before.json')['files'];after=load(d/'source-after.json')['files'];build=load(r/'candidate-build/identity.json');commands=load(d/'check-build-commands.json');assert len(commands)==17 and all(v['exit']==0 for v in commands);assert before==after==build['source_files'] and len(before)==972;assert build['verified'] and all(v['exit']==0 for v in build['commands']);counts={};duplicates=[]
for row in commands:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in counts or counts[key]==m[2]
    if key in counts:duplicates.append(m[1])
    counts[key]=m[2]
summary=load(r/'checks-summary.json');assert summary['tests']=={v:sum(x==v for x in counts.values()) for v in ['ok','ignored']};assert duplicates==summary['repeated_tests']
for row in commands:
 if 'reused_from' in row:
  name=row['label'];assert load(r/'checks-corrected/source-after.json')['files']==before
  for suffix in ['stdout','stderr']:assert (d/(name+'.'+suffix)).read_bytes()==(r/'checks-corrected'/(name+'.'+suffix)).read_bytes()
(r/'source-audit.json').write_text(json.dumps({'accepted':True,'head':build['head'],'source_inputs':972,'commands':17,'tests':summary['tests'],'repeated_tests_count':len(duplicates),'source_map_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'scope':'Passed first8checks reused only after all972sources matched the corrected build; timed agent/local groups rerun serially without changing their deadlines. Original failed runs remain. Full-source maps match fresh O3/default ordinary artifacts; unit builds use root-O0/all-features. Excluded binaries rely on recorded prearchive hashes.'},indent=2)+'\n');print(json.dumps({'accepted':True,'tests':summary['tests']}))
