#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdio.h>
#include <sys/socket.h>
int accept4(int fd, struct sockaddr *addr, socklen_t *length, int flags) {
  int (*original)(int, struct sockaddr *, socklen_t *, int) = dlsym(RTLD_NEXT, "accept4");
  int result = original(fd, addr, length, flags);
  if (result >= 0) {
    int saved = errno;
    struct sockaddr_storage local;
    socklen_t size = sizeof(local);
    if (getsockname(result, (struct sockaddr *)&local, &size) == 0 &&
        (local.ss_family == AF_INET || local.ss_family == AF_INET6)) {
      int enabled = 1;
      int status = setsockopt(result, IPPROTO_TCP, TCP_NODELAY, &enabled, sizeof(enabled));
      fprintf(stderr, "{\"diagnostic_tcp_nodelay_fd\":%d,\"status\":%d}\n", result, status);
    }
    errno = saved;
  }
  return result;
}
