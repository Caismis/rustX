import json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
while not (r/'formal-completed.json').exists():time.sleep(2)
s=Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/functional-products.py').read_text();s=s.replace("while not (r/'measurement-completed.json').exists():time.sleep(2)","assert (r/'formal-completed.json').exists()").replace("r/'final-build/conformance'","r/'candidate-build/conformance'").replace("Path('/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build/conformance')","Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/refinement/final-build/conformance')");s=s.replace("assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0","while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(2)");(r/'functional-products.py').write_text(s)
with (r/'functional-products.stdout').open('x') as so,(r/'functional-products.stderr').open('x') as se:p=subprocess.run([sys.executable,str(r/'functional-products.py')],cwd=repo,stdout=so,stderr=se)
assert p.returncode==0
cmd=[sys.executable,str(r/'capacity-rotating.py'),'--binary',str(r/'candidate-build/rustx'),'--output',str(r/'profile-fixed'),'--sessions','128','--history','8','--widths','1','--rounds','256','--cpu-profiler','/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0.5.11']
with (r/'profile-fixed.stdout').open('x') as so,(r/'profile-fixed.stderr').open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
assert p.returncode==0
pp='/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof';symbols=[]
for label,binary in [('baseline','/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build/rustx'),('current','/home/capi/.cache/rustx-pr485-memory-writes-20261103/refinement/final-build/rustx'),('clustered','/home/capi/.cache/rustx-pr485-memory-writes-20261103/final-build/rustx'),('fixed',str(r/'candidate-build/rustx'))]:
 d=r/('profile-'+label);profile=d/'active.cpu.0';assert profile.exists()
 for suffix,flags in [('cum',['--text','--cum']),('flat',['--text']),('stacks',['--collapsed'])]:
  if label in ['baseline','current'] and (d/(suffix+'-corrected.txt')).exists():continue
  cmd=[pp,*flags,'--nodecount=3000','--nodefraction=0','--edgefraction=0',binary,str(profile)]
  with (d/(suffix+'-corrected.txt')).open('x') as so,(d/(suffix+'-corrected.stderr')).open('x') as se:p=subprocess.run(cmd,stdout=so,stderr=se)
  symbols.append({'label':label,'command':cmd,'exit':p.returncode});assert p.returncode==0
(r/'symbolization.json').write_text(json.dumps(symbols,indent=2)+'\n');(r/'post-performance-completed.json').write_text('{"accepted":true}\n')
