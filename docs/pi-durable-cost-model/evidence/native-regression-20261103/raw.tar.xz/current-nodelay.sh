#!/bin/sh
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-native-regression-20261103/tcp-nodelay.so
exec /home/capi/.cache/rustx-pr485-memory-writes-20261103/refinement/final-build/rustx "$@"
