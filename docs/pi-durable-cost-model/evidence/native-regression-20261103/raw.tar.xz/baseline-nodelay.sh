#!/bin/sh
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-native-regression-20261103/tcp-nodelay.so
exec /home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build/rustx "$@"
