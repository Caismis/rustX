"""Package this round only; keep raw failed attempts and consistent images, omit runtime/ELFs/secrets."""
import hashlib,json,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/evidence/native-regression-20261103');sha=lambda b:hashlib.sha256(b).hexdigest();selected=[];excluded=[]
for p in sorted(r.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(r);parts=rel.parts;reason=None
 if any(v in parts for v in ['runtime','workspaces','node_modules','.git','__pycache__']):reason='Mutable/native runtime or duplicate workspace/Pi checkout, dependency tree or Python bytecode'
 elif p.name in ['WORK-IN-PROGRESS.txt','token','provider.stdout'] or p.name.startswith('.env'):reason='Working notes, ephemeral authentication, or duplicated provider stdout (full structured report retained)'
 elif p.suffix in ['.so','.rlib','.pyc'] or p.name in ['rustx','conformance']:reason='Excluded executable/library; stored identity and prearchive byte proof retained'
 else:
  with p.open('rb') as h:magic=h.read(4)
  if magic==b'\x7fELF':reason='Excluded ELF; prearchive identity retained'
 if reason:
  # List excluded roots and artifact names without copying mutable authentication bytes.
  excluded.append({'path':str(rel),'reason':reason});continue
 selected.append(p)
(r/'archive-selection.json').write_text(json.dumps({'selected_files':len(selected)+1,'excluded_files':len(excluded),'excluded':excluded,'scope':'All new ordinary/diagnostic/native/Pi-memory/failed-attempt records selected except listed mutable duplicate runtime, compiled artifacts and ephemeral auth. Previous archives are referenced, not copied.'},indent=2)+'\n');selected=sorted([*selected,r/'archive-selection.json']);assert len(selected)==len(set(selected));members=[];target=out/'raw.tar.xz';assert not target.exists()
with tarfile.open(target,'w:xz',preset=3) as archive:
 for p in selected:
  body=p.read_bytes();relative=str(p.relative_to(r));members.append({'path':relative,'bytes':len(body),'sha256':sha(body)});info=archive.gettarinfo(str(p),arcname=relative);info.uid=info.gid=0;info.uname=info.gname='';
  import io
  archive.addfile(info,io.BytesIO(body))
manifest={'archive':{'name':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes())},'members':members,'scope':'New native repair and one authorized Pi memory supplement only. Raw replay never executes products/builds/git/network. Executables/libraries/runtime/dependencies/authentication excluded.'};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'archive':manifest['archive'],'members':len(members),'raw_bytes':sum(v['bytes'] for v in members)}),flush=True)
