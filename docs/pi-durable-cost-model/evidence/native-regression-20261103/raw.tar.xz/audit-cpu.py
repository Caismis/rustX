"""Recompute CPU sample totals and explicitly overlapping stack groups."""
import collections,hashlib,json,re,struct
from pathlib import Path
r=Path(__file__).resolve().parent;rows=[]
for label in ['baseline','current','clustered','fixed']:
 d=r/('profile-'+label);p=d/'active.cpu.0';raw=p.read_bytes();header=struct.unpack_from('<5Q',raw);assert header==(0,3,0,4000,0);i=40;total=records=0
 while True:
  n,depth=struct.unpack_from('<2Q',raw,i);i+=16;assert depth<4096;pcs=struct.unpack_from('<'+'Q'*depth,raw,i);i+=8*depth
  if n==0 and depth==1 and pcs[0]==0:break
  assert n>0;total+=n;records+=1
 assert b'r-xp' in raw[i:];stacks=[]
 for line in (d/'stacks-corrected.txt').read_text().splitlines():
  if line.strip():stack,n=line.rsplit(' ',1);stacks.append((stack,int(n)))
 assert sum(n for _,n in stacks)==total;assert int(re.search(r'Total: (\d+) samples',(d/'flat-corrected.txt').read_text())[1])==total
 groups={key:sum(n for stack,n in stacks if all(token in stack for token in tokens)) for key,tokens in [('catalog_activity',['local_runtime::session_activity','publish_activity']),('catalog_json',['local_runtime::session_activity','serde_json']),('sqlite',['sqlite3']),('app_server',['rustx::app_server']),('checkpoint_materialization',['capture_checkpoint'])]}
 rows.append({'engine':label,'sha256':hashlib.sha256(raw).hexdigest(),'period_us':4000,'samples':total,'records':records,'inclusive_groups':groups,'sample_cpu_ms':total*4,'group_cpu_ms':{k:n*4 for k,n in groups.items()}})
(r/'cpu-audit.json').write_text(json.dumps({'accepted':True,'profiles':rows,'scope':'250Hz signal samples in native child only,256rotating active attempts keep histories near8–10. Diagnostic allocator/profiler timings are separate from ordinary. Raw/collapsed/text denominators agree. Inclusive groups overlap; optimized aliases/inlining and finite samples limit attribution. No driver/provider CPU or precise phase-timing claims.'},indent=2)+'\n');print(json.dumps({'accepted':True,'samples':[v['samples'] for v in rows]}))
