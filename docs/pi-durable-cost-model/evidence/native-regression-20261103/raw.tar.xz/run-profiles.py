import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');o=Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103');rows=[]
bins={'baseline':Path('/home/capi/.cache/rustx-pr485-resources-20261103/refined/candidate-build/rustx'),'current':o/'refinement/final-build/rustx','clustered':o/'final-build/rustx'}
for label in ['baseline','current','clustered']:
 cmd=[sys.executable,str(r/'capacity-rotating.py'),'--binary',str(bins[label]),'--output',str(r/('profile-'+label)),'--sessions','128','--history','8','--widths','1','--rounds','256','--cpu-profiler','/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0.5.11']
 at=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/('profile-'+label+'.stdout')).open('x') as so,(r/('profile-'+label+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 rows.append({'label':label,'command':cmd,'start_utc':at,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode});(r/'profile-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True);assert p.returncode==0
