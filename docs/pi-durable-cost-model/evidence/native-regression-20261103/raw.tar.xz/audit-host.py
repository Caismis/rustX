"""Summarize retained shared-host observations without claiming exclusive execution."""
import datetime,json
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());rows=[json.loads(v) for v in (r/'host-compiler-observations.jsonl').read_text().splitlines()];assert rows
assert all(a['monotonic_ns']<b['monotonic_ns'] for a,b in zip(rows,rows[1:]));products=[]
for c in load(r/'formal-commands.json'):
 if c['exit']!=0:continue
 points=[v for v in rows if c['start_utc']<=v['utc']<=c['end_utc']]
 products.append({'directory':c['directory'],'observations':len(points),'compiler_positive_observations':sum(bool(v['rustc']) for v in points),'fully_spanned_by_monitor':rows[0]['utc']<=c['start_utc'] and rows[-1]['utc']>=c['end_utc']})
result={'accepted':True,'observations':len(rows),'begin_utc':rows[0]['utc'],'end_utc':rows[-1]['utc'],'positive_observations':sum(bool(v['rustc']) for v in rows),'formal_products':products,'scope':'Two-second shared-host compiler observations start after the first formal product and stop after the CPU diagnostics. Preflight quiet gates do not exclude later activity, sampling can miss short jobs, and there is no exclusive-host or whole-cohort no-interference claim.'}
(r/'host-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
