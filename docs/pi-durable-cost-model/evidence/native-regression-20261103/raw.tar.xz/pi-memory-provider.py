"""Memory-only1024-request fixture; no timed hot benchmark window."""
import asyncio,json
from fake_provider.control import ScenarioRun
from fake_provider.scenario import OPENAI_CHAT_COMPLETIONS,Expect,Finish,Scenario,Step,Stream,Text
from fake_provider.server import ProviderServer
async def main():
 expect=Expect(protocol=OPENAI_CHAT_COMPLETIONS,model='capacity-model',body_contains=('capacity turn',))
 state=ScenarioRun(Scenario('pi128_memory',*[Step(expect,Stream(Text('capacity response'),Finish())) for _ in range(1024)]))
 server=ProviderServer(state);host,port=await server.start('127.0.0.1',0);print(json.dumps({'host':host,'port':port,'steps':1024}),flush=True);await server.serve_until_shutdown();report=state.report();print(json.dumps({'ok':report['ok'],'requests':report['requestCount']}),flush=True);return 0 if report['ok'] else 1
if __name__=='__main__':raise SystemExit(asyncio.run(main()))
