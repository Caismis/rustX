// One authorized128-session memory observation. No per-turn latency, CPU or write benchmark.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir,readFile,writeFile,readdir,readlink} from 'node:fs/promises';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const [checkout,out,baseURL]=process.argv.slice(2);
const write=async(name,v)=>writeFile(join(out,name),JSON.stringify(v,null,2)+'\n');
const canonical=v=>Array.isArray(v)?v.map(canonical):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,canonical(v[k])])):v;
const digest=v=>createHash('sha256').update(JSON.stringify(canonical(v))).digest('hex');
const phases=[];
const phase=async name=>{phases.push({phase:name,utc:new Date().toISOString(),pid:process.pid,memory:process.memoryUsage(),smaps_rollup:await readFile('/proc/self/smaps_rollup','utf8')});const fds=await readdir('/proc/self/fd');const links=await Promise.all(fds.map(f=>readlink('/proc/self/fd/'+f).catch(()=>'')));phases.at(-1).open_sqlite_files=[...new Set(links.filter(p=>p.endsWith('/conversation.sqlite')))].sort();await write('phases.json',phases);};
await phase('before_imports');
const load=path=>import(pathToFileURL(join(checkout,path)).href);
const {createModels,createProvider}=await load('packages/ai/src/models.ts');
const {openAICompletionsApi}=await load('packages/ai/src/api/openai-completions.lazy.ts');
const {Harness,createRegistry,watchEvents}=await load('packages/durable/src/index.ts');
const {CodingTools}=await load('packages/durable/src/tools/index.ts');
const {NodeExecutionEnv}=await load('packages/durable/src/env/node.ts');
const {allEntries,textOf}=await load('packages/durable/test/chat-support.ts');
const {context}=await load('packages/durable/test/session-support.ts');
const {openNodeSqliteStorage}=await load('packages/durable/src/storage/sqlite/node.ts');
await phase('after_imports');
const models=createModels();
models.setProvider(createProvider({id:'fixture',name:'Local memory fixture',baseUrl:baseURL+'/v1',auth:{apiKey:{name:'Fixture',resolve:async()=>({auth:{apiKey:'fixture'}})}},models:[{id:'capacity-model',name:'capacity-model',api:'openai-completions',provider:'fixture',baseUrl:baseURL+'/v1',reasoning:false,input:['text'],cost:{input:0,output:0,cacheRead:0,cacheWrite:0},contextWindow:128000,maxTokens:4096,compat:{supportsStore:false,maxTokensField:'max_completion_tokens'}}],api:openAICompletionsApi()}));
const registry=createRegistry();registry.install(CodingTools);
const reports=[],handles=[],watches=[],completed=Array.from({length:128},()=>new Set());
const open=async(i)=>{
 const workspace=join(out,'workspaces',String(i));await mkdir(workspace,{recursive:true});const db=join(workspace,'conversation.sqlite');
 const harness=await Harness.open(await openNodeSqliteStorage(db),{models,registry,settings:{stream:{maxRetries:0,cacheRetention:'none'}},env:()=>new NodeExecutionEnv({cwd:workspace}),onReport:e=>reports.push(String(e))},context);
 const root=await harness.root(context,{agent:{model:{provider:'fixture',modelId:'capacity-model'},cwd:workspace}});harness.resume();return {harness,root,db};
};
for(let i=0;i<128;i++){handles.push(await open(i));if([1,8,32,64,128].includes(i+1))await phase('empty_attached_'+(i+1));}
for(let i=0;i<128;i++){
 const watch=await watchEvents(handles[i].harness,handles[i].root.id,context);
 watch.start(async events=>{for(const e of events){if(e.type==='run_end')for(const id of e.inputs)completed[i].add(id);}});watches.push(watch);
}
await phase('all_subscribed_empty');
for(let turn=0;turn<8;turn++){
 for(let first=0;first<128;first+=8)await Promise.all(Array.from({length:8},async(_,offset)=>{
  const i=first+offset;const submission=await handles[i].root.submit({type:'input',content:`capacity turn session=${String(i).padStart(4,'0')} turn=${String(turn).padStart(4,'0')}`},context);
  const settled=await submission.wait(context);assert.equal(settled.status,'done');
  const deadline=Date.now()+30000;while(!completed[i].has(submission.id)){assert(Date.now()<deadline,'observer completion timeout');await new Promise(r=>setTimeout(r,1));}
 }));
 if([0,7].includes(turn))await phase('seeded_history_'+(turn+1));
}
assert.equal(handles.length,128);assert.equal(watches.length,128);assert.deepEqual(reports,[]);
// Verification follows the authoritative memory endpoint; keep raw entries outside the process.
const proofs=[];
for(let i=0;i<128;i++){
 const entries=await allEntries(handles[i].root);const assistants=entries.filter(e=>e.kind==='pi.assistant');assert.equal(assistants.length,8);assert(assistants.every(e=>textOf(e.model?.[0])==='capacity response'));
 const markers=entries.flatMap(e=>(e.model??[]).filter(m=>m.role==='user').flatMap(m=>JSON.stringify(m).match(/capacity turn session=\d{4} turn=\d{4}/g)??[]));assert.deepEqual(markers,Array.from({length:8},(_,turn)=>`capacity turn session=${String(i).padStart(4,'0')} turn=${String(turn).padStart(4,'0')}`));
 await write(`native-${String(i).padStart(4,'0')}.json`,entries);proofs.push({session:i,db:handles[i].db,id:handles[i].root.id,entries:entries.length,assistants:assistants.length,sha256:digest(entries)});
}
for(const w of watches){const end=await w.stop();assert.equal(end.reason,'stopped');}
watches.length=0;
for(const h of handles)await h.harness.close(context);handles.length=0;
await phase('all_closed');
for(let i=0;i<128;i++){
 const h=await open(i);const entries=await allEntries(h.root);assert.equal(digest(entries),proofs[i].sha256);await h.harness.close(context);
}
await phase('reopen_verified');assert.deepEqual(reports,[]);await write('completed.json',{accepted:true,sessions:128,history_turns:8,requests:1024,proofs,tools:CodingTools.tools.map(t=>t.name),node:process.version,versions:process.versions,execArgv:process.execArgv,scope:'One memory-only capacity sample.128independent workspaces/Harness/SQLite files; shared models/registry, native watchEvents per conversation. No hot latency/CPU/write benchmark. Verification/reopen after seed endpoint. Pi library has no rustX AppServer transport/history-inspection equivalence.'});
