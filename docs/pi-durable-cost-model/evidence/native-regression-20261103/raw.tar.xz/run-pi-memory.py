"""Run exactly one authorized Pi128×8 memory-only product after Rust measurements."""
import asyncio,datetime,hashlib,json,os,subprocess,sys,time,urllib.request
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');pi=Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/pi-1ced')
while not (r/'post-performance-completed.json').exists():time.sleep(2)
assert not (r/'pi-memory-run-started.json').exists(),'Pi capacity product already attempted; inspect instead of silently rerunning'
old=json.loads(Path('/home/capi/.cache/rustx-pr485-request-hotpath-20261103/final-triads/premeasurement.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=pi,text=True).strip()==old['pi_source'];assert not subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=pi,text=True).strip()
proof={}
for key in ['pi_tracked','pi_derived']:
 proof[key]={name:sha(pi/name) for name in old[key]};assert proof[key]==old[key],key
out=r/'pi128-memory';out.mkdir();(out/'identity.json').write_text(json.dumps({'source':old['pi_source'],'node':subprocess.check_output(['node','--version'],text=True).strip(),'inputs':{str(p):sha(p) for p in [r/'pi-memory.mjs',r/'pi-memory-provider.py']},'source_matches_prior_runtime':proof,'permission':'User explicitly allowed only one128-session Pi memory sample, not a performance benchmark.','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
(r/'pi-memory-run-started.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n');os.sched_setaffinity(0,[2,8])
provider=None
try:
 with (out/'provider.stderr').open('x') as errors:
  provider=subprocess.Popen(['uv','run','--project',str(repo/'test-support/fake-provider'),'--frozen','python',str(r/'pi-memory-provider.py')],stdout=subprocess.PIPE,stderr=errors,text=True,env=os.environ|{'UV_OFFLINE':'1'})
  ready=json.loads(provider.stdout.readline());base=f"http://{ready['host']}:{ready['port']}"
  cmd=['node','--conditions=source',str(r/'pi-memory.mjs'),str(pi),str(out),base];(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
  with (out/'stdout').open('x') as so,(out/'stderr').open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
  assert p.returncode==0,(out/'stderr').read_text()
  request=urllib.request.Request(base+'/__control/shutdown',data=b'');report=json.load(urllib.request.urlopen(request,timeout=30));(out/'provider-report.json').write_text(json.dumps(report,indent=2)+'\n');(out/'provider.stdout').write_text(provider.stdout.read());assert provider.wait(timeout=30)==0;assert report['ok'] and report['requestCount']==1024
 (r/'pi-memory-completed.json').write_text('{"accepted":true}\n')
finally:
 if provider is not None and provider.poll() is None:provider.terminate();provider.wait(timeout=30)
