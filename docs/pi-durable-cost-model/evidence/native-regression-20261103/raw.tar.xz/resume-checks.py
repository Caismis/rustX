"""Reuse source-identical passed checks; rerun the timed agent group serially and finish the queue."""
import datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');old=r/'checks-corrected';out=r/'checks-final';out.mkdir();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=load(old/'source-after.json')['files'];assert source==load(old/'source-before.json')['files'] and all(sha(repo/k)==v for k,v in source.items());shutil.copyfile(old/'source-before.json',out/'source-before.json');rows=load(old/'check-build-commands.json')[:-1];assert len(rows)==8 and all(v['exit']==0 for v in rows)
for row in rows:
 row['reused_from']='checks-corrected/'+row['label'];
 for ext in ['stdout','stderr']:shutil.copyfile(old/(row['label']+'.'+ext),out/(row['label']+'.'+ext))
binaries={}
for line in (old/'tests-build.stdout').read_text().splitlines():
 if line.startswith('{'):
  v=json.loads(line)
  if v.get('reason')=='compiler-artifact' and v.get('executable') and v['target']['name'] in ['rustx','durable','process'] and v['profile']['test']:binaries[v['target']['name']]=v['executable']
queue=load(Path('/home/capi/.cache/rustx-pr485-content-20261102/checks-third/check-build-commands.json'));queue.insert(-1,{'label':'tests-artifact-lineage','command':['pending','artifact_lineage_tests::','--test-threads=2']});queue.insert(-1,{'label':'tests-local-runtime','command':['pending','local_runtime::','--skip','::scale::','--test-threads=1']});start=next(i for i,v in enumerate(queue) if v['label']=='tests-agent')
for oldrow in queue[start:]:
 label=oldrow['label'];cmd=oldrow['command'].copy()
 if label.startswith('tests-'):
  key='durable' if label=='tests-durable' else 'process' if label=='tests-process' else 'rustx';cmd[0]=binaries[key]
  if label=='tests-agent':cmd=[v.replace('--test-threads=2','--test-threads=1') for v in cmd]
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'};rows.append(row)
 with (out/(label+'.stdout')).open('x') as so,(out/(label+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2'})
 row.update(exit=p.returncode,status='complete',end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'check-build-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:break
current={k:sha(repo/k) for k in source};assert current==source;(out/'source-after.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':current},indent=2)+'\n')
raise SystemExit(p.returncode)
