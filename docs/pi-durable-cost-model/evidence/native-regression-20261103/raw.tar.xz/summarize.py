import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());native=load(r/'native-audit.json');products={p['directory']:p for p in native['products']};rows=[x for x in load(r/'formal-commands.json') if x['exit']==0];assert len(rows)==12
by={(x['pair'],x['side']):products[x['directory']] for x in rows};metrics=[];phases=[]
for width in [1,4,8]:
 values={}
 for side in ['legacy','previous','fixed']:
  values[side]=[]
  for pair in range(4):
   v=next(x for x in by[pair,side]['activity'] if x['width']==width);values[side].append({'settled_ms':v['latency']['settled_us']['median_ms'],'accepted_ms':v['latency']['accepted_us']['median_ms'],'p95_ms':v['latency']['settled_us']['p95_ms'],'p99_ms':v['latency']['settled_us']['p99_ms'],'cpu_ms':v['server_cpu_ms_per_all_turns'],'write_kib':v['server_write_bytes_per_all_turns']/1024})
 absolute={side:{k:{'values':[x[k] for x in v],'median':statistics.median(x[k] for x in v)} for k in v[0]} for side,v in values.items()};changes={side:{k:{'values':[(a[k]/b[k]-1)*100 for a,b in zip(values['fixed'],values[side])],'median':statistics.median((a[k]/b[k]-1)*100 for a,b in zip(values['fixed'],values[side]))} for k in values['fixed'][0]} for side in ['legacy','previous']};metrics.append({'width':width,'absolute':absolute,'paired_changes_percent':changes})
for phase in ['empty_server','empty_attached_128','all_subscribed_empty','seeded_history_8','all_unloaded','reload_unload_cycle_2']:
 values={}
 for side in ['legacy','previous','fixed']:
  ps=[next(p for p in by[pair,side]['points'] if p['phase']==phase) for pair in range(4)];values[side]={k:{'values':[p['counters'][k] for p in ps],'median':statistics.median(p['counters'][k] for p in ps)} for k in ['anon_pss_mib','rss_mib']}
 phases.append({'phase':phase,'absolute':values})
pi=load(r/'pi-memory-audit.json');point=next(v for v in pi['points'] if v['phase']=='seeded_history_8');fixed=next(v for v in phases if v['phase']=='seeded_history_8')['absolute']['fixed'];catalog={side:[load(r/next(x['directory'] for x in rows if x['pair']==pair and x['side']==side)/'catalog-proof.json')['bytes'] for pair in range(4)] for side in ['legacy','previous','fixed']}
lifecycle={}
for side in ['legacy','previous','fixed']:
 values=[]
 for pair in range(4):
  points={v['phase']:v for v in by[pair,side]['points']};start=points['empty_server']['counters'];end=points['all_unloaded']['counters'];values.append({'cpu_ms':(end['cpu_ticks']-start['cpu_ticks'])*10,'write_mib':(end['write_bytes']-start['write_bytes'])/1048576})
 lifecycle[side]={key:{'values':[v[key] for v in values],'median':statistics.median(v[key] for v in values)} for key in values[0]}
result={'lifecycle':lifecycle,'accepted':True,'activity':metrics,'phases':phases,'pi_memory':point,'fixed_to_pi_ratio':{k:fixed[k]['median']/point[k] for k in ['anon_pss_mib','rss_mib']},'catalog_bytes':catalog,'scope':'Four balanced Rust128-session8-turn triads,12ordinary products. Medians of process-level values; paired changes are medians of matching triad ratios. Pi is one authorized128-session memory-only product, no Pi CPU/wall/write result. Common count/history/provider text and independent DBs; library-versus-AppServer, tool/inspection/replay capability differences prevent full equivalence or production capacity inference.'}
(r/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'width1':metrics[0],'memory':next(v for v in phases if v['phase']=='seeded_history_8'),'pi':point},indent=2))
