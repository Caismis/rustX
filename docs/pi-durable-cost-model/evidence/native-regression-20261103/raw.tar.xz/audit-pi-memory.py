"""Check the single authorized Pi128×8 memory product, its HTTP inputs and native databases."""
import argparse,collections,hashlib,json,re,sqlite3
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');a=p.parse_args();r=Path(__file__).resolve().parent;d=r/'pi128-memory';load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();done=load(d/'completed.json');identity=load(d/'identity.json');report=load(d/'provider-report.json');assert done['accepted'] and done['sessions']==128 and done['history_turns']==8 and done['requests']==1024
assert identity['source']=='1cedd32724abfcb0915f76cc61b6827e2c16dbad';assert report['ok'] and report['complete'] and not report['failures'];assert report['requestCount']==report['stepsTotal']==report['stepsMatched']==report['stepsSettled']==1024;assert report['stepStates']==['settled']*1024
counts=collections.Counter()
for request in report['requests']:
 assert request['protocol']=='openai_chat_completions' and request['model']=='capacity-model';body=request['body'];body=json.loads(body) if isinstance(body,str) else body;markers=re.findall(r'capacity turn session=(\d{4}) turn=(\d{4})',json.dumps(body['messages']));assert markers;index,turn=map(int,markers[-1]);assert 0<=index<128 and turn==counts[index];assert markers==[(f'{index:04}',f'{i:04}') for i in range(turn+1)];counts[index]+=1
assert dict(counts)=={i:8 for i in range(128)}
phases=load(d/'phases.json');points=[]
for point in phases:
 v=dict(line.split(':',1) for line in point['smaps_rollup'].splitlines() if ':' in line);points.append({'phase':point['phase'],'pid':point['pid'],'anon_pss_mib':int(v['Pss_Anon'].split()[0])/1024,'rss_mib':int(v['Rss'].split()[0])/1024,'node_memory':point['memory'],'open_sqlite_files':len(point['open_sqlite_files'])})
assert len({v['pid'] for v in points})==1;seed=next(v for v in points if v['phase']=='seeded_history_8');assert seed['open_sqlite_files']==128
for v in points:
 if v['phase'].startswith('empty_attached_'):assert v['open_sqlite_files']==int(v['phase'].rsplit('_',1)[1])
 if v['phase'] in ['all_closed','reopen_verified']:assert v['open_sqlite_files']==0
images=d/'native-snapshots'
if a.prepare:images.mkdir(exist_ok=False)
proofs=[]
for row in done['proofs']:
 i=row['session'];image=images/f'{i:04}.sqlite';api=load(d/f'native-{i:04}.json')
 if a.prepare:
  source=sqlite3.connect(f"file:{row['db']}?mode=ro",uri=True);dest=sqlite3.connect(image);source.backup(dest);dest.close();source.close()
 c=sqlite3.connect(f'file:{image}?mode=ro',uri=True);assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not c.execute('PRAGMA foreign_key_check').fetchall();entries=[json.loads(v[0]) for v in c.execute('SELECT record FROM entries ORDER BY id')];assert entries==api,(i,'native/API entries differ');assistants=[v for v in entries if v['kind']=='pi.assistant'];assert len(assistants)==8
 for v in assistants:assert v['model'][0]['content']==[{'type':'text','text':'capacity response'}]
 markers=[m for e in entries for v in e.get('model',[]) if v['role']=='user' for m in re.findall(r'capacity turn session=\d{4} turn=\d{4}',json.dumps(v))];assert markers==[f'capacity turn session={i:04} turn={t:04}' for t in range(8)];submissions=c.execute('SELECT status,count(*) FROM submissions GROUP BY status').fetchall();assert submissions==[('done',8)],submissions
 proofs.append({'session':i,'sha256':sha(image),'bytes':image.stat().st_size,'pages':c.execute('PRAGMA page_count').fetchone()[0],'page_size':c.execute('PRAGMA page_size').fetchone()[0],'api_sha256':sha(d/f'native-{i:04}.json'),'entries':len(entries),'assistants':8,'submissions':submissions});c.close()
assert len(proofs)==128
result={'accepted':True,'points':points,'native_proofs':proofs,'identity_sha256':sha(d/'identity.json'),'provider_sha256':sha(d/'provider-report.json'),'scope':'One authorized Pi memory-only sample,128independent workspaces/Harness/SQLite files and128native watchEvents.1024HTTPrequest full histories and native/API records verified; reopen checks executed by the saved Node script after the authoritative seed memory point. Ordinary Node allocator, no forcedGC. No Pi latency/CPU/write benchmark. Compare raw native PID RSS/anonymousPSS endpoints, with library-versus-AppServer and tool/inspection capability limits.'}
(r/'pi-memory-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'seed_memory':seed,'databases':128}))
