import hashlib,json,re,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');d=r/'checks';load=lambda p:json.loads(p.read_text())
while not (d/'source-after.json').exists():time.sleep(2)
commands=load(d/'check-build-commands.json');assert len(commands)==17 and all(v['exit']==0 for v in commands),[(v['label'],v['exit']) for v in commands];sources=load(d/'source-before.json')['files'];assert sources==load(d/'source-after.json')['files'];assert all(hashlib.sha256((repo/name).read_bytes()).hexdigest()==digest for name,digest in sources.items());names={};duplicates=[]
for row in commands:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in names or names[key]==m[2]
    if key in names:duplicates.append(m[1])
    names[key]=m[2]
counts={name:sum(v==name for v in names.values()) for name in ['ok','ignored']};(r/'checks-summary.json').write_text(json.dumps({'accepted':True,'tests':counts,'commands':len(commands),'source_inputs':len(sources),'repeated_tests':duplicates,'scope':'Local-runtime full subset includes the existing artifact-lineage subset; count unique test names once.'},indent=2)+'\n');print(counts,flush=True)
subprocess.run(['git','add','--','src/app_server/archive_download.rs','src/local_runtime/session.rs','src/local_runtime/session/catalog_file.rs'],cwd=repo,check=True);subprocess.run(['git','commit','-m','Avoid native RPC packet delays and repeated catalog preparation'],cwd=repo,check=True)
with (r/'candidate-build.stdout').open('x') as so,(r/'candidate-build.stderr').open('x') as se:p=subprocess.run([sys.executable,str(r/'build.py'),'candidate',str(repo)],cwd=repo,stdout=so,stderr=se)
assert p.returncode==0
(r/'ready.json').write_text('{"accepted":true}\n')
