"""Recheck successful non-chat request/native/reopen oracles from immutable raw products."""
import hashlib,importlib.util,json,os,sys
from pathlib import Path
r=Path(__file__).resolve().parent;sys.dont_write_bytecode=True
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,file):
 spec=importlib.util.spec_from_file_location(name,r/file);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
m=module('functional_math','recompute-pi.py');d=module('functional_direct','direct-audit.py');d.MATH=m;products=[];comparisons=[]
for relative in ['functional-products']:
 directory=r/relative;commands=load(directory/'commands.json');assert len(commands)==8 and all(v['accepted'] for v in commands)
 for left,right in zip(commands,commands[1:]):assert left['end_utc']<=right['start_utc']
 for case in ['stream','large','tool','cancel']:

  for side in ['before','after']:
   path=directory/f'{case}-{side}.json';raw=load(path);proc=load(path.with_suffix('.process.json'));d.counter_identity(raw);d.observer_check(raw,side,'no-live-subscriber');provider=proc['provider_report'];assert provider['complete'] and not provider['failures'] and provider['stepsSettled']==provider['requestCount'];assert raw['verified_live_requests']==raw['requests'] and raw['verified_reopened_requests']==raw['requests']
   products.append({'file':str(path.relative_to(r)),'sha256':sha(path),'process_sha256':sha(path.with_suffix('.process.json')),'requests':raw['requests'],'schema':raw['schema']})
  path=directory/f'{case}-comparison.json';comparisons.append({'file':str(path.relative_to(r)),'requests':d.comparison(path,case,'no-live-subscriber',True),'sha256':sha(path)})
(r/'functional-audit.json').write_text(json.dumps({'accepted':True,'products':products,'comparisons':comparisons,'scope':'One pair per non-chat case per stage, functional/persistence/provider/reopen checks, not an independent performance confidence claim.'},indent=2)+'\n');print(json.dumps({'accepted':True,'products':len(products)}))
