import hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();frozen=r/'frozen-inputs';frozen.mkdir(exist_ok=True);bindings={}
for row in load(r/'product-commands.json'):
 assert row['exit']==0;name=row['directory'];identity=load(r/name/'identity.json');assert sha(Path(identity['binary']))==identity['sha256']
 for key,digest in identity['inputs'].items():
  p=Path(key) if Path(key).is_absolute() else repo/key;assert sha(p)==digest;dest=frozen/digest
  if not dest.exists():dest.write_bytes(p.read_bytes())
 bindings[name]={'binary_sha256':identity['sha256'],'inputs':identity['inputs'],'scope':'Actual preserved executable and exact original driver/provider inputs verified before archiving.'}
(r/'native-product-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');print(json.dumps({'products':len(bindings),'frozen_inputs':len(list(frozen.iterdir()))}))
