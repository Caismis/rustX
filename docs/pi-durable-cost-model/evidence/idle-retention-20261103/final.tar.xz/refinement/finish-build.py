import hashlib,json,re,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();d=r/'checks-final'
while not (d/'source-after.json').exists():
 if(d/'commands.json').exists():assert all(v['exit']==0 for v in load(d/'commands.json'))
 time.sleep(2)
cmds=load(d/'commands.json');assert len(cmds)==17 and all(v['exit']==0 for v in cmds);source=load(d/'source-after.json');assert source==load(d/'source-before.json');assert all(sha(repo/p)==v for p,v in (source['files']|source['helpers']).items());counts={};duplicates=[]
for row in cmds:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in counts or counts[key]==m[2]
    if key in counts:duplicates.append(m[1])
    counts[key]=m[2]
(r/'checks-summary.json').write_text(json.dumps({'accepted':True,'commands':17,'source_inputs':len(source['files']),'helper_inputs':source['helpers'],'tests':{s:sum(v==s for v in counts.values()) for s in ['ok','ignored']},'duplicates':duplicates},indent=2)+'\n')
# Capture the illustrative numeric cache probe BEFORE deliberate fresh package clean.
binary=next(v['command'][0] for v in cmds if v['label']=='tests-sqlite');cmd=[binary,'durable::sqlite::idle_cache::tests::','--test-threads=1','--nocapture']
with(r/'cache-unit-probe.stdout').open('x') as so,(r/'cache-unit-probe.stderr').open('x') as se:subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,check=True)
owned=['src/durable/inbox.rs','src/durable/sqlite.rs','src/durable/sqlite/idle_cache.rs','src/local_runtime/session_runtime_manager.rs','src/runtime/conversation_runtime.rs'];subprocess.run(['git','add',*owned],cwd=repo,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True);subprocess.run(['git','commit','-m','Return freed idle cache pages once per maintenance batch'],cwd=repo,check=True)
with(r/'final-build.stdout').open('x') as so,(r/'final-build.stderr').open('x') as se:subprocess.run([sys.executable,str(r/'build.py'),'final',str(repo)],cwd=repo,stdout=so,stderr=se,check=True)
build=load(r/'final-build/identity.json');assert build['source_files']==source['files'];assert all(sha(repo/p)==v for p,v in (source['files']|source['helpers']).items());artifacts=[json.loads(v) for v in (r/'final-build/build.stdout').read_text().splitlines() if v.startswith('{')];main=next(v for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['kind']==['bin'] and v.get('executable'));(r/'final-build/app-server-identity.json').write_text(json.dumps({'head':build['head'],'binary':str(r/'final-build/rustx'),'sha256':sha(r/'final-build/rustx'),'artifact':main},indent=2)+'\n')
(r/'ready.json').write_text(json.dumps({'accepted':True,'head':build['head'],'native_sha256':sha(r/'final-build/rustx'),'conformance_sha256':build['sha256']},indent=2)+'\n');print('Final ready',flush=True)
