"""Run relevant checks serially against one frozen production/helper source map."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=r/sys.argv[1];out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 return {'files':{str(p.relative_to(repo)):sha(p) for f in ['src','tests'] for p in sorted((repo/f).rglob('*')) if p.is_file()}|{n:sha(repo/n) for n in ['Cargo.toml','Cargo.lock']},'helpers':{n:sha(repo/n) for n in ['benchmarks/runtime/app-server-capacity.py','benchmarks/runtime/app-server-capacity-provider.py']}}
before=snap();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n');old=json.loads(Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/checks-final/check-build-commands.json').read_text());rows=[];bins={};env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2'}
# Clippy first so lint repairs cannot invalidate a long already-passed test run.
order=[old[0],old[-1],*old[1:-1]]
for row in order:
 label=row['label'];cmd=row['command'].copy()
 if label.startswith('tests-') and label!='tests-build':
  key='durable' if label=='tests-durable' else 'process' if label=='tests-process' else 'rustx';cmd[0]=bins[key]
  cmd=[v if not v.startswith('--test-threads=') else '--test-threads=1' for v in cmd]
 item={'label':label,'command':cmd,'start_utc':now()};rows.append(item)
 with (out/(label+'.stdout')).open('x') as so,(out/(label+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=env,stdout=so,stderr=se)
 item.update(exit=p.returncode,end_utc=now());(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:break
 if label=='tests-build':
  for line in (out/(label+'.stdout')).read_text().splitlines():
   if not line.startswith('{'):continue
   v=json.loads(line)
   if v.get('reason')=='compiler-artifact' and v.get('executable') and v['target']['name'] in ['rustx','durable','process'] and v['profile']['test']:bins[v['target']['name']]=v['executable']
assert before==snap();(out/'source-after.json').write_text(json.dumps(snap(),indent=2)+'\n');assert p.returncode==0
