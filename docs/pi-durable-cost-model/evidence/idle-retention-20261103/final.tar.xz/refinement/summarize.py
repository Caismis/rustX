import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());native={v['directory']:v for v in load(r/'native-audit.json')['products']};cmds=[v for v in load(r/'product-commands.json') if v['exit']==0];ordinary={(v['pair'],v['side']):native[v['directory']] for v in cmds if v['family']=='ordinary'};cache={(v['pair'],v['side']):v['metrics'] for v in load(r/'cache-audit.json')['products']}
def series(v):return {'values':v,'median':statistics.median(v)}
def paired(before,after):return {'before':series(before),'after':series(after),'paired_changes_percent':series([(b/a-1)*100 if a else None for a,b in zip(before,after)])}
def comparison(getter,n):
 a=[getter(i,'before') for i in range(n)];b=[getter(i,'after') for i in range(n)];return paired(a,b)
activity=[]
for width in [1,4,8]:
 def metric(pair,side,key):
  v=next(x for x in ordinary[pair,side]['activity'] if x['width']==width)
  return {'settled_ms':v['latency']['settled_us']['median_ms'],'accepted_ms':v['latency']['accepted_us']['median_ms'],'p95_ms':v['latency']['settled_us']['p95_ms'],'p99_ms':v['latency']['settled_us']['p99_ms'],'cpu_ms_per_turn':v['server_cpu_ms_per_all_turns'],'write_kib_per_turn':v['server_write_bytes_per_all_turns']/1024}[key]
 activity.append({'width':width,'metrics':{key:comparison(lambda i,s:metric(i,s,key),4) for key in ['settled_ms','accepted_ms','p95_ms','p99_ms','cpu_ms_per_turn','write_kib_per_turn']}})
memory=[]
for phase in ['empty_server','empty_attached_128','all_subscribed_empty','seeded_history_8','all_unloaded','reload_unload_cycle_2']:
 memory.append({'phase':phase,'metrics':{k:comparison(lambda i,s:next(v for v in ordinary[i,s]['points'] if v['phase']==phase)['counters'][k],4) for k in ['anon_pss_mib','rss_mib']}})
extended=[]
for phase in ['all_subscribed_empty','seeded_history_8','cache_pages_idle','cache_statements_idle','cache_rotation_cold','cache_rotation_warm','all_unloaded']:
 extended.append({'phase':phase,'metrics':{key:comparison(lambda i,s:cache[i,s]['memory'][phase][key],2) for key in ['anon_pss_mib','rss_mib']}})
rotation=[]
for label in ['cold','warm']:
 data={key:comparison(lambda i,s:cache[i,s][label]['cold_eligible'][key],2) for key in ['settled_median_ms','accepted_median_ms','settled_p95_ms']}
 data.update({key:comparison(lambda i,s:cache[i,s][label]['window'][key],2) for key in ['cpu_ms_per_turn','write_kib_per_turn']});rotation.append({'label':label,'metrics':data})
kept={key:comparison(lambda i,s:cache[i,s]['kept_warm']['after_first4'][key],2) for key in ['settled_median_ms','accepted_median_ms','settled_p95_ms']};kept['mixed98s_cpu_ms']=comparison(lambda i,s:cache[i,s]['kept_warm']['mixed_window']['cpu_ms'],2)
inspector=comparison(lambda i,s:cache[i,s]['inspector']['elapsed_ms'],2)
lifecycle={}
for side in ['before','after']:
 vals=[]
 for i in range(4):
  p={v['phase']:v['counters'] for v in ordinary[i,side]['points']};vals.append({'cpu_ms':(p['all_unloaded']['cpu_ticks']-p['empty_server']['cpu_ticks'])*10,'write_mib':(p['all_unloaded']['write_bytes']-p['empty_server']['write_bytes'])/1048576})
 lifecycle[side]={k:series([v[k] for v in vals]) for k in vals[0]}
pi=load(r/'pi-memory-reference.json');seed=next(v for v in memory if v['phase']=='seeded_history_8')['metrics'];ratios={k:seed[k]['after']['median']/pi['seed_memory'][k] for k in ['anon_pss_mib','rss_mib']}
out={'accepted':True,'activity':activity,'memory':memory,'cache_memory':extended,'rotation':rotation,'kept_warm':kept,'inspector':inspector,'lifecycle':lifecycle,'prior_pi_memory_reference':pi,'seed8_after_to_prior_pi_ratio':ratios,'scope':'Eight primary ordinary products/four balancedpairs; four separate extended ordinary cache products/two balancedpairs. Medians of process values and per-pair ratios. Cold/warm latency uses122predefined eligible sessions; CPU/writes use whole128call windows.130s point is4active14turns+124idle8;32s point remainsall128exactly8. PriorPi is a previously authorized single memory sample, not rerun or a new equivalent-feature performance comparison.'}
(r/'summary.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'seed8':seed,'width1':activity[0],'rotation':rotation},indent=2))
