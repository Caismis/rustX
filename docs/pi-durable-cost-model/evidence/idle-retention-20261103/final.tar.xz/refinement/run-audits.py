import json,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
while not(r/'functional-completed.json').exists():time.sleep(2)
rows=[]
for name in ['prepare-bindings.py','audit-native.py','audit-cache.py','audit-functional.py','audit-source.py','audit-host.py','summarize.py']:
 with(r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run([sys.executable,str(r/name)],cwd=repo,stdout=so,stderr=se)
 rows.append({'script':name,'exit':p.returncode});(r/'audit-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0
(r/'audits-completed.json').write_text('{"accepted":true}\n')
