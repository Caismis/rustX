#!/bin/sh
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-idle-retention-20261103/allocator-control.so
export RUSTX_BENCH_PROFILE_SOCKET=/home/capi/.cache/rustx-pr485-idle-retention-20261103/trim-after/control.sock
exec /home/capi/.cache/rustx-pr485-idle-retention-20261103/candidate-build/rustx "$@"
