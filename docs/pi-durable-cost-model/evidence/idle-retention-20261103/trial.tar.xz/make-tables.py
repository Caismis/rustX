"""Derive all displayed values from independently audited products, including adverse cells."""
import hashlib,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;f=r/'refinement';load=lambda p:json.loads(p.read_text());s=load(f/'summary.json');trial=load(r/'summary.json');lines=[]
def say(x=''):lines.append(x)
def table(headers,rows):
 say('| '+' | '.join(headers)+' |');say('| '+' | '.join(['---']*len(headers))+' |')
 for row in rows:say('| '+' | '.join(str(v) for v in row)+' |')
 say()
def n(v):return f'{v:,.3f}'
def p(v):return f'{v:+.3f}%'
def row(key,v):return [key,n(v['before']['median']),n(v['after']['median']),p(v['paired_changes_percent']['median'])]
say('# Loaded-session retention: complete measurement tables');say();say('Before: `e1d4a40dc` (prior report `e1a984771`). Trial: `f2e1273d2`. Final: `d50125842`. All new products are rustX; Pi/DeepSeek were not run. MiB = 2^20 bytes. Changes are medians of paired ratios, not ratios of the displayed medians. All pairs and adverse cells are retained.');say()
say('## Final ordinary processes: four balanced pairs');say();say('128 independent SQLite conversations, eight seed turns each, all subscribed. These immediate endpoints precede the explicit cache-idle experiment. RSS and anonymous PSS are distinct process measurements.');say()
table(['Phase / metric','Before median','Final median','Paired change'],[row(v['phase']+' / '+k,x) for v in s['memory'] for k,x in v['metrics'].items()])
say('Each primary product performs 1,235 requests. Latencies omit the deliberately held first burst; CPU/write windows include all 16 bursts (16×width requests). Native server PID only. `/proc` CPU granularity is 10ms. P95/P99 are descriptive finite samples, not service-level guarantees.');say()
table(['Width / metric','Before median','Final median','Paired change'],[row(str(v['width'])+' / '+k,x) for v in s['activity'] for k,x in v['metrics'].items()])
native={v['directory']:v for v in load(f/'native-audit.json')['products']};cmds=load(f/'product-commands.json');rows=[]
for cmd in cmds:
 if cmd['family']!='ordinary':continue
 v=native[cmd['directory']];pts={x['phase']:x['counters'] for x in v['points']}
 for a in v['activity']:
  rows.append([cmd['pair'],cmd['side'],a['width'],n(pts['seeded_history_8']['anon_pss_mib']),n(pts['seeded_history_8']['rss_mib']),n(a['latency']['settled_us']['median_ms']),n(a['latency']['settled_us']['p95_ms']),n(a['server_cpu_ms_per_all_turns']),n(a['server_write_bytes_per_all_turns']/1024)])
table(['Pair','Side','Width','Seed anon MiB','Seed RSS MiB','Settled ms','P95 ms','CPU ms/turn','Write KiB/turn'],rows)
say('## Final idle-cache processes: two separate balanced pairs');say();say('Each extended product performs 1,515 requests. At 32s all 128 sessions still have exactly eight turns. At 130s, four kept-warm sessions have 14 turns and 124 idle sessions have eight. Later rotation points have additional turns and cannot be presented as 128×8 memory.');say()
table(['Phase / metric','Before median','Final median','Paired change'],[row(v['phase']+' / '+k,x) for v in s['cache_memory'] for k,x in v['metrics'].items()])
say('Latency below uses the 122 predeclared cold-eligible sessions: indices 4…124 and 127. Sessions 0…3 were kept warm; 125/126 were primed by Inspector. CPU and writes use the entire 128-request rotation. The warm rotation repeats the same order before a 30s idle gap.');say()
table(['Rotation / metric','Before median','Final median','Paired change'],[row(v['label']+' / '+k,x) for v in s['rotation'] for k,x in v['metrics'].items()])
say('Kept-warm latency excludes the first four calls after page-cache reclamation. The CPU counter spans approximately 98s of calls, idle time and maintenance; it is not CPU/turn. Inspector includes checkpoint/history and two exact Source content reads.');say()
table(['Metric','Before median','Final median','Paired change'],[row(k,v) for k,v in s['kept_warm'].items()]+[row('Inspector complete ms',s['inspector'])])
rows=[]
for v in load(f/'cache-audit.json')['products']:
 x=v['metrics']
 for label in ['cold','warm']:
  a=x[label];rows.append([v['pair'],v['side'],label,n(a['cold_eligible']['settled_median_ms']),n(a['cold_eligible']['settled_p95_ms']),n(a['window']['cpu_ms_per_turn']),n(a['window']['write_kib_per_turn'])])
table(['Pair','Side','Rotation','122 median ms','122 P95 ms','128 CPU ms/turn','128 KiB/turn'],rows)
cache_rows=[]
for v in load(f/'cache-audit.json')['products']:
 for phase,m in v['metrics']['memory'].items():cache_rows.append([v['pair'],v['side'],phase,n(m['anon_pss_mib']),n(m['rss_mib'])])
table(['Pair','Side','Phase','Anon MiB','RSS MiB'],cache_rows)
table(['Pair','Side','Kept20 median ms','Mixed98s CPU ms','Inspector ms','Warm max gap s','Warm gaps≥30s'],[[v['pair'],v['side'],n(v['metrics']['kept_warm']['after_first4']['settled_median_ms']),n(v['metrics']['kept_warm']['mixed_window']['cpu_ms']),n(v['metrics']['inspector']['elapsed_ms']),n(v['metrics']['warm']['maximum_same_session_idle_seconds']),v['metrics']['warm']['gaps_over30seconds']] for v in load(f/'cache-audit.json')['products']])
say('Raw `cache-rotation-{cold,warm}.json` and `cache-audit.json` retain every session time, actual idle gap and full counter boundary. No request or product was removed as an outlier.');say()
say('## Trial before allocator return: separate products');say();say('These measurements belong to f2e1273d2 and are not pooled with the final d50125842 products. They showed that cache objects were freed without a corresponding ordinary-glibc PSS drop.');say()
table(['Trial metric','Before median','Trial median','Paired change'],[row('seed8 anon MiB',next(v for v in trial['memory'] if v['phase']=='seeded_history_8')['metrics']['anon_pss_mib'])]+[row('width'+str(a['width'])+' '+k,v) for a in trial['activity'] for k,v in a['metrics'].items()])
say('## Heap diagnostic: one product per side, replacement tcmalloc');say();say('Same preserved O3/default native ELF, complete 64KiB sampled stacks. Allocator numeric properties are allocator counters; weighted requested bytes are a sampling estimate. Neither equals ordinary-glibc PSS. Stack-presence groups overlap and must not be added. This diagnostic uses the trial source, which already contains the complete cache/ownership changes; final only adds the allocator return hint.');say()
heap=load(r/'heap-audit.json')['products'];table(['Side','Phase','Requested estimate MiB','Allocator allocated MiB','Heap MiB','Page free MiB','Page unmapped MiB'],[[v['side'],v['phase'],n(v['weighted_requested_bytes']/1048576),*[n(v['allocator_numeric_properties'][k]/1048576) for k in ['allocated','heap','page_free','page_unmapped']]] for v in heap])
table(['Side','Phase','SQLite malloc MiB','Page-cache stack MiB','Prepare stack MiB','Schema stack MiB','Checkpoint stack MiB','Publish stack MiB'],[[v['side'],v['phase'],*[n(v['overlapping_stack_presence_bytes'][k]/1048576) for k in ['sqlite_malloc','sqlite_page_cache','sqlite_prepare','schema_compilation','checkpoint_materialization','publication_encoding']]] for v in heap])
say('## Controlled ordinary-glibc allocator return');say();say('One diagnostic product per side, one synchronous malloc_trim(0) at the 130s cut. The preload adds only a control thread; it does not replace glibc. Both native products still pass the full 1,515-request/native/reopen/cancel checks. This isolates a causal immediate PSS drop, not a statistical latency claim.');say()
table(['Source','Before anon MiB','After anon MiB','Returned MiB','Control wall ms','Control thread CPU ms'],[[v['side'],n(v['before']['anon_pss_mib']),n(v['after']['anon_pss_mib']),n(v['anon_pss_released_mib']),n(v['wall_ms']),n(v['control_thread_cpu_ms'])] for v in load(r/'trim-audit.json')['products']])
say('## Verification and reference boundaries');say()
table(['Record','Value'],[['Final unique tests',str(load(f/'source-audit.json')['tests'])],['Final source/test/Cargo inputs',load(f/'source-audit.json')['source_inputs']],['Final command groups',load(f/'source-audit.json')['commands']],['Primary ordinary products',8],['Extended ordinary products',4],['Final stream/large/tool/cancel products',len(load(f/'functional-audit.json')['products'])],['Trial native products including heap/control diagnostics',len(load(r/'native-audit.json')['products'])],['Heap profiles independently rechecked',len(heap)],['New Pi/DeepSeek products',0]])
pi=s['prior_pi_memory_reference'];say('Prior authorized Pi single memory sample only: anonymous PSS '+n(pi['seed_memory']['anon_pss_mib'])+'MiB, RSS '+n(pi['seed_memory']['rss_mib'])+'MiB. Final immediate rustX seed8 / that reference = '+n(s['seed8_after_to_prior_pi_ratio']['anon_pss_mib'])+'× anonymous PSS, '+n(s['seed8_after_to_prior_pi_ratio']['rss_mib'])+'× RSS. Different feature surfaces remain; no new Pi performance comparison. Idle rustX endpoints have no matched prior Pi idle endpoint.');say()
(r/'idle-retention-tables.md').write_text('\n'.join(lines)+'\n');print(json.dumps({'accepted':True,'sha256':hashlib.sha256((r/'idle-retention-tables.md').read_bytes()).hexdigest(),'lines':len(lines)}))
