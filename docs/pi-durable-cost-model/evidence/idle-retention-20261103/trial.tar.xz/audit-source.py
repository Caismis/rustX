"""Recheck the final source-identical17command validation and fresh ordinary artifacts."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());d=r/'checks-verified';before=load(d/'source-before.json');after=load(d/'source-after.json');build=load(r/'candidate-build/identity.json');cmds=load(d/'commands.json');assert before==after;assert len(cmds)==17 and all(v['exit']==0 for v in cmds);assert before['files']==build['source_files'] and len(before['files'])==973;assert build['verified'] and all(v['exit']==0 for v in build['commands']);counts={};dups=[]
for row in cmds:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (d/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in counts or counts[key]==m[2]
    if key in counts:dups.append(m[1])
    counts[key]=m[2]
summary=load(r/'checks-summary.json');assert summary['tests']=={s:sum(v==s for v in counts.values()) for s in ['ok','ignored']};assert dups==summary['duplicates'];assert summary['helper_inputs']==before['helpers']
rootartifacts=[json.loads(v) for v in (r/'candidate-build/build.stdout').read_text().splitlines() if v.startswith('{')];rootartifacts=[v for v in rootartifacts if v.get('reason')=='compiler-artifact' and v['target']['src_path'].startswith('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/')];assert rootartifacts and all(v['profile']['opt_level']=='3' and v['features']==[] and not v['fresh'] for v in rootartifacts)
result={'accepted':True,'head':build['head'],'source_inputs':973,'helpers':before['helpers'],'commands':17,'tests':summary['tests'],'duplicates':len(dups),'ordinary_root_artifacts':len(rootartifacts),'source_map_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'scope':'All17commands passed against exactly the same973source/test/Cargo inputs and2capacity helpers. Eight artifact-lineage cases are deduplicated. Ordinary root artifacts are freshO3/default; correctness is separate rootO0/all-features. Committed v52 schema/fixtures test passes without artifact regeneration. Failed/partial development attempts remain; the optional post-clean numeric probe did not execute and is not counted.'}
(r/'source-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'tests':summary['tests']}))
