"""Independent raw counters, wire history and closed-image verification for capacity products."""
import argparse,collections,hashlib,json,math,re,sqlite3,statistics
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--partial',action='store_true');p.add_argument('--raw-only',action='store_true');a=p.parse_args();r=a.root.resolve();load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
formal=[v['directory'] for v in load(r/'product-commands.json') if v['exit']==0 and v['family']=='ordinary']
selected=[v['directory'] for v in load(r/'product-commands.json') if v['exit']==0]+[v['directory'] for v in load(r/'heap-commands.json')+load(r/'trim-commands.json') if v['exit']==0];products=[];pending=[]
def counters(raw):
 stat=raw['stat'];tail=stat.rsplit(')',1)[1].split();io=dict(v.split(':',1) for v in raw['io'].splitlines());mem=dict(v.split(':',1) for v in raw['smaps_rollup'].splitlines() if ':' in v)
 return {'pid':int(stat.split('(',1)[0]),'start_ticks':int(tail[19]),'cpu_ticks':int(tail[11])+int(tail[12]),'write_bytes':int(io['write_bytes']),'rss_mib':int(mem['Rss'].split()[0])/1024,'anon_pss_mib':int(mem['Pss_Anon'].split()[0])/1024}
def percentile(values,q):return sorted(values)[max(0,math.ceil(q*len(values))-1)]
for relative in selected:
 directory=r/relative
 if not (directory/'completed.json').exists():pending.append(relative);continue
 identity=load(directory/'identity.json')
 bindings=load(r/'native-product-bindings.json');assert identity['sha256']==bindings[relative]['binary_sha256']
 if not a.raw_only:assert sha(Path(identity['binary']))==identity['sha256']
 for name,digest in identity['inputs'].items():assert sha(r/'frozen-inputs'/digest)==digest,(relative,name)
 complete=load(directory/'completed.json');report=load(directory/'provider-report.json');routing=load(directory/'routing.json');native=load(directory/'native-closed.json');n=identity['sessions'];history=identity['history_turns'];rounds=identity['rounds'];widths=identity['widths'];requests=n*history+sum(widths)*rounds+3+(24+2*n if identity.get('cache_probes') else 0)
 assert complete['accepted'] and complete['requests']==requests and report['ok'] and report['complete'] and not report['failures']
 assert report['requestCount']==report['stepsTotal']==report['stepsMatched']==report['stepsSettled']==requests
 assert report['stepStates']==['settled']*requests
 assert len(routing)==len(native)==n and len({v['conversation_id'] for v in routing})==n
 expected=collections.Counter();bindings=[]
 for request in report['requests']:
  assert request['protocol']=='openai_chat_completions' and request['model']=='capacity-model'
  body=request['body'];body=json.loads(body) if isinstance(body,str) else body
  markers=re.findall(r'capacity turn session=(\d{4}) turn=(\d{4})',json.dumps(body['messages']))
  assert markers;index,turn=map(int,markers[-1]);assert 0<=index<n and turn==expected[index]
  assert markers==[(f'{index:04}',f'{i:04}') for i in range(turn+1)]
  expected[index]+=1;bindings.append({'index':request['index'],'session':index,'turn':turn})
 assert bindings==load(directory/'request-bindings.json');assert dict(sorted(expected.items()))=={int(k):v for k,v in complete['turn_counts'].items()}
 proofs=[]
 for row in native:
  index=row['session_index'];image=directory/'native-snapshots'/f'{index:04}.sqlite';assert sha(image)==row['consistent_backup_sha256'] and image.stat().st_size==row['consistent_backup_bytes']
  c=sqlite3.connect(f'file:{image}?mode=ro',uri=True);assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert not c.execute('PRAGMA foreign_key_check').fetchall()
  messages=[json.loads(v[0]) for v in c.execute('SELECT message_json FROM message_ledger ORDER BY position')];users=[v for v in messages if v['role']=='user'];assistants=[v for v in messages if v['role']=='assistant'];assert len(users)==expected[index] and len(assistants)==expected[index]-int(index==0)
  assert [v['content'] for v in users]==[[{'type':'text','text':f'capacity turn session={index:04} turn={j:04}'}] for j in range(len(users))]
  assert [v['content'] for v in assistants]==[[{'type':'text','text':('S'*32768 if index==n-1 and j==len(assistants)-1 else 'capacity response')}] for j in range(len(assistants))]
  assert not any('forbidden' in json.dumps(v) for v in messages)
  assert c.execute('PRAGMA page_count').fetchone()[0]==row['pages'] and c.execute('PRAGMA freelist_count').fetchone()[0]==row['free_pages']
  proofs.append({'index':index,'sha256':sha(image),'schema':c.execute('SELECT schema_version FROM rustx_store').fetchone()[0],'users':len(users),'assistants':len(assistants),'used_page_bytes':(row['pages']-row['free_pages'])*row['page_size']});c.close()
 phases=load(directory/'phases.json');points=[{'phase':v['phase'],'monotonic_ns':v['monotonic_ns'],'counters':counters(v['process']),'loaded':v['diagnostics']['loaded'],'loading':v['diagnostics']['loading'],'unloading':v['diagnostics']['unloading'],'active':v['diagnostics']['active_roots'],'attachments':v['diagnostics']['external_attachments'],'refusals':v['diagnostics']['admission_refusals']} for v in phases];assert len({(v['counters']['pid'],v['counters']['start_ticks']) for v in points})==1;assert [v['monotonic_ns'] for v in points]==sorted(v['monotonic_ns'] for v in points)
 byphase={v['phase']:v for v in points};assert byphase['metadata_only']['loaded']==0 and byphase[f'empty_attached_{n}']['loaded']==n
 for width in widths:assert byphase[f'active_held_{width}']['active']==width
 for phase in ['all_unloaded',*[f'reload_unload_cycle_{i}' for i in range(3)]]:
  point=byphase[phase];assert point['loaded']==point['loading']==0
  if relative!='capacity-heap-bounded' or phase!='reload_unload_cycle_0':assert point['unloading']==0
  else:assert point['unloading']==1  # Original diagnostic sampled after loaded==0, before final unload completed.
 assert byphase['reload_unload_cycle_2']['unloading']==0
 for key in ['cpu_ticks','write_bytes']:assert [v['counters'][key] for v in points]==sorted(v['counters'][key] for v in points)
 activity=[]
 for width in widths:
  data=load(directory/f'active-{width}.json');rows=data['rows'];assert len(rows)==rounds and [v['repeat'] for v in rows]==list(range(rounds));assert all(v['held']==(v['repeat']==0) for v in rows)
  free=[turn for row in rows if not row['held'] for turn in row['turns']];allturns=[turn for row in rows for turn in row['turns']];assert len(free)==(rounds-1)*width
  for turn in allturns:assert turn['terminal']['outcome']['type']=='completed' and 0<=turn['accepted_us']<=turn['settled_us'] and math.isclose(turn['settled_monotonic_ns']-turn['began_monotonic_ns'],turn['settled_us']*1000,rel_tol=1e-12,abs_tol=1e-3)
  free_wall=sum(max(t['settled_monotonic_ns'] for t in row['turns'])-min(t['began_monotonic_ns'] for t in row['turns']) for row in rows if not row['held'])/1e9
  first,last=counters(data['before']),counters(data['after']);assert first['pid']==last['pid']==points[0]['counters']['pid']
  metrics={name:{'n':len(free),'median_ms':statistics.median(t[name] for t in free)/1000,'p95_ms':percentile([t[name] for t in free],.95)/1000,'p99_ms':percentile([t[name] for t in free],.99)/1000,'values_us':[t[name] for t in free]} for name in ['accepted_us','settled_us']}
  activity.append({'width':width,'free_rounds':rounds-1,'free_turns':len(free),'latency':metrics,'burst_completed_per_service_second':len(free)/free_wall,'server_cpu_ms_per_all_turns':(last['cpu_ticks']-first['cpu_ticks'])*10/(rounds*width),'server_write_bytes_per_all_turns':(last['write_bytes']-first['write_bytes'])/(rounds*width),'scope':'Latency and burst throughput exclude deliberately held first round; CPU/write window includes all rounds. Burst service windows exclude driver gate setup gaps; not a sustained production throughput or P99 guarantee.'})
 cancelled=load(directory/'cancellation.json');assert cancelled['turn']['terminal']['outcome']['type']=='cancelled' and cancelled['cancel_to_settled_us']>=0
 products.append({'directory':relative,'diagnostic':(relative not in formal),'identity_sha256':sha(directory/'identity.json'),'provider_sha256':sha(directory/'provider-report.json'),'phases_sha256':sha(directory/'phases.json'),'requests':requests,'sessions':n,'history':history,'schema':sorted({v['schema'] for v in proofs}),'points':points,'activity':activity,'native_proofs':proofs,'unload_sampling_note':('First heap diagnostic reload cycle sampled unloading=1; later two cycles and all_unloaded are zero. No exact teardown-barrier claim for that point.' if relative=='capacity-heap-bounded' else None),'cancel_to_settled_us':cancelled['cancel_to_settled_us']})
assert a.partial or not pending,pending
result={'accepted':not pending,'partial':a.partial,'raw_only':a.raw_only,'pending':pending,'script_sha256':sha(Path(__file__)),'products':products,'scope':'Ordinary extended cache workload and replacement-allocator heap diagnostics are separate from the8primary ordinary products. Server-PID resource counters and native/wire invariants independently rechecked. One ordinary process per scenario, no capacity/P99 confidence guarantee. Instrumented allocator/CPU products are diagnostic only and never pooled with ordinary memory/timing.'}
(r/('native-audit-partial.json' if a.partial else 'native-audit.json')).write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':not pending,'products':len(products),'pending':pending}))
