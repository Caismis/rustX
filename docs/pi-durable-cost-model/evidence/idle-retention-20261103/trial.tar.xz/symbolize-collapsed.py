"""Correct export format without executing any product again."""
import json,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;pprof='/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof';rows=[]
for side,binary in [('before','/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build/rustx'),('after',str(r/'candidate-build/rustx'))]:
 for i in range(1,6):
  d=r/('heap-'+side);cmd=[pprof,'--collapsed','--no_strip_temp','--nodecount=3000','--nodefraction=0','--edgefraction=0',binary,str(d/f'native-sample-{i}.heap')]
  with (d/f'sample-{i}-collapsed.txt').open('x') as so,(d/f'sample-{i}-collapsed.stderr').open('x') as se:p=subprocess.run(cmd,stdout=so,stderr=se)
  rows.append({'command':cmd,'exit':p.returncode});assert p.returncode==0
(r/'collapsed-symbolization.json').write_text(json.dumps(rows,indent=2)+'\n')
