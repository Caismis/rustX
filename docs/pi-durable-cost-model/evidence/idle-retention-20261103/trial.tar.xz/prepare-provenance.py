"""Verify present executables, libraries and source before deliberately excluding them."""
import datetime,hashlib,json,shutil,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;f=r/'refinement';repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for label,path in [('before',Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build')),('trial',r/'candidate-build'),('final',f/'final-build')]:
 native=load(path/'app-server-identity.json');build=load(path/'identity.json');assert sha(path/'rustx')==native['sha256'];assert sha(path/'conformance')==build['sha256'];assert build['verified'];records.append({'label':label,'head':build['head'],'production_tree':build['production_tree'],'native':native['sha256'],'conformance':build['sha256'],'library':sha(path/'librustx.rlib')})
 assert subprocess.check_output(['git','rev-parse',build['head']+':src'],cwd=repo,text=True).strip()==build['production_tree']
 if label=='before':
  out=r/'baseline-build-records';out.mkdir(exist_ok=True)
  for p in path.iterdir():
   if p.suffix in ['.json','.stdout','.stderr']:shutil.copyfile(p,out/p.name)
source=load(f/'final-build/identity.json');assert len(source['source_files'])==973;assert all(sha(repo/p)==digest for p,digest in source['source_files'].items());assert subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip()==source['production_tree']
for cohort,builddir,checks in [(r,r/'candidate-build',r/'checks-verified'),(f,f/'final-build',f/'checks-final')]:
 before=load(checks/'source-before.json');assert before==load(checks/'source-after.json');assert before['files']==load(builddir/'identity.json')['source_files'];assert all(sha(repo/p)==digest for p,digest in before['helpers'].items())
(r/'production-and-test.patch').write_bytes(subprocess.check_output(['git','diff','e1a9847712f520fbc189f479263449f0020c6014','HEAD','--','src','tests','benchmarks/runtime'],cwd=repo));(r/'allocator-return.patch').write_bytes(subprocess.check_output(['git','show','d50125842','--format=fuller'],cwd=repo))
wrappers=[]
for manifest in ['heap-commands.json','trim-commands.json']:
 for row in load(r/manifest):
  name=row['directory'];wrapper=r/(name+'.sh');assert sha(wrapper)==row['wrapper_sha256'];body=wrapper.read_text();target=Path(body.split('\nexec ',1)[1].split(' ',1)[0]);assert sha(target)==row['actual_native_sha256'];wrappers.append({'path':str(wrapper.relative_to(r)),'sha256':sha(wrapper),'native_sha256':sha(target)})
heap=load(r/'heap-tool-identity.json')
for key in ['tcmalloc','helper','pprof']:assert sha(Path(heap[key]['path']))==heap[key]['sha256']
assert sha(r/'heap-sample.cc')==heap['helper']['source_sha256'];control=load(r/'allocator-control-identity.json');assert sha(r/'allocator-control.c')==control['source_sha256'];assert sha(r/'allocator-control.so')==control['excluded_so_sha256']
pi=load(r/'pi-memory-reference.json');assert pi==load(f/'pi-memory-reference.json');original=Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/pi-memory-audit.json');assert sha(original)==pi['original_audit_sha256'];assert next(v for v in load(original)['points'] if v['phase']=='seeded_history_8')==pi['seed_memory']
proof={'accepted':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':source['head'],'production_tree':source['production_tree'],'source_inputs':973,'executables':records,'wrappers':wrappers,'heap_tool_identity_sha256':sha(r/'heap-tool-identity.json'),'allocator_control_identity_sha256':sha(r/'allocator-control-identity.json'),'prior_pi_reference_sha256':sha(r/'pi-memory-reference.json'),'new_pi_deepseek_products':0,'scope':'Actual saved ELF/library/helper/wrapper bytes and exact source/helper inputs verified before archive exclusion. Existing Pi numeric reference authenticated from prior audit only; no Pi runtime/build/performance execution. Offline replay authenticates these stored proofs but does not rehash deliberately omitted artifacts.'};(r/'prearchive-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
