import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');rows=[];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while not (r/'heap-completed.json').exists():time.sleep(2)
bins={'before':Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build/rustx'),'after':r/'candidate-build/rustx'}
for side in ['before','after']:
 while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(1)
 name='trim-'+side;d=r/name;wrapper=r/(name+'.sh');wrapper.write_text('#!/bin/sh\nexport LD_PRELOAD='+str(r/'allocator-control.so')+'\nexport RUSTX_BENCH_PROFILE_SOCKET='+str(d/'control.sock')+'\nexec '+str(bins[side])+' "$@"\n');wrapper.chmod(0o755)
 cmd=[sys.executable,str(r/'trim-capacity.py'),'--binary',str(wrapper),'--output',str(d),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16','--cache-probes'];row={'directory':name,'side':side,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'actual_native_sha256':sha(bins[side]),'wrapper_sha256':sha(wrapper)}
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'trim-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0
(r/'trim-completed.json').write_text('{"accepted":true}\n')
