"""Reuse existing complete sampled-heap exporter after all ordinary products."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
while not (r/'functional-completed.json').exists():time.sleep(2)
tcmalloc=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4.5.16');helper=Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/heap-sample.so');pprof=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof');bins={'before':Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build/rustx'),'after':r/'candidate-build/rustx'}
(r/'heap-tool-identity.json').write_text(json.dumps({'tcmalloc':{'path':str(tcmalloc),'sha256':sha(tcmalloc)},'helper':{'path':str(helper),'sha256':sha(helper),'source_sha256':sha(r/'heap-sample.cc')},'pprof':{'path':str(pprof),'sha256':sha(pprof)},'scope':'Reuse previously compiled gperftools2.15 complete64KiBsample exporter, replacement allocator in native child only; not ordinary timing/PSS.'},indent=2)+'\n')
for side in ['before','after']:
 while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(2)
 name='heap-'+side;directory=r/name;wrapper=r/(name+'.sh');wrapper.write_text('#!/bin/sh\nexport LD_PRELOAD='+str(tcmalloc)+':'+str(helper)+'\nexport TCMALLOC_SAMPLE_PARAMETER=65536\nexport RUSTX_SAMPLE_PREFIX='+str(directory/'native-sample')+'\nunset HEAPPROFILE HEAPPROFILESIGNAL\nexec '+str(bins[side])+' "$@"\n');wrapper.chmod(0o755)
 cmd=[sys.executable,str(r/'sampling-capacity.py'),'--binary',str(wrapper),'--output',str(directory),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16','--cache-probes'];row={'directory':name,'side':side,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'actual_native_sha256':sha(bins[side]),'wrapper_sha256':sha(wrapper)}
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'heap-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0 and load(directory/'completed.json')['accepted']
 for i in range(1,6):
  profile=directory/f'native-sample-{i}.heap';assert profile.exists()
  for label,flags in [('stacks',['--stacks','--no_strip_temp']),('cum',['--text','--cum','--no_strip_temp','--nodecount=3000','--nodefraction=0','--edgefraction=0'])]:
   cmd=[str(pprof),*flags,str(bins[side]),str(profile)]
   with (directory/f'sample-{i}-{label}.txt').open('x') as so,(directory/f'sample-{i}-{label}.stderr').open('x') as se:subprocess.run(cmd,stdout=so,stderr=se,check=True)
(r/'heap-completed.json').write_text('{"accepted":true}\n')
