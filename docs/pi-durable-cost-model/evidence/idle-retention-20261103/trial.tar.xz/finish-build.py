import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();checks=r/'checks-verified'
while not (checks/'source-after.json').exists():
 if (checks/'commands.json').exists():assert all(v['exit']==0 for v in load(checks/'commands.json')),'Check failed; inspect before proceeding'
 time.sleep(2)
commands=load(checks/'commands.json');assert len(commands)==17 and all(v['exit']==0 for v in commands);assert load(checks/'source-before.json')==load(checks/'source-after.json');source=load(checks/'source-after.json');assert all(sha(repo/p)==v for p,v in (source['files']|source['helpers']).items());counts={};duplicates=[]
for row in commands:
 if row['label'].startswith('tests-') and row['label']!='tests-build':
  for line in (checks/(row['label']+'.stdout')).read_text().splitlines():
   m=re.match(r'test (.+) \.\.\. (ok|ignored)',line)
   if m:
    key=(row['command'][0],m[1]);assert key not in counts or counts[key]==m[2]
    if key in counts:duplicates.append(m[1])
    counts[key]=m[2]
(r/'checks-summary.json').write_text(json.dumps({'accepted':True,'commands':17,'source_inputs':len(source['files']),'helper_inputs':source['helpers'],'tests':{v:sum(x==v for x in counts.values()) for v in ['ok','ignored']},'duplicates':duplicates},indent=2)+'\n')
owned=['benchmarks/runtime/app-server-capacity-provider.py','benchmarks/runtime/app-server-capacity.py','src/durable/inbox.rs','src/durable/sqlite.rs','src/durable/sqlite/idle_cache.rs','src/local_runtime/session_runtime_manager.rs','src/runtime/conversation_runtime.rs','src/runtime_client/event.rs','src/runtime_client/host.rs','src/runtime_client/projection.rs','src/runtime_client/projection/shared_domain_detach_tests.rs','src/runtime_client/projection/shared_snapshot.rs','src/runtime_client/snapshot.rs','src/app_server/schema.rs','src/runtime_client/checkpoint/metadata_fragment.rs','src/runtime_client/projection/incremental_checkpoint_tests.rs','src/runtime_client/projection/prepared_capture.rs','src/runtime_client/response/tests.rs','src/durable/sqlite/observation_response_tests.rs'];subprocess.run(['git','diff','--check'],cwd=repo,check=True);subprocess.run(['git','add',*owned],cwd=repo,check=True);subprocess.run(['git','diff','--cached','--check'],cwd=repo,check=True);subprocess.run(['git','commit','-m','Share replay descriptor rows and reclaim idle SQLite caches'],cwd=repo,check=True)
with (r/'candidate-build.stdout').open('x') as so,(r/'candidate-build.stderr').open('x') as se:subprocess.run([sys.executable,str(r/'build.py'),'candidate',str(repo)],cwd=repo,stdout=so,stderr=se,check=True)
build=load(r/'candidate-build/identity.json');assert build['source_files']==source['files'];assert all(sha(repo/p)==v for p,v in (source['files']|source['helpers']).items())
artifacts=[json.loads(v) for v in (r/'candidate-build/build.stdout').read_text().splitlines() if v.startswith('{')];main=next(v for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name']=='rustx' and v['target']['kind']==['bin'] and v.get('executable'));(r/'candidate-build/app-server-identity.json').write_text(json.dumps({'head':build['head'],'binary':str(r/'candidate-build/rustx'),'sha256':sha(r/'candidate-build/rustx'),'artifact':main},indent=2)+'\n')
# Structured test-only SQLite counters, independently of ordinary PID PSS.
bin=next(v['command'][0] for v in commands if v['label']=='tests-sqlite');cmd=[bin,'durable::sqlite::idle_cache::tests::','--test-threads=1','--nocapture']
with (r/'cache-unit-probe.stdout').open('x') as so,(r/'cache-unit-probe.stderr').open('x') as se:subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,check=True)
(r/'ready.json').write_text(json.dumps({'accepted':True,'head':build['head'],'native_sha256':sha(r/'candidate-build/rustx'),'conformance_sha256':build['sha256']},indent=2)+'\n');print('Ready',flush=True)
