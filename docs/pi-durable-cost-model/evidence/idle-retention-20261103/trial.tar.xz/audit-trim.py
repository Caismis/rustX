import base64,hashlib,json
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());rows=[]
def point(raw):
 tail=raw['stat'].rsplit(')',1)[1].split();mem=dict(v.split(':',1) for v in raw['smaps_rollup'].splitlines() if ':' in v);return {'pid':int(raw['stat'].split('(',1)[0]),'start_ticks':int(tail[19]),'cpu_ticks':int(tail[11])+int(tail[12]),'anon_pss_mib':int(mem['Pss_Anon'].split()[0])/1024,'rss_mib':int(mem['Rss'].split()[0])/1024}
for row in load(r/'trim-commands.json'):
 assert row['exit']==0;d=r/row['directory'];raw=load(d/'allocator-trim.json');before,after=point(raw['before']),point(raw['after']);assert (before['pid'],before['start_ticks'])==(after['pid'],after['start_ticks']);reply=raw['reply'];assert reply['released'] in [0,1] and reply['wall_ns']>=reply['cpu_ns']>=0
 phases={v['phase']:v for v in load(d/'phases.json')};assert phases['cache_statements_idle']['diagnostics']['loaded']==phases['cache_allocator_trimmed']['diagnostics']['loaded']==128
 rows.append({'directory':row['directory'],'side':row['side'],'native_sha256':row['actual_native_sha256'],'before':before,'after':after,'anon_pss_released_mib':before['anon_pss_mib']-after['anon_pss_mib'],'rss_released_mib':before['rss_mib']-after['rss_mib'],'wall_ms':reply['wall_ns']/1e6,'control_thread_cpu_ms':reply['cpu_ns']/1e6,'released':reply['released']})
(r/'trim-audit.json').write_text(json.dumps({'accepted':True,'products':rows,'scope':'Two diagnostic ordinary-glibc products with a control-thread-only preload, same preserved ELF before/after one malloc_trim(0) at130s.128actors retained,4sessions14turns/124sessions8turns; full1515request/native/reopen/cancel oracles separately rechecked. Immediate PSS/RSS drop is causal for this cut; a single sample per side is not a latency confidence claim.'},indent=2)+'\n');print(json.dumps({'accepted':True,'effects':[(v['side'],v['anon_pss_released_mib'],v['wall_ms']) for v in rows]}))
