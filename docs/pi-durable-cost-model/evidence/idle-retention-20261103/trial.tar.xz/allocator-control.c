/* Diagnostic-only allocator cut, using the existing profiling bridge handshake.
 * Never loaded by production. Native executable and stored facts stay unchanged. */
#define _GNU_SOURCE
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <pthread.h>
#include <malloc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static int server;
static unsigned long long nanoseconds(clockid_t clock) {
  struct timespec t;
  if (clock_gettime(clock, &t)) abort();
  return (unsigned long long)t.tv_sec * 1000000000ULL + t.tv_nsec;
}
static void *control(void *unused) {
  (void)unused;
  for (;;) {
    int fd = accept(server, NULL, NULL);
    if (fd < 0) abort();
    char command[16]; size_t n = 0;
    while (n + 1 < sizeof command) {
      if (read(fd,command+n,1)!=1) abort();
      if (command[n++]=='\n') break;
    }
    command[n]=0;
    if (strcmp(command,"trim\n")) abort();
    unsigned long long wall=nanoseconds(CLOCK_MONOTONIC), cpu=nanoseconds(CLOCK_THREAD_CPUTIME_ID);
    int released=malloc_trim(0);
    cpu=nanoseconds(CLOCK_THREAD_CPUTIME_ID)-cpu;
    wall=nanoseconds(CLOCK_MONOTONIC)-wall;
    char reply[256];
    int len=snprintf(reply,sizeof reply,"{\"released\":%d,\"wall_ns\":%llu,\"cpu_ns\":%llu}\n",released,wall,cpu);
    if (len<=0 || len>=(int)sizeof reply || write(fd,reply,len)!=len) abort();
    close(fd);
  }
  return NULL;
}
__attribute__((constructor)) static void initialize(void) {
  const char *path=getenv("RUSTX_BENCH_PROFILE_SOCKET");
  if (!path) return;
  struct sockaddr_un address={.sun_family=AF_UNIX};
  if(strlen(path)>=sizeof address.sun_path) abort();
  strcpy(address.sun_path,path);
  server=socket(AF_UNIX,SOCK_STREAM,0);
  if(server<0 || bind(server,(struct sockaddr*)&address,sizeof address) || listen(server,1)) abort();
  pthread_t thread;
  if(pthread_create(&thread,NULL,control,NULL) || pthread_detach(thread)) abort();
}
