"""Finish readiness from verified O3 artifacts after the optional cleared-test-executable probe."""
import datetime,hashlib,json,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
while True:
 if (r/'ready.json').exists():raise SystemExit(0)
 path=r/'candidate-build/identity.json'
 if path.exists() and load(path).get('verified'):break
 time.sleep(2)
while not (r/'ready.json').exists() and 'FileNotFoundError' not in (r/'finish-build-verified.stderr').read_text():time.sleep(1)
if (r/'ready.json').exists():raise SystemExit(0)
build=load(r/'candidate-build/identity.json');source=load(r/'checks-verified/source-after.json');assert build['verified'] and build['source_files']==source['files'];assert all(sha(repo/p)==v for p,v in (source['files']|source['helpers']).items());assert len(source['files'])==973;commands=load(r/'checks-verified/commands.json');assert len(commands)==17 and all(v['exit']==0 for v in commands);main=load(r/'candidate-build/app-server-identity.json');assert main['sha256']==sha(Path(main['binary']));assert build['sha256']==sha(r/'candidate-build/conformance')
(r/'readiness-recovery.json').write_text(json.dumps({'accepted':True,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cause':'Optional post-build numeric unit probe referred to a correctness executable removed by the deliberate fresh package clean. The17source-identical checks already pass; no product or check deadline changed. Do not count this probe as executed. Use the passed cache tests and subsequent native sampled-heap diagnostics.','source_inputs':973,'tests':load(r/'checks-summary.json')['tests'],'build_identity_sha256':sha(r/'candidate-build/identity.json')},indent=2)+'\n')
(r/'ready.json').write_text(json.dumps({'accepted':True,'head':build['head'],'native_sha256':main['sha256'],'conformance_sha256':build['sha256']},indent=2)+'\n');print('Ready from verified checks/build',flush=True)
