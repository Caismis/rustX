"""Package only this round in two bounded archives, with all failed/raw proof records."""
import hashlib,io,json,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/evidence/idle-retention-20261103');out.mkdir(parents=True,exist_ok=True);sha=lambda b:hashlib.sha256(b).hexdigest();selected=[];excluded=[]
for p in sorted(r.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(r);parts=rel.parts;reason=None
 if any(v in parts for v in ['runtime','workspaces','node_modules','.git','__pycache__']):reason='Mutable runtime/workspace/dependency tree or Python bytecode'
 elif p.name in ['WORK-IN-PROGRESS.txt','token','provider.stdout','archive-selection.json'] or p.name.startswith('.env'):reason='Working notes/authentication/duplicate provider stdout; structured full provider reports retained'
 elif p.suffix in ['.so','.rlib','.pyc'] or p.name in ['rustx','conformance']:reason='Excluded compiled executable/library; identity and prearchive byte proof retained'
 else:
  with p.open('rb') as h:magic=h.read(4)
  if magic==b'\x7fELF':reason='Excluded ELF; identity retained'
 if reason:excluded.append({'path':str(rel),'reason':reason})
 else:selected.append(p)
selection={'selected_files':len(selected)+1,'excluded_files':len(excluded),'excluded':excluded,'scope':'This round only: both trial/final raw products, consistent native images, complete profiles/symbolization, failures, source/build/check/input records. Prior Pi only numeric reference, no old archives/runtime duplicated.'};(r/'archive-selection.json').write_text(json.dumps(selection,indent=2)+'\n');selected=sorted([*selected,r/'archive-selection.json']);archives=[];members=[]
for group in ['trial','final']:
 target=out/(group+'.tar.xz');assert not target.exists()
 files=[p for p in selected if (p.relative_to(r).parts[0]=='refinement')==(group=='final')]
 with tarfile.open(target,'w:xz',preset=6) as archive:
  for p in files:
   body=p.read_bytes();relative=str(p.relative_to(r));members.append({'archive':target.name,'path':relative,'bytes':len(body),'sha256':sha(body)});info=archive.gettarinfo(str(p),arcname=relative);info.uid=info.gid=0;info.uname=info.gname='';archive.addfile(info,io.BytesIO(body))
 assert target.stat().st_size<95_000_000,target.stat().st_size
 archives.append({'name':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes())});print(json.dumps(archives[-1]),flush=True)
manifest={'archives':archives,'members':members,'scope':'No product, compiler, git, symbolizer or network execution needed by offline replay. Omitted runtime/ELF/shared libraries/authentication are identified by stored prearchive proofs.'};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'accepted':True,'members':len(members),'raw_bytes':sum(v['bytes'] for v in members)}),flush=True)
