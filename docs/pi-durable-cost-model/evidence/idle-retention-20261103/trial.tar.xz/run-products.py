import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();rows=[]
while not (r/'ready.json').exists():time.sleep(2)
bins={'before':Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build/rustx'),'after':r/'candidate-build/rustx'};before=load(Path('/home/capi/.cache/rustx-pr485-native-regression-20261103/candidate-build/app-server-identity.json'));assert sha(bins['before'])==before['sha256'];source={str(p.relative_to(repo)):sha(p) for p in [repo/'benchmarks/runtime/app-server-capacity.py',repo/'benchmarks/runtime/app-server-capacity-provider.py']};(r/'premeasurement.json').write_text(json.dumps({'binaries':{s:{'path':str(p),'sha256':sha(p)} for s,p in bins.items()},'inputs':source,'scope':'New Rust-only before/after ordinary products; Pi and DeepSeek not executed. Cache products have24kept-warm plus256rotation requests beyond the unchanged1235standard workload.'},indent=2)+'\n')
# Cache products first also validate the added bounded cold/Inspector oracle.
for family,orders in [('cache',[['before','after'],['after','before']]),('ordinary',[['before','after'],['after','before'],['after','before'],['before','after']])]:
 for pair,order in enumerate(orders):
  for side in order:
   while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(1)
   name=f'{family}-{pair}-{side}';cmd=[sys.executable,'benchmarks/runtime/app-server-capacity.py','--binary',str(bins[side]),'--output',str(r/name),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16']
   if family=='cache':cmd+=['--cache-probes']
   row={'family':family,'pair':pair,'side':side,'directory':name,'command':cmd,'start_utc':now()}
   with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
   row.update(exit=p.returncode,end_utc=now());rows.append(row);(r/'product-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0 and load(r/name/'completed.json')['accepted'];assert all(sha(repo/p)==v for p,v in source.items())
(r/'products-completed.json').write_text('{"accepted":true}\n')
