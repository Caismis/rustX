import datetime,json,os,subprocess
from pathlib import Path
root=Path('/home/capi/.cache/rustx-pr485-next')
records=[]
for mode,name in [('no-live-subscriber','direct-no-live'),('live-subscriber','direct-live')]:
    command=['python3','benchmarks/runtime/compare-revisions.py','--before','/home/capi/.cache/rustx-pr485-evidence/candidate-final-build/conformance','--after',str(root/'candidate-d-build/conformance'),'--output',str(root/name),'--pairs','3','--observer-mode',mode]
    record={'argv':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (root/(name+'.stdout')).open('w') as out,(root/(name+'.stderr')).open('w') as err:
        result=subprocess.run(command,stdout=out,stderr=err)
    record.update(exit=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record)
    (root/'direct-d-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    result.check_returncode()
command=['python3','docs/pi-durable-cost-model/evidence/read-cache-trial-20261027/recompute-direct.py','--root',str(root)]
with (root/'direct-d-recomputed.json').open('w') as out: subprocess.run(command,stdout=out,check=True)
