#!/usr/bin/env python3
"""Pure-data/mocked-runner checks. No products or builds are executed."""
import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

ROOT = Path('/home/capi/.cache/rustx-pr485-next')
def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result
pi = module('recompute_pi', 'recompute-pi.py')
runner = module('final_runner', 'run-final-cohorts.py')
checks = []
def passed(name, condition):
    assert condition, name
    checks.append(name)

passed('zero numerator retains zero ratio', pi.paired_ratio(0, 3) == (0, None))
passed('zero denominator has explicit reason', pi.paired_ratio(0, 0) == (None, 'zero_denominator'))
passed('missing counter has distinct reason', pi.paired_ratio(None, 1) == (None, 'missing_counter'))
s = pi.summary([0, 1, 2])
passed('zero remains in arithmetic summary without a log interval', s['median'] == 1 and s['minimum'] == 0 and s['values'] == [0, 1, 2] and 'lower90' not in s and s['log_interval_unavailable_reason'])
s = pi.summary([0, None, 2])
passed('partial ratios keep all positions and unavailable state', s['values'] == [0, None, 2] and s['available'] == 2 and s['median'] == 1)

with tempfile.TemporaryDirectory(prefix='final-cache-audit-check-') as directory:
    root = Path(directory)
    binary = root / 'conformance'
    binary.write_bytes(b'pure fixture, never executable')
    sha = pi.sha256_file(binary)
    identity = {'verified': True, 'build_exit': 0, 'sha256': sha, 'binary': str(binary), 'head': 'a' * 40, 'production_tree': 'b' * 40, 'harness': {'fixture': 'c' * 64}, 'rustc': 'fixture rustc'}
    path = root / 'identity.json'; path.write_text(json.dumps(identity))
    manifests = {name: {'manifest': {'rust': str(binary), 'rust_sha256': sha}} for name in ('pi-no-live', 'pi-live')}
    args = argparse.Namespace(expect_rust_sha256=sha, identity=path, raw_only=False)
    out = pi.identity_audit(manifests, args)
    passed('strict actual/build/expected identities all bind', out['strict_identity_verified'] and not out['errors'])
    binary.unlink()
    args.raw_only = True
    out = pi.identity_audit(manifests, args)
    passed('archived supplied identity needs no host binary', not out['strict_identity_verified'] and out['recorded_build_identity_verified'] and not out['actual_binary_checks'] and not out['errors'])
    args.identity = None
    out = pi.identity_audit(manifests, args)
    passed('raw-only skips all inferred historical paths', not out['strict_identity_verified'] and out['identity_file'] is None and not out['errors'])
    args.expect_rust_sha256 = '0' * 64
    passed('raw-only still enforces explicit advertised identity', bool(pi.identity_audit(manifests, args)['errors']))
    args.expect_rust_sha256 = sha; args.raw_only = False
    out = pi.identity_audit(manifests, args)
    passed('missing actual binary is a distinct strict identity failure', bool(out['errors']) and not out['actual_binary_files_verified'])

    original_cache = runner.CACHE
    def exercise(label, outcome):
        case = root / label; case.mkdir()
        runner.CACHE = case
        fake_identity = {'data': {'harness': {'fixture': 'c' * 64}, 'rustc': 'fixture rustc'}}
        with patch.object(runner, 'build_identity', return_value=fake_identity), patch.object(runner.subprocess, 'run', side_effect=outcome) as runs, patch.object(sys, 'argv', ['runner', '--stage', 'final', '--rust', str(binary)]), contextlib.redirect_stdout(io.StringIO()):
            code = runner.main()
        plan = json.loads((case / 'final-cohorts/plan.json').read_text())
        return code, plan, runs.call_args_list
    outcome = lambda *a, **k: argparse.Namespace(returncode=0)
    code, plan, calls = exercise('success', outcome)
    passed('full final plan has five cohorts and three strict audits', code == 0 and len(plan['steps']) == 9 and [s['name'] for s in plan['steps'][-3:]] == ['audit-pi', 'audit-append', 'audit-three-engine'] and all(s['status'] == 'complete' for s in plan['steps']))
    passed('every child uses explicit repository cwd and both evidence roots are retained', all(c.kwargs['cwd'] == runner.REPO for c in calls) and len(plan['evidence_roots']) == 2)
    code, plan, calls = exercise('failed', [argparse.Namespace(returncode=0), argparse.Namespace(returncode=7)])
    passed('failed product retains failure and all unexecuted plan entries', code == 7 and plan['steps'][2]['status'] == 'failed' and all(s['status'] == 'not_run' for s in plan['steps'][3:]) and len(calls) == 2)
    code, plan, calls = exercise('spawn-error', FileNotFoundError('fixture missing executable'))
    passed('spawn exception is retained and later commands never run', code == 1 and plan['steps'][1]['status'] == 'failed' and 'FileNotFoundError' in plan['steps'][1]['error'] and all(s['status'] == 'not_run' for s in plan['steps'][2:]) and len(calls) == 1)
    runner.CACHE = original_cache

result = {'pure_data_checks_passed': len(checks), 'checks': checks, 'no_product_execution': True, 'scripts': {f: pi.sha256_file(ROOT / f) for f in ('run-final-cohorts.py', 'recompute-pi.py', 'test-final-cache-scripts.py')}}
(ROOT / 'final-cache-script-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
