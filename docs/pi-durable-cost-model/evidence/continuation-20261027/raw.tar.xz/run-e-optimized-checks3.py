import datetime,json,os,subprocess
from pathlib import Path
r=Path('/home/capi/.cache/rustx-pr485-next');d=r/'candidate-e-optimized-check3';d.mkdir(exist_ok=False)
binary=r/'candidate-e-build/lib-tests';records=[]
env=os.environ|{'UV_OFFLINE':'1','RUSTX_REQUIRE_PROVIDER_EMULATOR':'1'}
for label,selector in [('sqlite','durable::sqlite::'),('client','runtime_client::'),('conversation-runtime','runtime::conversation_runtime::'),('read-layout','runtime::read_layout::'),('content','boundary_suites::durable::content::')]:
 command=[str(binary),selector,'--skip','::scale::','--test-threads=2']
 record={'label':label,'argv':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (d/(label+'.stdout')).open('w') as out,(d/(label+'.stderr')).open('w') as err:
  result=subprocess.run(command,cwd='/home/capi/.codex/worktrees/pr485-pi-performance/rustX',env=env,stdout=out,stderr=err)
 record.update(exit=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record)
 (d/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print(label,result.returncode,flush=True);result.check_returncode()
command=[str(binary),'durable::sqlite::observation_request::composed::scalar_benchmark::request_scalar_reader_representation_benchmark','--exact','--ignored','--nocapture','--test-threads=1']
record={'label':'reader-diagnostic','argv':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with (d/'reader.stdout').open('w') as out,(d/'reader.stderr').open('w') as err:
 result=subprocess.run(command,cwd='/home/capi/.codex/worktrees/pr485-pi-performance/rustX',env=env|{'RUSTX_SCALAR_BENCH_OUTPUT':str(r/'candidate-e-reader.json')},stdout=out,stderr=err)
record.update(exit=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(record)
(d/'commands.json').write_text(json.dumps(records,indent=2)+'\n');print('reader',result.returncode,flush=True);result.check_returncode()
if not (r/'candidate-e-reader.json').is_file(): raise ValueError('diagnostic selector did not write output')
