#!/usr/bin/env python3
"""Pure-data checks for audit-final-append.py; never execute a product."""
import argparse
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import tempfile

base = Path('/home/capi/.cache/rustx-pr485-next')
script = base / 'audit-final-append.py'
spec = importlib.util.spec_from_file_location('append_audit', script)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)
source = Path('/home/capi/.cache/rustx-pr485-evidence')
raw = json.loads((source / 'append-cold/0-0-before.json').read_text())
process = json.loads((source / 'append-cold/0-0-before.process.json').read_text())
checks = []
def passed(name, value):
    assert value, name
    checks.append(name)

passed('zero denominator stays undefined', audit.ratio(audit.cell(0), audit.cell(0))['status'] == 'zero_denominator')
passed('zero numerator preserved', audit.ratio(audit.cell(2), audit.cell(0))['value'] == 0)
d = audit.distribution([audit.cell(0), audit.cell(status='missing'), audit.cell(2)])
passed('missing summary positions and zero retained', d['values'] == [0, None, 2] and d['zero_values'] == 1 and not d['complete'])
n = audit.scaled(audit.difference(audit.cell(3), audit.cell(1)), 10)
passed('negative delta retained in correct units', n['status'] == 'invalid' and n['value'] == -20)
m = copy.deepcopy(raw)
m['lifecycle'][1]['process']['stat'] = None
passed('missing CPU endpoint remains unavailable', audit.metrics(m, process, 100)[0]['append_phase_cpu_ms']['status'] == 'unavailable')
m = copy.deepcopy(raw)
m['operation_counters'][0]['before']['io'] = None
mout = audit.metrics(m, process, 100)[0]
passed('missing cold I/O bracket does not replace phase counters', mout['cold_operation_write_mib_per_append']['status'] == 'unavailable' and mout['append_phase_write_mib']['status'] == 'ok')
m = copy.deepcopy(raw)
m['lifecycle'][0]['process']['smaps_rollup'] = None
passed('missing memory remains explicitly partial', audit.metrics(m, process, 100)[0]['max_sampled_anon_pss_mib']['status'] == 'partial')
m = copy.deepcopy(raw)
m['lifecycle'][0] = None
m['operation_counters'][0] = None
mout = audit.metrics(m, process, 100)[0]
passed('malformed sample rows remain unavailable without aborting arithmetic', mout['lifecycle_cpu_ms']['status'] == 'unavailable' and mout['cold_operation_cpu_ms_per_append']['status'] == 'unavailable')

with tempfile.TemporaryDirectory(prefix='append-audit-portability-') as temporary:
    root = Path(temporary)
    for mode in ('warm', 'cold'):
        folder = root / ('append-' + mode)
        folder.mkdir()
        for path in (source / ('append-' + mode)).iterdir():
            if path.name == 'manifest.json':
                manifest = json.loads(path.read_text())
                for engine in ('before', 'after'):
                    manifest['executables'][engine]['path'] = str(root / 'absent-host' / engine / 'conformance')
                (folder / path.name).write_text(json.dumps(manifest))
            elif path.suffix in ('.json', '.log'):
                (folder / path.name).symlink_to(path)
    def run(mode, before_identity=None, after_identity=None):
        args = argparse.Namespace(root=root, output=root / ('result-' + mode + '.json'), binary_verification=mode, before_identity=before_identity, after_identity=after_identity, expect_before_sha256=None, expect_after_sha256=None, reference_audit=source / 'append-audit.json')
        with contextlib.redirect_stdout(io.StringIO()):
            code = audit.audit(args)
        return code, json.loads(args.output.read_text())
    code, archived = run('off')
    passed('archive off mode recomputes all 48 products and 864 prior summaries without host identities', code == 0 and archived['raw_data_verified'] and not archived['binary_files_verified'] and not archived['recorded_build_identities_verified'] and archived['accepted_products'] == 48 and archived['reference_audit_comparison']['checks'] == 864)
    code, strict = run('strict')
    passed('strict missing binaries fail identity verification while completing all raw calculations', code == 1 and strict['raw_data_verified'] and not strict['binary_files_verified'] and strict['accepted_products'] == 48 and strict['summaries'] == archived['summaries'] and bool(strict['binary_file_errors']))
    identities = []
    manifest = json.loads((source / 'append-warm/manifest.json').read_text())
    for engine in ('before', 'after'):
        identity = json.loads((Path(manifest['executables'][engine]['path']).parent / 'identity.json').read_text())
        identity['binary'] = str(root / 'absent-host' / engine / 'conformance')
        identity_path = root / (engine + '-identity.json')
        identity_path.write_text(json.dumps(identity))
        identities.append(identity_path)
    code, archived_with_identity = run('off', *identities)
    passed('archive supplied build identities verify records without claiming actual binary verification', code == 0 and archived_with_identity['recorded_build_identities_verified'] and not archived_with_identity['binary_files_verified'] and archived_with_identity['summaries'] == archived['summaries'])

result = {'pure_data_checks_passed': len(checks), 'source': str(script), 'script_sha256': audit.digest(script), 'test_script_sha256': audit.digest(__file__), 'checks': checks, 'no_product_execution': True}
(base / 'append-audit-script-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
