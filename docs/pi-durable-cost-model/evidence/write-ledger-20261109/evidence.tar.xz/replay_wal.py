"""Replay captured WAL page images and resolve dbstat owners at their commit."""
import argparse
from collections import Counter, defaultdict
import contextlib
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import struct
import tempfile
from trace_products import layout, dump, quote

CALL=re.compile(r'^(\d+) +(\d+\.\d+) (pwrite64|write|writev|ftruncate|fsync|fdatasync)\(\d+<([^>]*)>(.*)\) += +(-?\d+)')
BUFFER=re.compile(r'^, "((?:\\x[0-9a-f]{2})*)", (\d+), (\d+)$')
PAGE=2048
FRAME=PAGE+24

def decode(s):
    return bytes.fromhex(s.replace('\\x',''))

def rows(path):
    phases=json.loads((path/'phases.json').read_text())
    t0=0
    names=[(p['epoch_ns']/1e9,p['phase']) for p in phases]
    names.append((float('inf'),'finished'))
    ends=iter(names)
    edge,after=next(ends)
    phase='startup'
    pending={}
    with (path/'calls.strace').open() as trace:
        for line in trace:
            if '<unfinished ...>' in line:
                if re.search(r'\b(?:pwrite64|writev?|ftruncate|fdatasync|fsync)\(',line):
                    tid=line.split()[0]
                    assert tid not in pending, line[:150]
                    pending[tid]=line.split('<unfinished ...>',1)[0].rstrip()
                continue
            if ' resumed>' in line:
                tid=line.split()[0]
                if tid not in pending:
                    continue
                line=pending.pop(tid)+line.split(' resumed>',1)[1]
            match=CALL.match(line)
            if not match:
                continue
            tid,t,op,filename,arg,done=match.groups()
            stamp=float(t)
            while stamp>=edge:
                phase=after
                edge,after=next(ends)
            try:
                filename=os.fsdecode(decode(filename))
            except ValueError:
                continue
            yield phase,op,filename,arg,int(done)
    assert not pending

def update_rows(c, tables, previous):
    changed={}
    for name in sorted(tables):
        fields=[row for row in c.execute(f'PRAGMA table_xinfo({quote(name)})') if row[-1] in (0,3)]
        if not fields:
            continue
        columns=[quote(row[1]) for row in fields]
        primary=[i for i,row in sorted(enumerate(fields),key=lambda entry:entry[1][5]) if row[5]]
        lengths=[f'coalesce(length(cast({column} AS BLOB)),0)' for column in columns]
        key_col='' if primary else 'rowid,'
        prefix=int(not primary)
        size=len(columns)
        now={}
        for row in c.execute(f'SELECT {key_col}{",".join(columns+lengths)} FROM {quote(name)}'):
            values=row[prefix:prefix+size]
            key=tuple(values[i] for i in primary) if primary else row[0]
            now[key]=(values,row[prefix+size:])
        old=previous.get(name,{})
        added=now.keys()-old.keys()
        removed=old.keys()-now.keys()
        updates=[key for key in old.keys() & now.keys() if old[key][0]!=now[key][0]]
        if added or removed or updates:
            changed[name]={'inserted':len(added),'deleted':len(removed),'updated':len(updates),
                           'inserted_column_bytes':sum(sum(now[key][1]) for key in added),
                           'changed_new_column_bytes':sum(n for key in updates for a,b,n in
                               zip(old[key][0],now[key][0],now[key][1]) if a!=b)}
        previous[name]=now
    return changed

def owner(db, frames, previous):
    with contextlib.closing(sqlite3.connect(db.as_uri()+'?immutable=1',uri=True)) as c:
        c.execute('PRAGMA query_only=ON')
        pages={p:(n,k) for p,n,k in c.execute('SELECT pageno,name,pagetype FROM dbstat')}
        has_events=c.execute("SELECT 1 FROM sqlite_schema WHERE name='events'").fetchone()
        if has_events:
            events=c.execute("SELECT sequence,json_extract(event_json,'$.event.type') FROM events ORDER BY sequence").fetchall()
            pending=c.execute('SELECT count(*) FROM pending_inbound').fetchone()[0]
        else:
            events,pending=[],0
        touched={pages[pg][0] for pg,_,_ in frames if pg in pages}
        tables={name for name, in c.execute("SELECT name FROM sqlite_schema WHERE type='table'")} & touched
        mutations=update_rows(c,tables,previous)
    return pages,events,pending,mutations

def phase_of(events,pending_delta,sequence):
    if not events:
        return 'inbound_acceptance' if pending_delta>0 else ('empty_schema' if not sequence else 'no_new_native_event')
    kinds={kind for _,kind in events}
    if 'inbound_turn_adopted' in kinds:
        return 'inbound_adoption'
    if 'model_request_started' in kinds:
        return 'request_start'
    if any(kind in kinds for kind in ('attempt_completed','attempt_cancelled','attempt_failed','model_request_completed')):
        return 'final_settlement'
    if any(kind in kinds for kind in ('attempt_started','turn_started')):
        return 'attempt_turn_start'
    return '+'.join(sorted(kinds))

def checksum(data,initial,endian):
    s1,s2=initial
    for a,b in struct.iter_unpack(endian+'II',data):
        s1=(s1+a+s2)&0xffffffff
        s2=(s2+b+s1)&0xffffffff
    return s1,s2

def replay(path):
    totals=defaultdict(Counter)
    wal_owners=defaultdict(Counter)
    main_owners=defaultdict(Counter)
    commits=[]
    unique=defaultdict(set)
    versions=defaultdict(set)
    frames=[]
    header=None
    epoch=-1
    cursor=None
    sequence=prev_pending=0
    saw_wal=False
    latest={}
    expected=json.loads((path/'after_turns-layout.json').read_text())
    main_path=expected['path']
    last_known_owner={}
    previous_rows={}
    with tempfile.TemporaryDirectory(prefix='rx-page-replay-') as directory:
        shadow=Path(directory)/'copy.sqlite'
        with shadow.open('w+b',buffering=0) as image:
            for phase,op,filename,arg,done in rows(path):
                filename=filename.removesuffix(' (deleted)')
                name=Path(filename).name
                role=('main' if filename==main_path else 'wal' if filename==main_path+'-wal' else
                      'shm' if filename==main_path+'-shm' else 'rollback_journal' if filename==main_path+'-journal' else
                      ('diagnostic_socket_or_pipe' if not filename.startswith('/') else
                       'benchmark_output' if name=='sample.json' else name))
                if done<0:
                    totals[phase][(role,op,'failed')]+=1
                    continue
                totals[phase][(role,op,'calls')]+=1
                if op in ('write','writev','pwrite64'):
                    totals[phase][(role,op,'bytes')]+=done
                if op=='ftruncate' and role=='main' and not saw_wal:
                    image.truncate(int(arg.strip().removeprefix(', ')))
                if op!='pwrite64' or role not in ('main','wal'):
                    continue
                match=BUFFER.fullmatch(arg)
                assert match is not None,(role,arg[:70],arg[-55:])
                encoded,length,offset=match.groups()
                data=decode(encoded)
                length,offset=int(length),int(offset)
                assert len(data)==length==done,(role,len(data),length,done)
                if role=='main':
                    if not saw_wal:
                        image.seek(offset)
                        image.write(data)
                        main_owners[phase]['bootstrap_unattributed']+=len(data)
                    else:
                        assert len(data)==PAGE and offset%PAGE==0
                        pg=offset//PAGE+1
                        key=pg,hashlib.sha256(data).digest()
                        candidates=versions[key]
                        name=next(iter(candidates)) if len(candidates)==1 else 'unattributed_or_free'
                        main_owners[phase][name]+=len(data)
                    continue
                saw_wal=True
                if offset==0:
                    assert not frames and len(data)==32
                    magic,_,page_size,*_=struct.unpack('>8I',data)
                    assert magic in (0x377f0682,0x377f0683) and page_size==PAGE
                    endian='<' if magic==0x377f0682 else '>'
                    rolling=checksum(data[:24],(0,0),endian)
                    assert rolling==struct.unpack('>II',data[24:])
                    salt=data[16:24]
                    epoch+=1
                    cursor=32
                    totals[phase][('wal','epochs','calls')]+=1
                elif len(data)==24:
                    assert offset==cursor and data[8:16]==salt and header is None,(offset,cursor)
                    header=data
                elif len(data)==PAGE:
                    assert header is not None and offset==cursor+24
                    rolling=checksum(header[:8]+data,rolling,endian)
                    assert rolling==struct.unpack('>II',header[16:])
                    page,size=struct.unpack('>II',header[:8])
                    cursor+=FRAME
                    header=None
                    unique[phase].add(page)
                    frames.append((page,data,phase))
                    if not size:
                        continue
                    for pg,body,_ in frames:
                        image.seek((pg-1)*PAGE)
                        image.write(body)
                    image.truncate(size*PAGE)
                    pages,events,pending,mutations=owner(shadow,frames,previous_rows)
                    new_events=[e for e in events if e[0]>sequence]
                    kind=phase_of(new_events,pending-prev_pending,sequence)
                    sequence=events[-1][0] if events else sequence
                    prev_pending=pending
                    count=Counter()
                    for pg,body,phase_at_write in frames:
                        name,typ=pages.get(pg,('unattributed_or_free',None))
                        latest[pg]=(body,name)
                        count[name]+=1
                        wal_owners[phase_at_write][name]+=1
                        versions[pg,hashlib.sha256(body).digest()].add(name)
                    commits.append({'phase':phase,'epoch':epoch,'frames':sum(count.values()),
                                    'by_owner':dict(count),'events':new_events,'semantic_phase':kind,'committed_row_changes':mutations})
                    frames.clear()
                    last_known_owner=pages
                else:
                    raise AssertionError((role,length,offset))
            assert not frames and header is None
            end=layout(shadow,immutable=True)
    assert end is not None and end['tables']==expected['tables'], 'page replay and live logical endpoints diverged'
    assert last_known_owner=={pg:(name,typ) for name,_,pg,typ,*_ in expected['dbstat']}
    return {'totals':{phase:[[*key,n] for key,n in sorted(count.items())] for phase,count in totals.items()},
            'wal_owners':{phase:dict(count) for phase,count in wal_owners.items()},
            'main_owners':{phase:dict(count) for phase,count in main_owners.items()},
            'unique_wal_pages':{phase:len(pages) for phase,pages in unique.items()},
            'commits':commits,'checked_wal_frame_checksums':True,'shadow_matches_live_final_layout':True}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('products',nargs='+',type=Path)
    a=p.parse_args()
    for path in a.products:
        report=replay(path)
        dump(path/'write-replay.json',report)
        hot=[c for c in report['commits'] if c['phase']=='before_measured_turns']
        print(path,len(hot),sum(c['frames'] for c in hot),Counter(c['semantic_phase'] for c in hot),flush=True)
