import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');os.sched_setaffinity(0,[2,8]);rows=[]
for pair in range(2):
 for mode in (['no-live-subscriber','live-subscriber'] if pair==0 else ['live-subscriber','no-live-subscriber']):
  name=f'counts-{pair}-{mode}';cmd=[sys.executable,'benchmarks/runtime/profiling/run.py','--binary',str(r/'diagnostic-build/conformance'),'--profiler-root',str(r/'diagnostic-profiler'),'--output',str(r/name),'--mode','cpu','--case','short-large','--observer-mode',mode];row={'command':cmd,'name':name,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1','RUSTX_SOURCE_PROFILE':'1'})
  row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'counter-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,done.returncode,flush=True);assert done.returncode==0
