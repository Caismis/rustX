import json,subprocess,struct,re
from pathlib import Path
r=Path(__file__).resolve().parent;rows=json.loads((r/'profile-commands.json').read_text());pprof='/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof'
for row in rows:
 if not row['name'].endswith('-cpu'):continue
 root=r/row['name'];m=json.loads((root/'manifest.json').read_text());binary=m['argv'][-5]
 for name,flags in [('steady-flat.txt',['--text']),('steady-cumulative.txt',['--text','--cum']),('steady-stacks.txt',['--collapsed'])]:
  cmd=[pprof,*flags,'--no_strip_temp','--nodecount=500',binary,str(root/'before_measured_turns.cpu')]
  with (root/name).open('x') as so,(root/(name+'.stderr')).open('x') as se:subprocess.run(cmd,check=True,stdout=so,stderr=se)
 print(row['name'],flush=True)
