"""Reparse diagnostic boundary records, retaining nested wall times as such."""
import collections,json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;rows=[]
for prefix in ['counts','candidate-counts']:
 for pair in range(2):
  for mode in ['no-live-subscriber','live-subscriber']:
   name=f'{prefix}-{pair}-{mode}';d=r/name;records=[];phase=None;boundaries=[]
   for line in (d/'sample.log').read_text().splitlines():
    if line.startswith('HOTPATH_BOUNDARY '):phase=line.split()[1];boundaries.append(phase)
    if not line.startswith('{'):continue
    try:record=json.loads(line)
    except json.JSONDecodeError:continue
    if phase=='before_measured_turns' and record.get('kind') in ['hotpath_profile','source_profile']:records.append(record)
   assert boundaries.count('before_measured_turns')==boundaries.count('after_turns')==1
   stat=[v for v in records if v['kind']=='hotpath_profile'];source=[v for v in records if v['kind']=='source_profile'];fold=[v for v in stat if v['phase']=='statistics_fold'];history=[v for v in stat if v['phase']=='statistics_history']
   assert len(source)==32 and len(fold)==192
   names=set(v['phase'] for v in stat)
   rows.append({'name':name,'phase_counts':dict(collections.Counter(v['phase'] for v in stat)),
    'inclusive_wall_ms':{n:sum(v['elapsed_ns'] for v in stat if v['phase']==n)/1e6 for n in sorted(names)},
    'fold_hits':sum(v['hit'] for v in fold),'fold_misses':sum(not v['hit'] for v in fold),
    'history_distances':dict(sorted(collections.Counter(v['distance'] for v in history).items())),
    'source_medians':{k:statistics.median(v[k] for v in source) for k in source[0] if k.endswith('_us') or k in ['source_node_loads','lookup_calls']},
    'stable_encodes':sum(v['scalar_encodes'] for v in source) if 'scalar_encodes' in source[0] else None,
    'source_completed':sum(v['layout_completed'] for v in source),'measured_records':records})
(r/'final-counter-analysis.json').write_text(json.dumps({'scope':'Diagnostic fixed counters and nested intrusive wall timings, not CPU percentages or formal latency. Old predicates count invocations, not true invalidations. Baseline scalar-encode counter was not present; kept unavailable.','rows':rows},indent=2)+'\n')
print(json.dumps({'accepted':True,'products':len(rows)}))
