"""Render audited values without substituting ratios of medians for paired ratios."""
import json
from pathlib import Path
r=Path(__file__).resolve().parent;a=json.loads((r/'final-audit.json').read_text());s=json.loads((r/'support-audit.json').read_text())
out=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/2026-11-03-request-hotpath-tables.md')
fmt=lambda v:'unavailable' if v is None else f'{v:.6f}'
seq=lambda vs:', '.join(fmt(v) for v in vs)
lines=['# Request hot-path full values','','Raw recomputation: `final-audit.json` and `support-audit.json` in the evidence archive. Four descriptive pairs per formal cell; all reversals retained. No confidence interval or parity claim. A product value for warm wall is the median of its 32 warm turns; the displayed absolute value is the median of four product values. Changes/ratios are calculated pair by pair first.','','## Final ordinary triads','']
metrics=[('median_measured_turn_ms','Warm median wall, ms'),('mean_turn_ms','Warm mean wall, ms'),('turn_cpu_ms_per_turn','Warm CPU/turn, ms'),('turn_write_bytes_per_turn','Warm process writes/turn, bytes'),('lifecycle_self_cpu_ms','Lifecycle CPU, ms'),('through_cleanup_process_write_mib','Through-cleanup process writes, MiB'),('lifecycle_ms','Lifecycle wall, ms'),('max_sampled_anon_pss_mib','Maximum sampled anonymous PSS, MiB'),('max_sampled_turn_rss_mib','Warm maximum sampled RSS, MiB'),('closed_logical_bytes','Post-writer-close recorded file bytes')]
for c in a['cells']:
 lines += [f"### {c['mode']} / {c['case']}",'','| Metric | Before | Candidate | Pi | Paired change %, pairs 0–3 | Median change % | Candidate/Pi, pairs 0–3 | Median ratio |','|---|---:|---:|---:|---|---:|---|---:|']
 for k,label in metrics:
  ab=c['absolute'];ch=c['direct_change_percent'][k];pi=c['candidate_pi_ratio'][k]
  lines += [f"| {label} | {fmt(ab['before'][k]['median'])} | {fmt(ab['after'][k]['median'])} | {fmt(ab['pi'][k]['median'])} | {seq(ch['values'])} | {fmt(ch['median'])} | {seq(pi['values'])} | {fmt(pi['median'])} |"]
 lines += ['']
lines += ['The post-writer-close footprint sums each engine\'s recorded files. Rust still records WAL/SHM and small session/configuration files at this endpoint, whereas Pi records its database/workspace. It is not a comparison of compacted main-database sizes or proof that all SQLite handles have closed. Complete file lists remain in the raw products.','','## Earlier same-turn cohorts, separately','','These are not pooled with final results. `current-pi` is the fresh predevelopment c9/Pi baseline; `regression-repeat` compares the two older Statistics binaries. Ratios are rust/Pi for the former and c9/pre-Statistics for the latter.','','| Cohort | Mode | Case | Metric | All four paired ratios | Median |','|---|---|---|---|---|---:|']
for c in s['separate_cells']:
 for k,label in metrics[:6]:
  v=c['paired'][k];lines += [f"| {c['cohort']} | {c['mode']} | {c['case']} | {label} | {seq(v['values'])} | {fmt(v['median'])} |"]
lines += ['','## Synchronized storage diagnostics','','One diagnostic product per revision/scenario per diagnostic kind. Logical columns are not WAL or physical device bytes. WAL ownership uses endpoint dbstat snapshots; transient page reuse is not excluded. Five warm write commits/turn remain.','','| Case | Revision | Logical column bytes / 32 turns | Statistical facts | Full statistical checkpoints | Statistical bytes | WAL frames | WAL frame bytes | Write commits |','|---|---|---:|---:|---:|---:|---:|---:|---:|']
for v in s['storage']:
 t=v['statistics'];w=v['wal'];lines += [f"| {v['case']} | {v['engine']} | {v['logical_bytes']} | {t['facts']} | {t['full_states']} | {t['fact_bytes']+t['full_state_bytes']} | {w['wal_frames']} | {w['wal_frame_bytes']} | {w['wal_write_commits']} |"]
lines += ['','The complete logical-byte-by-table and WAL page-owner breakdowns are in `support-audit.json`; selected largest WAL owners follow.','','| Case | Revision | WAL owners and frames (largest 12) |','|---|---|---|']
for v in s['storage']:
 entries=list(v['wal']['wal_frames_by_snapshot_page_owner'].items())[:12];lines += [f"| {v['case']} | {v['engine']} | "+'; '.join(f'`{k}` {n}' for k,n in entries)+' |']
if (r/'final-counter-analysis.json').exists():
 c=json.loads((r/'final-counter-analysis.json').read_text());lines += ['','## Intrusive diagnostic counters','','No timing here is a formal product latency or a CPU percentage. Timers are nested and must not be added. Two independently executed products per mode/revision. A missing old scalar-encode counter stays unavailable.','','| Product | Fold hits | Fold misses | History distance: count | Actual read-domain calls | Source median µs | Scalar median µs | Nodes loaded/request median | Warm stable encodes |','|---|---:|---:|---|---:|---:|---:|---:|---:|']
 for v in c['rows']:
  m=v['source_medians'];lines += [f"| {v['name']} | {v['fold_hits']} | {v['fold_misses']} | {v['history_distances']} | {v['phase_counts'].get('read_domain',0)} | {fmt(m['source_us'])} | {fmt(m['scalar_us'])} | {fmt(m['source_node_loads'])} | {v['stable_encodes'] if v['stable_encodes'] is not None else 'unavailable'} |"]
profiles=json.loads((r/'cpu-partitions.json').read_text())
lines += ['','## Existing ordinary diagnostic CPU profiles','','Each warm stack is assigned once within the operation partition. Cumulative areas overlap that partition and each other. Samples are diagnostic 250 Hz signals, not elapsed phase measurements. Inherited owner rules group some `runtime_client::trace` producer work under `other_publication`; do not equate that label with publication-only cost. The Source cumulative stack predicate is more direct.','','| Profile | Total samples | SQL execute | SQL prepare | Structural encoding | Source navigation | Other | Request Source cumulative samples |','|---|---:|---:|---:|---:|---:|---:|---:|']
for v in profiles['profiles']:
 o=v['operations'];assert sum(o.values())==v['samples'];lines += [f"| {v['name']} | {v['samples']} | {o.get('sql_execute',0)} | {o.get('sql_prepare',0)} | {o.get('structural_encoding',0)} | {o.get('source_navigation',0)} | {o.get('other',0)} | {v['overlapping_cumulative_areas'].get('request_source',0)} |"]
lines += ['','## Retained exclusions and checks','','`triads-overlap-excluded`: all 48 trial products excluded from formal performance, not cherry-picked. `extra-products`: 16 correctness-only Rust products, including the overlap; 10 checked before/after requests. `pi-smoke`: one setup product. Exact build/check/command failures remain in the archive. Source/build identities and all 970 input hashes accompany the final 2,378-test, Fmt and Clippy results. The 48 Python harness tests and 24 Node oracle tests pass.','']
out.write_text('\n'.join(lines))
