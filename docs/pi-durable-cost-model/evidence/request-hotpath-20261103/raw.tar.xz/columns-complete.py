"""Synchronous read-only columns diagnostics; ordinary Rust binaries only."""
import sys, os, json, threading, socket, sqlite3, subprocess, time, hashlib, tempfile, argparse, traceback
from pathlib import Path
from fixture_binding import CPU_AFFINITY, affinity_snapshot, validate_affinity
repo = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
out = Path(__file__).resolve().parent
sys.path.insert(0, str(repo/'benchmarks/runtime'))
from controller import run, TEST

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
def snapshot(paths, directory, phase):
    snapshots=[]
    for path in sorted(paths):
     c=sqlite3.connect(f'file:{path}?mode=ro',uri=True);tables=c.execute("SELECT name FROM sqlite_schema WHERE type='table'").fetchall()
     if not any(name=='events' for (name,) in tables):c.close();continue
     quote=lambda name:'"'+name.replace('"','""')+'"'
     allcols={}
     for (name,) in tables:
      info=c.execute('PRAGMA table_info('+quote(name)+')').fetchall();cols=[row[1] for row in info]
      exprs=[f'coalesce(sum(length(cast({quote(col)} as blob))),0)' for col in cols]
      row=c.execute('SELECT count(*),'+','.join(exprs)+' FROM '+quote(name)).fetchone()
      allcols[name]={'rows':row[0],'column_value_bytes':dict(zip(cols,row[1:]))}
     cols=[row[1] for row in c.execute('PRAGMA table_info(events)')]
     exprs=[f'coalesce(sum(length(cast({quote(col)} as blob))),0)' for col in cols]
     kinds=[{'kind':row[0],'rows':row[1],'column_value_bytes':dict(zip(cols,row[2:]))} for row in c.execute("SELECT json_extract(event_json,'$.event.type'),count(*),"+','.join(exprs)+" FROM events GROUP BY json_extract(event_json,'$.event.type')")]
     if 'observation_json' in cols:
      duplicate=c.execute('SELECT count(*),coalesce(sum(length(event_json)),0) FROM events WHERE observation_json IS NOT NULL AND cast(observation_json as text)=event_json').fetchone()
      duplicate_record={'status':'measured','rows':duplicate[0],'native_bytes':duplicate[1]}
     else:
      duplicate_record={'status':'retired_layout_absent','table':'events','column':'observation_json','rows':None,'native_bytes':None}
     inline_present='bytes' in allcols['content_frontiers']['column_value_bytes']
     if inline_present:
      inline_rows,inline_bytes=c.execute('SELECT count(bytes),coalesce(sum(length(bytes)),0) FROM content_frontiers').fetchone()
      inline={'status':'measured','rows':inline_rows,'value_bytes':inline_bytes}
     else:
      inline={'status':'layout_absent','rows':None,'value_bytes':None}
     first_rows=c.execute('SELECT count(*) FROM content_segments WHERE segment=0').fetchone()[0]
     content_layout={'frontier_inline':inline,'segment_first_rows':first_rows}
     source_column='observation_source' if 'observation_source' in cols else 'observation_source_overlay'
     source_records=[{'tag':tag,'rows':rows,'bytes':n} for tag,rows,n in c.execute('SELECT hex(substr('+quote(source_column)+',1,1)),count(*),sum(length('+quote(source_column)+')) FROM events WHERE '+quote(source_column)+' IS NOT NULL GROUP BY 1')]
     stat_rows,stat_bytes=c.execute('SELECT count(observation_statistics),coalesce(sum(length(observation_statistics)),0) FROM events').fetchone()
     if 'observation_statistics_checkpoint' in cols:
      full_rows,full_bytes=c.execute('SELECT count(observation_statistics_checkpoint),coalesce(sum(length(observation_statistics_checkpoint)),0) FROM events').fetchone();statistics_layout={'kind':'contributions_and_checkpoints','facts':stat_rows,'fact_bytes':stat_bytes,'full_states':full_rows,'full_state_bytes':full_bytes}
     else:
      statistics_layout={'kind':'full_per_event','facts':0,'fact_bytes':0,'full_states':stat_rows,'full_state_bytes':stat_bytes}
     snapshots.append({'statistics_layout':statistics_layout,'event_source_records':source_records,'content_layout':content_layout,'scope':'main_database_only; connection-local TEMP owner state and virtual generated columns are outside this read-only connection measurement', 'path':path,'tables':allcols,'events_by_kind':kinds,'equal_event_observation_json':duplicate_record,'dbstat':c.execute('SELECT name,sum(pgsize),sum(payload),count(*) FROM dbstat GROUP BY name').fetchall()});c.close()
    assert len(snapshots)==1
    (directory/(phase+'.json')).write_text(json.dumps(snapshots[0],indent=2))

parser = argparse.ArgumentParser()
parser.add_argument('--binary', type=Path, required=True)
parser.add_argument('--label', choices=['baseline','complete'], required=True)
args = parser.parse_args()
binary = args.binary.resolve(); label = args.label
build = json.loads((binary.parent/'identity.json').read_text())
assert build['verified'] and sha(binary) == build['sha256']
os.sched_setaffinity(0, CPU_AFFINITY)
validate_affinity(affinity_snapshot())
records_path = out/f'columns-records-{label}.json'
assert not records_path.exists(), 'retain previous attempt; do not overwrite evidence'
original = subprocess.Popen
records = []
for case in ('short-small','short-large'):
    directory = out/f'columns-{label}-{case}'
    directory.mkdir(exist_ok=False)
    sock = Path(tempfile.mkdtemp(prefix='rxcolumns-'))/'control.sock'
    server = socket.socket(socket.AF_UNIX); server.bind(str(sock)); server.listen(1); server.settimeout(0.25)
    ready = threading.Event(); stopped = threading.Event(); state = {}; phases = []; failures = []
    def serve():
        conn = None
        try:
            while not ready.wait(0.25):
                if stopped.is_set():
                    return
            while not stopped.is_set():
                try:
                    conn, _ = server.accept()
                except socket.timeout:
                    continue
                conn.settimeout(30)
                line = b''
                while not line.endswith(b'\n'):
                    chunk = conn.recv(128)
                    if not chunk:
                        raise RuntimeError('EOF before phase newline')
                    line += chunk
                phase = line.decode().strip()
                phases.append({'phase': phase, 'monotonic_ns': time.monotonic_ns()})
                if phase in ('before_measured_turns','after_turns'):
                    pid = state['pid']
                    paths = set()
                    for fd in Path(f'/proc/{pid}/fd').iterdir():
                        try:
                            path = os.readlink(fd)
                        except OSError:
                            continue
                        if path.endswith(('.sqlite','.db')) and Path(path).exists():
                            paths.add(path)
                    snapshot(paths, directory, phase)
                conn.sendall(b'K'); conn.close(); conn = None
                if phase == 'after_cleanup':
                    return
        except BaseException:
            failures.append(traceback.format_exc())
        finally:
            if conn is not None:
                conn.close()
    argv = [str(binary), TEST, '--exact','--ignored','--nocapture']
    exec_argv = argv
    def start(command, *a, **kw):
        if command == argv:
            product = original(exec_argv, *a, **kw)
            state['pid'] = product.pid; ready.set()
            return product
        return original(command, *a, **kw)
    before = {'build': build, 'binary_sha256': sha(binary), 'runner_sha256': sha(__file__), 'argv': argv, 'executed_argv': exec_argv, 'affinity': affinity_snapshot(), 'scope': 'Read-only synchronized SQL column logical-byte diagnostics, not WAL/device bytes or timing results. Exact recorded ordinary O3 binary; main database only, TEMP state unavailable from this connection. Controller calling-thread pinned; descendants inherit CPU 2,8; no independent child-thread sampling.'}
    validate_affinity(before['affinity']); write(directory/'identity-before.json', before)
    thread = threading.Thread(target=serve, daemon=True); thread.start()
    env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
    env.update(UV_OFFLINE='1', RUSTX_BENCH_CASE=case, RUSTX_BENCH_OBSERVER_MODE='no-live-subscriber', RUSTX_BENCH_OUTPUT=str(directory/'sample.json'), RUSTX_BENCH_PROFILE_SOCKET=str(sock))
    result = {'accepted': False, 'error': 'controller did not return'}
    start_ns = time.monotonic_ns()
    subprocess.Popen = start
    try:
        result = run(argv, directory/'sample', case, env, repo/'test-support/fake-provider')
    except BaseException:
        result['error'] = traceback.format_exc()
        write(directory/'runner-error.json', result)
        raise
    finally:
        subprocess.Popen = original
        stopped.set(); ready.set(); thread.join(5); server.close()
        if thread.is_alive():
            failures.append('phase collector thread did not stop')
        sock.unlink(missing_ok=True); sock.parent.rmdir()
        write(directory/'phases.json', phases)
        after = {'binary_sha256': sha(binary), 'runner_sha256': sha(__file__), 'affinity': affinity_snapshot()}
        write(directory/'identity-after.json', after)
        records.append({'engine': 'rust', 'case': case, 'accepted': result['accepted'], 'error': result.get('error'), 'diagnostic_error': failures, 'start_ns': start_ns, 'end_ns': time.monotonic_ns()})
        write(records_path, records); print(records[-1], flush=True)
    assert not failures, failures
    assert result['accepted'], result.get('error')
    assert after['binary_sha256'] == build['sha256'] and after['runner_sha256'] == before['runner_sha256']
    validate_affinity(after['affinity'])
    assert before['affinity']['topology'] == after['affinity']['topology'] and before['affinity']['online_cpus'] == after['affinity']['online_cpus']

