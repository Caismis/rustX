"""Frozen ordinary production triads. Never select or overwrite samples."""
import datetime, hashlib, json, os, subprocess, sys
from pathlib import Path
r=Path(__file__).resolve().parent; h=r/'harness'; pi=r/'pi-1ced'
sys.path.insert(0,str(h/'benchmarks/runtime')); from controller import run, TEST
sys.path.insert(0,str(r));from fixture_binding import affinity_snapshot,validate_affinity
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
os.sched_setaffinity(0,[2,8]); os.chdir(h)
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode != 0, 'compiler overlaps measurement'
assert (r/'extra-products/completed.json').is_file(), 'functional products must have finished'
out=r/'final-triads';out.mkdir(exist_ok=False)
before=Path('/home/capi/.cache/rustx-pr485-statistics-20261103/refined/candidate-build/conformance')
after=r/'candidate-build/conformance'; binaries={'before':before,'after':after}
builds={k:json.loads((p.parent/'identity.json').read_text()) for k,p in binaries.items()}
assert all(v['verified'] and sha(binaries[k])==v['sha256'] for k,v in builds.items())
frozen=json.loads((r/'current-pi/premeasurement.json').read_text())
orders=[['pi','before','after'],['after','before','pi'],['before','after','pi'],['pi','after','before']]
pre={'utc':now(),'clock_ticks':os.sysconf('SC_CLK_TCK'),'affinity':sorted(os.sched_getaffinity(0)),
 'builds':builds,'pi_source':frozen['pi_source'],'pi_tracked':frozen['pi_tracked'],'pi_derived':frozen['pi_derived'],
 'harness':frozen['harness'],'node':subprocess.check_output(['node','--version'],text=True).strip(),
 'protocol':{'cases':['short-small','short-large'],'modes':['no-live-subscriber','live-subscriber'],'pairs':4,'orders':orders,'products':48,'scope':'Descriptive balanced triads; request window and full lifecycle separate; no headline diagnostic timings, no Pi durability/feature equivalence claim.'}}
pre['topology']=affinity_snapshot();validate_affinity(pre['topology'])
provider=h/'test-support/fake-provider'
provider_names=subprocess.check_output(['git','ls-files','--','test-support/fake-provider'],cwd=provider.resolve().parents[1],text=True).splitlines()
provider_repo=provider.resolve().parents[1]
pre['provider']={n:sha(provider_repo/n) for n in provider_names if (provider_repo/n).is_file()}
def check():
 assert all(sha(h/n)==v for n,v in pre['harness'].items())
 assert all(sha(pi/n)==v for key in ['pi_tracked','pi_derived'] for n,v in pre[key].items())
 assert all(sha(p)==builds[k]['sha256'] for k,p in binaries.items())
 assert all(sha(provider_repo/n)==v for n,v in pre['provider'].items())
check();write(out/'premeasurement.json',pre);records=[]
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
for mode in pre['protocol']['modes']:
 directory=out/mode;directory.mkdir()
 write(directory/'manifest.json',{'observer_mode':mode,'clock_ticks':pre['clock_ticks'],'pi':str(pi),'rust':str(after),'rust_sha256':builds['after']['sha256'],'executables':{k:{'path':str(p),'sha256':builds[k]['sha256']} for k,p in binaries.items()},'pairs':4,'cases':pre['protocol']['cases']})
 for pair,order in enumerate(orders):
  for case in pre['protocol']['cases']:
   for engine in order:
    stem=directory/f'{pair}-{case}-{engine}';output=stem.with_suffix('.json')
    argv=[str(binaries[engine]),TEST,'--exact','--ignored','--nocapture'] if engine!='pi' else ['node','--conditions=source','benchmarks/runtime/pi-http.mjs',str(pi),case,str(output)]
    at=now();res=run(argv,stem,case,env|{'UV_OFFLINE':'1','RUSTX_BENCH_CASE':case,'RUSTX_BENCH_OBSERVER_MODE':mode,'RUSTX_BENCH_OUTPUT':str(output)},h/'test-support/fake-provider')
    row={'mode':mode,'pair':pair,'case':case,'engine':engine,'start_utc':at,'end_utc':now(),'accepted':res['accepted']};records.append(row);write(out/'commands.json',records);print(row,flush=True);assert res['accepted'],res.get('error')
   for label,engines in [('direct',['before','after']),('pi',['after','pi'])]:
    cmd=['node','benchmarks/runtime/compare-http.mjs',*[str(directory/f'{pair}-{case}-{e}.json') for e in engines],str(directory/f'{pair}-{case}-{label}-comparison.json')]
    done=subprocess.run(cmd,capture_output=True,text=True)
    (directory/f'{pair}-{case}-{label}-comparison.stderr').write_text(done.stderr)
    assert done.returncode==0,done.stderr
check();post=affinity_snapshot();validate_affinity(post);assert post['topology']==pre['topology']['topology'];write(out/'completed.json',{'accepted':True,'unchanged_inputs':True,'topology':post,'products':len(records),'direct_matched_requests':1088,'pi_matched_requests':1088,'end_utc':now()})
