import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');sys.path.insert(0,str(r));from fixture_binding import affinity_snapshot,validate_affinity
os.sched_setaffinity(0,[2,8]);before=affinity_snapshot();validate_affinity(before);rows=[]
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
(r/'candidate-counter-premeasurement.json').write_text(json.dumps({'affinity':before,'build':json.loads((r/'diagnostic-candidate-build/identity.json').read_text()),'scope':'Four replacements after the first diagnostic trial had an unpinned first child. No ordinary performance product rerun.'},indent=2)+'\n')
for pair in range(2):
 for mode in (['no-live-subscriber','live-subscriber'] if pair==0 else ['live-subscriber','no-live-subscriber']):
  name=f'candidate-counts-{pair}-{mode}';cmd=[sys.executable,'benchmarks/runtime/profiling/run.py','--binary',str(r/'diagnostic-candidate-build/conformance'),'--profiler-root',str(r/'diagnostic-profiler'),'--output',str(r/name),'--mode','cpu','--case','short-large','--observer-mode',mode]
  row={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'affinity':sorted(os.sched_getaffinity(0))}
  with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,stdout=so,stderr=se,cwd=repo,env=os.environ|{'UV_OFFLINE':'1','RUSTX_SOURCE_PROFILE':'1'})
  row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'candidate-counter-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,done.returncode,flush=True);assert done.returncode==0
after=affinity_snapshot();validate_affinity(after);assert before['topology']==after['topology'];(r/'candidate-counter-completed.json').write_text(json.dumps({'accepted':True,'affinity':after},indent=2)+'\n')
