"""Read-only raw recomputation; producer summaries never supply reported metrics."""
import argparse,collections,datetime,hashlib,importlib.util,json,math,re,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);p.add_argument('--raw-only',action='store_true');p.add_argument('--output',type=Path);args=p.parse_args();r=args.root.resolve();sys.path.insert(0,str(r))
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mod(name,file):
 spec=importlib.util.spec_from_file_location(name,r/file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
maths=mod('maths','recompute-pi.py');direct=mod('direct','direct-audit.py');direct.MATH=maths;maths.PI_REVISION='1cedd32724abfcb0915f76cc61b6827e2c16dbad'
require=maths.require
def desc(v):return direct.descriptive(v)
def ratio(a,b):return maths.paired_ratio(a,b)[0]
def change(a,b):
 v=ratio(a,b);return None if v is None else 100*(v-1)
products=[];comparisons=[];cells=[]
pre=load(r/'final-triads/premeasurement.json');require(pre['protocol']['products']==48,'protocol size')
check_before=load(r/'checks-final/source-before.json')['files'];check_after=load(r/'checks-final/source-after.json')['files']
require(check_before==check_after==pre['builds']['after']['source_files'],'final checks/build source mismatch')
checks=load(r/'checks-final/check-build-commands.json');require(len(checks)==16 and all(v['status']=='complete' and v['exit']==0 for v in checks),'final check failure')
statuses={}
for row in checks:
 for name,status in re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:, [^\n]*)?$',(r/'checks-final'/(row['label']+'.stdout')).read_text(),re.M):
  require(name not in statuses,'test counted more than once');statuses[name]=status
require(collections.Counter(statuses.values())=={'ok':2378,'ignored':1},'test coverage mismatch')
for k,b in pre['builds'].items():
 require(b['verified'] and b['commands'][-1]['exit']==0,'build failure')
 if not args.raw_only:require(sha(Path(b['binary']))==b['sha256'],'binary identity')
 require(b['sha256']==load(Path(b['binary']).parent/'identity.json')['sha256'] if not args.raw_only else True,'build manifest differs')
commands=load(r/'final-triads/commands.json');require(len(commands)==48,'all scheduled products retained')
expected=[]
for mode in pre['protocol']['modes']:
 for pair,order in enumerate(pre['protocol']['orders']):
  for case in pre['protocol']['cases']:
   expected += [(mode,pair,case,e) for e in order]
require([(v['mode'],v['pair'],v['case'],v['engine']) for v in commands]==expected,'execution order differs')
require(all(v['accepted'] for v in commands),'unaccepted scheduled product')
for left,right in zip(commands,commands[1:]):require(left['end_utc']<=right['start_utc'],'overlapping products')
for mode in pre['protocol']['modes']:
 d=r/'final-triads'/mode;manifest=load(d/'manifest.json')
 require(len(list(d.glob('*.process.json')))==24,'unexpected/missing product record')
 for case in pre['protocol']['cases']:
  grouped={e:[] for e in ['before','after','pi']}
  for pair in range(4):
   for e in grouped:
    f=d/f'{pair}-{case}-{e}.json';raw=load(f);proc=load(f.with_suffix('.process.json'))
    if e!='pi':require(raw['schema']==(90 if e=='before' else 91),'private schema identity')
    value=direct.derived_product(raw,proc,case,mode,e,manifest);grouped[e].append(value['metrics'])
    products.append({'file':str(f.relative_to(r)),'sha256':sha(f),'process_sha256':sha(f.with_suffix('.process.json')),'mode':mode,'case':case,'pair':pair,'engine':e,**value})
   for kind,is_direct in [('direct',True),('pi',False)]:
    f=d/f'{pair}-{case}-{kind}-comparison.json';n=direct.comparison(f,case,mode,is_direct);comparisons.append({'file':str(f.relative_to(r)),'sha256':sha(f),'kind':kind,'requests':n})
  metrics=list(grouped['after'][0]);cells.append({'mode':mode,'case':case,'absolute':{e:{k:desc([v[k] for v in rows]) for k in metrics} for e,rows in grouped.items()},'direct_change_percent':{k:desc([change(a[k],b[k]) for a,b in zip(grouped['after'],grouped['before'])]) for k in metrics},'candidate_pi_ratio':{k:desc([ratio(a[k],b[k]) for a,b in zip(grouped['after'],grouped['pi'])]) for k in metrics}})
require(len(products)==48 and sum(c['requests'] for c in comparisons if c['kind']=='direct')==1088 and sum(c['requests'] for c in comparisons if c['kind']=='pi')==1088,'coverage totals')
report={'accepted':True,'mode':'raw-only' if args.raw_only else 'actual-binary-and-raw','script_sha256':sha(Path(__file__)),'helpers':{n:sha(r/n) for n in ['direct-audit.py','recompute-pi.py','fixture_binding.py']},'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'premeasurement_sha256':sha(r/'final-triads/premeasurement.json'),'products':products,'comparisons':comparisons,'cells':cells,'scope':'Four descriptive pairs per cell, no confidence/parity inference; raw-only never follows recorded external paths; Pi source pin overridden explicitly, arithmetic unchanged.'}
output=args.output or r/'final-audit.json';output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'accepted':True,'products':48,'direct_requests':1088,'pi_requests':1088}))
