//! Diagnostic-only fixed scalar records, never enabled in ordinary builds.
use std::time::Instant;
pub(crate) struct Timer { phase: &'static str, sequence: u64, distance: u8, hit: bool, at: Instant, cpu: Option<u64> }
fn ticks() -> Option<u64> { let raw=std::fs::read_to_string("/proc/self/stat").ok()?; let fields:Vec<_>=raw.rsplit_once(") ")?.1.split_whitespace().collect(); Some(fields.get(11)?.parse::<u64>().ok()?+fields.get(12)?.parse::<u64>().ok()?) }
impl Timer {
 pub(crate) fn new(phase:&'static str,sequence:u64)->Self { Self{phase,sequence,distance:255,hit:false,at:Instant::now(),cpu:None} }
 pub(crate) fn cpu(phase:&'static str,sequence:u64)->Self { let mut timer=Self::new(phase,sequence);timer.cpu=ticks();timer }
 pub(crate) fn distance(&mut self,distance:u8){self.distance=distance;}
 pub(crate) fn hit(&mut self,hit:bool){self.hit=hit;}
}
impl Drop for Timer {fn drop(&mut self){let cpu=self.cpu.and_then(|start|ticks().map(|end|end.saturating_sub(start)));eprintln!("{}",serde_json::json!({"kind":"hotpath_profile","phase":self.phase,"sequence":self.sequence,"distance":self.distance,"hit":self.hit,"elapsed_ns":self.at.elapsed().as_nanos(),"process_cpu_ticks":cpu}));}}
