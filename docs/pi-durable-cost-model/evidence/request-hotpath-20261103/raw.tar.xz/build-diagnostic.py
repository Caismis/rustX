import datetime,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;label=sys.argv[1];repo=Path(sys.argv[2]);out=root/(label+'-build');out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
def snapshot():
 return {str(p.relative_to(repo)):sha(p) for f in ('src','tests') for p in sorted((repo/f).rglob('*')) if p.is_file()}|{p:sha(repo/p) for p in ('Cargo.toml','Cargo.lock')}
source=snapshot();identity={'head':git('rev-parse','HEAD'),'diagnostic':True,'production_tree':git('rev-parse','HEAD:src'),'source_files':source,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':[]}
env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2'}
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS') and not any(k.startswith('CARGO_PROFILE_') for k in env)
for name,cmd in [('clean',['cargo','clean','--release','--package','rustx']),('build',['cargo','test','--release','--locked','--test','conformance','--no-run','--features','issue-387-profile','--message-format=json'])]:
 with (out/(name+'.stdout')).open('x') as so,(out/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,env=env,stdout=so,stderr=se)
 identity['commands'].append({'command':cmd,'exit':done.returncode});(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(label,name,done.returncode,flush=True)
 if done.returncode:raise SystemExit(done.returncode)
rows=[json.loads(l) for l in (out/'build.stdout').read_text().splitlines() if l.startswith('{')]
artifacts=[v for v in rows if v.get('reason')=='compiler-artifact' and v['target']['src_path'].startswith(str(repo))]
assert artifacts and all(v['profile']['opt_level']=='3' and v['features']==['issue-387-profile'] and not v['fresh'] for v in artifacts)
exe=next(Path(v['executable']) for v in artifacts if v['target']['name']=='conformance' and v.get('executable'));shutil.copy2(exe,out/'conformance')
lib=next(Path(f) for v in artifacts if v['target']['name']=='rustx' and v['target']['kind']==['lib'] for f in v['filenames'] if f.endswith('.rlib'));shutil.copy2(lib,out/'librustx.rlib')
assert source==snapshot()
identity.update(binary=str(out/'conformance'),sha256=sha(out/'conformance'),verified=True,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'identity.json').write_text(json.dumps(identity,indent=2)+'\n');print(label,'binary',identity['sha256'],flush=True)
