"""Sequential diagnostics after ordinary products; no measurement/compiler overlap."""
import datetime,json,subprocess,sys,os
from pathlib import Path
r=Path(__file__).resolve().parent
os.sched_setaffinity(0,[2,8])
assert (r/'final-triads/completed.json').exists()
assert (r/'extra-products/completed.json').exists()
rows=[]
def run(label,cmd,env=None,cwd=None):
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(label+'.stdout')).open('x') as so,(r/(label+'.stderr')).open('x') as se:done=subprocess.run(cmd,stdout=so,stderr=se,env=env,cwd=cwd)
 row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'after-formal-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,done.returncode,flush=True);assert done.returncode==0
run('storage-products',[sys.executable,str(r/'storage-products.py')])
run('build-diagnostic-candidate',[sys.executable,str(r/'build-diagnostic.py'),'diagnostic-candidate',str(r/'diagnostic-candidate')])
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
for pair in range(2):
 for mode in (['no-live-subscriber','live-subscriber'] if pair==0 else ['live-subscriber','no-live-subscriber']):
  name=f'candidate-counts-{pair}-{mode}'
  cmd=[sys.executable,'benchmarks/runtime/profiling/run.py','--binary',str(r/'diagnostic-candidate-build/conformance'),'--profiler-root',str(r/'diagnostic-profiler'),'--output',str(r/name),'--mode','cpu','--case','short-large','--observer-mode',mode]
  run(name,cmd,os.environ|{'UV_OFFLINE':'1','RUSTX_SOURCE_PROFILE':'1'},repo)
(r/'after-formal-completed.json').write_text(json.dumps({'accepted':True,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
