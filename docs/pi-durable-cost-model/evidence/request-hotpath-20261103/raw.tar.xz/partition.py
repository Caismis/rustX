from pathlib import Path
from collections import Counter
import json,re,struct
r=Path(__file__).resolve().parent;records=[]
for row in json.loads((r/'profile-commands.json').read_text()):
 if not row['name'].endswith('-cpu'):continue
 p=r/row['name'];owners=Counter();operations=Counter();areas=Counter();total=0
 for line in (p/'steady-stacks.txt').read_text().splitlines():
  stack,n=line.rsplit(' ',1);n=int(n);total+=n
  if 'runtime_benchmark::process_sample' in stack or 'runtime_benchmark::footprint' in stack:owner='benchmark_counter_and_footprint'
  elif '<conformance::agent_loop::Driver>::start_in::{closure#0}::{closure#0}' in stack:owner='publication_relay'
  elif 'ReadDomainCut>::read' in stack:owner='read_domain'
  elif 'PublicationDraft>::encode' in stack:owner='publication_encoding'
  elif any(x in stack for x in ['runtime_client::host::','runtime_client::projection::','runtime_client::trace::']):owner='other_publication'
  elif any(x in stack for x in ['rustx::agent::execution::','rustx::runtime::conversation_runtime::','rustx::durable::','rustx::runtime::read_layout::']):owner='engine'
  elif 'conformance::agent_loop::' in stack:owner='other_driver'
  else:owner='unassigned'
  owners[owner]+=n
  if 'sqlite3_prepare' in stack or 'sqlite3Prepare' in stack or 'sqlite3LockAndPrepare' in stack:op='sql_prepare'
  elif 'sqlite3_step' in stack or 'sqlite3VdbeExec' in stack:op='sql_execute'
  elif 'structural_json::' in stack:op='structural_encoding'
  elif 'read_layout::' in stack:op='source_navigation'
  else:op='other'
  operations[op]+=n
  for name,pattern in [('request_source','observation_request::composed::index_selection'),('statistics_writer','observation_statistics::prepare_cached'),('statistics_history','observation_statistics::history::layout'),('statistics_publish','observation_statistics::owner::FoldCache>::publish'),('read_domain','ReadDomainCut>::read'),('request_start','start_actual_model_request'),('request_prepare','prepare_model_turn'),('event_insert','event_insert::prepared'),('settle_turn','settle_model_turn'),('request_scalar','composed::scalar::'),('native_validation','native_request::'),('sqlite_wal','pagerWalFrames')]:
   if pattern in stack:areas[name]+=n
 data=(p/'before_measured_turns.cpu').read_bytes();header=struct.unpack_from('<5Q',data);assert header[:3]==(0,3,0);at=40;raw_count=0
 while True:
  count,depth=struct.unpack_from('<2Q',data,at);at+=16;pcs=struct.unpack_from(f'<{depth}Q',data,at);at+=8*depth
  if count==0 and pcs==(0,):break
  raw_count+=count
 assert total==raw_count==int(re.search(r'Total: (\d+) samples',(p/'steady-flat.txt').read_text())[1]);assert sum(owners.values())==sum(operations.values())==total
 records.append({'name':row['name'],'samples':total,'owners':dict(owners),'operations':dict(operations),'overlapping_cumulative_areas':dict(areas)})
result={'scope':'Adapted existing partition-stacks; each stack assigned once within owners and once within operations. Cumulative areas overlap and must not be added. 250Hz signals, small diagnostic samples, no precise attribution of a small regression. Bench counters explicit; samples are not exclusive elapsed timers.','profiles':records};(r/'cpu-partitions.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(records,indent=2))
