import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');os.sched_setaffinity(0,[2,8])
source=Path('/home/capi/.cache/rustx-pr485-statistics-20261103');binary={'before':source/'baseline-build/conformance','current':source/'refined/candidate-build/conformance'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
pre={'scope':'Diagnostic-only ordinary immutable O3 binaries with existing CPU bridge, 250Hz; two balanced pairs without subscribers, one pair with subscribers, CPU/control separately. No headline timing from sampling. No compilers or formal samples overlap.','binaries':{k:{'path':str(v),'sha256':sha(v)} for k,v in binary.items()},'scripts':{n:sha(repo/n) for n in ['benchmarks/runtime/profiling/run.py','benchmarks/runtime/profiling/bridge.c','benchmarks/runtime/controller.py']},'affinity':sorted(os.sched_getaffinity(0))};write(r/'profile-pre.json',pre)
records=[]
for mode,pairs in [('no-live-subscriber',2),('live-subscriber',1)]:
 for pair in range(pairs):
  for label in (['before','current'] if pair%2==0 else ['current','before']):
   for kind in ['control','cpu']:
    name=f'{mode}-{pair}-{label}-{kind}';cmd=[sys.executable,'benchmarks/runtime/profiling/run.py','--binary',str(binary[label]),'--profiler-root','/home/capi/.cache/rustx-pr485-profilers','--output',str(r/name),'--mode',kind,'--case','short-large','--observer-mode',mode];row={'name':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
    row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());records.append(row);write(r/'profile-commands.json',records);print(name,done.returncode,flush=True);assert done.returncode==0
assert all(sha(v)==pre['binaries'][k]['sha256'] for k,v in binary.items())
