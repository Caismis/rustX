"""Native non-chat regression products; these do not add Pi timing samples."""
import datetime,hashlib,json,os,sys,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;h=r/'harness';sys.path.insert(0,str(h/'benchmarks/runtime'));from controller import run,TEST
os.sched_setaffinity(0,[2,8]);os.chdir(h);out=r/'extra-products';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
pre=json.loads((r/'final-triads/premeasurement.json').read_text());write(out/'premeasurement.json',pre);records=[]
for mode in pre['protocol']['modes']:
 directory=out/mode;directory.mkdir()
 for i,case in enumerate(['stream','large','tool','cancel']):
  for engine in (['before','after'] if i%2==0 else ['after','before']):
   binary=Path(pre['builds'][engine]['binary']);assert sha(binary)==pre['builds'][engine]['sha256']
   stem=directory/f'{case}-{engine}';at=datetime.datetime.now(datetime.timezone.utc).isoformat()
   env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
   value=run([str(binary),TEST,'--exact','--ignored','--nocapture'],stem,case,env|{'UV_OFFLINE':'1','RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json')),'RUSTX_BENCH_CASE':case,'RUSTX_BENCH_OBSERVER_MODE':mode},h/'test-support/fake-provider')
   row={'mode':mode,'case':case,'engine':engine,'start_utc':at,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'accepted':value['accepted']};records.append(row);write(out/'commands.json',records);print(row,flush=True);assert value['accepted'],value.get('error')
  done=subprocess.run(['node','benchmarks/runtime/compare-http.mjs',str(directory/f'{case}-before.json'),str(directory/f'{case}-after.json'),str(directory/f'{case}-comparison.json')],capture_output=True,text=True)
  (directory/f'{case}-comparison.stderr').write_text(done.stderr);assert done.returncode==0,done.stderr
assert all(sha(h/n)==v for n,v in pre['harness'].items());write(out/'completed.json',{'accepted':True,'products':len(records),'matched_requests':10})
