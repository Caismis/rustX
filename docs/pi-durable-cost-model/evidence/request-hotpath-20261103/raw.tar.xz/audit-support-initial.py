"""Audit separate baseline/reproduction/functional/storage cohorts from raw files."""
import collections,hashlib,importlib.util,json,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r));sys.path.insert(0,str(r/'harness/benchmarks/runtime'))
from controller import validate_sample
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def mod(n,f):
 spec=importlib.util.spec_from_file_location(n,r/f);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v);return v
m=mod('support_math','recompute-pi.py');d=mod('support_direct','direct-audit.py');d.MATH=m;m.PI_REVISION='1cedd32724abfcb0915f76cc61b6827e2c16dbad'
products=[];cells=[];checks=[]
def derive(directory,stem,case,mode,engine,manifest):
 f=directory/(stem+'.json');raw=load(f);proc=load(directory/(stem+'.process.json'));validate_sample(proc,raw,case,(directory/(stem+'.log')).read_text())
 value=d.derived_product(raw,proc,case,mode,engine,manifest)
 products.append({'file':str(f.relative_to(r)),'sha256':sha(f),'process_sha256':sha(directory/(stem+'.process.json')),'engine':engine,'mode':mode,'case':case,**value});return value['metrics']
for kind in ['current-pi','regression-repeat']:
 for label,mode in [('no-live','no-live-subscriber'),('live','live-subscriber')]:
  directory=r/kind/(label if kind=='current-pi' else mode)
  manifest=load(directory/'manifest.json') if kind=='current-pi' else load(r/kind/'premeasurement.json')
  for case in (['short-small','short-large'] if kind=='current-pi' else ['short-large']):
   engines=['rust','pi'] if kind=='current-pi' else ['before','after'];group={e:[] for e in engines}
   for pair in range(4):
    for e in engines:group[e].append(derive(directory,f'{pair}-{case}-{e}',case,mode,e,manifest))
    f=directory/f'{pair}-{case}-comparison.json';n=d.comparison(f,case,mode,kind!='current-pi');checks.append({'file':str(f.relative_to(r)),'requests':n})
   a,b=('rust','pi') if kind=='current-pi' else ('after','before')
   cells.append({'cohort':kind,'mode':mode,'case':case,'absolute':{e:{k:d.descriptive([v[k] for v in rows]) for k in rows[0]} for e,rows in group.items()},'paired':{k:d.descriptive([m.paired_ratio(v[k],w[k])[0] for v,w in zip(group[a],group[b])]) for k in group[a][0]}})
extra=[]
for mode in ['no-live-subscriber','live-subscriber']:
 directory=r/'extra-products'/mode
 for case in ['stream','large','tool','cancel']:
  for e in ['before','after']:
   f=directory/f'{case}-{e}.json';raw=load(f);proc=load(f.with_suffix('.process.json'));validate_sample(proc,raw,case,f.with_suffix('.log').read_text());extra.append({'file':str(f.relative_to(r)),'sha256':sha(f),'accepted':True})
  f=directory/f'{case}-comparison.json';checks.append({'file':str(f.relative_to(r)),'requests':d.comparison(f,case,mode,True)})
storage=[]
for case in ['short-small','short-large']:
 for label in ['baseline','complete']:
  directory=r/f'columns-{label}-{case}';before=load(directory/'before_measured_turns.json');after=load(directory/'after_turns.json')
  total=lambda s:sum(sum(v['column_value_bytes'].values()) for v in s['tables'].values())
  pertable={n:sum(v['column_value_bytes'].values())-sum(before['tables'].get(n,{'column_value_bytes':{}})['column_value_bytes'].values()) for n,v in after['tables'].items()}
  stat={k:after['statistics_layout'][k]-before['statistics_layout'][k] for k in ['facts','fact_bytes','full_states','full_state_bytes']}
  wal=load(r/f'wal-summary-{label}-corrected.json')[case+'-rust']
  assert wal['steady_turns']==32 and wal['wal_write_commits']==160
  for folder in [directory,r/f'wal-{label}-{case}-rust']:
   raw=load(folder/'sample.json');proc=load(folder/'sample.process.json');validate_sample(proc,raw,case,(folder/'sample.log').read_text())
  storage.append({'case':case,'engine':label,'logical_bytes':total(after)-total(before),'logical_bytes_by_table':pertable,'statistics':stat,'wal':wal})
assert len(products)==48 and len(extra)==16 and len(storage)==4
inventory=[]
for p in sorted(r.rglob('*.process.json')):
 if any(x in p.parts for x in ['node_modules','.git','diagnostic-current','diagnostic-candidate','pi-1ced']):continue
 v=load(p);assert v['accepted'] and v['product_exit']==v['provider_exit']==0
 inventory.append({'file':str(p.relative_to(r)),'sha256':sha(p),'accepted':v['accepted']})
result={'accepted':True,'script_sha256':sha(Path(__file__)),'separate_products':products,'separate_cells':cells,'extra_correctness':extra,'comparisons':checks,'storage':storage,'inventory':inventory,'scope':'Cohorts remain separate. The 48 overlap-excluded products are inventoried for retention only; no performance calculation pools them with final or earlier products.'}
(r/'support-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':True,'separate_products':48,'extra':16,'storage_products':8,'inventory':len(inventory)}))
