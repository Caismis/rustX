"""Unmodified ordinary executables, synchronized logical bytes and WAL traces."""
import datetime,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;pre=json.loads((r/'final-triads/premeasurement.json').read_text());rows=[]
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
for script in ['columns-complete.py','run-wal-rust.py']:
 for label,engine in [('baseline','before'),('complete','after')]:
  stem=script.removesuffix('.py')+'-'+label
  cmd=[sys.executable,str(r/script),'--binary',pre['builds'][engine]['binary'],'--label',label]
  row={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with (r/(stem+'.stdout')).open('x') as so,(r/(stem+'.stderr')).open('x') as se:done=subprocess.run(cmd,stdout=so,stderr=se)
  row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'storage-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(stem,done.returncode,flush=True);assert done.returncode==0
  if script=='run-wal-rust.py':subprocess.run([sys.executable,str(r/'analyze-wal.py'),'--label',label],check=True,stdout=(r/('wal-analysis-'+label+'.stdout')).open('x'))
