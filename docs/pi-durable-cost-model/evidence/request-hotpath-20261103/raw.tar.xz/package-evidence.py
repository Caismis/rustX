"""Freeze regular evidence payloads after all commands, without binaries/worktrees."""
import hashlib,io,json,tarfile
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/docs/pi-durable-cost-model/evidence/request-hotpath-20261103')
assert (r/'after-formal-completed.json').exists();assert not (out/'raw.tar.xz').exists()
assert (r/'candidate-counter-completed.json').exists()
exclude={'diagnostic-current','diagnostic-candidate','pi-1ced','__pycache__','.git','node_modules','.venv'}
members=[];entries=[]
for path in sorted(r.rglob('*')):
 relative=path.relative_to(r)
 if any(v in exclude for v in relative.parts) or path.is_symlink() or not path.is_file():continue
 if path.name in ['WORK-IN-PROGRESS.txt','conformance','librustx.rlib','bridge.so'] or path.suffix in ['.so','.rlib','.pyc']:continue
 members.append((str(relative),path))
provider=r/'harness/test-support/fake-provider'
pre=json.loads((r/'final-triads/premeasurement.json').read_text())
for name,digest in pre['provider'].items():
 path=provider.resolve().parents[1]/name;assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
 members.append(('provider-source/'+name,path))
for name,path in sorted(members):
 body=path.read_bytes();entries.append({'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
assert len(set(v['path'] for v in entries))==len(entries)
with tarfile.open(out/'raw.tar.xz','w:xz',preset=6) as archive:
 for entry,(_,path) in zip(entries,sorted(members)):
  info=tarfile.TarInfo(entry['path']);info.size=entry['bytes'];info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(path.read_bytes()))
blob=(out/'raw.tar.xz').read_bytes();manifest={'archive':{'file':'raw.tar.xz','bytes':len(blob),'sha256':hashlib.sha256(blob).hexdigest()},'members':entries,'scope':'Regular raw measurements, failed attempts, source/build identities and executable audit scripts. Worktrees, installed dependencies, ELF binaries/rlibs, sockets, symlinks and private work notes excluded.'}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'members':len(entries),**manifest['archive']}))
