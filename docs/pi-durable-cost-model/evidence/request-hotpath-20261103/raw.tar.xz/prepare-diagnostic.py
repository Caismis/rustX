from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parent;p=r/'diagnostic-current'
(p/'src/hotpath_profile.rs').write_text('''//! Diagnostic-only fixed scalar records, never enabled in ordinary builds.
use std::time::Instant;
pub(crate) struct Timer { phase: &'static str, sequence: u64, distance: u8, hit: bool, at: Instant, cpu: Option<u64> }
fn ticks() -> Option<u64> { let raw=std::fs::read_to_string("/proc/self/stat").ok()?; let fields:Vec<_>=raw.rsplit_once(") ")?.1.split_whitespace().collect(); Some(fields.get(11)?.parse::<u64>().ok()?+fields.get(12)?.parse::<u64>().ok()?) }
impl Timer {
 pub(crate) fn new(phase:&'static str,sequence:u64)->Self { Self{phase,sequence,distance:255,hit:false,at:Instant::now(),cpu:None} }
 pub(crate) fn cpu(phase:&'static str,sequence:u64)->Self { let mut timer=Self::new(phase,sequence);timer.cpu=ticks();timer }
 pub(crate) fn distance(&mut self,distance:u8){self.distance=distance;}
 pub(crate) fn hit(&mut self,hit:bool){self.hit=hit;}
}
impl Drop for Timer {fn drop(&mut self){let cpu=self.cpu.and_then(|start|ticks().map(|end|end.saturating_sub(start)));eprintln!("{}",serde_json::json!({"kind":"hotpath_profile","phase":self.phase,"sequence":self.sequence,"distance":self.distance,"hit":self.hit,"elapsed_ns":self.at.elapsed().as_nanos(),"process_cpu_ticks":cpu}));}}
''')
f=p/'src/lib.rs';f.write_text(f.read_text()+'\n#[cfg(feature = "issue-387-profile")]\nmod hotpath_profile;\n')
def edit(name,old,new):
 f=p/name;s=f.read_text();assert s.count(old)==1,(name,old,s.count(old));f.write_text(s.replace(old,new))
def timer(name,signature,phase,seq='0',cpu=False):
 edit(name,signature,signature+'\n    let _diagnostic=crate::hotpath_profile::Timer::'+('cpu' if cpu else 'new')+'("'+phase+'",'+seq+');')
timer('src/durable/sqlite/observation_statistics.rs','fn encode(state: &StatisticsLayout) -> Result<Vec<u8>, ConversationStoreError> {','statistics_encode')
timer('src/durable/sqlite/observation_statistics.rs','fn decode(bytes: &[u8]) -> Result<StatisticsLayout, ConversationStoreError> {','statistics_decode')
timer('src/durable/sqlite/observation_statistics.rs','fn normalized_fold(mut state: StatisticsLayout) -> StatisticsLayout {','statistics_normalize')
timer('src/durable/sqlite/observation_statistics/history.rs','    fn checkpoint(&self, bytes: Option<&[u8]>) -> Result<StatisticsLayout, ConversationStoreError> {','statistics_checkpoint')
edit('src/durable/sqlite/observation_statistics/history.rs','    let latest = latest(connection, through)?;','    let mut diagnostic=crate::hotpath_profile::Timer::new("statistics_history",through);\n    let latest = latest(connection, through)?;\n    if let Some((_,record,_))=&latest {diagnostic.distance(record.distance);}')
edit('src/durable/sqlite/observation_statistics/owner.rs','        let data: u64 = connection','        let mut diagnostic=crate::hotpath_profile::Timer::new("statistics_fold",through);\n        let data: u64 = connection')
edit('src/durable/sqlite/observation_statistics/owner.rs','        Ok((data, frame))','        diagnostic.hit(frame.is_some());\n        Ok((data, frame))')
edit('src/durable/sqlite/observation_statistics/owner.rs','        let Some(certificate) = pending else { return };','        let Some(certificate) = pending else { return };\n        let _diagnostic=crate::hotpath_profile::Timer::new("statistics_publish",certificate.frame.sequence);')
edit('src/runtime_client/projection.rs','        materialize_trace: bool,\n    ) -> ReadDomains {','        materialize_trace: bool,\n    ) -> ReadDomains {\n        let _diagnostic=crate::hotpath_profile::Timer::new("read_domain",self.through);')
timer('src/runtime_client/projection.rs','fn invalidates_read_domains(observation: &ConversationObservation) -> bool {','read_invalidation')
edit('src/agent/execution.rs','    ) -> Result<PreparedModelTurn, Terminal> {','    ) -> Result<PreparedModelTurn, Terminal> {\n        let _diagnostic=crate::hotpath_profile::Timer::cpu("request_prepare",u64::from(request_ordinal));')
edit('src/agent/execution.rs','    ) -> Result<StartedModelTurn, Terminal> {\n        let started = self.start_model_turn(prepared)?;','    ) -> Result<StartedModelTurn, Terminal> {\n        let _diagnostic=crate::hotpath_profile::Timer::cpu("request_start",u64::from(*next_request_ordinal));\n        let started = self.start_model_turn(prepared)?;')
# This scratch build always enables the opt-in diagnostics feature.
patch=subprocess.check_output(['git','diff','--binary'],cwd=p)+(p/'src/hotpath_profile.rs').read_bytes();(r/'diagnostic-source.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=p));(r/'diagnostic-added.rs').write_bytes((p/'src/hotpath_profile.rs').read_bytes())
