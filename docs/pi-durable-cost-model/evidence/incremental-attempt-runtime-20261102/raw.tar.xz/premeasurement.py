#!/usr/bin/env python3
"""Read-only readiness gate. Never starts Cargo, Rust, Node, Pi or DeepSeek."""
import argparse, ast, datetime, hashlib, importlib.util, json, re, subprocess, sys
from pathlib import Path
from fixture_binding import capture as capture_fixtures, provider_proof, FORMAL_PROTOCOL, affinity_snapshot, validate_affinity
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PRODUCERS=['build-candidate.py','run-cohorts.py','run-diagnostics.py','columns-complete.py','run-wal-rust.py','analyze-wal-verified.py']
AUDITORS=['direct-audit.py','diagnostic-audit.py','recompute-pi.py','premeasurement.py','fixture_binding.py']
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(ok,message):
 if not ok:raise ValueError(message)
def script_inventory(root):
 result={}
 for name in PRODUCERS+AUDITORS:
  p=root/name;source=p.read_text();ast.parse(source);result[name]=sha(p)
 # Closed entry-point policy: fresh cohorts use the revision runner only. The
 # diagnostic run list is separately checked against its exact recorded argv by
 # diagnostic-audit; imported controller.run receives only conformance argv.
 cohorts=(root/'run-cohorts.py').read_text()
 require("choices=['direct']" in cohorts and 'compare-revisions.py' in cohorts and 'deepseek-compare.py' not in cohorts and "'--pi'" not in cohorts and 'pi-http' not in cohorts, 'formal producer contains a reference-engine entry point')
 for name in ('run-diagnostics.py','run-wal-rust.py','columns-complete.py'):
  source=(root/name).read_text()
  require(not any(token in source for token in ('deepseek-compare.py','pi-http','--conditions=source',"'--pi'",'"--pi"')), name+' contains a reference-engine entry point')
 return result

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=HERE);p.add_argument('--repo',type=Path,default=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX'));p.add_argument('--output',type=Path,required=True);a=p.parse_args()
 require(not a.output.exists(),'retain previous premeasurement receipt')
 spec=importlib.util.spec_from_file_location('owner_direct',a.root/'direct-audit.py');audit=importlib.util.module_from_spec(spec);spec.loader.exec_module(audit)
 errors=[];result={'accepted':False,'scope':'Read-only premeasurement gate; no product or build runs','errors':errors}
 def check(label,fn):
  try:return fn()
  except Exception as error:errors.append(f'{label}: {type(error).__name__}: {error}');return None
 result['scripts']=check('script inventory',lambda:script_inventory(a.root))
 result['protocol']=FORMAL_PROTOCOL
 result['host_affinity']=check('CPU topology capture',affinity_snapshot)
 if result['host_affinity'] is not None:result['cpu_class']=check('CPU topology validation',lambda:validate_affinity(result['host_affinity'],pinned=False))
 builds={name:check(name+' identity',lambda name=name:json.loads((a.root/name/'identity.json').read_text())) for name in ('baseline-build','candidate-complete-build')}
 if all(builds.values()):
  b,c=builds.values()
  def binding():
   require((b['head'],b['sha256'])==('e9df19d2db38961343d4f05aa7d9c601fecc5968','ed788eb3b39027ea9597a9b07b7bda1d4fc9e5eb314096948f40cf1000acde27'),'old Rust pin differs')
   require(b['production_tree']=='682c72fbc9d0ce39fd2f11c73555e026effd7ff4', 'baseline source tree differs')
   require('pub const SQLITE_SCHEMA_VERSION: i64 = 87;' in (a.repo/'src/durable/sqlite.rs').read_text(), 'candidate schema differs')
   require(all(b[k]==c[k] for k in ('harness','rustc','cargo')) and b['sha256']!=c['sha256'],'same harness/toolchain pair differs')
   for build in builds.values():
    require(build['verified'] is True and build['clean_exit']==build['build_exit']==0 and sha(build['binary'])==build['sha256'],'actual build is not verified')
    require(audit.git(a.repo,'rev-parse',build['head']+':src')==build['production_tree'],'recorded source tree differs')
   require(not audit.git(a.repo,'status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime','test-support/fake-provider'),'source dirty')
   require(audit.git(a.repo,'rev-parse','HEAD')==c['head'],'current commit differs from candidate')
   require(all(sha(a.repo/f)==digest for f,digest in c['source_files'].items()),'candidate source input differs')
   require(set(audit.git(a.repo,'ls-tree','-r','--name-only','HEAD','--','src','tests').splitlines())=={f for f in c['source_files'] if f.startswith(('src/','tests/'))},'source input inventory incomplete')
   require(all(sha(a.repo/f)==digest for f,digest in c['harness'].items()),'harness differs')
   return {name:{k:build[k] for k in ('head','production_tree','sha256')} for name,build in builds.items()}
  result['identities']=check('source/build pair',binding)
  result['fixtures']=check('measurement fixture inputs',lambda:capture_fixtures(a.repo))
  if result['fixtures'] is not None:
   result['provider_binding']=check('provider source equality',lambda:provider_proof(a.repo,b['head'],c['head'],result['fixtures']))
  a.raw_only=False;collector=audit.Audit();result['validation']=check('functional checks',lambda:audit.validation(a,collector,c));errors.extend(collector.errors)
 result['accepted']=not errors
 result['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':result['accepted'],'errors':errors},indent=2));return int(not result['accepted'])
if __name__=='__main__':raise SystemExit(main())
