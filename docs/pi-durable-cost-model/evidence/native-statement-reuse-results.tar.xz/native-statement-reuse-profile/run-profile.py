from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent/'v3';root.mkdir(exist_ok=False)
binaries={'before':Path('/workspace/issue-481-evidence/observer-oracle-v2-build/conformance'),'after':Path('/workspace/issue-481-evidence/native-statement-reuse-build/conformance')}
identities={name:json.loads((path.parent/'identity.json').read_text()) for name,path in binaries.items()}
assert identities['before']['harness']==identities['after']['harness']
for name,path in binaries.items():assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==identities[name]['sha256']
planned=[root/f'{o}-{c}-{n}-{m}' for o in range(2) for c in range(2) for n in ['b','a'] for m in ['control','cpu']]
assert len(set(planned))==16 and all(len(str(path/'control.sock').encode())<108 for path in planned)
(root/'build-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
for observer in ['no-live-subscriber','live-subscriber']:
 for case in ['short-small','short-large']:
  for name,binary in binaries.items():
   for mode in ['control','cpu']:
    destination=root/f"{['no-live-subscriber','live-subscriber'].index(observer)}-{['short-small','short-large'].index(case)}-{name[0]}-{mode}"
    assert len(str(destination/'control.sock').encode())<108
    command=['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(destination),'--mode',mode,'--case',case,'--observer-mode',observer]
    with (root/f'{destination.name}.log').open('x') as log:subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
    print(observer,case,name,mode,'passed',flush=True)
    if mode=='cpu':
     for output,flags in [('steady-flat.txt',['--text']),('steady-cumulative.txt',['--text','--cum']),('steady-stacks.txt',['--collapsed'])]:
      command=['/workspace/issue-481-profilers/unpacked/usr/bin/google-pprof',*flags,'--no_strip_temp','--nodecount=200',str(binary),str(destination/'before_measured_turns.cpu')]
      with (destination/output).open('x') as out,(destination/(output+'.stderr')).open('x') as err:subprocess.run(command,stdout=out,stderr=err,check=True)
print('Diagnostic controls/profiles completed; no formal timing inference or overhead subtraction.',flush=True)
