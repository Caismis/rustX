from pathlib import Path
import collections,importlib.util,json,re,sys
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent;data=root/'v3'
sys.path.insert(0,str(repo/'benchmarks/runtime'))
spec=importlib.util.spec_from_file_location('summary',repo/'benchmarks/runtime/summarize-http.py');summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
records=[];overhead=[]
for oi,observer in enumerate(['no-live-subscriber','live-subscriber']):
 for ci,case in enumerate(['short-small','short-large']):
  for name in ['before','after']:
   p=data/f'{oi}-{ci}-{name[0]}-cpu';ops=collections.Counter();owners=collections.Counter();total=0
   for line in (p/'steady-stacks.txt').read_text().splitlines():
    stack,count=line.rsplit(' ',1);count=int(count);total+=count
    if any(t in stack for t in ['sqlite3_prepare','sqlite3Prepare','sqlite3LockAndPrepare']):
     op='sql_prepare';frames=[f for f in stack.split(';') if 'rustx::durable::sqlite::' in f];owner=re.sub(r'<[0-9a-f]{16}>','',frames[-1]) if frames else 'unassigned';owners[owner]+=count
    elif 'fit_checkpoint' in stack:op='complete_checkpoint_fit'
    elif 'preflight::' in stack or 'preflight::Check' in stack:op='other_preflight'
    elif 'ReadDomainCut>::read' in stack:op='other_read_domains'
    else:op='other'
    ops[op]+=count
   assert total==int(re.search(r'Total: (\d+) samples',(p/'steady-flat.txt').read_text())[1]) and sum(ops.values())==total
   records.append({'observer_mode':observer,'case':case,'side':name,'total_signals':total,'disjoint_operations':dict(ops),'sql_prepare_native_owners':owners.most_common()})
   ctrl=summary.sample(data/f'{oi}-{ci}-{name[0]}-control/sample.json');prof=summary.sample(p/'sample.json')
   keys=['mean_turn_ms','turn_cpu_ms_per_turn','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib','max_sampled_anon_pss_mib']
   overhead.append({'observer_mode':observer,'case':case,'side':name,'control':{k:ctrl[k] for k in keys},'profile':{k:prof[k] for k in keys},'profile_over_control':{k:prof[k]/ctrl[k] if ctrl[k] else None for k in keys}})
(root/'disjoint-operations.json').write_text(json.dumps({'scope':'Separate diagnostic CPU signal samples. Each stack assigned once; unknown frames retained. Different signal totals reflect sampled CPU and diagnostic scheduling. Not overlapping elapsed percentages, not a formal comparison.','profiles':records},indent=2)+'\n')
(root/'overhead-controls.json').write_text(json.dumps({'scope':'One control/profile pair for each build/case/mode. Diagnostic overhead and noise only; 10 ms self CPU ticks. No subtraction from formal samples and no statistical overhead bound.','pairs':overhead},indent=2)+'\n')
for r in records:print(r['observer_mode'],r['case'],r['side'],r['total_signals'],r['disjoint_operations'])
