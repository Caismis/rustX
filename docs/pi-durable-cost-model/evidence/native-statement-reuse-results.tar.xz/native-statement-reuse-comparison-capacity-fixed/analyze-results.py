from pathlib import Path
import csv,hashlib,importlib.util,json,math,statistics,sys
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'))
spec=importlib.util.spec_from_file_location('summary',repo/'benchmarks/runtime/summarize-http.py');summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
out=root/'readable';out.mkdir(exist_ok=False)
metrics=['mean_turn_ms','turn_cpu_ms_per_turn','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib','max_sampled_anon_pss_mib']
append_metrics=['mean_append_ms','append_cpu_ms_per_append','lifecycle_cpu_ms','lifecycle_write_mib','max_sampled_anon_pss_mib']
rows=[];groups={};hashes={}
def record(cohort,mode,case,pair,before,after,keys):
 for metric in keys:
  a,b=before.get(metric),after.get(metric)
  good=a is not None and b is not None and a>0 and b>0
  ratio=b/a if good else None
  rows.append({'cohort':cohort,'scope':mode,'case':case,'pair':pair,'metric':metric,'before':a,'after':b,'ratio':ratio,'state':'positive' if good else 'unavailable_or_quantized_zero'})
  groups.setdefault((cohort,mode,case,metric),[]).append(ratio)
for mode in ['no-live-subscriber','live-subscriber','warm-append','cold-append']:
 data=json.loads((root/f'{mode}-summary.json').read_text())
 for case,records in data['samples'].items():
  for r in records:record('complete',mode,case,r['pair'],r['before'],r['after'],append_metrics if mode.endswith('append') else metrics)
 for p in sorted((root/mode).glob('*.json')):hashes[str(p.relative_to(root.parent))]=hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
old=root.parent/'native-statement-reuse-comparison'
for mode in ['no-live-subscriber','live-subscriber']:
 for p in sorted((old/mode).glob('*-before.json')):
  q=p.with_name(p.name.replace('-before.json','-after.json'));status=[]
  for f in [p,q]:
   sp=f.with_name(f.stem+'.process.json')
   if not f.exists() or not sp.exists():status.append(False)
   else:status.append(json.loads(sp.read_text())['accepted'])
  if not all(status):continue
  pair,case=p.stem.removesuffix('-before').split('-',1)
  record('capacity_limited',mode,case,int(pair),summary.sample(p),summary.sample(q),metrics)
  for f in [p,q,p.with_name(p.stem+'.process.json'),q.with_name(q.stem+'.process.json')]:hashes[str(f.relative_to(root.parent))]=hashlib.file_digest(f.open('rb'),'sha256').hexdigest()
rows.sort(key=lambda r:(r['cohort'],r['scope'],r['case'],r['metric'],r['pair']))
with (out/'paired-costs.csv').open('x',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(rows[0]),lineterminator='\n');writer.writeheader();writer.writerows(rows)
records=[];t=2.919985580355516
for identity,values in sorted(groups.items()):
 r=dict(zip(['cohort','scope','case','metric'],identity));r.update(n=len(values),ratios=values)
 if len(values)==3 and all(v is not None for v in values):
  logs=list(map(math.log,values));m=statistics.mean(logs);w=t*statistics.stdev(logs)/math.sqrt(3)
  r.update(state='three_positive_pairs',paired_median=statistics.median(values),geometric_mean=math.exp(m),two_sided_90_lower=math.exp(m-w),one_sided_95_upper=math.exp(m+w),min=min(values),max=max(values))
 else:r.update(state='incomplete_or_quantized; no interval or selected-subset median')
 records.append(r)
(out/'paired-uncertainty.json').write_text(json.dumps({'scope':'Within-pair after/before ratios. Complete cohort is three interleaved pairs per case/scope. Earlier capacity-limited data remains separately labeled, with no pooling. 90% two-sided/95% one-sided paired log-t interval, df2, critical 2.919985580355516. Zero/unavailable values make the whole interval indeterminate; no dropping adverse/zero samples. Normal independent log-ratio assumption; exploratory cloud data, no Pi parity.','records':records},indent=2)+'\n')
(out/'input-hashes.json').write_text(json.dumps(hashes,indent=2)+'\n')
assert len([r for r in rows if r['cohort']=='complete'])==300
assert len([r for r in rows if r['cohort']=='capacity_limited'])==155
print(json.dumps({'rows':len(rows),'complete_rows':300,'capacity_limited_rows':155,'metric_groups':len(records),'positive_three_pair_intervals':sum(r['state']=='three_positive_pairs' for r in records),'indeterminate_or_incomplete':sum(r['state']!='three_positive_pairs' for r in records)}))
