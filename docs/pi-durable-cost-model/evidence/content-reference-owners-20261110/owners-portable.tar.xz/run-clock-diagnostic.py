"""Measure the adverse cold burst through the existing profiler phase seam."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,statistics
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0,str(repo/'benchmarks/runtime'))
from controller import run,TEST
binaries={'before':Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/conformance'),'after':root/'reference-build/conformance'}
rows=[]
for pair in range(4):
 for side in (['before','after'] if pair%2==0 else ['after','before']):
  directory=root/f'clock-burst-{pair}-{side}';directory.mkdir(exist_ok=False)
  env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])}
  env.update(RUSTX_BENCH_CASE='large',RUSTX_BENCH_OUTPUT=str(directory/'sample.json'),RUSTX_BENCH_OBSERVER_MODE='live-subscriber')
  argv=['env',f'LD_PRELOAD={root}/clock-bridge.so:{root}/clock-window.so',f'RUSTX_BENCH_PROFILE_SOCKET={directory}/control.sock',f'RUSTX_BENCH_PROFILE_DIR={directory}',str(binaries[side]),TEST,'--exact','--ignored','--nocapture']
  result=run(argv,directory/'sample','large',env,repo/'test-support/fake-provider');assert result['accepted']
  clock=json.loads((directory/'before_measured_turns.cpu.json').read_text());sample=json.loads((directory/'sample.json').read_text())['samples'][0]
  rows.append({'pair':pair,'side':side,**clock,'settled_us':sample['settled_us'],'accepted_us':sample['accepted_us'],'notifications':sample['notification_records'],'binary_sha256':hashlib.file_digest(binaries[side].open('rb'),'sha256').hexdigest()})
  print(pair,side,clock,flush=True)
summary={}
for k in ['cpu_ns','wall_ns','accepted_us','settled_us','minor_faults','voluntary_switches','involuntary_switches']:
 changes=[]
 for pair in range(4):
  a,b=[next(x[k] for x in rows if x['pair']==pair and x['side']==side) for side in ['before','after']]
  if a:changes.append((b-a)/a*100)
 summary[k]={'before_median':statistics.median(x[k] for x in rows if x['side']=='before'),'after_median':statistics.median(x[k] for x in rows if x['side']=='after'),'paired_percent':changes,'median_paired_percent':statistics.median(changes) if changes else None}
report={'scope':'Diagnostic only. Four balanced pairs over the existing phase socket. Same ordinary executables, one added control thread, no signal sampler and no allocator replacement. Precise process CPU includes runtime plus driver and phase handshakes; wall is not a headline timing. This asks whether the adverse cold burst is additional CPU work or elapsed wait. No production checkpoint/durability setting changes.','rows':rows,'summary':summary,'inputs':{str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [Path(__file__),root/'clock-window.c',root/'clock-window.so',root/'clock-bridge.so',repo/'benchmarks/runtime/profiling/bridge.c']}}
(root/'clock-diagnostic-summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(summary),flush=True)
