"""Keep every measurement and verification record; sample redundant DB images explicitly."""
from pathlib import Path
import json,subprocess,sys
r=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
patterns=['*.py','*.c','*.so','*.json','*.jsonl','*.log','*.rs','*.ll','inputs/*.json','ordinary/*','burst-uncertainty/*','functional/*','clock-burst-*/*.json','clock-burst-*/*.log']
for family in ['memory-*','native-*','deep-*','census-*']:
 patterns += [family+'/'+suffix for suffix in ['*.json','*.log','*.stdout','*.stderr','*.toml','native-snapshots/0000.sqlite','native-snapshots/0127.sqlite','native-snapshots/0015.sqlite']]
patterns += ['*build/'+suffix for suffix in ['*.json','*.jsonl','*.log','*.stdout','*.stderr']]
record={'scope':'Portable archive retains all measurement products, raw per-turn/process counters, complete provider requests, all verifier outputs and backup hashes, build identities, inputs and scripts. It includes representative first/last/deep database images. All original consistent DB images and a separate complete archive remain in the local evidence root; the portable archive does not contain every DB image. No timing or counter sample is omitted.','patterns':patterns,'root':str(r)}
(r/'portable-scope.json').write_text(json.dumps(record,indent=2)+'\n')
subprocess.run([sys.executable,str(repo/'benchmarks/runtime/pack-evidence.py'),'--root',str(r),'--output',str(r/'packed/owners-portable.tar.xz'),*patterns],cwd=repo,check=True)
