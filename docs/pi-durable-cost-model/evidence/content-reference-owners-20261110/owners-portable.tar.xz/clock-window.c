/* Diagnostic adapter for the existing profiler bridge. No signal sampling or
 * allocator replacement; precise process CPU separates work from elapsed wait. */
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>
static char active[4096];
static uint64_t cpu_begin, wall_begin;
static struct rusage usage_begin;
static uint64_t stamp(clockid_t id) {
  struct timespec value;
  if (clock_gettime(id, &value)) return 0;
  return (uint64_t)value.tv_sec * 1000000000ULL + value.tv_nsec;
}
int ProfilerStart(const char *path) {
  if (strlen(path) + 6 >= sizeof active) return 0;
  strcpy(active, path);
  getrusage(RUSAGE_SELF, &usage_begin);
  wall_begin = stamp(CLOCK_MONOTONIC);
  cpu_begin = stamp(CLOCK_PROCESS_CPUTIME_ID);
  return 1;
}
void ProfilerStop(void) {
  if (!active[0]) return;
  uint64_t cpu = stamp(CLOCK_PROCESS_CPUTIME_ID), wall = stamp(CLOCK_MONOTONIC);
  struct rusage usage; getrusage(RUSAGE_SELF, &usage);
  strcat(active, ".json");
  FILE *out = fopen(active, "wx");
  if (out) {
    fprintf(out, "{\"cpu_ns\":%llu,\"wall_ns\":%llu,\"minor_faults\":%ld,\"major_faults\":%ld,\"voluntary_switches\":%ld,\"involuntary_switches\":%ld}\n", (unsigned long long)(cpu-cpu_begin), (unsigned long long)(wall-wall_begin), usage.ru_minflt-usage_begin.ru_minflt, usage.ru_majflt-usage_begin.ru_majflt, usage.ru_nvcsw-usage_begin.ru_nvcsw, usage.ru_nivcsw-usage_begin.ru_nivcsw);
    fclose(out);
  }
  active[0]=0;
}
