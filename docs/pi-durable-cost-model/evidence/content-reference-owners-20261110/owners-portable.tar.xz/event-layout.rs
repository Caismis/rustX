#[unsafe(no_mangle)] pub extern "C" fn size_event() -> usize { std::mem::size_of::<rustx::runtime_client::RuntimeClientEvent>() }
#[unsafe(no_mangle)] pub extern "C" fn size_metadata() -> usize { std::mem::size_of::<rustx::runtime_client::checkpoint::ProjectionMetadata>() }
