from pathlib import Path
import hashlib,json,subprocess
r=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
rows=[json.loads(x) for x in (r/'shared-binding-owner-unit-build.jsonl').read_text().splitlines() if x.startswith('{')]
a=next(x for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('src_path')==str(repo/'src/lib.rs') and x.get('executable'))
assert a['fresh'] is False
binary=Path(a['executable'])
identity={'binary':str(binary),'sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'profile':a['profile'],'groups':[]}
for group in ['observation::','runtime_client::','durable::sqlite::','agent::execution::','app_server::schema::','app_server::wire::']:
    name=group.replace('::','-').strip('-')
    command=[str(binary),group,'--test-threads=8']
    with (r/(name+'-owner-tests.log')).open('x') as output:
        result=subprocess.run(command,cwd=repo,stdout=output,stderr=subprocess.STDOUT)
    record={'group':group,'command':command,'exit':result.returncode}
    identity['groups'].append(record)
    (r/'owner-tests.json').write_text(json.dumps(identity,indent=2)+'\n')
    print(group,result.returncode,flush=True)
    result.check_returncode()
