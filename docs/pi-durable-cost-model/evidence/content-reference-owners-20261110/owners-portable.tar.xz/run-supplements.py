"""Fixed follow-up for the adverse burst result, plus functional/deep checks."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
before=Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build')
after=root/'reference-build'
compare=[sys.executable,str(repo/'benchmarks/runtime/compare-revisions.py'),'--before',str(before/'conformance'),'--after',str(after/'conformance'),'--observer-mode','live-subscriber']
jobs=[('burst-uncertainty',compare+['--output',str(root/'burst-uncertainty'),'--pairs','4','--pair-offset','4','--case','large']),('functional',compare+['--output',str(root/'functional'),'--pairs','1','--case','tool','--case','cancel'])]
for side,binary in [('after',after/'rustx'),('before',before/'rustx')]:
 name='deep-16x64-'+side
 jobs.append((name,[sys.executable,str(repo/'benchmarks/runtime/app-server-capacity.py'),'--binary',str(binary),'--output',str(root/name),'--sessions','16','--history','64','--history-checkpoints','8','32','--memory-only']))
records=[]
for name,command in jobs:
 assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
 record={'name':name,'command':command,'begin_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 host=[]
 with (root/(name+'-driver.log')).open('x') as log:
  process=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  while process.poll() is None:
   host.append({'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'compiler_pids':subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True).stdout.split()})
   time.sleep(.5)
 (root/(name+'-host.json')).write_text(json.dumps(host,indent=2)+'\n')
 record.update(exit=process.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),compiler_overlap_samples=sum(bool(x['compiler_pids']) for x in host))
 records.append(record);(root/'supplement-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,process.returncode,flush=True)
 assert process.returncode==0
