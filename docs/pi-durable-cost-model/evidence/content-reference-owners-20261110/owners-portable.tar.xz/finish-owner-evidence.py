from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
p=root/'exact-source-tests.json';data=json.loads(p.read_text());seen={};executions=0
for group in data['groups']:
 name=group['group'].replace('::','-').strip('-');log=root/(name+'-exact-tests.log');s=log.read_text();group['result']=re.findall(r'test result: (.*)',s)[-1];group['log_sha256']=hashlib.file_digest(log.open('rb'),'sha256').hexdigest();assert group['exit']==0 and '0 failed' in group['result']
 for name,result in re.findall(r'^test (\S+) \.\.\. (ok|ignored)',s,re.M):seen[name]=result;executions+=1
assert sum(x=='ok' for x in seen.values())==1664
data.update(unique_passed=1664,unique_ignored=sum(x=='ignored' for x in seen.values()),test_executions=executions,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),source_tree=subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip(),fresh_all_feature_cli_and_supervisors='exact-source-bins.jsonl')
p.write_text(json.dumps(data,indent=2)+'\n')
groups={}
for name,dirs in {'memory':[root/f'memory-{i}-{side}' for i in range(4) for side in ['before','after']], 'active':[root/f'native-{family}-{side}' for family in ['fixed','rotating'] for side in ['before','after']], 'deep':[root/f'deep-16x64-{side}' for side in ['before','after']]}.items():
 identities=[json.loads((directory/'identity.json').read_text()) for directory in dirs];assert all(x['inputs']==identities[0]['inputs'] for x in identities)
 groups[name]={'directories':[str(x.relative_to(root)) for x in dirs],'inputs':identities[0]['inputs'],'accepted':all(json.loads((directory/'completed.json').read_text())['accepted'] for directory in dirs)}
assert json.loads((root/'ordinary-command.json').read_text())['compiler_overlap_samples']==0
ordinary=json.loads((root/'ordinary-summary.json').read_text());assert len(ordinary['samples'])==32
comparisons=list((root/'ordinary').glob('*-comparison.json'));checked=0
for p in comparisons:
 x=json.loads(p.read_text());assert all(c['coreSemanticEqual'] and c['fullSemanticRequestEqual'] for c in x['checked']);checked+=len(x['checked'])
assert checked==552
(root/'input-immutability.json').write_text(json.dumps({'native_groups':groups,'ordinary_products':32,'ordinary_semantic_request_comparisons':checked,'harness_identity':'baseline-authentication-final.json','compiler_overlap_in_original_four_cells':0},indent=2)+'\n')
# Preserve the earlier authenticated storage ledger behind the next index decision.
source=Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/candidate-write-ledger.json');(root/'inputs').mkdir(exist_ok=True);(root/'inputs/kind-write-ledger.json').write_bytes(source.read_bytes())
print('exact tests',data['unique_passed'],'request comparisons',checked,'native products',sum(len(x['directories']) for x in groups.values()))
