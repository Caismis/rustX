from pathlib import Path
import hashlib,json,shutil,subprocess,sys
r=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
target=Path('/home/capi/.cache/rustx-pr485-main-integration-target')
command=[sys.executable,'/home/capi/.cache/rustx-pr485-history-growth-20261109/build-revision-eight-jobs.py','--repo',str(repo),'--target',str(target),'--output',str(r/'reference-build')]
subprocess.run(command,cwd=repo,check=True)
out=r/'reference-build'
rows=[json.loads(x) for x in (out/'build.stdout').read_text().splitlines() if x.startswith('{')]
a=next(x for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('src_path')==str(repo/'src/main.rs') and x.get('executable'))
assert a['fresh'] is False
shutil.copy2(a['executable'],out/'rustx')
p=out/'identity.json'; identity=json.loads(p.read_text());identity['cli']={'binary':str(out/'rustx'),'sha256':hashlib.file_digest((out/'rustx').open('rb'),'sha256').hexdigest(),'source':a['target']['src_path'],'profile':a['profile'],'fresh':a['fresh']}
p.write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps(identity['cli']),flush=True)
