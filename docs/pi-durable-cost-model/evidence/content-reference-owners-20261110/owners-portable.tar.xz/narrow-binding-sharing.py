"""Remove the path wrapper that did not reduce measured unique path owners."""
from pathlib import Path
import subprocess
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
for name in ['src/runtime_client/history_observation.rs','src/runtime_client/trace_observation.rs','src/observation/transcript/prepared.rs','src/runtime_client/checkpoint/metadata_fragment.rs','tests/conformance/agent_loop/runtime_benchmark/aligned.rs']:
 (repo/name).write_bytes(subprocess.check_output(['git','show','ddbced4c2:'+name],cwd=repo))
p=repo/'src/observation/cut.rs';s=p.read_text().replace('    #[schemars(with = "Option<Vec<String>>")]\n    pub source_path: Option<Arc<[String]>>,\n    #[schemars(with = "Vec<String>")]\n    pub path: Arc<[String]>,','    pub source_path: Option<Vec<String>>,\n    pub path: Vec<String>,');s=s.replace('// Display position and native read evidence can change independently.\n    // Sharing immutable parts avoids copying both when only one is replaced.','// Display positions vary across captures; native byte evidence is immutable\n    // and shared with the source-owned metadata root.');p.write_text(s)
p=repo/'src/runtime_client/projection/retention_profile.rs';s=p.read_text();s=s.replace('''            if self.owner(
                "binding_path_arrays",
                path.as_ptr() as usize,
                path.len() * size_of::<String>() + ARC_HEADER,
            ) {''','''            if self.vector("binding_path_vectors", path) {''');s=s.replace('assert_eq!(census.allocations["binding_path_arrays"].owners, 1);','assert_eq!(census.allocations["binding_path_vectors"].owners, 2);');p.write_text(s)
p=repo/'src/runtime_client/checkpoint/metadata_fragment_tests.rs';s=p.read_text().replace('shared.source_path = source_path.clone().map(Into::into);','shared.source_path.clone_from(&source_path);');s=s.replace('''    assert!(Arc::ptr_eq(&original.path, &resolved.path));
    assert!(Arc::ptr_eq(
        original.source_path.as_ref().unwrap(),
        resolved.source_path.as_ref().unwrap()
    ));''','''    assert_eq!(original.path, resolved.path);
    assert_eq!(original.source_path, resolved.source_path);''');s=s.replace('Arc::make_mut(&mut resolved.path)[0] = "changed".into();','resolved.path[0] = "changed".into();');p.write_text(s)
p=repo/'src/runtime_client/projection/prepared_capture.rs';s=p.read_text();start=s.index('                .map(|value| {',s.index('    fn prefixed('));end=s.index('\n                .collect(),',start);chunk=s[start:end];chunk=chunk.replace('                    let mut value = value.clone();\n','');chunk=chunk.replace('''                    value.path = path;
                    value.into()''','''                    crate::observation::cut::ContentBinding {
                        source_path: value.source_path.clone(),
                        path,
                        content_ref: Arc::clone(&value.content_ref),
                        deferred: value.deferred,
                    }
                    .into()''');s=s[:start]+chunk+s[end:];p.write_text(s)
