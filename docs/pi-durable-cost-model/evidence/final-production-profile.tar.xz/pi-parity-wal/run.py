import sys,os,json,threading,socket,sqlite3,subprocess,time,hashlib
from pathlib import Path
repo=Path('/workspace/rustX-pi-durable');out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run,TEST
original=subprocess.Popen
for engine in ['rust','pi']:
 root=out/('complete-'+engine);root.mkdir(exist_ok=False);sock=root/'control.sock';server=socket.socket(socket.AF_UNIX);server.bind(str(sock));server.listen(1);ready=threading.Event();state={};phases=[];fail=[]
 def serve():
  conn=None
  try:
   ready.wait()
   while True:
    conn,_=server.accept();line=b''
    while not line.endswith(b'\n'):
     chunk=conn.recv(128)
     if not chunk:raise RuntimeError('phase controller reached EOF before newline')
     line+=chunk
    phase=line.decode().strip();phases.append({'phase':phase,'monotonic_ns':time.monotonic_ns()})
    if phase in ['before_measured_turns','after_turns']:
     paths=set()
     for fd in Path(f'/proc/{state["pid"]}/fd').iterdir():
      try:p=os.readlink(fd)
      except OSError:continue
      if p.endswith(('.sqlite','.db')) and Path(p).exists():paths.add(p)
     snapshots=[]
     for path in sorted(paths):
      c=sqlite3.connect(f'file:{path}?mode=ro',uri=True);tables=c.execute("SELECT name,sql,rootpage FROM sqlite_schema WHERE type='table'").fetchall();s={'path':path,'tables':tables,'counts':{name:c.execute('SELECT count(*) FROM "'+name.replace('"','""')+'"').fetchone()[0] for name,_,_ in tables},'pages':c.execute('SELECT name,pageno,pagetype,ncell,payload FROM dbstat').fetchall()}
      if any(t[0]=='request_source_nodes' for t in tables):s['source_nodes']=[{'id':i,'metadata':json.loads(m)} for i,m in c.execute('SELECT native_id,metadata FROM request_source_nodes')]
      c.close()
      if path.endswith('conversation.db') or any(t[0]=='events' for t in tables): snapshots.append(s)
     assert len(snapshots)==1, snapshots
     (root/(phase+'-database.json')).write_text(json.dumps(snapshots,indent=2))
    conn.sendall(b'K');conn.close()
    if phase=='after_cleanup':break
  except Exception as e:
   fail.append(repr(e))
   if conn is not None:conn.close()
 thread=threading.Thread(target=serve,daemon=True);thread.start();tracers=[]
 binary='/workspace/issue-481-evidence/pi-partial-build/conformance'
 argv=[binary,TEST,'--exact','--ignored','--nocapture'] if engine=='rust' else ['node','--conditions=source',str(out/'pi-http-wal.mjs'),'/workspace/pi-481','short-small',str(root/'sample.json')]
 def start(args,*a,**kw):
  product=original(args,*a,**kw)
  if args==argv:
   state['pid']=product.pid
   tracer=original(['strace','-f','-yy','-s','96','-e','trace=pwrite64,write,writev,sendto,sendmsg,fsync,fdatasync','-o',str(root/'calls.strace'),'-p',str(product.pid)],stderr=subprocess.PIPE,text=True);tracers.append(tracer);line=tracer.stderr.readline();assert 'attached' in line,line;ready.set()
  return product
 subprocess.Popen=start
 env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))};env.update(UV_CACHE_DIR='/workspace/.uv-cache',RUSTX_BENCH_CASE='short-small',RUSTX_BENCH_OUTPUT=str(root/'sample.json'),RUSTX_BENCH_PROFILE_SOCKET=str(sock),GAP_OUTPUT=str(root))
 result=run(argv,root/'sample','short-small',env,repo/'test-support/fake-provider');subprocess.Popen=original
 for tracer in tracers:
  (root/'tracer.log').write_text(tracer.communicate()[1]);assert tracer.returncode==0
 thread.join(5);server.close();(root/'phases.json').write_text(json.dumps(phases,indent=2));assert not fail,fail;assert not thread.is_alive();assert result['accepted'],result.get('error');print(engine,'passed',flush=True)
subprocess.run(['node',str(repo/'benchmarks/runtime/compare-http.mjs'),str(out/'complete-rust/sample.json'),str(out/'complete-pi/sample.json'),str(out/'comparison.json')],check=True)
(out/'identity.json').write_text(json.dumps({'rust_sha256':hashlib.file_digest(Path(binary).open('rb'),'sha256').hexdigest(),'rust_head':'a3c116fe91d7689d86c5009c7b563289d3cd34cc','pi_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/pi-481',text=True).strip(),'scope':'Fresh diagnostic WAL counts only; overlapped diagnostic compilation. External sibling provider/tracer, dbstat at synchronous boundaries; no timing claims. Pi production unmodified; added boundary handshake in driver.'},indent=2))
