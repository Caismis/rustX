from pathlib import Path
from collections import Counter
import json,re,struct
root=Path('/workspace/issue-481-evidence/pi-parity-final-profile');records=[]
for case in ['short-small','short-large']:
 p=root/(case+'-cpu');groups=Counter();operations=Counter();total=0
 for line in (p/'steady-stacks.txt').read_text().splitlines():
  stack,n=line.rsplit(' ',1);n=int(n);total+=n
  if '<conformance::agent_loop::Driver>::start_in::{closure#0}::{closure#0}' in stack:owner='publication_consumption_relay'
  elif 'runtime_benchmark::process_sample' in stack or 'runtime_benchmark::footprint' in stack:owner='benchmark_counter_and_footprint_work'
  elif 'Driver>::assert_original_terminal' in stack or 'Driver>::submitted_attempt' in stack:owner='benchmark_validation_reads'
  elif 'PublicationDraft>::encode' in stack:owner='publication_encoding'
  elif 'ReadDomainCut>::read' in stack:owner='publication_read_domains'
  elif any(x in stack for x in ['runtime_client::host::','runtime_client::projection::','runtime_client::trace::']):owner='other_runtime_client_publication'
  elif any(x in stack for x in ['rustx::agent::execution::','rustx::runtime::conversation_runtime::','rustx::durable::','rustx::runtime::read_layout::']):owner='engine_and_coordinator'
  elif 'rustx::app_server::' in stack:owner='app_server_wire'
  elif 'conformance::agent_loop::' in stack:owner='benchmark_driver'
  elif 'hyper::' in stack or 'reqwest::' in stack:owner='http_transport_unassigned'
  else:owner='scheduler_native_or_unassigned'
  groups[owner]+=n
  if 'sqlite3_prepare' in stack or 'sqlite3Prepare' in stack or 'sqlite3LockAndPrepare' in stack:op='sql_prepare'
  elif 'sqlite3_step' in stack or 'sqlite3VdbeExec' in stack:op='sql_execute'
  elif 'structural_json::' in stack:op='structural_encoding'
  elif 'read_layout::' in stack:op='source_navigation'
  else:op='other'
  operations[op]+=n
 expected=int(re.search(r'Total: (\d+) samples',(p/'steady-flat.txt').read_text())[1]);assert total==expected;assert sum(groups.values())==sum(operations.values())==total
 records.append({'case':case,'samples':total,'ownership':dict(groups),'operation_separate_partition':dict(operations)})
(root/'disjoint-cpu-attribution.json').write_text(json.dumps({'scope':'Each complete CPU signal stack is assigned exactly once within each partition. The ownership and operation partitions are separate views and must not be added. Ordered ownership rules prioritize the exact conformance notification relay, measurement counter/footprint work, driver validation reads, publication encoding, domain refresh, other Host/projection/trace ownership (not utility serializers), engine/coordinator/durable/Source, App Server wire, benchmark-driver, HTTP transport, unassigned. A stack containing runtime_client work under an engine caller is charged to publication; unknown/optimized frames remain unassigned. CPU signals include native work but exclude idle wall. Samples are diagnostic and have profiler overhead; these are not exclusive elapsed timers or exact engine CPU counters.','profiles':records},indent=2)+'\n');print(json.dumps(records,indent=2))
