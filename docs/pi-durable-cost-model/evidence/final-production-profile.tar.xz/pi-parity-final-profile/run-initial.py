from pathlib import Path
import subprocess,json,hashlib
repo=Path('/workspace/rustX-pi-durable');out=Path('/workspace/issue-481-evidence/pi-parity-final-profile');binary=Path('/workspace/issue-481-evidence/pi-partial-build/conformance');ident=json.loads((binary.parent/'identity.json').read_text());assert ident['sha256']==hashlib.sha256(binary.read_bytes()).hexdigest();assert ident['head']=='a3c116fe91d7689d86c5009c7b563289d3cd34cc'
for case in ['short-small','short-large']:
 for mode in ['control','cpu']:
  dest=out/(case+'-'+mode);cmd=['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(dest),'--mode',mode,'--case',case]
  with (out/(case+'-'+mode+'.log')).open('w') as f:subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
  print(case,mode,'passed',flush=True)
  if mode=='cpu':
   for name,args in [('steady-flat.txt',['--text']),('steady-cumulative.txt',['--text','--cum']),('steady-stacks.txt',['--collapsed'])]:
    cmd=['/workspace/issue-481-profilers/unpacked/usr/bin/google-pprof',*args,'--no_strip_temp','--nodecount=200',str(binary),str(dest/'before_measured_turns.cpu')]
    with (dest/name).open('w') as f, (dest/(name+'.stderr')).open('w') as e:subprocess.run(cmd,stdout=f,stderr=e,check=True)
print('initial CPU profiles complete',flush=True)
