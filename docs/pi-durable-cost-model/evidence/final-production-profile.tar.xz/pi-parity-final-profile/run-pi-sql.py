from pathlib import Path
import sys,subprocess,os,json
repo=Path('/workspace/rustX-pi-durable');out=Path('/workspace/issue-481-evidence/pi-parity-final-profile');sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run
prefix='''import {DatabaseSync as ProfileDatabase} from 'node:sqlite';
const sqlCounters = new Map(), statementSql = new WeakMap();
const countSql = (kind,sql) => {const key=kind+'|'+sql;sqlCounters.set(key,(sqlCounters.get(key)??0)+1);};
const probeDb = new ProfileDatabase(':memory:');
const statementPrototype = Object.getPrototypeOf(probeDb.prepare('SELECT 1'));probeDb.close();
for(const method of ['prepare','exec']) {const original=ProfileDatabase.prototype[method];ProfileDatabase.prototype[method]=function(sql,...args){countSql('sql.'+method,sql);const result=Reflect.apply(original,this,[sql,...args]);if(method==='prepare')statementSql.set(result,sql);return result;};}
for(const method of ['run','get','all','iterate']) {const original=statementPrototype[method];statementPrototype[method]=function(...args){countSql('sql.execute.'+method,statementSql.get(this)??'<unknown>');return Reflect.apply(original,this,args);};}
const sqlSnapshots=[];
'''
source=(repo/'benchmarks/runtime/pi-http.mjs').read_text().replace("'./pi-oracle.mjs'",repr(str(repo/'benchmarks/runtime/pi-oracle.mjs')))
source=prefix+source
source=source.replace('for (let i=0;i<history+measured;i++) {','for (let i=0;i<history+measured;i++) {\n  sqlSnapshots.push({turn:i,boundary:"before",counters:[...sqlCounters]});')
source=source.replace('  samples.push({turn:i,','  sqlSnapshots.push({turn:i,boundary:"after",counters:[...sqlCounters]});\n  samples.push({turn:i,')
source=source.replace("await phase('after_cleanup');","await phase('after_cleanup');\nawait writeFile(output+'.sql-counters.json',JSON.stringify(sqlSnapshots));")
script=out/'pi-http-sql-diagnostic.mjs';script.write_text(source)
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])};env['UV_CACHE_DIR']='/workspace/.uv-cache'
for case in ['short-small','short-large']:
 stem=out/(case+'-pi-sql');r=run(['node','--conditions=source',str(script),'/workspace/pi-481',case,str(stem.with_suffix('.json'))],stem,case,env,repo/'test-support/fake-provider');assert r['accepted'],r.get('error');print(case,'Pi SQL passed',flush=True)
