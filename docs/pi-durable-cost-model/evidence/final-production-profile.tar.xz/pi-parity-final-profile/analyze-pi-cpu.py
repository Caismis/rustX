import json,collections
from pathlib import Path
root=Path(__file__).resolve().parent
out={'scope':'V8 main-isolate timed stack samples; includes idle and inspector startup/stop overhead. Not CPU signal samples, not all-thread CPU, not a cross-engine percentage comparison. Each sample classified once by stack ancestry. Native work inside SQLite/transport stays in its calling stack category; program/GC remain explicit.'}
for case in ['short-small','short-large']:
 data=json.loads((root/(case+'-pi-cpu.json.cpuprofile')).read_text()); nodes={n['id']:n for n in data['nodes']}; parents={c:n['id'] for n in data['nodes'] for c in n.get('children',[])}; categories=collections.Counter(); leaves=collections.Counter()
 for node,delta in zip(data['samples'],data['timeDeltas']):
  frame=nodes[node]['callFrame']; leaves[(frame['functionName'],frame['url'],frame['lineNumber'])]+=delta
  stack=[]; at=node
  while at in nodes:
   stack.append(nodes[at]['callFrame']); at=parents.get(at)
  urls=[f['url'] for f in stack]
  if frame['functionName'] in ['(idle)','(program)','(garbage collector)']: category=frame['functionName']
  elif any(u=='node:inspector' for u in urls): category='inspector overhead'
  elif any(f['functionName']=='beforeRequest' and 'pi-http-diagnostic.mjs' in f['url'] for f in stack): category='driver capture/validation including native context API'
  elif any(f['functionName'] in ['processSample','footprint'] and 'pi-http-diagnostic.mjs' in f['url'] for f in stack): category='driver counters/footprint'
  elif any('/packages/durable/src/storage/sqlite/' in u for u in urls): category='Pi SQLite stack'
  elif any('/packages/' in u for u in urls): category='other Pi package stack'
  elif any('pi-http-diagnostic.mjs' in u for u in urls): category='other driver stack'
  else: category='runtime/unassigned'
  categories[category]+=delta
 out[case]={'profile_elapsed_us':data['endTime']-data['startTime'],'sampled_time_us':sum(data['timeDeltas']),'disjoint_stack_time_us':dict(categories),'top_leaf_time_us':[{'function':f,'url':u,'zero_based_line':l,'us':v} for (f,u,l),v in leaves.most_common(30)]}
(root/'pi-cpu-attribution.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({k:{n:v for n,v in s.items() if n!='top_leaf_time_us'} for k,s in out.items() if isinstance(s,dict)},indent=2))
