from pathlib import Path
import sys,subprocess,os,json,hashlib
repo=Path('/workspace/rustX-pi-durable');out=Path('/workspace/issue-481-evidence/pi-parity-final-profile');sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run
source=(repo/'benchmarks/runtime/pi-http.mjs').read_text().replace("'./pi-oracle.mjs'",repr(str(repo/'benchmarks/runtime/pi-oracle.mjs')))
source="import {Session as InspectorSession} from 'node:inspector/promises';\n"+source
source=source.replace('const samples = [];',"const samples = [];\nconst inspector = new InspectorSession(); inspector.connect();\nawait inspector.post('Profiler.enable');\nawait inspector.post('Profiler.setSamplingInterval',{interval:1000});\nlet cpuProfile;\n")
source=source.replace('for (let i=0;i<history+measured;i++) {','for (let i=0;i<history+measured;i++) {\n  if(i===history) await inspector.post(\'Profiler.start\');')
source=source.replace("await phase('after_turns');","cpuProfile = (await inspector.post('Profiler.stop')).profile; inspector.disconnect();\nawait phase('after_turns');")
source=source.replace("await phase('after_cleanup');","await phase('after_cleanup');\nawait writeFile(output+'.cpuprofile',JSON.stringify(cpuProfile));")
script=out/'pi-http-diagnostic.mjs';script.write_text(source)
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])};env['UV_CACHE_DIR']='/workspace/.uv-cache'
for case in ['short-small','short-large']:
 stem=out/(case+'-pi-cpu');result=run(['node','--conditions=source',str(script),'/workspace/pi-481',case,str(stem.with_suffix('.json'))],stem,case,env,repo/'test-support/fake-provider');assert result['accepted'],result.get('error')
 subprocess.run(['node',str(repo/'benchmarks/runtime/compare-http.mjs'),str(out/(case+'-cpu')/'sample.json'),str(stem.with_suffix('.json')),str(out/(case+'-pi-profile-comparison.json'))],check=True)
 print(case,'Pi CPU and ordered pair passed',flush=True)
(out/'pi-profile-identity.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/pi-481',text=True).strip(),'node':subprocess.check_output(['node','--version'],text=True).strip(),'original_harness_sha256':hashlib.sha256((repo/'benchmarks/runtime/pi-http.mjs').read_bytes()).hexdigest(),'diagnostic_harness_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'scope':'Diagnostic V8 timed stack samples, including idle/native boundaries; not equivalent to gperftools CPU signals and not headline CPU. Original product self CPU available in sample phase counters. Production Pi code unchanged. Inspector starts after seeding, stops before after_turns endpoint; profile output follows cleanup counters. No artificial delay.'},indent=2)+'\n')
