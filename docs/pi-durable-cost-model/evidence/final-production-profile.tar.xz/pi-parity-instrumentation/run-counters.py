from pathlib import Path
import os,sys,json,hashlib,subprocess,shutil
repo=Path('/workspace/rustX-pi-parity-diagnostic');root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run,TEST
rows=[json.loads(s) for s in (root/'build.jsonl').read_text().splitlines() if s.startswith('{')]
artifact=next(r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='conformance')
assert not artifact['fresh'];assert artifact['target']['src_path']==str(repo/'tests/conformance/main.rs')
binary=root/'conformance';shutil.copy2(artifact['executable'],binary)
(root/'diagnostic.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=repo))
identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'patch_sha256':hashlib.sha256((root/'diagnostic.patch').read_bytes()).hexdigest(),'scope':'DIAGNOSTIC ONLY: mutex counters and snapshots of cumulative maps; instrumented rusqlite copy. Not headline performance. Counts cover all product threads plus benchmark validation reads in each turn interval. Explicit API prepare attempts exclude SQLite internal reprepare; sqlite.step counts row steps, execute counts first step after reset. Driver snapshots/evidence follow or surround turn intervals and are not subtracted from process CPU.'}
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])};env['UV_CACHE_DIR']='/workspace/.uv-cache'
for case in ['short-small','short-large']:
 stem=root/case;result=run([str(binary),TEST,'--exact','--ignored','--nocapture'],stem,case,env|{'RUSTX_BENCH_CASE':case,'RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json'))},repo/'test-support/fake-provider');assert result['accepted'],result.get('error')
 subprocess.run(['node',str(repo/'benchmarks/runtime/compare-http.mjs'),str(stem.with_suffix('.json')),str(Path('/workspace/issue-481-evidence/pi-parity-final-profile')/(case+'-pi-sql.json')),str(root/(case+'-comparison.json'))],check=True)
 print(case,'diagnostic full oracles and pair equality passed',flush=True)
