import json,collections
from pathlib import Path
root=Path(__file__).resolve().parent; report={}
for case,history in [('short-small',8),('short-large',64)]:
 raw=json.loads((root/(case+'.cost-counters.json')).read_text()); turns=collections.defaultdict(dict)
 for point in raw: turns[point['turn']][point['boundary']]={k:(n,b,m) for k,n,b,m in point['counters']}
 total=collections.Counter();byte_total=collections.Counter(); per_turn=[]; source_max={}
 for turn,points in sorted(turns.items()):
  before,after=points['before'],points['after']; delta={k:(v[0]-before.get(k,(0,0,0))[0],v[1]-before.get(k,(0,0,0))[1]) for k,v in after.items()};delta={k:v for k,v in delta.items() if v!=(0,0)}
  if turn<history:continue
  total.update({k:v[0] for k,v in delta.items()});byte_total.update({k:v[1] for k,v in delta.items()});per_turn.append({'turn':turn,'source':{k:{'count':v[0],'bytes':v[1]} for k,v in delta.items() if not k.startswith('sql.')},'sql':{prefix:sum(v[0] for k,v in delta.items() if k.startswith(prefix+'|')) for prefix in ['sql.prepare','sql.execute','sql.step']}})
  for k,v in after.items():
   if k.startswith('source.encoded|'):source_max[k]=max(source_max.get(k,0),v[2])
 report[case]={'measured_turns':len(per_turn),'per_turn':per_turn,'source_totals':{k:{'count':v,'bytes':byte_total[k]} for k,v in total.items() if not k.startswith('sql.')},'source_max_encoded_bytes_including_seed':source_max,'sql_totals':{prefix:sum(v for k,v in total.items() if k.startswith(prefix+'|')) for prefix in ['sql.prepare','sql.execute','sql.step']},'top_prepares':[{'sql':k.split('|',1)[1],'count':v} for k,v in total.most_common() if k.startswith('sql.prepare|')][:80], 'top_executions':[{'sql':k.split('|',1)[1],'count':v} for k,v in total.most_common() if k.startswith('sql.execute|')][:80]}
(root/'counter-summary.json').write_text(json.dumps(report,indent=2)+'\n')
for case,s in report.items():
 print(case,s['sql_totals'],s['source_totals']);print('top prepares',s['top_prepares'][:15])
