from pathlib import Path
import shutil
root=Path('/workspace/issue-481-evidence/pi-parity-instrumentation');dep=root/'rusqlite';repo=Path('/workspace/rustX-pi-parity-diagnostic')
(dep/'src/cost_profile.rs').write_text('''//! Diagnostic-only fork counters. Never used in headline builds.
use std::collections::BTreeMap;
use std::sync::{LazyLock,Mutex};
static COUNTERS: LazyLock<Mutex<BTreeMap<String,(u64,u64,u64)>>> = LazyLock::new(|| Mutex::new(BTreeMap::new()));
pub fn record(key: &str, bytes: u64) {
 let mut counters=COUNTERS.lock().unwrap();
 let value=counters.entry(key.to_owned()).or_default(); value.0+=1; value.1+=bytes; value.2=value.2.max(bytes);
}
pub fn snapshot()->Vec<(String,u64,u64,u64)> {
 COUNTERS.lock().unwrap().iter().map(|(k,(n,bytes,max))|(k.clone(),*n,*bytes,*max)).collect()
}
''')
p=dep/'src/lib.rs';s=p.read_text();i=s.index('\nmod cache;') if '\nmod cache;' in s else s.index('\nmod backup;');s=s[:i]+'\npub mod cost_profile;\n'+s[i:];p.write_text(s)
p=dep/'src/inner_connection.rs';s=p.read_text();needle='    ) -> Result<(Statement<\'a>, usize)> {\n';assert needle in s;s=s.replace(needle,needle+'        crate::cost_profile::record(&format!("sql.prepare|{}",sql),sql.len() as u64);\n',1);p.write_text(s)
p=dep/'src/raw_statement.rs';s=p.read_text().replace('pub struct RawStatement {','pub struct RawStatement {\n    cost_active: std::cell::Cell<bool>,').replace('            ptr: stmt,','            ptr: stmt,\n            cost_active: std::cell::Cell::new(false),',1)
s=s.replace('    pub fn step(&self) -> c_int {','    pub fn step(&self) -> c_int {\n        if let Some(sql) = self.sql() {\n            let sql=sql.to_string_lossy();\n            crate::cost_profile::record(&format!("sql.step|{}",sql),0);\n            if !self.cost_active.replace(true) { crate::cost_profile::record(&format!("sql.execute|{}",sql),0); }\n        }',1).replace('    pub fn reset(&self) -> c_int {','    pub fn reset(&self) -> c_int {\n        self.cost_active.set(false);',1);p.write_text(s)
p=repo/'Cargo.toml';s=p.read_text();assert '[patch.crates-io]' not in s;p.write_text(s+'\n# Diagnostic checkout only; never a production dependency change.\n[patch.crates-io]\nrusqlite = { path = "/workspace/issue-481-evidence/pi-parity-instrumentation/rusqlite" }\n')
p=repo/'src/runtime/read_layout.rs';s=p.read_text();needle='        let mut layout = Layout::unindexed();\n';assert needle in s;s=s.replace(needle,'        rusqlite::cost_profile::record(&format!("source.new|{}",std::any::type_name::<T>()),0);\n'+needle,1)
needle='        layout.initialize_index(layout.written <= MEMORY_INDEX_BYTES as u64)?;';s=s.replace(needle,'        rusqlite::cost_profile::record(&format!("source.encoded|{}",std::any::type_name::<T>()),layout.written);\n        rusqlite::cost_profile::record("source.parse_bytes",layout.written);\n'+needle,1)
needle="    fn initialize_index(&mut self, memory: bool) -> Result<(), &'static str> {";s=s.replace(needle,needle+'\n        rusqlite::cost_profile::record(if memory {"source.small_index"} else {"source.sqlite_index"},self.written);',1)
needle='    ) -> std::io::Result<u64> {\n        let file = self.layout.bytes.reader';s=s.replace(needle,'    ) -> std::io::Result<u64> {\n        rusqlite::cost_profile::record("source.copy_original_bytes",self.layout.written);\n        let file = self.layout.bytes.reader',1)
needle='            let field = FieldMetadata {';s=s.replace(needle,'            rusqlite::cost_profile::record("source.geometry_visit",node.end-node.start);\n'+needle,1);p.write_text(s)
p=repo/'src/durable/sqlite/observation_request.rs';s=p.read_text();needle='    let source =\n        crate::runtime::read_layout::SeekableObservationSource::new(value).map_err(storage)?;';assert needle in s;s=s.replace(needle,'    rusqlite::cost_profile::record(&format!("state.index|{kind}"),0);\n'+needle,1);p.write_text(s)
p=repo/'tests/conformance/agent_loop/runtime_benchmark.rs';s=p.read_text();needle='    let mut samples = Vec::new();\n';s=s.replace(needle,needle+'    let mut cost_counters = Vec::new();\n',1);needle='        let began = Instant::now();\n        driver.submit';s=s.replace(needle,'        cost_counters.push(json!({"turn":turn,"boundary":"before","counters":rusqlite::cost_profile::snapshot()}));\n'+needle,1);needle='        samples.push(json!({"turn":turn';s=s.replace(needle,'        cost_counters.push(json!({"turn":turn,"boundary":"after","counters":rusqlite::cost_profile::snapshot()}));\n'+needle,1);needle='    lifecycle_sample(&mut lifecycle, "after_cleanup", lifecycle_began);';s=s.replace(needle,needle+'\n    std::fs::write(output.with_extension("cost-counters.json"),serde_json::to_vec(&cost_counters).unwrap()).unwrap();',1);p.write_text(s)
print('Diagnostic-only fork and Source/SQL/per-turn counters installed')
