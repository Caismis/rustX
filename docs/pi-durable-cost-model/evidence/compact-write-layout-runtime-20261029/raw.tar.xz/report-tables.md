# Compact write layout performance evidence

Fresh Rust comparison: five interleaved pairs per cell. Historical Pi/DeepSeek rows are fixed, separate batches; their ratios are ratios of medians, not paired results.

| Mode | Case | Paired median wall % [min,max] | Full CPU % | Full write bytes % | Sample anon PSS % | Sample RSS % |
|---|---|---:|---:|---:|---:|---:|
| no-live-subscriber | short-small | -8.899 [-46.731,0.589] | -7.634 | -2.505 | 0.404 | 1.047 |
| no-live-subscriber | short-large | -29.348 [-46.085,12.973] | -5.276 | -2.160 | -0.232 | 0.217 |
| no-live-subscriber | stream | -1.364 [-1.485,0.581] | -7.143 | -2.844 | 0.336 | 0.992 |
| no-live-subscriber | large | -11.346 [-23.207,6.327] | 0.000 | -3.217 | -0.849 | 0.359 |
| no-live-subscriber | tool | 5.754 [-12.079,37.760] | 0.000 | -3.652 | 0.079 | 0.917 |
| no-live-subscriber | cancel | 2.327 [-21.880,8.546] | -5.882 | -3.315 | 0.164 | 0.819 |
| live-subscriber | short-small | 1.273 [-10.312,54.895] | -1.351 | -2.515 | 0.024 | 0.450 |
| live-subscriber | short-large | -5.091 [-39.506,79.386] | -2.193 | -2.200 | -0.111 | 0.333 |
| live-subscriber | stream | -1.215 [-2.649,3.301] | -3.448 | -2.844 | 0.123 | 0.917 |
| live-subscriber | large | 11.062 [-12.253,35.810] | 5.882 | -3.217 | -0.241 | 0.860 |
| live-subscriber | tool | 15.147 [-36.267,41.994] | 6.250 | -3.652 | -0.505 | 0.472 |
| live-subscriber | cancel | 4.835 [-8.339,49.806] | 0.000 | -3.315 | 0.507 | 1.409 |

| Mode | Case | Mean wall / old Pi | Median wall / old Pi | Full CPU / old Pi | Full writes / old Pi |
|---|---|---:|---:|---:|---:|
| no-live-subscriber | short-small | 3.911 | 4.480 | 1.287 | 4.145 |
| no-live-subscriber | short-large | 3.526 | 3.607 | 2.603 | 4.630 |
| no-live-subscriber | stream | 0.910 | 0.910 | 0.236 | 3.727 |
| no-live-subscriber | large | 0.356 | 0.356 | 0.271 | 4.198 |
| no-live-subscriber | tool | 0.456 | 0.456 | 0.270 | 3.737 |
| no-live-subscriber | cancel | 0.358 | 0.358 | 0.262 | 4.403 |
| live-subscriber | short-small | 4.119 | 4.696 | 1.505 | 4.146 |
| live-subscriber | short-large | 4.178 | 5.057 | 2.967 | 4.629 |
| live-subscriber | stream | 0.915 | 0.915 | 0.252 | 3.727 |
| live-subscriber | large | 0.476 | 0.476 | 0.288 | 4.198 |
| live-subscriber | tool | 0.407 | 0.407 | 0.270 | 3.737 |
| live-subscriber | cancel | 0.316 | 0.316 | 0.250 | 4.403 |

Warm measured windows (per-product statistic, then median [minimum,maximum] across five Rust/Pi products; each has 32 measured turns):

| Mode | History | Engine/batch | Mean ms/turn | Median ms/turn | CPU ms/turn | Write bytes/turn |
|---|---:|---|---:|---:|---:|---:|
| no-live-subscriber | 8 | current Rust | 14.179 [8.752,15.365] | 14.046 [7.833,15.110] | 16.562 [10.312,17.500] | 944000.000 [943872.000,944384.000] |
| no-live-subscriber | 8 | fixed old Pi | 3.625 [3.524,4.546] | 3.135 [3.014,3.328] | 7.188 [6.875,9.688] | 224512.000 [224512.000,224512.000] |
| no-live-subscriber | 64 | current Rust | 13.035 [9.599,43.958] | 11.899 [8.800,18.172] | 15.000 [11.250,20.000] | 1132928.000 [1131136.000,1134336.000] |
| no-live-subscriber | 64 | fixed old Pi | 3.697 [3.667,3.911] | 3.299 [3.159,3.524] | 6.250 [5.938,6.875] | 224384.000 [224384.000,224384.000] |
| live-subscriber | 8 | current Rust | 16.204 [13.297,17.491] | 16.059 [12.432,16.542] | 22.500 [18.750,23.750] | 944128.000 [944000.000,944640.000] |
| live-subscriber | 8 | fixed old Pi | 3.934 [3.784,4.165] | 3.420 [3.309,3.699] | 7.500 [7.188,8.438] | 224512.000 [224512.000,224512.000] |
| live-subscriber | 64 | current Rust | 16.668 [10.939,18.134] | 17.906 [9.889,18.488] | 22.500 [15.625,24.688] | 1131904.000 [1131520.000,1133312.000] |
| live-subscriber | 64 | fixed old Pi | 3.989 [3.827,4.233] | 3.541 [3.482,3.679] | 6.875 [6.250,7.188] | 224384.000 [224384.000,224384.000] |

| Live case | Current mean ms/turn | Fixed DS mean ms/turn | Wall ratio | CPU ratio | Measured write ratio |
|---|---:|---:|---:|---:|---:|
| short-small | 16.204 | 15.541 | 1.043 | 1.241 | 43.905 |
| short-large | 16.668 | 15.450 | 1.079 | 1.286 | 52.952 |
| stream | 1588.502 | 1583.218 | 1.003 | 0.467 | 45.429 |
| large | 42.805 | 165.613 | 0.258 | 0.250 | 30.143 |

DeepSeek exit/flush CPU remains separate from measured turns and from Rust full-lifecycle CPU; full DeepSeek process write bytes remain unavailable. The JSON retains the exact wait4 metrics and source-specific limits.

All adverse metrics (including individual fresh paired reversals):

| Comparison | Mode | Case | Metric | Median % or cross-batch ratio | Adverse pairs |
|---|---|---|---|---:|---|
| fresh_paired_rust | no-live-subscriber | short-small | mean_turn_ms | -11.673 | 1:+0.589% |
| fresh_paired_rust | no-live-subscriber | short-small | through_cleanup_self_cpu_ms | -7.634 | 1:+1.575% |
| fresh_paired_rust | no-live-subscriber | short-small | lifecycle_ms | -6.448 | 1:+0.841% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_anon_pss_mib | 0.404 | 0:+0.593%,1:+0.404%,2:+0.523% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_pss_mib | 1.010 | 0:+1.168%,1:+1.038%,2:+1.010%,3:+0.553%,4:+0.312% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_rss_mib | 1.047 | 0:+1.107%,1:+1.047%,2:+1.062%,3:+0.586%,4:+0.295% |
| fresh_paired_rust | no-live-subscriber | short-small | median_measured_turn_ms | -8.899 | 1:+0.589% |
| fresh_paired_rust | no-live-subscriber | short-small | lifecycle_self_cpu_ms | -7.634 | 1:+1.575% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_turn_rss_mib | 0.677 | 0:+1.031%,1:+0.677%,2:+1.623%,3:+0.342%,4:+0.432% |
| fresh_paired_rust | no-live-subscriber | short-small | through_product_exit_wall_ms | -6.245 | 1:+1.037% |
| fresh_paired_rust | no-live-subscriber | short-small | complete_harness_lifecycle_wall_ms | -7.103 | 1:+1.276% |
| fresh_paired_rust | no-live-subscriber | short-large | mean_turn_ms | -33.123 | 3:+13.427% |
| fresh_paired_rust | no-live-subscriber | short-large | turn_cpu_ms_per_turn | -21.311 | 2:+12.281%,3:+16.327% |
| fresh_paired_rust | no-live-subscriber | short-large | through_cleanup_self_cpu_ms | -5.276 | 3:+0.517% |
| fresh_paired_rust | no-live-subscriber | short-large | lifecycle_ms | -14.252 | 3:+0.512% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_anon_pss_mib | -0.232 | 1:+0.171% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_pss_mib | 0.227 | 0:+0.347%,1:+0.486%,2:+0.168%,3:+0.162%,4:+0.227% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_rss_mib | 0.217 | 0:+0.352%,1:+0.503%,2:+0.217%,3:+0.197%,4:+0.201% |
| fresh_paired_rust | no-live-subscriber | short-large | median_measured_turn_ms | -29.348 | 3:+12.973% |
| fresh_paired_rust | no-live-subscriber | short-large | lifecycle_self_cpu_ms | -5.276 | 3:+0.517% |
| fresh_paired_rust | no-live-subscriber | short-large | measured_turn_cpu_ms | -21.311 | 2:+12.281%,3:+16.327% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_turn_rss_mib | 0.511 | 0:+0.592%,1:+0.682%,2:+0.511%,3:+0.167%,4:+0.253% |
| fresh_paired_rust | no-live-subscriber | short-large | through_product_exit_wall_ms | -13.695 | 3:+0.376% |
| fresh_paired_rust | no-live-subscriber | short-large | complete_harness_lifecycle_wall_ms | -13.192 | 3:+0.317% |
| fresh_paired_rust | no-live-subscriber | stream | mean_turn_ms | -1.364 | 1:+0.581% |
| fresh_paired_rust | no-live-subscriber | stream | turn_cpu_ms_per_turn | -12.500 | 1:+6.250% |
| fresh_paired_rust | no-live-subscriber | stream | lifecycle_ms | -1.676 | 1:+0.429% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_anon_pss_mib | 0.336 | 0:+0.049%,1:+0.443%,3:+0.596%,4:+0.336% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_pss_mib | 1.015 | 0:+1.015%,1:+1.262%,2:+0.222%,3:+1.532%,4:+0.886% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_rss_mib | 0.992 | 0:+0.992%,1:+1.246%,2:+0.216%,3:+1.445%,4:+0.875% |
| fresh_paired_rust | no-live-subscriber | stream | median_measured_turn_ms | -1.364 | 1:+0.581% |
| fresh_paired_rust | no-live-subscriber | stream | measured_turn_cpu_ms | -12.500 | 1:+6.250% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_turn_rss_mib | 0.935 | 0:+0.935%,1:+1.151%,2:+0.180%,3:+1.251%,4:+0.597% |
| fresh_paired_rust | no-live-subscriber | stream | through_product_exit_wall_ms | -1.819 | 1:+0.251% |
| fresh_paired_rust | no-live-subscriber | stream | complete_harness_lifecycle_wall_ms | -2.978 | 1:+0.345% |
| fresh_paired_rust | no-live-subscriber | large | mean_turn_ms | -11.346 | 1:+6.327% |
| fresh_paired_rust | no-live-subscriber | large | through_cleanup_self_cpu_ms | 0.000 | 0:+6.667%,1:+6.667% |
| fresh_paired_rust | no-live-subscriber | large | lifecycle_ms | -2.366 | 0:+0.928%,1:+7.025% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_anon_pss_mib | -0.849 | 3:+0.062% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_pss_mib | 0.364 | 0:+0.364%,1:+0.188%,2:+0.718%,3:+0.978%,4:+0.120% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_rss_mib | 0.359 | 0:+0.359%,1:+0.163%,2:+0.659%,3:+0.880%,4:+0.161% |
| fresh_paired_rust | no-live-subscriber | large | median_measured_turn_ms | -11.346 | 1:+6.327% |
| fresh_paired_rust | no-live-subscriber | large | lifecycle_self_cpu_ms | 0.000 | 0:+6.667%,1:+6.667% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_turn_rss_mib | 0.124 | 0:+0.124%,2:+0.429%,3:+0.938% |
| fresh_paired_rust | no-live-subscriber | large | through_product_exit_wall_ms | -0.546 | 0:+0.686%,1:+7.727% |
| fresh_paired_rust | no-live-subscriber | large | complete_harness_lifecycle_wall_ms | -3.021 | 1:+7.123% |
| fresh_paired_rust | no-live-subscriber | tool | mean_turn_ms | 5.754 | 0:+5.754%,3:+37.760%,4:+26.550% |
| fresh_paired_rust | no-live-subscriber | tool | turn_cpu_ms_per_turn | 25.000 | 1:+25.000%,3:+75.000%,4:+66.667% |
| fresh_paired_rust | no-live-subscriber | tool | through_cleanup_self_cpu_ms | 0.000 | 3:+5.556% |
| fresh_paired_rust | no-live-subscriber | tool | lifecycle_ms | 0.275 | 1:+0.275%,3:+4.113%,4:+0.625% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_anon_pss_mib | 0.079 | 2:+0.079%,3:+1.019%,4:+1.016% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_pss_mib | 0.944 | 0:+0.944%,2:+0.758%,3:+1.209%,4:+1.167% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_rss_mib | 0.917 | 0:+0.917%,2:+0.676%,3:+1.199%,4:+1.197% |
| fresh_paired_rust | no-live-subscriber | tool | median_measured_turn_ms | 5.754 | 0:+5.754%,3:+37.760%,4:+26.550% |
| fresh_paired_rust | no-live-subscriber | tool | lifecycle_self_cpu_ms | 0.000 | 3:+5.556% |
| fresh_paired_rust | no-live-subscriber | tool | measured_turn_cpu_ms | 25.000 | 1:+25.000%,3:+75.000%,4:+66.667% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_turn_rss_mib | 0.635 | 0:+0.902%,2:+0.635%,3:+0.550%,4:+0.895% |
| fresh_paired_rust | no-live-subscriber | tool | through_product_exit_wall_ms | -0.096 | 3:+2.641%,4:+0.730% |
| fresh_paired_rust | no-live-subscriber | tool | complete_harness_lifecycle_wall_ms | 0.334 | 0:+0.681%,3:+0.862%,4:+0.334% |
| fresh_paired_rust | no-live-subscriber | cancel | mean_turn_ms | 2.327 | 0:+2.327%,2:+8.546%,3:+6.143% |
| fresh_paired_rust | no-live-subscriber | cancel | turn_cpu_ms_per_turn | 25.000 | 0:+33.333%,2:+33.333%,3:+25.000% |
| fresh_paired_rust | no-live-subscriber | cancel | through_cleanup_self_cpu_ms | -5.882 | 0:+13.333%,2:+13.333% |
| fresh_paired_rust | no-live-subscriber | cancel | lifecycle_ms | -1.501 | 0:+10.543%,2:+10.671% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_anon_pss_mib | 0.164 | 0:+1.999%,2:+0.013%,3:+0.164%,4:+0.338% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_pss_mib | 0.826 | 0:+2.002%,1:+0.826%,2:+0.511%,3:+0.561%,4:+1.152% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_rss_mib | 0.819 | 0:+1.906%,1:+0.819%,2:+0.515%,3:+0.560%,4:+1.076% |
| fresh_paired_rust | no-live-subscriber | cancel | median_measured_turn_ms | 2.327 | 0:+2.327%,2:+8.546%,3:+6.143% |
| fresh_paired_rust | no-live-subscriber | cancel | lifecycle_self_cpu_ms | -5.882 | 0:+13.333%,2:+13.333% |
| fresh_paired_rust | no-live-subscriber | cancel | measured_turn_cpu_ms | 25.000 | 0:+33.333%,2:+33.333%,3:+25.000% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_turn_rss_mib | 0.458 | 0:+1.454%,1:+0.458%,2:+0.362%,3:+0.285%,4:+0.954% |
| fresh_paired_rust | no-live-subscriber | cancel | through_product_exit_wall_ms | -1.749 | 0:+12.422%,2:+12.904% |
| fresh_paired_rust | no-live-subscriber | cancel | complete_harness_lifecycle_wall_ms | -1.620 | 0:+14.036%,2:+15.412% |
| fresh_paired_rust | live-subscriber | short-small | mean_turn_ms | -0.705 | 1:+10.822%,4:+48.651% |
| fresh_paired_rust | live-subscriber | short-small | turn_cpu_ms_per_turn | 0.000 | 1:+12.121%,4:+43.396% |
| fresh_paired_rust | live-subscriber | short-small | through_cleanup_self_cpu_ms | -1.351 | 1:+4.895%,4:+26.230% |
| fresh_paired_rust | live-subscriber | short-small | lifecycle_ms | -1.575 | 1:+3.607%,4:+22.755% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_anon_pss_mib | 0.024 | 1:+0.894%,3:+0.283%,4:+0.024% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_pss_mib | 0.445 | 0:+0.364%,1:+0.880%,2:+0.014%,3:+0.761%,4:+0.445% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_rss_mib | 0.450 | 0:+0.335%,1:+0.828%,2:+0.065%,3:+0.719%,4:+0.450% |
| fresh_paired_rust | live-subscriber | short-small | median_measured_turn_ms | 1.273 | 1:+4.198%,3:+1.273%,4:+54.895% |
| fresh_paired_rust | live-subscriber | short-small | lifecycle_self_cpu_ms | -1.351 | 1:+4.895%,4:+26.230% |
| fresh_paired_rust | live-subscriber | short-small | measured_turn_cpu_ms | 0.000 | 1:+12.121%,4:+43.396% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_turn_rss_mib | 0.437 | 0:+0.162%,1:+0.765%,3:+0.593%,4:+0.437% |
| fresh_paired_rust | live-subscriber | short-small | through_product_exit_wall_ms | -1.825 | 1:+3.287%,4:+21.526% |
| fresh_paired_rust | live-subscriber | short-small | complete_harness_lifecycle_wall_ms | -2.352 | 1:+3.332%,4:+18.768% |
| fresh_paired_rust | live-subscriber | short-large | mean_turn_ms | -11.444 | 2:+69.185% |
| fresh_paired_rust | live-subscriber | short-large | turn_cpu_ms_per_turn | -12.195 | 2:+64.583% |
| fresh_paired_rust | live-subscriber | short-large | through_cleanup_self_cpu_ms | -2.193 | 2:+7.416% |
| fresh_paired_rust | live-subscriber | short-large | lifecycle_ms | -1.736 | 2:+6.800% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_anon_pss_mib | -0.111 | 0:+0.395%,4:+0.177% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_pss_mib | 0.352 | 0:+0.848%,1:+0.352%,4:+0.365% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_rss_mib | 0.333 | 0:+0.869%,1:+0.355%,4:+0.333% |
| fresh_paired_rust | live-subscriber | short-large | median_measured_turn_ms | -5.091 | 2:+79.386% |
| fresh_paired_rust | live-subscriber | short-large | lifecycle_self_cpu_ms | -2.193 | 2:+7.416% |
| fresh_paired_rust | live-subscriber | short-large | measured_turn_cpu_ms | -12.195 | 2:+64.583% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_turn_rss_mib | -0.046 | 0:+0.916%,1:+0.264% |
| fresh_paired_rust | live-subscriber | short-large | through_product_exit_wall_ms | -1.994 | 2:+6.291% |
| fresh_paired_rust | live-subscriber | short-large | complete_harness_lifecycle_wall_ms | -2.159 | 2:+6.120% |
| fresh_paired_rust | live-subscriber | stream | mean_turn_ms | -1.215 | 4:+3.301% |
| fresh_paired_rust | live-subscriber | stream | turn_cpu_ms_per_turn | -6.667 | 4:+33.333% |
| fresh_paired_rust | live-subscriber | stream | through_cleanup_self_cpu_ms | -3.448 | 4:+11.538% |
| fresh_paired_rust | live-subscriber | stream | lifecycle_ms | -0.296 | 4:+3.829% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_anon_pss_mib | 0.123 | 0:+1.471%,2:+0.123%,4:+1.922% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_pss_mib | 0.929 | 0:+1.320%,1:+0.271%,2:+0.929%,3:+0.400%,4:+1.993% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_rss_mib | 0.917 | 0:+1.303%,1:+0.228%,2:+0.917%,3:+0.380%,4:+1.942% |
| fresh_paired_rust | live-subscriber | stream | median_measured_turn_ms | -1.215 | 4:+3.301% |
| fresh_paired_rust | live-subscriber | stream | lifecycle_self_cpu_ms | -3.448 | 4:+11.538% |
| fresh_paired_rust | live-subscriber | stream | measured_turn_cpu_ms | -6.667 | 4:+33.333% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_turn_rss_mib | 0.633 | 0:+1.149%,1:+0.027%,2:+0.633%,3:+0.019%,4:+1.626% |
| fresh_paired_rust | live-subscriber | stream | through_product_exit_wall_ms | -0.874 | 4:+3.967% |
| fresh_paired_rust | live-subscriber | stream | complete_harness_lifecycle_wall_ms | -1.113 | 4:+3.910% |
| fresh_paired_rust | live-subscriber | large | mean_turn_ms | 11.062 | 0:+17.855%,1:+4.589%,3:+11.062%,4:+35.810% |
| fresh_paired_rust | live-subscriber | large | turn_cpu_ms_per_turn | 0.000 | 0:+25.000%,4:+25.000% |
| fresh_paired_rust | live-subscriber | large | through_cleanup_self_cpu_ms | 5.882 | 0:+13.333%,2:+5.882%,4:+12.500% |
| fresh_paired_rust | live-subscriber | large | lifecycle_ms | 6.489 | 0:+9.065%,1:+3.328%,2:+7.690%,3:+0.156%,4:+6.489% |
| fresh_paired_rust | live-subscriber | large | max_sampled_anon_pss_mib | -0.241 | 1:+2.385%,2:+0.582% |
| fresh_paired_rust | live-subscriber | large | max_sampled_pss_mib | 0.946 | 1:+2.547%,2:+0.946%,3:+0.351%,4:+1.055% |
| fresh_paired_rust | live-subscriber | large | max_sampled_rss_mib | 0.860 | 1:+2.515%,2:+0.860%,3:+0.417%,4:+1.053% |
| fresh_paired_rust | live-subscriber | large | median_measured_turn_ms | 11.062 | 0:+17.855%,1:+4.589%,3:+11.062%,4:+35.810% |
| fresh_paired_rust | live-subscriber | large | lifecycle_self_cpu_ms | 5.882 | 0:+13.333%,2:+5.882%,4:+12.500% |
| fresh_paired_rust | live-subscriber | large | measured_turn_cpu_ms | 0.000 | 0:+25.000%,4:+25.000% |
| fresh_paired_rust | live-subscriber | large | max_sampled_turn_rss_mib | 0.436 | 1:+2.063%,2:+0.436%,3:+0.376%,4:+0.748% |
| fresh_paired_rust | live-subscriber | large | through_product_exit_wall_ms | 6.983 | 0:+9.506%,1:+2.039%,2:+7.863%,4:+6.983% |
| fresh_paired_rust | live-subscriber | large | complete_harness_lifecycle_wall_ms | 6.344 | 0:+11.067%,1:+2.377%,2:+6.553%,4:+6.344% |
| fresh_paired_rust | live-subscriber | tool | mean_turn_ms | 15.147 | 0:+39.566%,2:+15.147%,3:+41.994% |
| fresh_paired_rust | live-subscriber | tool | turn_cpu_ms_per_turn | 25.000 | 0:+75.000%,2:+25.000%,3:+40.000% |
| fresh_paired_rust | live-subscriber | tool | through_cleanup_self_cpu_ms | 6.250 | 0:+11.111%,2:+6.250%,3:+17.647% |
| fresh_paired_rust | live-subscriber | tool | lifecycle_ms | -0.988 | 0:+8.804%,3:+4.877% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_anon_pss_mib | -0.505 | 1:+0.121%,2:+0.153% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_pss_mib | 0.402 | 0:+0.125%,1:+0.481%,2:+0.762%,3:+0.402% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_rss_mib | 0.472 | 0:+0.137%,1:+0.477%,2:+0.848%,3:+0.472% |
| fresh_paired_rust | live-subscriber | tool | median_measured_turn_ms | 15.147 | 0:+39.566%,2:+15.147%,3:+41.994% |
| fresh_paired_rust | live-subscriber | tool | lifecycle_self_cpu_ms | 6.250 | 0:+11.111%,2:+6.250%,3:+17.647% |
| fresh_paired_rust | live-subscriber | tool | measured_turn_cpu_ms | 25.000 | 0:+75.000%,2:+25.000%,3:+40.000% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_turn_rss_mib | 0.127 | 0:+0.279%,1:+0.127%,2:+0.551%,3:+0.101% |
| fresh_paired_rust | live-subscriber | tool | through_product_exit_wall_ms | 0.189 | 0:+8.847%,2:+0.189%,3:+4.190% |
| fresh_paired_rust | live-subscriber | tool | complete_harness_lifecycle_wall_ms | -0.433 | 0:+7.424%,3:+4.883% |
| fresh_paired_rust | live-subscriber | cancel | mean_turn_ms | 4.835 | 0:+49.806%,1:+20.610%,3:+4.835% |
| fresh_paired_rust | live-subscriber | cancel | turn_cpu_ms_per_turn | 33.333 | 0:+33.333%,1:+33.333%,2:+33.333% |
| fresh_paired_rust | live-subscriber | cancel | through_cleanup_self_cpu_ms | 0.000 | 0:+21.429% |
| fresh_paired_rust | live-subscriber | cancel | lifecycle_ms | 0.320 | 0:+13.477%,3:+0.320%,4:+2.142% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_anon_pss_mib | 0.507 | 0:+1.916%,3:+0.793%,4:+0.507% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_pss_mib | 1.349 | 0:+1.948%,1:+0.662%,2:+0.565%,3:+1.568%,4:+1.349% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_rss_mib | 1.409 | 0:+1.913%,1:+0.727%,2:+0.565%,3:+1.521%,4:+1.409% |
| fresh_paired_rust | live-subscriber | cancel | median_measured_turn_ms | 4.835 | 0:+49.806%,1:+20.610%,3:+4.835% |
| fresh_paired_rust | live-subscriber | cancel | lifecycle_self_cpu_ms | 0.000 | 0:+21.429% |
| fresh_paired_rust | live-subscriber | cancel | measured_turn_cpu_ms | 33.333 | 0:+33.333%,1:+33.333%,2:+33.333% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_turn_rss_mib | 1.119 | 0:+2.005%,1:+0.465%,2:+0.343%,3:+1.577%,4:+1.119% |
| fresh_paired_rust | live-subscriber | cancel | through_product_exit_wall_ms | 1.046 | 0:+15.905%,3:+1.046%,4:+3.907% |
| fresh_paired_rust | live-subscriber | cancel | complete_harness_lifecycle_wall_ms | 2.018 | 0:+16.302%,3:+2.018%,4:+5.027% |
| prior_pi | no-live-subscriber | short-small | closed_allocated_bytes | 40.881 | cross-batch |
| prior_pi | no-live-subscriber | short-small | closed_logical_bytes | 40.785 | cross-batch |
| prior_pi | no-live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 1.835 | cross-batch |
| prior_pi | no-live-subscriber | short-small | lifecycle_ms | 2.799 | cross-batch |
| prior_pi | no-live-subscriber | short-small | lifecycle_self_cpu_ms | 2.373 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_anon_pss_mib | 1.126 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_pss_mib | 1.485 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_rss_mib | 1.085 | cross-batch |
| prior_pi | no-live-subscriber | short-small | mean_turn_ms | 3.911 | cross-batch |
| prior_pi | no-live-subscriber | short-small | measured_turn_cpu_ms | 2.304 | cross-batch |
| prior_pi | no-live-subscriber | short-small | measured_turn_write_bytes | 4.205 | cross-batch |
| prior_pi | no-live-subscriber | short-small | median_measured_turn_ms | 4.480 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_process_write_bytes | 4.145 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_process_write_mib | 4.145 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_self_cpu_ms | 1.287 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_product_exit_wall_ms | 1.833 | cross-batch |
| prior_pi | no-live-subscriber | short-small | turn_cpu_ms_per_turn | 2.304 | cross-batch |
| prior_pi | no-live-subscriber | short-small | turn_write_bytes_per_turn | 4.205 | cross-batch |
| prior_pi | no-live-subscriber | short-large | closed_allocated_bytes | 41.300 | cross-batch |
| prior_pi | no-live-subscriber | short-large | closed_logical_bytes | 41.236 | cross-batch |
| prior_pi | no-live-subscriber | short-large | complete_harness_lifecycle_wall_ms | 3.317 | cross-batch |
| prior_pi | no-live-subscriber | short-large | lifecycle_ms | 4.400 | cross-batch |
| prior_pi | no-live-subscriber | short-large | lifecycle_self_cpu_ms | 3.707 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_anon_pss_mib | 1.274 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_pss_mib | 1.515 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_rss_mib | 1.201 | cross-batch |
| prior_pi | no-live-subscriber | short-large | mean_turn_ms | 3.526 | cross-batch |
| prior_pi | no-live-subscriber | short-large | measured_turn_cpu_ms | 2.400 | cross-batch |
| prior_pi | no-live-subscriber | short-large | measured_turn_write_bytes | 5.049 | cross-batch |
| prior_pi | no-live-subscriber | short-large | median_measured_turn_ms | 3.607 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_process_write_bytes | 4.630 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_process_write_mib | 4.630 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_self_cpu_ms | 2.603 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_product_exit_wall_ms | 3.398 | cross-batch |
| prior_pi | no-live-subscriber | short-large | turn_cpu_ms_per_turn | 2.400 | cross-batch |
| prior_pi | no-live-subscriber | short-large | turn_write_bytes_per_turn | 5.049 | cross-batch |
| prior_pi | no-live-subscriber | stream | closed_allocated_bytes | 15.531 | cross-batch |
| prior_pi | no-live-subscriber | stream | closed_logical_bytes | 15.430 | cross-batch |
| prior_pi | no-live-subscriber | stream | max_sampled_pss_mib | 1.254 | cross-batch |
| prior_pi | no-live-subscriber | stream | measured_turn_write_bytes | 2.524 | cross-batch |
| prior_pi | no-live-subscriber | stream | through_cleanup_process_write_bytes | 3.727 | cross-batch |
| prior_pi | no-live-subscriber | stream | through_cleanup_process_write_mib | 3.727 | cross-batch |
| prior_pi | no-live-subscriber | stream | turn_write_bytes_per_turn | 2.524 | cross-batch |
| prior_pi | no-live-subscriber | large | closed_allocated_bytes | 10.263 | cross-batch |
| prior_pi | no-live-subscriber | large | closed_logical_bytes | 10.161 | cross-batch |
| prior_pi | no-live-subscriber | large | lifecycle_ms | 1.208 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_anon_pss_mib | 1.082 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_pss_mib | 1.550 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_rss_mib | 1.048 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_turn_rss_mib | 1.044 | cross-batch |
| prior_pi | no-live-subscriber | large | measured_turn_write_bytes | 2.931 | cross-batch |
| prior_pi | no-live-subscriber | large | through_cleanup_process_write_bytes | 4.198 | cross-batch |
| prior_pi | no-live-subscriber | large | through_cleanup_process_write_mib | 4.198 | cross-batch |
| prior_pi | no-live-subscriber | large | turn_write_bytes_per_turn | 2.931 | cross-batch |
| prior_pi | no-live-subscriber | tool | closed_allocated_bytes | 17.406 | cross-batch |
| prior_pi | no-live-subscriber | tool | closed_logical_bytes | 17.284 | cross-batch |
| prior_pi | no-live-subscriber | tool | lifecycle_ms | 1.176 | cross-batch |
| prior_pi | no-live-subscriber | tool | max_sampled_pss_mib | 1.381 | cross-batch |
| prior_pi | no-live-subscriber | tool | max_sampled_turn_rss_mib | 1.059 | cross-batch |
| prior_pi | no-live-subscriber | tool | measured_turn_write_bytes | 2.589 | cross-batch |
| prior_pi | no-live-subscriber | tool | through_cleanup_process_write_bytes | 3.737 | cross-batch |
| prior_pi | no-live-subscriber | tool | through_cleanup_process_write_mib | 3.737 | cross-batch |
| prior_pi | no-live-subscriber | tool | turn_write_bytes_per_turn | 2.589 | cross-batch |
| prior_pi | no-live-subscriber | cancel | closed_allocated_bytes | 12.700 | cross-batch |
| prior_pi | no-live-subscriber | cancel | closed_logical_bytes | 12.569 | cross-batch |
| prior_pi | no-live-subscriber | cancel | lifecycle_ms | 1.183 | cross-batch |
| prior_pi | no-live-subscriber | cancel | max_sampled_pss_mib | 1.404 | cross-batch |
| prior_pi | no-live-subscriber | cancel | max_sampled_turn_rss_mib | 1.039 | cross-batch |
| prior_pi | no-live-subscriber | cancel | measured_turn_write_bytes | 3.015 | cross-batch |
| prior_pi | no-live-subscriber | cancel | through_cleanup_process_write_bytes | 4.403 | cross-batch |
| prior_pi | no-live-subscriber | cancel | through_cleanup_process_write_mib | 4.403 | cross-batch |
| prior_pi | no-live-subscriber | cancel | turn_write_bytes_per_turn | 3.015 | cross-batch |
| prior_pi | live-subscriber | short-small | closed_allocated_bytes | 40.881 | cross-batch |
| prior_pi | live-subscriber | short-small | closed_logical_bytes | 40.785 | cross-batch |
| prior_pi | live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 1.907 | cross-batch |
| prior_pi | live-subscriber | short-small | lifecycle_ms | 2.904 | cross-batch |
| prior_pi | live-subscriber | short-small | lifecycle_self_cpu_ms | 2.704 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_anon_pss_mib | 1.196 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_pss_mib | 1.551 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_rss_mib | 1.127 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_turn_rss_mib | 1.011 | cross-batch |
| prior_pi | live-subscriber | short-small | mean_turn_ms | 4.119 | cross-batch |
| prior_pi | live-subscriber | short-small | measured_turn_cpu_ms | 3.000 | cross-batch |
| prior_pi | live-subscriber | short-small | measured_turn_write_bytes | 4.205 | cross-batch |
| prior_pi | live-subscriber | short-small | median_measured_turn_ms | 4.696 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_process_write_bytes | 4.146 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_process_write_mib | 4.146 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_self_cpu_ms | 1.505 | cross-batch |
| prior_pi | live-subscriber | short-small | through_product_exit_wall_ms | 1.916 | cross-batch |
| prior_pi | live-subscriber | short-small | turn_cpu_ms_per_turn | 3.000 | cross-batch |
| prior_pi | live-subscriber | short-small | turn_write_bytes_per_turn | 4.205 | cross-batch |
| prior_pi | live-subscriber | short-large | closed_allocated_bytes | 41.350 | cross-batch |
| prior_pi | live-subscriber | short-large | closed_logical_bytes | 41.287 | cross-batch |
| prior_pi | live-subscriber | short-large | complete_harness_lifecycle_wall_ms | 3.498 | cross-batch |
| prior_pi | live-subscriber | short-large | lifecycle_ms | 4.640 | cross-batch |
| prior_pi | live-subscriber | short-large | lifecycle_self_cpu_ms | 4.198 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_anon_pss_mib | 1.282 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_pss_mib | 1.520 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_rss_mib | 1.208 | cross-batch |
| prior_pi | live-subscriber | short-large | mean_turn_ms | 4.178 | cross-batch |
| prior_pi | live-subscriber | short-large | measured_turn_cpu_ms | 3.273 | cross-batch |
| prior_pi | live-subscriber | short-large | measured_turn_write_bytes | 5.044 | cross-batch |
| prior_pi | live-subscriber | short-large | median_measured_turn_ms | 5.057 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_process_write_bytes | 4.629 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_process_write_mib | 4.629 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_self_cpu_ms | 2.967 | cross-batch |
| prior_pi | live-subscriber | short-large | through_product_exit_wall_ms | 3.585 | cross-batch |
| prior_pi | live-subscriber | short-large | turn_cpu_ms_per_turn | 3.273 | cross-batch |
| prior_pi | live-subscriber | short-large | turn_write_bytes_per_turn | 5.044 | cross-batch |
| prior_pi | live-subscriber | stream | closed_allocated_bytes | 15.531 | cross-batch |
| prior_pi | live-subscriber | stream | closed_logical_bytes | 15.430 | cross-batch |
| prior_pi | live-subscriber | stream | max_sampled_pss_mib | 1.263 | cross-batch |
| prior_pi | live-subscriber | stream | measured_turn_write_bytes | 2.524 | cross-batch |
| prior_pi | live-subscriber | stream | through_cleanup_process_write_bytes | 3.727 | cross-batch |
| prior_pi | live-subscriber | stream | through_cleanup_process_write_mib | 3.727 | cross-batch |
| prior_pi | live-subscriber | stream | turn_write_bytes_per_turn | 2.524 | cross-batch |
| prior_pi | live-subscriber | large | closed_allocated_bytes | 10.263 | cross-batch |
| prior_pi | live-subscriber | large | closed_logical_bytes | 10.161 | cross-batch |
| prior_pi | live-subscriber | large | lifecycle_ms | 1.186 | cross-batch |
| prior_pi | live-subscriber | large | lifecycle_self_cpu_ms | 1.062 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_anon_pss_mib | 1.093 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_pss_mib | 1.561 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_rss_mib | 1.055 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_turn_rss_mib | 1.052 | cross-batch |
| prior_pi | live-subscriber | large | measured_turn_write_bytes | 2.931 | cross-batch |
| prior_pi | live-subscriber | large | through_cleanup_process_write_bytes | 4.198 | cross-batch |
| prior_pi | live-subscriber | large | through_cleanup_process_write_mib | 4.198 | cross-batch |
| prior_pi | live-subscriber | large | turn_write_bytes_per_turn | 2.931 | cross-batch |
| prior_pi | live-subscriber | tool | closed_allocated_bytes | 17.406 | cross-batch |
| prior_pi | live-subscriber | tool | closed_logical_bytes | 17.284 | cross-batch |
| prior_pi | live-subscriber | tool | lifecycle_ms | 1.169 | cross-batch |
| prior_pi | live-subscriber | tool | max_sampled_pss_mib | 1.370 | cross-batch |
| prior_pi | live-subscriber | tool | max_sampled_turn_rss_mib | 1.057 | cross-batch |
| prior_pi | live-subscriber | tool | measured_turn_write_bytes | 2.589 | cross-batch |
| prior_pi | live-subscriber | tool | through_cleanup_process_write_bytes | 3.737 | cross-batch |
| prior_pi | live-subscriber | tool | through_cleanup_process_write_mib | 3.737 | cross-batch |
| prior_pi | live-subscriber | tool | turn_write_bytes_per_turn | 2.589 | cross-batch |
| prior_pi | live-subscriber | cancel | closed_allocated_bytes | 12.700 | cross-batch |
| prior_pi | live-subscriber | cancel | closed_logical_bytes | 12.569 | cross-batch |
| prior_pi | live-subscriber | cancel | lifecycle_ms | 1.200 | cross-batch |
| prior_pi | live-subscriber | cancel | max_sampled_pss_mib | 1.395 | cross-batch |
| prior_pi | live-subscriber | cancel | max_sampled_turn_rss_mib | 1.038 | cross-batch |
| prior_pi | live-subscriber | cancel | measured_turn_write_bytes | 3.015 | cross-batch |
| prior_pi | live-subscriber | cancel | through_cleanup_process_write_bytes | 4.403 | cross-batch |
| prior_pi | live-subscriber | cancel | through_cleanup_process_write_mib | 4.403 | cross-batch |
| prior_pi | live-subscriber | cancel | turn_write_bytes_per_turn | 3.015 | cross-batch |
| prior_deepseek | live-subscriber | short-small | mean_turn_ms | 1.043 | cross-batch |
| prior_deepseek | live-subscriber | short-small | median_measured_turn_ms | 1.087 | cross-batch |
| prior_deepseek | live-subscriber | short-small | turn_cpu_ms_per_turn | 1.241 | cross-batch |
| prior_deepseek | live-subscriber | short-small | turn_write_bytes_per_turn | 43.905 | cross-batch |
| prior_deepseek | live-subscriber | short-large | mean_turn_ms | 1.079 | cross-batch |
| prior_deepseek | live-subscriber | short-large | median_measured_turn_ms | 1.168 | cross-batch |
| prior_deepseek | live-subscriber | short-large | turn_cpu_ms_per_turn | 1.286 | cross-batch |
| prior_deepseek | live-subscriber | short-large | turn_write_bytes_per_turn | 52.952 | cross-batch |
| prior_deepseek | live-subscriber | stream | mean_turn_ms | 1.003 | cross-batch |
| prior_deepseek | live-subscriber | stream | median_measured_turn_ms | 1.003 | cross-batch |
| prior_deepseek | live-subscriber | stream | turn_write_bytes_per_turn | 45.429 | cross-batch |
| prior_deepseek | live-subscriber | large | turn_write_bytes_per_turn | 30.143 | cross-batch |

- Only the fresh old/new Rust products are interleaved pairs. Pi/DeepSeek use fixed previous batches and separate descriptive ratios of medians; no causal parity or paired confidence claim.
- /proc CPU counters use 100 ticks/s; each cumulative endpoint has 10 ms granularity. This is not profiler sampling.
- A product measured-turn median and a product measured-turn mean are different estimands. Across products we report median and range of those statistics, not pooled turns.
- DeepSeek SDK idle does not await flush/fsync. Native wait4 CPU covers exit/flush and verification separately; full process write_bytes is unavailable, not zero. No equivalent lifecycle ratio is constructed.
- All recorded adverse pairs and all unavailable ratios are retained, including reversals hidden by a favorable group median.

Unavailable ratio records, all per-product values, and reference hashes are retained in report-data.json.
