from pathlib import Path
import subprocess,json,os,datetime,hashlib
repo=Path('/workspace/rustX-pi-durable');out=Path(__file__).resolve().parent;before=Path('/workspace/issue-481-evidence/pi-partial-build/conformance');after=Path('/workspace/issue-481-evidence/pi-parity-qpsg-build/conformance')
identity=json.loads((after.parent/'identity.json').read_text());assert identity['verified'] and identity['head']=='15e7e7125dc34f54a245ea06e95f517d67c9ea53';assert hashlib.file_digest(after.open('rb'),'sha256').hexdigest()==identity['sha256']
processes=subprocess.check_output(['ps','-eo','stat,comm'],text=True);assert not any(line.split()[-1] in ['cargo','rustc','rust-lld'] and not line.split()[0].startswith('Z') for line in processes.splitlines()[1:]),'build active'
(out/'formal-host.json').write_text(json.dumps({'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'uname':list(os.uname()),'affinity':sorted(os.sched_getaffinity(0)),'cpu_quota':Path('/sys/fs/cgroup/cpu.max').read_text(),'memory_limit':Path('/sys/fs/cgroup/memory.max').read_text(),'cpu_tick_hz':os.sysconf('SC_CLK_TCK'),'scope':'Three interleaved exploratory revision pairs, all six runtime cases and four warm/cold append histories. No build/test/profiler/compression overlap. Final Pi non-inferiority requires the separately declared seven-pair criterion.'},indent=2)+'\n')
for name,script,extra in [('runtime','compare-revisions.py',[]),('append-warm','compare-append.py',[]),('append-cold','compare-append.py',['--cold'])]:
 cmd=['python3',str(repo/'benchmarks/runtime'/script),'--before',str(before),'--after',str(after),'--output',str(out/name),'--pairs','3',*extra]
 with (out/(name+'.log')).open('w') as f:subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT,check=True)
 args=['python3',str(repo/'benchmarks/runtime/summarize-comparisons.py'),str(out/name)]+(['--append'] if name.startswith('append') else [])
 with (out/(name+'-summary.json')).open('w') as f:subprocess.run(args,cwd=repo,stdout=f,check=True)
 print(name,'all paired samples passed',flush=True)
print('QPSG stage measurements complete',flush=True)
