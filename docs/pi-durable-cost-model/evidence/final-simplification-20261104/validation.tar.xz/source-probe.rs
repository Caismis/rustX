use rustx::durable::{ConversationStore,SqliteConversationStore};
use rustx::runtime::identity::ConversationId;
use serde_json::{Value,json};
use std::time::Instant;
fn ns(at:Instant)->u64{at.elapsed().as_nanos().try_into().unwrap()}
fn bytes(store:&SqliteConversationStore,start:u64,through:u64,path:&[String])->Vec<u8>{
 let mut result=Vec::new();let mut offset=0;
 loop{let v=store.request_value_read_at(start,through,path,offset,65536).unwrap();assert_eq!(v.end_offset,offset+v.bytes.len() as u64);result.extend(v.bytes);match v.next_offset{Some(next)=>{assert!(next>offset);offset=next;},None=>{assert_eq!(v.readable_end,v.end_offset);break;}}}result
}
fn sample(store:&SqliteConversationStore,start:u64,through:u64)->Value{
 let mut times=Vec::new();let mut original=None;
 for _ in 0..17{
  let at=Instant::now();let header=store.request_summary_header_at(start,through).unwrap();let header_ns=ns(at);
  let at=Instant::now();let page=store.request_field_page_at(start,through,&[],0,32).unwrap();let page_ns=ns(at);
  let at=Instant::now();let raw=bytes(store,start,through,&[]);let range_ns=ns(at);
  let value:Value=serde_json::from_slice(&raw).unwrap();assert_eq!(header.encoded_bytes,raw.len() as u64);assert!(page.next_offset.is_none());assert_eq!(page.fields.len() as u64,page.total);
  for field in &page.fields {let mut selected=&value;for key in &field.path {selected=if selected.is_array(){&selected[key.parse::<usize>().unwrap()]}else{&selected[key]};}let raw=bytes(store,start,through,&field.path);assert_eq!(serde_json::from_slice::<Value>(&raw).unwrap(),*selected);assert_eq!(field.encoded_bytes,raw.len() as u64);}
  let current=json!({"header":header,"page":page,"value":value});if let Some(old)=&original{assert_eq!(old,&current);}else{original=Some(current);}
  times.push(json!({"header_ns":header_ns,"page_ns":page_ns,"range_ns":range_ns}));
 }
 json!({"start":start,"through":through,"timings":times,"view":original.unwrap()})
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let root=std::path::Path::new(&args[1]);let input:Value=serde_json::from_slice(&std::fs::read(root.join("source-input.json")).unwrap()).unwrap();let id=ConversationId::new(input["conversation_id"].as_str().unwrap());let through=input["through"].as_u64().unwrap();
 let store=SqliteConversationStore::open_existing(id.clone(),&root.join("source.sqlite")).unwrap();let samples=input["starts"].as_array().unwrap().iter().map(|v|sample(&store,v.as_u64().unwrap(),through)).collect::<Vec<_>>();drop(store);
 let reopened=SqliteConversationStore::open_existing(id,&root.join("source.sqlite")).unwrap();let reread=sample(&reopened,input["starts"][0].as_u64().unwrap(),through);assert_eq!(reread["view"],samples[0]["view"]);
 println!("{}",json!({"samples":samples,"reopened":reread,"oracle":"passed"}));
}
