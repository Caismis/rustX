"""One fresh two-pair fixed cohort; original shared-load data is retained."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());rows=load(r/'product-commands.json')
assert load(r/'measurements-completed.json')['accepted']
monitor=subprocess.Popen([sys.executable,str(r/'watch-fresh-host.py')],cwd=repo)
for pair,order in enumerate([['before','after'],['after','before']]):
 for side in order:
  while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(1)
  name=f'fresh-ordinary-{pair}-{side}';binary=r/('baseline-build' if side=='before' else 'candidate-build')/'rustx';cmd=[sys.executable,str(r/'capacity-ordinary.py'),'--binary',str(binary),'--output',str(r/name),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16'];row={'family':'ordinary-fresh','pair':pair,'side':side,'directory':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'io_start':Path('/proc/pressure/io').read_text()}
  with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
  row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),io_end=Path('/proc/pressure/io').read_text());rows.append(row);(r/'product-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0 and load(r/name/'completed.json')['accepted']
(r/'fresh-fixed-completed.json').write_text('{"accepted":true}\n');assert monitor.wait(10)==0
