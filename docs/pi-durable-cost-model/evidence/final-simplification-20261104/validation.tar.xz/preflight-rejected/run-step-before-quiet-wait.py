"""Bounded Rust-only interleaved hot and historical-read comparisons per cleanup."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');step,left,right=sys.argv[1:];out=r/step;out.mkdir(exist_ok=False);os.sched_setaffinity(0,[2,8]);rows=[]
def run(name,cmd):
 row={'name':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.stdout')).open('x') as so,(out/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(step,name,p.returncode,flush=True);assert p.returncode==0
assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
for mode in ['no-live-subscriber','live-subscriber']:
 run(mode,[sys.executable,str(repo/'benchmarks/runtime/compare-revisions.py'),'--before',str(r/(left+'-build/conformance')),'--after',str(r/(right+'-build/conformance')),'--output',str(out/mode),'--pairs','4','--observer-mode',mode,'--case','short-small','--case','short-large'])
# Identical public API probe against each ordinary O3 library. Timing includes the
# probe's JSON conversion; no profiling allocator or production instrumentation.
for pair in range(2):
 for count,mode in [(64,'plain'),(512,'plain'),(512,'concurrent')]:
  for side in (['before','after'] if pair==0 else ['after','before']):
   label=left if side=='before' else right;name=f'cut-{pair}-{count}-{mode}-{side}';run(name,[str(r/(label+'-build/statistics-probe')),str(out/(name+'-db')),str(count),mode]);raw=json.loads((out/(name+'.stdout')).read_text().splitlines()[-1]);assert raw['oracle']=='passed';(out/(name+'.json')).write_text(json.dumps(raw,indent=2)+'\n')
(out/'completed.json').write_text(json.dumps({'accepted':True,'hot_products':32,'statistics_products':12,'before':left,'after':right,'scope':'Rust-only; hot and history diagnostics are separate. Four pairs per hot cell; two history pairs; no Pi/DSH runs.'},indent=2)+'\n')
