import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');stage,left,right=sys.argv[1:];commands=[];os.sched_setaffinity(0,[2,8])
def run(name,cmd):
 row={'name':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());commands.append(row);(r/(stage+'-commands.json')).write_text(json.dumps(commands,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0
run(stage+'-probe-build',[sys.executable,str(r/'compile-probes.py'),right])
run(stage+'-hot',[sys.executable,str(r/'run-step.py'),stage+'-step',left,right])
for label in ([left,right] if stage=='statistics' else [right]):
 run('wal-'+label,[sys.executable,str(r/'run-wal.py'),'--label',label,'--binary',str(r/(label+'-build/conformance'))])
 run('wal-analysis-'+label,[sys.executable,str(r/'analyze-wal.py'),'--label',label])
 for case in ['short-small','short-large']:
  name='source-'+label+'-'+case;run(name,[str(r/(label+'-build/source-probe')),str(r/f'wal-{label}-{case}-rust')]);raw=json.loads((r/(name+'.stdout')).read_text().splitlines()[-1]);assert raw['oracle']=='passed';(r/(name+'.json')).write_text(json.dumps(raw,indent=2)+'\n')
for mode in ['no-live-subscriber','live-subscriber']:
 run(stage+'-summary-'+mode,[sys.executable,str(repo/'benchmarks/runtime/summarize-comparisons.py'),str(r/(stage+'-step')/mode)])
(r/(stage+'-completed.json')).write_text('{"accepted":true}\n')
