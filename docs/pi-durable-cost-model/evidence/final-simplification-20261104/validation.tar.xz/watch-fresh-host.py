"""Read-only, low-rate host activity for the post-stress fixed cohort."""
import datetime,json,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent
while not (r/'fresh-fixed-completed.json').exists():
 p=subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True);items=[]
 for pid in p.stdout.split():
  try:items.append({'pid':int(pid),'cwd':str((Path('/proc')/pid/'cwd').resolve()),'stat':(Path('/proc')/pid/'stat').read_text()})
  except OSError:pass
 with (r/'host-compiler-observations.jsonl').open('a') as f:f.write(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'rustc':items,'io_pressure':Path('/proc/pressure/io').read_text(),'device_stat':Path('/sys/class/block/nvme0n1/stat').read_text()})+'\n')
 time.sleep(2)
