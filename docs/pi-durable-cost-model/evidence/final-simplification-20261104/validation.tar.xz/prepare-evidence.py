from pathlib import Path
import shutil
r=Path(__file__).resolve().parent;p=Path('/home/capi/.cache/rustx-pr485-observation-ownership-20261104');s=Path('/home/capi/.cache/rustx-pr485-statistics-20261103')
(r/'baseline-build').symlink_to(p/'candidate-build',target_is_directory=True)
shutil.copy2(p/'fixture_binding.py',r/'fixture_binding.py')
source=(s/'statistics-probe.rs').read_text().replace('let tail=sample(&store,63);let checkpoint=sample(&store,64);','let cut63=sample(&store,63);let cut64=sample(&store,64);')
source=source.replace('let after_read=io();drop(store);','for cut in 1..=count as u64 {read(&store,cut);}\n let after_read=io();drop(store);')
source=source.replace('assert_eq!(read(&reopened,63),old);drop(reopened);','let reopened63=sample(&reopened,63);assert_eq!(reopened63["value"],old);drop(reopened);')
source=source.replace('"tail":tail,"checkpoint":checkpoint','"cut63":cut63,"cut64":cut64,"reopened63":reopened63');(r/'statistics-probe.rs').write_text(source)
source=(s/'compile-probes.py').read_text().replace("r/(label+'-build')","r/(label+'-build')").replace("['statistics-probe','boundary-probe']","['statistics-probe']");(r/'compile-probes.py').write_text(source)
source=(s/'run-wal-rust.py').read_text().replace("choices=['baseline','complete']","choices=['baseline','statistics','navigation','candidate']")
old="s={'path':path,'tables':tables,"
new="""s={'path':path,'page_size':c.execute('PRAGMA page_size').fetchone()[0],'page_count':c.execute('PRAGMA page_count').fetchone()[0],'freelist_count':c.execute('PRAGMA freelist_count').fetchone()[0],'tables':tables,"""
assert old in source;source=source.replace(old,new)
old="     c.close()\n     if path.endswith"
new="""     if any(t[0]=='events' for t in tables):
      cols=[row[1] for row in c.execute('PRAGMA table_info(events)')]
      s['statistics_columns']={col:c.execute('SELECT count('+col+'),coalesce(sum(length('+col+')),0) FROM events').fetchone() for col in cols if col.startswith('observation_statistics') and not col.endswith('required')}
      s['source_page_encoding']=[{'magic':m,'rows':n,'bytes':b} for m,n,b in c.execute('SELECT hex(substr(bytes,1,5)),count(*),sum(length(bytes)) FROM request_source_pages GROUP BY 1')]
      s['used_pages_by_table']=c.execute('SELECT name,count(*),sum(payload),sum(pgsize) FROM dbstat GROUP BY name').fetchall()
     c.close()
     if path.endswith"""
assert old in source;source=source.replace(old,new);(r/'run-wal.py').write_text(source)
source=(s/'analyze-wal.py').read_text().replace("choices=['baseline','complete']","choices=['baseline','statistics','navigation','candidate']").replace(" owners=collections.defaultdict(set)"," assert before['page_size']==after['page_size']==2048\n owners=collections.defaultdict(set)")
source=source.replace('4120','2072').replace('n==4096','n==2048')
source=source.replace("summary[engine]=s","s['statistics_columns_delta']={k:[v[0]-before['statistics_columns'][k][0],v[1]-before['statistics_columns'][k][1]] for k,v in after['statistics_columns'].items()}\n s['database_used_bytes_growth']=((after['page_count']-after['freelist_count'])-(before['page_count']-before['freelist_count']))*2048\n s['source_page_encodings']={'before':before['source_page_encoding'],'after':after['source_page_encoding']}\n summary[engine]=s")
(r/'analyze-wal.py').write_text(source)
