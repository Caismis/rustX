import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat();rows=[]
bins={'before':r/'baseline-build/rustx','after':r/'candidate-build/rustx'};inputs={str(p):sha(p) for p in [r/'capacity-ordinary.py',repo/'benchmarks/runtime/app-server-capacity-provider.py',r/'capacity-rotating.py',r/'capacity-deep.py']};(r/'premeasurement.json').write_text(json.dumps({'binaries':{s:{'path':str(p),'sha256':sha(p)} for s,p in bins.items()},'inputs':inputs,'scope':'Only new Rust products. Fixed/rotating/deep/cache families are separate. No Pi/DeepSeek executions.'},indent=2)+'\n')
orders=[['before','after'],['after','before'],['after','before'],['before','after']]
for family,orderlist in [('ordinary',orders),('rotating',orders),('deep',orders[:2]),('cache',[['before','after']])]:
 for pair,order in enumerate(orderlist):
  for side in order:
   while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(1)
   name=f'{family}-{pair}-{side}';driver=(r/'capacity-rotating.py' if family=='rotating' else r/'capacity-deep.py' if family=='deep' else r/'capacity-ordinary.py');cmd=[sys.executable,str(driver),'--binary',str(bins[side]),'--output',str(r/name),'--sessions',('8' if family=='deep' else '128'),'--history',('64' if family=='deep' else '8'),'--widths',*(['4'] if family in ['deep','rotating'] else ['1','4','8']),'--rounds',('128' if family=='rotating' else '32' if family=='deep' else '16')]
   if family=='cache':cmd+=['--cache-probes']
   row={'family':family,'pair':pair,'side':side,'directory':name,'command':cmd,'start_utc':now()}
   with(r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se,env=os.environ|{'UV_OFFLINE':'1'})
   row.update(exit=p.returncode,end_utc=now());rows.append(row);(r/'product-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0 and load(r/name/'completed.json')['accepted'];assert all(sha(Path(k))==v for k,v in inputs.items())
(r/'products-completed.json').write_text('{"accepted":true}\n')
