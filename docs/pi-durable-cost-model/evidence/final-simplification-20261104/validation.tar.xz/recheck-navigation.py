"""One predeclared navigation retake after observed severe external I/O pressure.
Original samples remain intact. This retake changes no production or workloads.
"""
import datetime,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=r/'navigation-recheck';out.mkdir(exist_ok=False);rows=[];os.sched_setaffinity(0,[2,8])
def total():
 text=Path('/proc/pressure/io').read_text();return int(text.split('full ',1)[1].split('total=',1)[1].split()[0])
# The foreign Rust stress test has ended. Use instantaneous device busy time
# and compiler/test absence; retain global PSI rather than calling it exclusive.
def busy():return int(Path('/sys/class/block/nvme0n1/stat').read_text().split()[9])
while True:
 start=total();device=busy();time.sleep(5);ratio=(total()-start)/5_000_000;disk=(busy()-device)/5000
 compiler=subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0
 if disk<.05 and not compiler:break
(out/'preflight.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'full_io_stall_fraction_last5seconds':ratio,'device_busy_fraction_last5seconds':disk,'paused_own_native_coordinator':3302937,'scope':'No shared-host exclusivity claim; retain original polluted matrix and monitor ongoing pressure.'},indent=2)+'\n')
for mode in ['no-live-subscriber','live-subscriber']:
 cmd=[sys.executable,str(repo/'benchmarks/runtime/compare-revisions.py'),'--before',str(r/'statistics-build/conformance'),'--after',str(r/'candidate-build/conformance'),'--output',str(out/mode),'--pairs','4','--observer-mode',mode,'--case','short-small','--case','short-large'];row={'mode':mode,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'io_start':Path('/proc/pressure/io').read_text()}
 with (out/(mode+'.stdout')).open('x') as so,(out/(mode+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),io_end=Path('/proc/pressure/io').read_text());rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(mode,p.returncode,flush=True);assert p.returncode==0
 cmd=[sys.executable,str(repo/'benchmarks/runtime/summarize-comparisons.py'),str(out/mode)];done=subprocess.run(cmd,cwd=repo,capture_output=True,text=True);assert done.returncode==0,done.stderr;(out/(mode+'-summary.json')).write_text(done.stdout)
(out/'completed.json').write_text('{"accepted":true}\n')
