"""Package only this bounded round's authenticated evidence, never build/auth payloads."""
import hashlib,json,tarfile,shutil
from pathlib import Path
r=Path(__file__).resolve().parent;out=Path('/home/capi/.cache/rustx-pr485-final-simplification-publish-20261104');out.mkdir(exist_ok=False);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((r/'audits-completed.json').read_text())['accepted']
# Baseline build metadata is inherited; copy records only, not old data archives/binaries.
base=r/'baseline-build'
for name in ['identity.json','build.stdout','build.stderr']:
 p=base/name
 if p.is_symlink():
  body=p.read_bytes();p.unlink();p.write_bytes(body)
groups={'fixed.tar.xz':[],'rotating.tar.xz':[],'validation.tar.xz':[]}
excluded={'runtime','workspaces','node_modules','.git','__pycache__','target','.env','token'}
for p in sorted(r.rglob('*')):
 rel=p.relative_to(r)
 if not p.is_file() or p.is_symlink() or any(part in excluded for part in rel.parts):continue
 if p.name in ['rustx','conformance','statistics-probe','source-probe','provider.stdout','WORK-IN-PROGRESS.md','report-draft.md','report.md','package.stdout','package.stderr','offline-replay.stdout','offline-replay.stderr','finalize-evidence.stdout','finalize-evidence.stderr']:continue
 if p.suffix in ['.rlib','.rmeta','.so','.o','.pyc'] or '.so.' in p.name:continue
 top=rel.parts[0];name='fixed.tar.xz' if top.startswith(('ordinary-','fresh-ordinary-')) else 'rotating.tar.xz' if top.startswith('rotating-') else 'validation.tar.xz';groups[name].append(p)
manifest={'archives':[],'members':[],'scope':'New Rust round only. Full raw interleaved hot/retake, native closed images/provider reports/counters, history/Source probes, WAL diagnostics, source/build/check/provenance/host records and rejected preflights. No old data archives recopied. Baseline build metadata and actual artifact byte proofs reused; binary/library/profiler/credentials/mutable workspaces excluded. Original polluted fixed matrix and fresh acceptance matrix remain distinct.'}
for name,paths in groups.items():
 dest=out/name
 with tarfile.open(dest,'w:xz',preset=6) as archive:
  for p in paths:
   rel=str(p.relative_to(r));manifest['members'].append({'archive':name,'path':rel,'bytes':p.stat().st_size,'sha256':sha(p)});info=archive.gettarinfo(str(p),arcname=rel);info.uid=info.gid=info.mtime=0;info.uname=info.gname=''
   with p.open('rb') as body:archive.addfile(info,body)
 assert dest.stat().st_size<95_000_000,(name,dest.stat().st_size);manifest['archives'].append({'name':name,'bytes':dest.stat().st_size,'sha256':sha(dest)});print(name,dest.stat().st_size,flush=True)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copy2(r/'replay.py',out/'replay.py');print('members',len(manifest['members']),flush=True)
