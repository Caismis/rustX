"""Revalidate the one navigation retake without hiding original adverse samples."""
import json,importlib.util,sys,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'analysis-inputs'));from controller import validate_sample
spec=importlib.util.spec_from_file_location('frozen_summary',r/'analysis-inputs/summarize-comparisons.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);load=lambda p:json.loads(p.read_text());checks=[];summaries={}
for mode in ['no-live-subscriber','live-subscriber']:
 d=r/'navigation-recheck'/mode
 for pair in range(4):
  for case in ['short-small','short-large']:
   sides={}
   for side in ['before','after']:
    p=d/f'{pair}-{case}-{side}.json';v=load(p);proc=load(p.with_name(p.stem+'.process.json'));validate_sample(proc,v,case,p.with_suffix('.log').read_text());sides[side]=v;checks.append({'file':str(p.relative_to(r)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
   assert [json.dumps(x['body'],ensure_ascii=False,separators=(',',':')) for x in sides['before']['wire_requests']]==[json.dumps(x['body'],ensure_ascii=False,separators=(',',':')) for x in sides['after']['wire_requests']]
 v=m.summarize([d]);saved=load(r/'navigation-recheck'/(mode+'-summary.json'))
 for item in [v,saved]:
  for records in item['samples'].values():
   for row in records:
    for side in ['before','after']:row[side]['file']=Path(row[side]['file']).name
 assert v==saved;summaries[mode]=v
(r/'navigation-recheck-audit.json').write_text(json.dumps({'accepted':True,'products':checks,'summaries':summaries,'scope':'One predeclared retake after confirmed unrelated stress; all original data remains. Filesystem artifact basenames alone normalized.'},indent=2)+'\n');print(json.dumps({'accepted':True,'products':len(checks)}))
