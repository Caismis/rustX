"""Recompute the finite decision tables; no products, compiler or network."""
import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text())
def paired(a,b):
 assert len(a)==len(b) and a
 change=[None if x==0 else (y/x-1)*100 for x,y in zip(a,b)]
 return {'before':a,'after':b,'before_median':statistics.median(a),'after_median':statistics.median(b),'paired_percent':change,'paired_percent_median':statistics.median(change) if all(x is not None for x in change) else None}
hot=load(r/'hot-audit.json');native={v['directory']:v for v in load(r/'native-audit.json')['products']};commands=load(r/'product-commands.json');out={'scope':'Descriptive paired medians. Hot/runtime driver, native/server PID, WAL diagnostic and Source/history probes remain separate; no cross-cohort pooled costs. No Pi/DSH runs.','hot':hot['hot'],'history':hot['history'],'activity':{},'memory':{},'deep_memory':{},'wal':{},'source':[]}
for family in ['ordinary','ordinary-fresh','rotating','deep']:
 index={(c['pair'],c['side']):native[c['directory']] for c in commands if c['family']==family};pairs=sorted({k[0] for k in index});widths=[1,4,8] if family in ['ordinary','ordinary-fresh'] else [4]
 out['activity'][family]=[]
 for width in widths:
  def metric(i,s,key):
   row=next(v for v in index[i,s]['activity'] if v['width']==width)
   return {'wall_ms':row['latency']['settled_us']['median_ms'],'p95_ms':row['latency']['settled_us']['p95_ms'],'p99_ms':row['latency']['settled_us']['p99_ms'],'cpu_ms':row['server_cpu_ms_per_all_turns'],'write_kib':row['server_write_bytes_per_all_turns']/1024}[key]
  out['activity'][family].append({'width':width,'pairs':pairs,'metrics':{key:paired([metric(i,'before',key) for i in pairs],[metric(i,'after',key) for i in pairs]) for key in ['wall_ms','cpu_ms','write_kib','p95_ms','p99_ms']}})
 if family in ['ordinary','ordinary-fresh','deep']:
  phases=['all_subscribed_empty','seeded_history_8','all_unloaded'] if family in ['ordinary','ordinary-fresh'] else ['all_subscribed_empty','seeded_history_8','seeded_history_16','seeded_history_32','seeded_history_64']
  points={(i,s):{v['phase']:v['counters'] for v in index[i,s]['points']} for i in pairs for s in ['before','after']}
  target=out['memory'] if family=='ordinary-fresh' else out['deep_memory'] if family=='deep' else out.setdefault('original_memory',{})
  for phase in phases:target[phase]={key:paired([points[i,'before'][phase][key] for i in pairs],[points[i,'after'][phase][key] for i in pairs]) for key in ['anon_pss_mib','rss_mib']}
  if family=='ordinary-fresh':
   out['growth_per_session_mib']=paired([(points[i,'before']['seeded_history_8']['anon_pss_mib']-points[i,'before']['all_subscribed_empty']['anon_pss_mib'])/128 for i in pairs],[(points[i,'after']['seeded_history_8']['anon_pss_mib']-points[i,'after']['all_subscribed_empty']['anon_pss_mib'])/128 for i in pairs])
for label in ['baseline','statistics','candidate']:
 values=load(r/f'wal-summary-{label}-corrected.json');out['wal'][label]=values
 for case,v in values.items():
  name=case.removesuffix('-rust');before=load(r/f'wal-{label}-{name}-rust/before_measured_turns-database.json')[0];after=load(r/f'wal-{label}-{name}-rust/after_turns-database.json')[0]
  def nav(s):
   rows=[x for x in s['source_page_encoding'] if x['magic'] in ['5258535002','5258535003']];return {'rows':sum(x['rows'] for x in rows),'bytes':sum(x['bytes'] for x in rows)}
  def overflow(s):return sum(1 for x in s['pages'] if x[0]=='request_source_pages' and x[2]=='overflow')
  a,b=nav(before),nav(after);v['navigation_pages_delta']={k:b[k]-a[k] for k in ['rows','bytes']};v['source_page_overflow_net_delta']=overflow(after)-overflow(before)
  p=load(r/f'source-{label}-{name}.json');samples=[]
  for kind,item in [('old',p['samples'][0]),('latest',p['samples'][1]),('reopened_old',p['reopened'])]:
   samples.append({'kind':kind,'encoded_bytes':item['view']['header']['encoded_bytes'],'timings':{op:{'first_us':item['timings'][0][op]/1000,'repeated_median_us':statistics.median(v[op] for v in item['timings'][1:])/1000} for op in ['header_ns','page_ns','range_ns']}})
  out['source'].append({'label':label,'case':name,'samples':samples})
out['cache']=load(r/'cache-audit.json')
out['navigation_recheck']=load(r/'navigation-recheck-audit.json')
(r/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'accepted':True,'ordinary_memory':out['memory'],'fixed4':out['activity']['ordinary'][1],'rotating4':out['activity']['rotating'][0]},indent=2))
