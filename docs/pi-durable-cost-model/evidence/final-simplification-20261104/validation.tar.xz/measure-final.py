"""Finite Rust-only acceptance, with builds/checks finished before measurements."""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');rows=[]
while True:
 p=r/'candidate-build/identity.json'
 if p.exists() and json.loads(p.read_text()).get('verified'):break
 time.sleep(2)
assert json.loads((r/'checks-completed.json').read_text())['accepted'];assert json.loads((r/'frontend-extra-completed.json').read_text())['accepted']
assert not os.environ.get('LD_PRELOAD') and not any(k.startswith('CARGO_PROFILE_') for k in os.environ)
(r/'runtime-environment.json').write_text(json.dumps({'clock_ticks':os.sysconf('SC_CLK_TCK'),'ld_preload_set':False,'profile_overrides':[],'glibc_tunables_set':bool(os.environ.get('GLIBC_TUNABLES')),'scope':'Ordinary System/GNU allocator, no heap/CPU profiler. Product/provider/driver boundaries stay distinct.'},indent=2)+'\n')
for label in ['baseline','statistics','candidate']:
 b=r/(label+'-build');meta=json.loads((b/'identity.json').read_text());proof={'head':meta['head']}
 for name in ['rustx','conformance','librustx.rlib']:
  path=b/name;proof[name.replace('.','_')+'_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
 assert proof['conformance_sha256']==meta['sha256'];(r/(label+'-artifact-proof.json')).write_text(json.dumps(proof,indent=2)+'\n')
while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(2)
watch=subprocess.Popen([sys.executable,str(r/'watch-host.py')],cwd=repo,stdout=(r/'host-watch.stdout').open('x'),stderr=(r/'host-watch.stderr').open('x'))
for name,cmd in [('navigation-measure',[sys.executable,str(r/'measure-stage.py'),'navigation','statistics','candidate']),('native-products',[sys.executable,str(r/'run-products.py')]),('functional-products',[sys.executable,str(r/'functional-products.py')])]:
 row={'name':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'final-measure-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(r/'measurements-completed.json').write_text('{"accepted":true}\n');assert watch.wait(10)==0
