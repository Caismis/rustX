import hashlib,json,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;label=sys.argv[1];out=r/(label+'-build');repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
rows=[json.loads(l) for l in (out/'build.stdout').read_text().splitlines() if l.startswith('{')]
for name in sys.argv[2:] or ['statistics-probe','source-probe']:
 source=r/(name+'.rs');cmd=['rustc','--edition=2024','-O','-D','warnings',str(source),'--extern','rustx='+str(out/'librustx.rlib'),'-L','dependency=/home/capi/.cache/rustx-pr485-target/release/deps']
 for dependency in ['chrono','serde_json']:
  path=next(f for v in rows if v.get('reason')=='compiler-artifact' and v['target']['name']==dependency for f in v['filenames'] if f.endswith('.rlib'));cmd+=['--extern',dependency+'='+path]
 for directory in Path('/home/capi/.cache/rustx-pr485-target/release/build').glob('*/out'):cmd+=['-L','native='+str(directory)]
 cmd+=['-o',str(out/name)]
 with (out/(name+'.stdout')).open('x') as so,(out/(name+'.stderr')).open('x') as se:done=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
 meta={'command':cmd,'exit':done.returncode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest()}
 if done.returncode==0:meta['binary_sha256']=hashlib.sha256((out/name).read_bytes()).hexdigest()
 (out/(name+'.json')).write_text(json.dumps(meta,indent=2)+'\n');print(label,name,done.returncode,flush=True)
 if done.returncode:raise SystemExit(done.returncode)
