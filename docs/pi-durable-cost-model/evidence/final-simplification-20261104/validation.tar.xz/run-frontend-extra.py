"""Existing protocol/dev/browser verification, no engine performance products."""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=r/'frontend-extra';out.mkdir(exist_ok=False);rows=[];env=os.environ.copy();env.pop('CARGO_TARGET_DIR',None);env.pop('RUSTX_BINARY',None);env.update(CARGO_BUILD_JOBS='2',UV_OFFLINE='1')
commands=[('protocol-check',['pnpm','check'],repo/'protocol/app-server'),('dev-install',['pnpm','install','--frozen-lockfile'],repo/'dev'),('dev-typecheck',['pnpm','typecheck'],repo/'dev'),('dev-test',['pnpm','test'],repo/'dev'),('web-e2e',['pnpm','test:e2e'],repo/'web-console')]
(out/'scope.json').write_text(json.dumps({'browser':'Browser plugin not available','path':'Existing pinned Docker Playwright E2E script; image preflight passed','flow':'Session/history -> Inspector/Source selection -> committed contents render with working controls','url':'http://127.0.0.1:5173','configured_viewport':{'width':1440,'height':1000},'scope':'Linux local existing suites; no frontend code change and no macOS/main-integration claim.'},indent=2)+'\n')
for name,cmd,cwd in commands:
 row={'label':name,'command':cmd,'cwd':str(cwd),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(name+'.stdout')).open('x') as so,(out/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(r/'frontend-extra-completed.json').write_text('{"accepted":true}\n')
