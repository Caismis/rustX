"""Finite postprocessing after performance windows; no new production work."""
import datetime,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');rows=[]
while not (r/'measurements-completed.json').exists():time.sleep(2)
commands=[('fresh-fixed',[sys.executable,str(r/'run-fresh-fixed.py')]),('bindings',[sys.executable,str(r/'prepare-bindings.py')]),('native',[sys.executable,str(r/'audit-native.py')]),('requests',[sys.executable,str(r/'audit-requests.py')]),('cache',[sys.executable,str(r/'audit-cache.py')]),('hot',[sys.executable,str(r/'audit-hot.py')]),('source',[sys.executable,str(r/'audit-source.py')]),('host',[sys.executable,str(r/'audit-host.py')]),('retake',[sys.executable,str(r/'audit-recheck.py')]),('arithmetic',[sys.executable,str(r/'arithmetic.py')]),('tables',[sys.executable,str(r/'make-tables.py')])]
for name,cmd in commands:
 row={'name':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/('finish-'+name+'.stdout')).open('x') as so,(r/('finish-'+name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'audit-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(r/'audits-completed.json').write_text('{"accepted":true}\n')
