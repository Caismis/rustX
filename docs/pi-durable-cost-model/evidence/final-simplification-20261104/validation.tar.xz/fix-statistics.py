from pathlib import Path
import subprocess
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
def edit(name,old,new):
 p=repo/name;s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new))
p=repo/'src/durable/sqlite/observation_statistics/contribution.rs'
p.write_bytes(subprocess.check_output(['git','show','HEAD:src/durable/sqlite/observation_statistics/contribution.rs'],cwd=repo))
p=repo/'src/durable/sqlite/append_facts.rs';s=p.read_text().replace('    let checkpoint = prepared.statistics.checkpoint.as_ref();\n','').replace(',observation_statistics_checkpoint=?6','').replace('let values: [&dyn rusqlite::ToSql; 6]', 'let values: [&dyn rusqlite::ToSql; 5]').replace('                &checkpoint,\n','').replace('statement.execute(&values[..if statistics.is_some() { 6 } else { 5 }])','statement.execute(&values[..])');p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics.rs';s=p.read_text();s+='''\n#[cfg(test)]
pub(super) fn stored_parts(sequence: u64, bytes: &[u8]) -> Result<(&[u8], &[u8]), ConversationStoreError> {
    record::parts(sequence, bytes)
}
''';p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics_history_tests.rs';s=p.read_text().replace('// Statistical facts are independent of native bodies; checkpoint validity and\n// replay distance are part of the new format, not compatibility behavior.','// Each statistical event owns one independently bound full historical record.')
s=s.replace('statistics_contributions_remove_full_per_event_materialization_and_match_all_cuts','statistics_full_records_match_every_cut_with_one_direct_read')
s=s.replace('write_work(), (2, 41)','write_work(), (41, 41)')
a='''    let counts:(u64,u64)=store.lock().unwrap().query_row("SELECT count(observation_statistics),count(observation_statistics_checkpoint) FROM events",[],|row|Ok((row.get(0)?,row.get(1)?))).unwrap();
    assert_eq!(counts, (42, 3));'''
b='''    let count: u64 = store.lock().unwrap().query_row(
        "SELECT count(observation_statistics) FROM events", [], |row| row.get(0),
    ).unwrap();
    assert_eq!(count, 42);
    let obsolete: bool = store.lock().unwrap().query_row(
        "SELECT EXISTS(SELECT 1 FROM pragma_table_xinfo('events') WHERE name='observation_statistics_checkpoint')",
        [], |row| row.get(0),
    ).unwrap();
    assert!(!obsolete, "there is one full record column, not two history forms");'''
assert a in s;s=s.replace(a,b).replace('assert!(rows <= 18, "Innocuous","bad")','assert!(rows <= 18, "Innocuous","bad")')
s=s.replace('assert!(rows <= 18, "{rows} at {cut}");','assert!(rows <= 1, "{rows} at {cut}");').replace('assert!(bytes <= 18 * 49_152);','assert!(bytes <= 98_340);')
start=s.index('#[test]\nfn statistics_checkpoint_is_independent')
end=s.index('#[test]\nfn statistics_replay_never',start)
s=s[:start]+'''#[test]
fn statistics_full_record_is_independent_of_older_damage_but_not_its_own_bytes() {
    use self::observation_response_tests::{response_message, response_start};
    let store = store();
    store.initialize(&[]).unwrap();
    let attempt = response_start(&store, "independent-statistics");
    for i in 0..32 {
        response_message(&store, &attempt, &format!("independent-statistics-message-{i}"));
    }
    let third = store.observation_statistics(3).unwrap();
    let latest = store.observation_statistics(33).unwrap();
    for replacement in ["x'ff'", "NULL"] {
        store.lock().unwrap().execute_batch(&format!(
            "UPDATE events SET observation_statistics={replacement} WHERE sequence=2"
        )).unwrap();
        assert!(store.observation_statistics(2).is_err());
        assert_eq!(store.observation_statistics(3).unwrap(), third);
        assert_eq!(store.observation_statistics(33).unwrap(), latest);
    }
    response_message(&store, &attempt, "after-old-statistics-damage");
    assert_eq!(store.observation_statistics(34).unwrap().turns, 1);
    store.lock().unwrap().execute(
        "UPDATE events SET observation_statistics=x'ff' WHERE sequence=34", [],
    ).unwrap();
    assert!(store.observation_statistics(34).is_err());
    response_message(&store, &attempt, "after-current-statistics-damage");
    assert!(store.observation_statistics(35).is_err());
    assert_eq!(store.load_canonical().unwrap().len(), 34);
    assert_eq!(store.read_events(None, 128).unwrap().events.len(), 35);
}

'''+s[end:]
s=s.replace('statistics_replay_never_reads_native_bodies_or_timestamps','statistics_full_record_never_reads_native_bodies_or_timestamps')
start=s.index('#[test]\nfn statistics_forged_ancient_anchor')
end=s.index('#[test]\nfn statistics_rollback_sequence_reuse',start)
s=s[:start]+'''#[test]
fn statistics_full_record_is_row_bound_and_uses_one_bounded_head_lookup() {
    use self::observation_response_tests::{response_message, response_start};
    let store = store();
    store.initialize(&[]).unwrap();
    let attempt = response_start(&store, "bounded-statistical-history");
    for i in 0..40 {
        response_message(&store, &attempt, &format!("bounded-statistical-message-{i}"));
    }
    let connection = store.lock().unwrap();
    let bytes: Vec<u8> = connection.query_row(
        "SELECT observation_statistics FROM events WHERE sequence=40", [], |row| row.get(0),
    ).unwrap();
    connection.execute(
        "UPDATE events SET observation_statistics=?1 WHERE sequence=41", [&bytes],
    ).unwrap();
    let sql = super::event_heads::STATISTICS;
    connection.prepare_cached(sql).unwrap().reset_status(rusqlite::StatementStatus::VmStep);
    assert!(observation_statistics::read(&connection, 41).is_err());
    let statement = connection.prepare_cached(sql).unwrap();
    assert_eq!(statement.get_status(rusqlite::StatementStatus::FullscanStep), 0);
    assert_eq!(statement.get_status(rusqlite::StatementStatus::Sort), 0);
    assert!(statement.get_status(rusqlite::StatementStatus::VmStep) < 1000);
}

'''+s[end:]
s=s.replace('bytes.len() < 128,\n        "a giant identity leaves a bounded scalar fact"','bytes.len() < 2048,\n        "a giant identity leaves a bounded full record and deferred clock"')
s=s.replace('let record: serde_json::Value = observation_codec::decode(&bytes).unwrap();\n    let identity = record[3][2].as_array().unwrap();','let (fact, _) = observation_statistics::stored_parts(start.sequence, &bytes).unwrap();\n    let record: serde_json::Value = observation_codec::decode(fact).unwrap();\n    let identity = record[1][2].as_array().unwrap();')
p.write_text(s)
p=repo/'src/durable/sqlite/append_facts_tests.rs';s=p.read_text().replace('a_valid_external_checkpoint_rewrite_cannot_redefine_statistical_facts','a_valid_external_full_state_rewrite_cannot_redefine_statistical_facts')
s=s.replace('SELECT observation_statistics_checkpoint FROM events WHERE sequence=3','SELECT observation_statistics FROM events WHERE sequence=3')
s=s.replace('let mut value:serde_json::Value=observation_codec::decode(&bytes).unwrap();value[0][0]=serde_json::json!(44);\n    other.execute("UPDATE events SET observation_statistics_checkpoint=?1 WHERE sequence=3",[observation_codec::encode_admitted(&value).unwrap()]).unwrap();','''let (fact, state)=observation_statistics::stored_parts(3, &bytes).unwrap();
    let mut value:serde_json::Value=observation_codec::decode(state).unwrap();value[0][0]=serde_json::json!(44);
    let mut changed=bytes[..36+fact.len()].to_vec();
    changed.extend_from_slice(&observation_codec::encode_admitted(&value).unwrap());
    other.execute("UPDATE events SET observation_statistics=?1 WHERE sequence=3",[changed]).unwrap();''')
p.write_text(s)
