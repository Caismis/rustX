"""Verify final checked inputs and ordinary artifact provenance, offline-capable."""
import hashlib,json,re
from pathlib import Path
r=Path(__file__).resolve().parent;load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();source=load(r/'checks-final/source-before.json');assert source==load(r/'checks-final/source-after.json');checks=load(r/'checks-summary.json');assert checks['accepted']
for path in ['checks-final/commands.json','frontend-extra/commands.json']:assert all(v['exit']==0 for v in load(r/path))
rows=[];serde=[]
for label in ['baseline','statistics','candidate']:
 b=r/(label+'-build');identity=load(b/'identity.json');assert identity['verified'] and all(v['exit']==0 for v in identity['commands'])
 artifacts=[json.loads(line) for line in (b/'build.stdout').read_text().splitlines() if line.startswith('{')]
 root=[v for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['src_path'].startswith('/home/capi/.codex/worktrees/pr485-pi-performance/rustX/')];assert root and all(v['profile']['opt_level']=='3' and v['features']==[] and not v['fresh'] for v in root)
 sj=[v for v in artifacts if v.get('reason')=='compiler-artifact' and v['target']['name']=='serde_json' and v['profile']['opt_level']=='3'];assert len(sj)==1;serde.append((sj[0]['package_id'],sj[0]['features'],sj[0]['profile']))
 if label=='candidate':assert all(source[k]==v for k,v in identity['source_files'].items())
 proof=load(r/(label+'-artifact-proof.json'));assert proof['head']==identity['head'] and proof['conformance_sha256']==identity['sha256'];rows.append({'label':label,'head':identity['head'],'root_artifacts':len(root),'source_files':len(identity['source_files']),'artifact_proof':proof})
assert serde[0]==serde[1]==serde[2]
raw=(r/'checks-final/rust-full.stdout').read_text();counts=[tuple(map(int,x)) for x in re.findall(r'test result: ok\. (\d+) passed; 0 failed; (\d+) ignored;',raw)];assert sum(x[0] for x in counts)==checks['rust_passed'] and sum(x[1] for x in counts)==checks['rust_ignored'];assert len(counts)==checks['rust_cargo_targets']==checks['rust_result_sections']
(r/'source-audit.json').write_text(json.dumps({'accepted':True,'checked_tracked_inputs':len(source),'rust_passed':checks['rust_passed'],'rust_ignored':checks['rust_ignored'],'browser_passed':checks['browser_passed'],'ordinary_builds':rows,'scope':'All ordinary root artifacts freshO3/default; final source byte-identical to full Linux checks. Actual artifact byte proofs recorded before omission; offline replay authenticates proofs, not absent executables. Correctness rootO0/allfeatures and default debug browser helpers are separate from performance. Main/macOS integration not performed.'},indent=2)+'\n');print(json.dumps({'accepted':True,'source_inputs':len(source),'rust_passed':checks['rust_passed'],'browser_passed':checks['browser_passed']}))
