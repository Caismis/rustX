"""Read-only replay of frozen controller oracles and same-pair arithmetic."""
import hashlib,importlib.util,json,statistics,sys
from pathlib import Path
r=Path(__file__).resolve().parent;sys.path.insert(0,str(r/'analysis-inputs'));from controller import validate_sample
spec=importlib.util.spec_from_file_location('frozen_summary',r/'analysis-inputs/summarize-comparisons.py');summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
load=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();results={};checks=[]
for stage in ['statistics','navigation']:
 results[stage]={}
 for mode in ['no-live-subscriber','live-subscriber']:
  directory=r/(stage+'-step')/mode;manifest=load(directory/'manifest.json');assert manifest['pairs']==4
  for pair in range(4):
   for case in ['short-small','short-large']:
    values={}
    for side in ['before','after']:
     p=directory/f'{pair}-{case}-{side}.json';data=load(p);process=load(p.with_name(p.stem+'.process.json'));validate_sample(process,data,case,p.with_suffix('.log').read_text());assert process['argv'][0]==manifest['executables'][side]['path'];values[side]=data
     checks.append({'file':str(p.relative_to(r)),'sha256':sha(p),'case':case,'requests':len(data['wire_requests'])})
    def bodies(v):return [json.dumps(x['body'],ensure_ascii=False,separators=(',',':')) for x in v['wire_requests']]
    assert bodies(values['before'])==bodies(values['after']),('full request body differs',stage,mode,pair,case)
  result=summary.summarize([directory]);saved=load(r/(stage+'-summary-'+mode+'.stdout'))
  # Only artifact locations move during offline extraction. Never normalize
  # wire bodies, model schemas, IDs, native values, counters or measurements.
  for item in [result,saved]:
   for records in item['samples'].values():
    for record in records:
     for side in ['before','after']:record[side]['file']=Path(record[side]['file']).name
  assert result==saved;results[stage][mode]=result
history=[]
for stage in ['statistics','navigation']:
 for count,mode in [(64,'plain'),(512,'plain'),(512,'concurrent')]:
  pairs=[]
  for pair in range(2):
   sides={side:load(r/(stage+'-step')/f'cut-{pair}-{count}-{mode}-{side}.json') for side in ['before','after']}
   for v in sides.values():assert v['oracle']=='passed' and v['events']==count
   assert all(sides['before'][key]['value']==sides['after'][key]['value'] for key in ['cut63','cut64','reopened63'])
   pairs.append(sides)
  metrics={}
  for key in ['cut63','cut64','reopened63']:
   for kind in ['first_ns','repeated_ns']:
    def value(v):return (statistics.median(v[key][kind]) if kind=='repeated_ns' else v[key][kind])/1000
    a=[value(v['before']) for v in pairs];b=[value(v['after']) for v in pairs];metrics[key+'_'+kind]={'before':a,'after':b,'before_median_us':statistics.median(a),'after_median_us':statistics.median(b),'paired_changes_percent':[(y/x-1)*100 for x,y in zip(a,b)]}
  history.append({'stage':stage,'events':count,'mode':mode,'metrics':metrics})
functional=[]
for case in ['stream','large','tool','cancel']:
 for side in ['before','after']:
  p=r/'functional-products'/f'{case}-{side}.json';data=load(p);proc=load(p.with_name(p.stem+'.process.json'));validate_sample(proc,data,case,p.with_suffix('.log').read_text());functional.append({'file':str(p.relative_to(r)),'sha256':sha(p),'requests':len(data['wire_requests'])})
sources=[]
for label in ['baseline','statistics','candidate']:
 for case in ['short-small','short-large']:
  p=r/f'source-{label}-{case}.json';data=load(p);assert data['oracle']=='passed';assert data['samples'][0]['view']==data['reopened']['view'];sources.append({'label':label,'case':case,'sha256':sha(p),'values':data})
(r/'hot-audit.json').write_text(json.dumps({'accepted':True,'products':checks,'functional':functional,'hot':results,'history':history,'source':sources,'scope':'Frozen Rust controller/reopen/live oracles and full ordinary HTTP bodies replayed; no product/compiler/git/network. Timing descriptive only; CPU/window denominator unchanged.'},indent=2)+'\n');print(json.dumps({'accepted':True,'hot_products':len(checks),'functional_products':len(functional),'history_groups':len(history),'source_products':len(sources)}))
