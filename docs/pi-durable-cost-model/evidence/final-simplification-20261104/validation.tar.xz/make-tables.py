"""Render complete finite measurement tables from audited arithmetic."""
import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent;s=json.loads((r/'summary.json').read_text());lines=['# Final simplification: complete measurements','','Before is saved production e7289ac18; Statistics is35ae68b5f; final is3d5055779. No Pi/DeepSeek builds, products or performance runs. MiB=2^20 bytes, KiB=2^10 bytes. Changes are medians of same-pair percentages, not ratios of displayed medians. Hot, native, history, Source and WAL products have distinct denominators.','']
def table(headers,rows):
 lines.extend(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |']);lines.extend('| '+' | '.join(map(str,row))+' |' for row in rows);lines.append('')
def f(v):return 'unavailable' if v is None else f'{v:.3f}'
def vec(v):return ', '.join(f(x) for x in v)
def paired(v):return [f(v['before_median']),f(v['after_median']),f(v['paired_percent_median'])+'%']
for stage,modes in s['hot'].items():
 lines.extend(['## '+stage+' independent hot comparison','','32 hot turns after8/64 history; four alternating pairs per cell. CPU includes driver,10ms process ticks. live-subscriber excludes AppServer/WebUI transport.',''])
 rows=[];raw=[]
 for mode,data in modes.items():
  for case,m in data['medians'].items():
   for key in ['mean_turn_ms','turn_cpu_ms_per_turn','turn_write_mib_per_turn','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib']:
    ratio=m['after_over_before'][key];rows.append([mode,case,key,f(m['before'][key]),f(m['after'][key]),f((ratio-1)*100) if ratio is not None else 'unavailable'])
    values=data['samples'][case];raw.append([mode,case,key,vec([v['before'][key] for v in values]),vec([v['after'][key] for v in values]),vec([(v['after_over_before'][key]-1)*100 if v['after_over_before'][key] is not None else None for v in values])])
 table(['Mode','History case','Metric','Before','After','Paired %'],rows);table(['Mode','Case','Metric','Before pairs','After pairs','Paired % values'],raw)
lines.extend(['## Navigation retake after severe external I/O stress','','One bounded four-pair retake per hot cell; original matrix above is retained. No exclusivity claim: instantaneous device busy <5% at preflight, global PSI remained high. Short-history adverse values are not dropped.',''])
table(['Mode','Case','Metric','Before','After','Paired %'],[[mode,case,key,f(v['before'][key]),f(v['after'][key]),f((v['after_over_before'][key]-1)*100)] for mode,data in s['navigation_recheck']['summaries'].items() for case,v in data['medians'].items() for key in ['mean_turn_ms','turn_cpu_ms_per_turn','turn_write_mib_per_turn']])
lines.extend(['## History statistics','','Public API plus probe JSON conversion. Two alternating pairs; first is process-first check after appends, not disk-cold. Reopen means same process/new connection. All cut values agree.',''])
rows=[]
for v in s['history']:
 for key,m in v['metrics'].items():rows.append([v['stage'],v['events'],v['mode'],key,vec(m['before']),vec(m['after']),vec(m['paired_changes_percent'])])
table(['Step','Events','Mode','Read / µs','Before pairs','After pairs','Paired %'],rows)
lines.extend(['## Storage diagnostics','','One synchronous strace/SQL product per history/build, separate from timing.2KiB pages. WAL frames are page writes, not device writes; db growth and overflow deltas are endpoint net counts. Shared endpoint page-owner labels are not exact function attribution.',''])
rows=[]
for label,cases in s['wal'].items():
 for case,v in cases.items():
  cols=v['statistics_columns_delta'];rows.append([label,case,v['wal_frames'],v['wal_write_commits'],v['wal_frame_bytes'],v['database_used_bytes_growth'],sum(x[1] for x in cols.values()),str(cols),str(v['navigation_pages_delta']),v['source_page_overflow_net_delta']])
table(['Build','History','WAL frames','Commits','WAL bytes','Used DB growth bytes','Statistics bytes','Statistics records / bytes','Navigation page / byte delta','Source overflow net pages'],rows)
lines.extend(['## Native memory','','Fresh fixed cohort: four balanced pairs; sampled ordinary GNU-allocator process endpoints, not peaks or live heap. All128sessions have8turns at the seeding endpoint.',''])
table(['Endpoint','Metric','Before','After','Paired %','Before values','After values'],[[phase,key,*paired(v),vec(v['before']),vec(v['after'])] for phase,metrics in s['memory'].items() for key,v in metrics.items()])
table(['Eight-turn growth /session MiB','Before','After','Paired %','Before values','After values'],[['Anonymous PSS',*paired(s['growth_per_session_mib']),vec(s['growth_per_session_mib']['before']),vec(s['growth_per_session_mib']['after'])]])
lines.extend(['## Native activity','','Server PID only. Original fixed four pairs retained as shared-load diagnostics; fresh fixed has four balanced pairs. Fixed1/4/8:128×8seed,16rounds per width; rotating4:128rounds/512calls. Deep:8×64,32rounds width4, two balanced pairs. Latency excludes held first round; CPU/write includes it. P95/P99 are finite sample summaries.',''])
rows=[]
for family,values in s['activity'].items():
 for item in values:
  for key,m in item['metrics'].items():rows.append([family,item['width'],key,*paired(m),vec(m['before']),vec(m['after']),vec(m['paired_percent'])])
table(['Family','Width','Metric','Before','After','Paired %','Before values','After values','Paired % values'],rows)
lines.extend(['## Deep-history memory','','Two separate pairs, eight sessions,8/16/32/64turn endpoints; not pooled into128×8.',''])
table(['Endpoint','Metric','Before','After','Paired %','Before values','After values'],[[phase,key,*paired(v),vec(v['before']),vec(v['after'])] for phase,metrics in s['deep_memory'].items() for key,v in metrics.items()])
lines.extend(['## Request Source inspection','','One ordinary public-API probe per history/build on consistent closed images. Header/page/range first calls are sequential in one connection; repeated calls include intervening child-field correctness checks. Reopen is same process/new connection. Whole Source bytes and every top-level child agree; old request survives later requests. No cross-process Source cache is claimed.',''])
table(['Build','History','Request','Operation','Encoded bytes','First µs','Repeated µs'],[[v['label'],v['case'],item['kind'],op,item['encoded_bytes'],f(values['first_us']),f(values['repeated_median_us'])] for v in s['source'] for item in v['samples'] for op,values in item['timings'].items()])
lines.extend(['## Cold/cache diagnostic','','One before/after product per side, functional/cost diagnostic rather than a timing confidence cohort.32s endpoint is128×8;130s has4×14and124×8. Cold/warm latency excludes4kept-active and2Inspector-primed sessions (122eligible); CPU/write includes128.',''])
cache={v['side']:v['metrics'] for v in s['cache']['products']}
table(['Endpoint','Metric','Before','After'],[[phase,key,f(cache['before']['memory'][phase][key]),f(cache['after']['memory'][phase][key])] for phase in ['seeded_history_8','cache_pages_idle','cache_statements_idle','all_unloaded'] for key in ['anon_pss_mib','rss_mib']])
table(['Rotation','Metric','Before','After'],[[label,key,f(cache['before'][label]['cold_eligible'][key]),f(cache['after'][label]['cold_eligible'][key])] for label in ['cold','warm'] for key in ['settled_median_ms','settled_p95_ms']])
table(['Side','Inspector/history/2 Source reads ms','Max kept-warm gap s','Warm gaps≥30s'],[[side,f(v['inspector']['elapsed_ms']),f(v['kept_warm']['maximum_same_session_db_idle_seconds']),v['warm']['gaps_over30seconds']] for side,v in cache.items()])
(r/'tables.md').write_text('\n'.join(lines).rstrip()+'\n')
