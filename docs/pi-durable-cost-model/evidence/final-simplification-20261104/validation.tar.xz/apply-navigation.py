from pathlib import Path
import shutil
r=Path(__file__).resolve().parent;b=Path('src/durable/sqlite/observation_request/composed');shutil.copy2(r/'page_codec.rs',b/'page_codec.rs')
p=b/'index.rs';s=p.read_text().replace('codec::Size','usize').replace('usize::new()','codec::HEADER');s=s.replace('''        let previous = self.entries.last().map_or("", |entry| entry.0.as_str());
        let mut size = codec::leaf_size(previous, &key, &value);''','''        let size = codec::leaf_size(&key, &value);''').replace('!self.entry_bytes.plus(size).fits()','self.entry_bytes.saturating_add(size) > PAGE_BYTES').replace('''            // A new page cannot borrow any bytes from the previous page's key.
            size = codec::leaf_size("", &key, &value);
''','').replace('self.entry_bytes.plus(size)','self.entry_bytes.saturating_add(size)')
s=s.replace('''        let previous = self.levels[level]
            .children
            .last()
            .map_or("", |child| child.last.as_str());
        let mut size = codec::branch_size(previous, &reference);''','''        let size = codec::branch_size(&reference);''').replace('!self.levels[level].size.plus(size).fits()','self.levels[level].size.saturating_add(size) > PAGE_BYTES').replace('''            size = codec::branch_size("", &reference);
''','').replace('self.levels[level].size.plus(size)','self.levels[level].size.saturating_add(size)');p.write_text(s)
for name in ['src/durable/sqlite.rs','src/durable/sqlite/reading_tests.rs','src/durable/sqlite/observation_event_probe_tests.rs','src/durable/sqlite/observation_request/composed/scalar_tests.rs']:
 p=Path(name);s=p.read_text().replace('SQLITE_SCHEMA_VERSION: i64 = 95','SQLITE_SCHEMA_VERSION: i64 = 96').replace('SQLITE_SCHEMA_VERSION, 95','SQLITE_SCHEMA_VERSION, 96').replace('expected: 95','expected: 96');s=s.replace('pub const SQLITE_SCHEMA_VERSION: i64 = 96;','/// Version 96 stores bounded full-key binary Request Source navigation pages.\npub const SQLITE_SCHEMA_VERSION: i64 = 96;');p.write_text(s)
p=b/'page_codec_tests.rs';s=p.read_text();s=s[:s.index('// Deliberately bypasses')];s=s.replace('RXSP\\x02','RXSP\\x03').replace('\\x01\\x00\\x00\\x00\\x03\\x00','\\x01\\x00\\x03\\x00').replace('&encoded[..16]','&encoded[..14]').replace('&encoded[16..]','&encoded[14..]').replace('45_136','45_134');s=s.replace('b"RXSP\\x03\\x00\\x01\\x00\\x00\\x00\\x41\\x10"','b"RXSP\\x03\\x00\\x01\\x00\\x41\\x10"').replace('b"RXSP\\x03\\x00\\x01\\x00\\x00\\x00\\x00\\x00\\xff','b"RXSP\\x03\\x00\\x01\\x00\\x00\\x00\\xff').replace('b"RXSP\\x03\\x00\\x01\\x00\\x00\\x00\\x01\\x00\\xff"','b"RXSP\\x03\\x00\\x01\\x00\\x01\\x00\\xff"')
s+=(r/'page-full-key-tests.rs').read_text();p.write_text(s)
