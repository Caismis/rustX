"""Resume after a compiler-preflight rejection; zero earlier navigation samples.
Candidate probe artifacts already built and verified. No production change.
"""
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');rows=[];os.sched_setaffinity(0,[2,8]);commands=[('navigation-hot',[sys.executable,str(r/'run-step.py'),'navigation-step','statistics','candidate']),('wal-candidate',[sys.executable,str(r/'run-wal.py'),'--label','candidate','--binary',str(r/'candidate-build/conformance')]),('wal-analysis-candidate',[sys.executable,str(r/'analyze-wal.py'),'--label','candidate'])]
for name in ['statistics-probe','source-probe']:
 p=r/'candidate-build'/name;m=json.loads(p.with_suffix('.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==m['binary_sha256'] and hashlib.sha256((r/(name+'.rs')).read_bytes()).hexdigest()==m['source_sha256']
for case in ['short-small','short-large']:commands.append(('source-candidate-'+case,[str(r/'candidate-build/source-probe'),str(r/('wal-candidate-'+case+'-rust'))]))
for mode in ['no-live-subscriber','live-subscriber']:commands.append(('navigation-summary-'+mode,[sys.executable,str(repo/'benchmarks/runtime/summarize-comparisons.py'),str(r/'navigation-step'/mode)]))
commands += [('native-products',[sys.executable,str(r/'run-products.py')]),('functional-products',[sys.executable,str(r/'functional-products.py')])]
for name,cmd in commands:
 while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:time.sleep(1)
 row={'name':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'final-measure-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if name.startswith('source-candidate-'):
  raw=json.loads((r/(name+'.stdout')).read_text().splitlines()[-1]);assert raw['oracle']=='passed';(r/(name+'.json')).write_text(json.dumps(raw,indent=2)+'\n')
(r/'navigation-completed.json').write_text('{"accepted":true}\n');(r/'measurements-completed.json').write_text('{"accepted":true}\n')
