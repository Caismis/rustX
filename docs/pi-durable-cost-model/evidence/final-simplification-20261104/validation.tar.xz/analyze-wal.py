import ast,collections,json,re,struct,argparse
from pathlib import Path
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--label',choices=['baseline','statistics','navigation','candidate'],required=True);args=parser.parse_args();label=args.label
target=root/f'wal-summary-{label}-corrected.json'
assert not target.exists(), 'retain previous summary; do not overwrite evidence'
summary={}
for engine in ['short-small-rust','short-large-rust']:
 path=root/('wal-'+label+'-'+engine);before=json.loads((path/'before_measured_turns-database.json').read_text())[0];after=json.loads((path/'after_turns-database.json').read_text())[0]
 assert before['page_size']==after['page_size']==2048
 owners=collections.defaultdict(set)
 for snapshot in [before,after]:
  for name,page,*_ in snapshot['pages']:owners[page].add(name)
 frames=collections.Counter();commits=0;pending={};phase='startup';allcommits=collections.Counter();unresolved=0;datawrites=collections.Counter();txpages=[];tx=collections.Counter();active=False;headers=collections.Counter();payloads=collections.Counter()
 for line in (path/'calls.strace').read_text().splitlines():
  m=re.match(r'(\d+)\s+(.*)',line)
  if not m:continue
  pid,call=m.groups()
  if '<unfinished ...>' in call:
   assert pid not in pending;pending[pid]=call.split('<unfinished ...>')[0];continue
  m=re.match(r'<\.\.\. \w+ resumed>(.*)',call)
  if m:
   assert pid in pending,(pid,call);call=pending.pop(pid)+m[1]
  if 'UNIX-STREAM' in call and 'before_measured_turns' in call:phase='steady';active=True
  if 'UNIX-STREAM' in call and 'after_turns' in call:phase='after_turns';active=False
  if active and call.startswith('pwrite64(') and '-wal>' in call:
   tail=re.search(r', (\d+), (\d+)\s*\)\s*=\s*(\d+)$',call)
   assert tail,('unparsed WAL write',call)
   n,o,ret=map(int,tail.groups());assert n==ret
   if n==24:
    assert (o-32)%2072==0;headers[o]+=1
   elif n==2048:
    assert (o-56)%2072==0;payloads[o-24]+=1
   else:assert n==32 and o==0,('unexpected WAL write',n,o)
  m=re.match(r'pwrite64\(\d+<([^>]+-wal)>, ("(?:\\.|[^"\\])*"), (\d+), (\d+)\s*\)\s*=\s*(\d+)$',call)
  if not m:continue
  fn,quoted,n,offset,ret=m.groups();n,offset,ret=map(int,(n,offset,ret));assert ret==n
  if active:assert fn==before['path']+'-wal',('unexpected steady WAL',fn)
  if n!=24:continue
  data=ast.literal_eval('b'+quoted);assert len(data)==24
  page,size=struct.unpack('>II',data[:8]);assert (offset-32)%2072==0
  if active:
   frames[page]+=1;tx[page]+=1
  if size:
   allcommits[phase]+=1
   if active:commits+=1;txpages.append(dict(tx));tx.clear()
 assert not pending;assert not tx;assert phase=='after_turns';assert commits>0
 assert headers==payloads and sum(headers.values())==sum(frames.values()), 'header/payload/parser coverage differs'
 bytable=collections.Counter()
 for page,n in frames.items():bytable['|'.join(sorted(owners[page])) or '<unmapped>']+=n
 delta={k:after['counts'][k]-before['counts'].get(k,0) for k in after['counts'] if after['counts'][k]!=before['counts'].get(k,0)}
 s={'steady_turns':32,'wal_write_commits':commits,'wal_frames':sum(frames.values()),'wal_frame_bytes':sum(frames.values())*2072,'commits_by_phase':allcommits,'wal_frames_by_snapshot_page_owner':dict(bytable.most_common()),'net_row_count_changes':delta,'transaction_page_counts':[sum(t.values()) for t in txpages],'limitations':'WAL write-commit markers, not read-only SQL commits. Snapshot dbstat ownership at endpoints; mixed owners or unmapped pages explicit, intermediate page reuse not excluded. No exclusive timing or semantic parity inference.'}
 s['statistics_columns_delta']={k:[v[0]-before['statistics_columns'][k][0],v[1]-before['statistics_columns'][k][1]] for k,v in after['statistics_columns'].items()}
 s['database_used_bytes_growth']=((after['page_count']-after['freelist_count'])-(before['page_count']-before['freelist_count']))*2048
 s['source_page_encodings']={'before':before['source_page_encoding'],'after':after['source_page_encoding']}
 summary[engine]=s
target.write_text(json.dumps(summary,indent=2));print(json.dumps({e:{k:v for k,v in s.items() if k not in ['sql_counts','v8_cpu','transaction_page_counts']} for e,s in summary.items()},indent=2))
