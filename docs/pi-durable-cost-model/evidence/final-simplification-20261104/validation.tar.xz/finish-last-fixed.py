"""Recover completed product metadata after coordinator TERM; run only missing pair3."""
import datetime,json,os,subprocess,sys
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');load=lambda p:json.loads(p.read_text());rows=load(r/'product-commands.json')
name='fresh-ordinary-2-before';d=r/name
if not any(v['directory']==name for v in rows):
 assert load(d/'completed.json')['accepted'];identity=load(d/'identity.json');assert identity['sessions']==128 and identity['history_turns']==8 and identity['widths']==[1,4,8] and identity['rounds']==16
 utc=lambda t:datetime.datetime.fromtimestamp(t,datetime.timezone.utc).isoformat()
 rows.append({'family':'ordinary-fresh','pair':2,'side':'before','directory':name,'command':[sys.executable,str(r/'capacity-ordinary.py'),'--binary',str(r/'baseline-build/rustx'),'--output',str(d),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16'],'start_utc':utc((d/'identity.json').stat().st_mtime),'end_utc':utc((d/'completed.json').stat().st_mtime),'exit':0,'coordinator_metadata_recovery':'Parent terminated143 after accepted child wrote closed images/report/completed. UTC boundaries recovered from file mtimes, not used as product timing. Exact latency/PID counters untouched.'})
 (r/'product-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
for side in ['before','after']:
 name=f'fresh-ordinary-3-{side}';binary=r/('baseline-build' if side=='before' else 'candidate-build')/'rustx';cmd=[sys.executable,str(r/'capacity-ordinary.py'),'--binary',str(binary),'--output',str(r/name),'--sessions','128','--history','8','--widths','1','4','8','--rounds','16'];row={'family':'ordinary-fresh','pair':3,'side':side,'directory':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'io_start':Path('/proc/pressure/io').read_text()}
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),io_end=Path('/proc/pressure/io').read_text());rows.append(row);(r/'product-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0 and load(r/name/'completed.json')['accepted']
(r/'fixed-four-completed.json').write_text('{"accepted":true}\n')
