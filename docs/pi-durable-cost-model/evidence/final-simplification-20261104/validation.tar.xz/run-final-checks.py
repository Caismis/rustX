"""Run full local branch verification; performance artifacts are already saved.
No macOS claim and no main integration are implied by these Linux checks.
"""
import datetime,hashlib,json,os,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=r/'checks-final';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snap():
 names=subprocess.check_output(['git','ls-files','--','src','tests','protocol','tui','web-console','dev','benchmarks/runtime','Cargo.toml','Cargo.lock','rust-toolchain.toml'],cwd=repo,text=True).splitlines()
 return {name:sha(repo/name) for name in names}

source=snap();(out/'source-before.json').write_text(json.dumps(source,indent=2)+'\n');rows=[];env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2','UV_OFFLINE':'1','RUSTX_BINARY':'/home/capi/.cache/rustx-pr485-target/release/rustx'};base=['cargo'];flags=['--release','--config','profile.release.package.rustx.opt-level=0','--locked','--all-features']
commands=[('fmt',['cargo','fmt','--all','--','--check'],repo),('clippy',['cargo','clippy',*flags,'--all-targets','--','-D','warnings'],repo),('benchmark-tests',['python3','-m','unittest','discover','-s','benchmarks/runtime','-p','test_*.py','-v'],repo),('rust-build',['cargo','build',*flags,'--bins','--examples'],repo),('rust-full',['cargo','test',*flags,'--lib','--bins','--examples','--tests','--','--test-threads=1'],repo),('rust-doc',['cargo','test',*flags,'--doc'],repo)]
for name in ['protocol/app-server','tui','web-console']:
 commands.append((name.replace('/','-')+'-typecheck',['pnpm','typecheck'],repo/name))
commands += [('tui-test',['pnpm','test'],repo/'tui'),('web-test',['pnpm','test'],repo/'web-console'),('web-i18n',['pnpm','check:i18n'],repo/'web-console'),('web-provenance',['pnpm','check:provenance'],repo/'web-console')]
for label,cmd,cwd in commands:
 row={'label':label,'command':cmd,'cwd':str(cwd),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(label+'.stdout')).open('x') as so,(out/(label+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=cwd,env=env,stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(out/'commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
# Native-addon rebuilds may change ignored build files, never checked sources.
assert source==snap();(out/'source-after.json').write_text(json.dumps(snap(),indent=2)+'\n');(r/'checks-completed.json').write_text('{"accepted":true}\n')
