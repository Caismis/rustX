from pathlib import Path
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
def change(name,old,new):
 p=repo/name;s=p.read_text();assert old in s,(name,old);p.write_text(s.replace(old,new))
old=(repo/'src/durable/sqlite/observation_statistics/history.rs').read_text()
bootstrap=old[old.index('fn bootstrap('):old.index('fn hole(')]
record='''//! One self-contained full statistics record per relevant event. Facts and
//! state share one bounded cell; no history chain or separate checkpoint column.
use super::contribution::Contribution;
use super::{
    Connection, ConversationStoreError, OptionalExtension, StatisticsLayout, codec, decode, encode,
    fields, normalized_fold, params, shared, storage,
};
use sha2::{Digest as _, Sha256};

const PREFIX: usize = 36;
pub(in crate::durable::sqlite) const MAX_BYTES: usize = 2 * codec::MAX_BYTES + PREFIX;
pub(super) struct Frame {
    pub(super) sequence: u64,
    pub(super) state: StatisticsLayout,
}

/// The two component tuples keep their existing independent JSON admission.
/// The fixed prefix is a binding digest plus the fact length. Both are always
/// present: there is only one record shape, not checkpoint/delta variants.
pub(super) fn capture(
    sequence: u64,
    contribution: &Contribution,
    state: &StatisticsLayout,
) -> Result<Vec<u8>, ConversationStoreError> {
    let fact = codec::encode(
        &(sequence, contribution.fields()),
        &(sequence, contribution.fields()),
        crate::durable::observation::HEADER_ENCODED_MAX,
    )?;
    let state = encode(state)?;
    let mut record = Vec::with_capacity(PREFIX + fact.len() + state.len());
    record.resize(32, 0);
    record.extend_from_slice(
        &u32::try_from(fact.len()).expect("bounded statistics fact").to_le_bytes(),
    );
    record.extend_from_slice(&fact);
    record.extend_from_slice(&state);
    let digest = binding(sequence, &record[32..]);
    record[..32].copy_from_slice(&digest);
    #[cfg(test)]
    super::WRITE_WORK.with(|work| {
        let (full, records) = work.get();
        work.set((full, records + 1));
    });
    Ok(record)
}

fn binding(sequence: u64, payload: &[u8]) -> [u8; 32] {
    let mut digest = Sha256::new();
    digest.update(b"rustx-full-statistics-record-v1\\0");
    digest.update(sequence.to_be_bytes());
    digest.update(payload);
    digest.finalize().into()
}
pub(super) fn parts(
    sequence: u64,
    bytes: &[u8],
) -> Result<(&[u8], &[u8]), ConversationStoreError> {
    if !(PREFIX + 2..=MAX_BYTES).contains(&bytes.len())
        || bytes[..32] != binding(sequence, &bytes[32..])
    {
        return Err(storage("statistics record differs from its fact binding"));
    }
    let fact_length = u32::from_le_bytes(
        bytes[32..PREFIX].try_into().expect("checked record prefix"),
    ) as usize;
    if fact_length == 0 || fact_length > codec::MAX_BYTES {
        return Err(storage("statistics fact length invalid"));
    }
    let end = PREFIX.checked_add(fact_length)
        .filter(|end| *end < bytes.len())
        .ok_or_else(|| storage("statistics record length invalid"))?;
    let state = &bytes[end..];
    if state.len() > codec::MAX_BYTES {
        return Err(storage("statistics state length invalid"));
    }
    Ok((&bytes[PREFIX..end], state))
}
fn restore(sequence: u64, bytes: &[u8]) -> Result<StatisticsLayout, ConversationStoreError> {
    let (fact, state) = parts(sequence, bytes)?;
    let (position, contribution): (u64, super::contribution::Stored) =
        codec::decode_json_tuple(fact, crate::durable::observation::HEADER_ENCODED_MAX)?;
    if position != sequence {
        return Err(storage("statistics fact position invalid"));
    }
    // Keep independent fact validation even though public history needs only
    // this record's full state. No native event body is a recovery fallback.
    Contribution::restore(contribution, sequence)?;
    let state = normalized_fold(decode(state)?);
    codec::admit(
        &fields(&state, shared(&state)),
        crate::durable::observation::HEADER_ENCODED_MAX,
    )?;
    Ok(state)
}
'''
record+=bootstrap
record+='''pub(super) fn layout(
    connection: &Connection,
    through: u64,
) -> Result<Frame, ConversationStoreError> {
    let latest = connection
        .prepare_cached(super::super::event_heads::STATISTICS)
        .and_then(|mut statement| statement.query_row([through], |row| {
            let sequence: u64 = row.get(0)?;
            let state = match row.get_ref(1)? {
                rusqlite::types::ValueRef::Blob(bytes) => {
                    #[cfg(test)]
                    super::record_read(1, bytes.len());
                    restore(sequence, bytes)
                }
                _ => Err(storage("statistics record type invalid")),
            };
            Ok(state.map(|state| Frame { sequence, state }))
        }))
        .optional()
        .map_err(|error| storage(error.to_string()))?
        .transpose()?;
    let sequence = latest.as_ref().map_or(0, |frame| frame.sequence);
    // A newer independent full record survives damage before its own cut.
    // Missing relevant facts after the selected record still fail closed.
    let missing: bool = connection.prepare_cached(
        "SELECT EXISTS(SELECT 1 FROM events INDEXED BY events_aggregate_holes_idx WHERE observation_aggregate_holes>0 AND observation_aggregate_holes IN (4,5,6,7) AND sequence>?1 AND sequence<=?2)",
    ).and_then(|mut statement| statement.query_row(params![sequence, through], |row| row.get(0)))
        .map_err(|error| storage(error.to_string()))?;
    if missing {
        return Err(storage("native statistics record unavailable"));
    }
    match latest {
        Some(frame) => Ok(frame),
        None => Ok(Frame { sequence: 0, state: bootstrap(connection)? }),
    }
}
'''
(repo/'src/durable/sqlite/observation_statistics/record.rs').write_text(record)
(repo/'src/durable/sqlite/observation_statistics/history.rs').unlink()
p=repo/'src/durable/sqlite/observation_statistics.rs';s=p.read_text().replace('//! Independent statistical facts with bounded checkpoint replay in the native commit.','//! Independent statistical facts and self-contained full historical states.').replace('mod history;','mod record;').replace('history::Frame','record::Frame').replace('history::layout','record::layout').replace('Verify the current checkpoint and its bounded fact suffix.','Verify the selected self-contained full record.')
s=s.replace('    pub(super) checkpoint: Option<Vec<u8>>,\n','').replace('cache.stage(fold, data, capture.bytes, self.checkpoint);','cache.stage(fold, data, capture.bytes);').replace('        checkpoint: None,\n','')
a='''    let (record, checkpoint) =
        history::Record::capture(&frame, event.sequence, contribution, &frame.state)?;
    let bytes = record.encode()?;'''
assert a in s;s=s.replace(a,'''    let bytes = record::capture(event.sequence, &contribution, &frame.state)?;''').replace('    frame.anchor = record.anchor;\n    frame.distance = record.distance;\n','').replace('    prepared.checkpoint = checkpoint;\n','');p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics/owner.rs';s=p.read_text().replace('use super::history::Frame;','use super::record::Frame;').replace('    checkpoint: Option<Vec<u8>>,\n','').replace('                    "observation_statistics_checkpoint",\n','')
s=s.replace('selected.get(3)','selected.get(2)').replace('selected.get(1..3)','selected.get(1..2)').replace('                checkpoint,\n','')
a='''                    let checkpoint=match(row.get_ref(2)?,certificate.checkpoint.as_deref()){
                        (rusqlite::types::ValueRef::Null,None)=>true,
                        (rusqlite::types::ValueRef::Blob(bytes),Some(expected))=>bytes==expected,
                        _=>false,
                    };
                    Ok(sequence==certificate.frame.sequence&&fact&&checkpoint)'''
assert a in s;s=s.replace(a,'                    Ok(sequence==certificate.frame.sequence&&fact)')
s=s.replace('and its optional checkpoint are exactly the ones we staged. Borrow','is exactly the full record we staged. Borrow');p.write_text(s)
p=repo/'src/durable/sqlite/observation_statistics/contribution.rs';s=p.read_text();start=s.index('    pub(super) fn terminal(');end=s.index('    pub(super) fn apply(',start);s=s[:start]+s[end:];p.write_text(s)
p=repo/'src/durable/sqlite/event_heads.rs';s=p.read_text();s=s.replace("CASE WHEN typeof(observation_statistics)='blob' AND length(observation_statistics)<=49152 THEN observation_statistics ELSE 0 END,\n    CASE WHEN observation_statistics_checkpoint IS NULL THEN NULL WHEN typeof(observation_statistics_checkpoint)='blob' AND length(observation_statistics_checkpoint)<=49152 THEN observation_statistics_checkpoint ELSE 0 END", "CASE WHEN typeof(observation_statistics)='blob' AND length(observation_statistics)<=98340 THEN observation_statistics ELSE 0 END");p.write_text(s)
p=repo/'src/durable/sqlite/event_insert.rs';s=p.read_text().replace('observation_unavailable,observation_statistics_checkpoint)','observation_unavailable)').replace(',?39)',')').replace(',aggregate.and_then(|value|value.statistics.checkpoint.as_ref())','');p.write_text(s)
p=repo/'src/durable/sqlite/append_facts.rs';s=p.read_text();print('remaining append checkpoint lines:',[v for v in s.splitlines() if 'statistics_checkpoint' in v])
s=s.replace(',observation_statistics_checkpoint=?4','').replace(',prepared.statistics.checkpoint.as_deref()','').replace(',aggregates.statistics.checkpoint.as_deref()','');p.write_text(s)
p=repo/'src/durable/sqlite.rs';s=p.read_text().replace('pub const SQLITE_SCHEMA_VERSION: i64 = 94;','pub const SQLITE_SCHEMA_VERSION: i64 = 95;').replace('assert_eq!(SQLITE_SCHEMA_VERSION, 94)','assert_eq!(SQLITE_SCHEMA_VERSION, 95)')
s=s.replace('observation_statistics BLOB CHECK(observation_statistics IS NULL OR length(observation_statistics)<=49152),','observation_statistics BLOB CHECK(observation_statistics IS NULL OR length(observation_statistics)<=98340),')
s=''.join(v for v in s.splitlines(True) if 'observation_statistics_checkpoint' not in v)
p.write_text(s)
for name in ['src/durable/sqlite/reading_tests.rs','src/durable/sqlite/observation_event_probe_tests.rs','src/durable/sqlite/observation_request/composed/scalar_tests.rs']:
 p=repo/name;s=p.read_text().replace('SQLITE_SCHEMA_VERSION, 94','SQLITE_SCHEMA_VERSION, 95').replace('expected: 94','expected: 95');p.write_text(s)
