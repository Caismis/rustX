use rustx::durable::{ConversationStore,SqliteConversationStore};
use rustx::events::types::{RuntimeEvent,RuntimeEventEnvelope,EVENT_SCHEMA_VERSION};
use rustx::runtime::identity::{ConversationId,AttemptId,EventId};
use serde_json::json;
use std::sync::{Arc,Barrier};
use std::time::Instant;
fn ns(at:Instant)->u64{at.elapsed().as_nanos().try_into().unwrap()}
fn io()->String{std::fs::read_to_string("/proc/self/io").unwrap()}
fn append(store:&SqliteConversationStore,i:usize){
 let attempt=AttemptId::new(format!("stats-owner-{i}"));
 let event=RuntimeEventEnvelope{schema_version:EVENT_SCHEMA_VERSION,event_id:EventId::new(format!("stats-event-{i}")),sequence:0,tool_occurrence:None,observation:None,conversation_id:store.conversation_id().clone(),attempt_id:Some(attempt.clone()),turn_id:None,timestamp:chrono::DateTime::parse_from_rfc3339("2026-01-01T00:00:00Z").unwrap().with_timezone(&chrono::Utc),event:RuntimeEvent::AttemptStarted{attempt_id:attempt}};
 store.append_event(event).unwrap();
}
fn read(store:&SqliteConversationStore,cut:u64)->serde_json::Value{
 let view=store.observation_agent_statistics(cut).unwrap();assert_eq!(view.statistics.turns,cut);assert_eq!(view.statistics.steps,0);assert_eq!(view.duration.settled_ms,0);assert!(view.duration.active.is_some());serde_json::to_value(view).unwrap()
}
fn sample(store:&SqliteConversationStore,cut:u64)->serde_json::Value{
 let at=Instant::now();let original=read(store,cut);let first_ns=ns(at);let mut repeated=Vec::new();
 for _ in 0..32{let at=Instant::now();assert_eq!(read(store,cut),original);repeated.push(ns(at));}
 json!({"cut":cut,"first_ns":first_ns,"repeated_ns":repeated,"value":original})
}
fn main(){
 let args:Vec<String>=std::env::args().collect();let root=std::path::Path::new(&args[1]);let count:usize=args[2].parse().unwrap();let concurrent=args[3]=="concurrent";std::fs::create_dir_all(root).unwrap();
 let id=ConversationId::new("conv_36524fd8-f674-7fc2-8125-06d01fee0e18");let at_all=Instant::now();let store=Arc::new(SqliteConversationStore::open(id.clone(),&root.join("conversation.sqlite")).unwrap());store.initialize(&[]).unwrap();
 let before=io();let at=Instant::now();for i in 0..count{append(&store,i);}let append_ns=ns(at);let after_append=io();
 let cut63=sample(&store,63);let cut64=sample(&store,64);let old=read(&store,63);let mut concurrent_reads=Vec::new();let mut writer_ns=None;
 if concurrent{
  let barrier=Arc::new(Barrier::new(3));let writer=Arc::clone(&store);let sync=Arc::clone(&barrier);let writing=std::thread::spawn(move||{sync.wait();let at=Instant::now();for i in count..count+32{append(&writer,i);}ns(at)});
  let reader=Arc::clone(&store);let sync=Arc::clone(&barrier);let original=old.clone();let reading=std::thread::spawn(move||{sync.wait();let mut times=Vec::new();for _ in 0..64{let at=Instant::now();assert_eq!(read(&reader,63),original);times.push(ns(at));}times});
  barrier.wait();writer_ns=Some(writing.join().unwrap());concurrent_reads=reading.join().unwrap();
 }
 for cut in 1..=count as u64 {read(&store,cut);}
 let after_read=io();drop(store);let reopened=SqliteConversationStore::open_existing(id,&root.join("conversation.sqlite")).unwrap();let reopened63=sample(&reopened,63);assert_eq!(reopened63["value"],old);drop(reopened);
 println!("{}",json!({"events":count,"concurrent":concurrent,"append_ns":append_ns,"cut63":cut63,"cut64":cut64,"reopened63":reopened63,"concurrent_reads_ns":concurrent_reads,"concurrent_writer_ns":writer_ns,"io_before":before,"io_after_append":after_append,"io_after_read":after_read,"io_after_close":io(),"elapsed_ns":ns(at_all),"oracle":"passed"}));
}
