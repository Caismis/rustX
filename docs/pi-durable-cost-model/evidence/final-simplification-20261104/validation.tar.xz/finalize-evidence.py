"""Finalize existing audits after the finite four-pair fixed retake."""
import datetime,json,subprocess,sys,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');rows=[]
while not (r/'fixed-four-completed.json').exists():time.sleep(2)
for name,args in [('prepare-bindings.py',[]),('audit-native.py',[]),('audit-requests.py',[]),('audit-cache.py',[]),('audit-hot.py',[]),('audit-source.py',[]),('audit-host.py',[]),('audit-recheck.py',[]),('arithmetic.py',[]),('make-tables.py',[])]:
 cmd=[sys.executable,str(r/name),*args];row={'script':name,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/('final-'+name+'.stdout')).open('x') as so,(r/('final-'+name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
 row.update(exit=p.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'final-audit-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(r/'audits-completed.json').write_text('{"accepted":true,"fixed_pairs":4}\n')
for name,cmd in [('package',[sys.executable,str(r/'pack.py')]),('offline-replay',[sys.executable,str(Path('/home/capi/.cache/rustx-pr485-final-simplification-publish-20261104/replay.py')),'--directory','/home/capi/.cache/rustx-pr485-final-simplification-publish-20261104','--output','/home/capi/.cache/rustx-pr485-final-simplification-publish-20261104/replay-result.json'])]:
 with (r/(name+'.stdout')).open('x') as so,(r/(name+'.stderr')).open('x') as se:p=subprocess.run(cmd,cwd=repo,stdout=so,stderr=se)
 print(name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
(r/'evidence-completed.json').write_text('{"accepted":true}\n')
