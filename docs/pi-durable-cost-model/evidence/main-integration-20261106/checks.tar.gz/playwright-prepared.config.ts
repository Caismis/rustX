import base from '/home/capi/.codex/worktrees/pr485-pi-performance/rustX/web-console/playwright.config.ts';
// Native addons were already built and checked. Keep every test and assertion
// while avoiding parallel node-gyp rebuilds in this shared local checkout.
export default { ...base, testDir: '/home/capi/.codex/worktrees/pr485-pi-performance/rustX/web-console/test/e2e', webServer: base.webServer.map((server, index) => ({ ...server, cwd: '/home/capi/.codex/worktrees/pr485-pi-performance/rustX/web-console', ...(index === 1 ? { command: `pnpm exec vite --host 127.0.0.1 --config test/workbench.vite.config.ts --port ${process.env.RUSTX_E2E_FIXTURE_PORT} --strictPort` } : {}) })) };
