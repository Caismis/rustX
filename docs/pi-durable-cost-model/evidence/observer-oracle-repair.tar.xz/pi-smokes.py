from pathlib import Path
import importlib.util, json, os, subprocess
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('controller',repo/'benchmarks/runtime/controller.py')
import sys
sys.path.insert(0,str(repo/'benchmarks/runtime'));controller=importlib.util.module_from_spec(spec);spec.loader.exec_module(controller)
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))}
env['UV_CACHE_DIR']='/workspace/.uv-cache'
(root/'pi-runtime.txt').write_text(subprocess.check_output(['node','--version'],text=True))
records=[]
for mode in ['no-live-subscriber','live-subscriber']:
 for case in controller.CASES:
  stem=root/f'pi-{mode}-{case}'
  assert not stem.with_suffix('.json').exists()
  output=stem.with_suffix('.json')
  child_env=env|{'RUSTX_BENCH_OBSERVER_MODE':mode}
  argv=['node','--conditions=source','benchmarks/runtime/pi-http.mjs','/workspace/pi-481',case,str(output)]
  record=controller.run(argv,stem,case,child_env,repo/'test-support/fake-provider')
  records.append(record)
  print(mode,case,'accepted',record['accepted'],record.get('error',''),flush=True)
(root/'pi-smoke-results.json').write_text(json.dumps(records,indent=2)+'\n')
raise SystemExit(int(any(not r['accepted'] for r in records)))
