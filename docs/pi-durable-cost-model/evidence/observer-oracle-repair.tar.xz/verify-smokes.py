from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
binary=Path('/workspace/issue-481-evidence/observer-oracle-v2-build/conformance')
identity=json.loads((binary.parent/'identity.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert identity['verified'] and identity['head']==head=='b6c5b4a67775c4db36540e5ee840afcce9ccc45b'
assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==identity['sha256']
assert all(hashlib.file_digest((repo/path).open('rb'),'sha256').hexdigest()==expected for path,expected in identity['harness'].items())
(root/'smoke-build-identity.json').write_text(json.dumps(identity,indent=2)+'\n')
commands=[['--list'],['agent_loop::runtime_benchmark::request_oracle::tests::','--nocapture'],['agent_loop::runtime_benchmark::aligned::explicit_terminal_duplicates_fail_while_checkpoint_sightings_remain_idempotent','--exact','--nocapture']]
for name,args,count in zip(['rust-discovery','rust-request-oracle-negatives','rust-explicit-terminal-negative'],commands,[None,6,1]):
 with (root/(name+'.log')).open('w') as log:
  subprocess.run([str(binary),*args],cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
 if count is not None:
  evidence=(root/(name+'.log')).read_text();assert f'running {count} test' in evidence and f'{count} passed; 0 failed' in evidence
for mode in ['no-live-subscriber','live-subscriber']:
 command=['python3','benchmarks/runtime/controller.py','--rust',str(binary),'--pi','/workspace/pi-481','--output',str(root/f'paired-{mode}'),'--pairs','1','--observer-mode',mode]
 with (root/f'paired-{mode}.log').open('w') as log:
  result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=False)
 print(mode,'exit',result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
print('Correctness smokes only; no performance conclusions from one pair.',flush=True)
