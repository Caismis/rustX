import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
base=root/'confirmation-cohorts';base.mkdir(exist_ok=False)
before=Path('/home/capi/.cache/rustx-pr485-cost-reduction/candidate-f-build/conformance');after=root/'candidate-gh-build/conformance'
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
ids={name:json.loads((binary.parent/'identity.json').read_text()) for name,binary in [('before',before),('after',after)]}
def snapshot():
 assert not subprocess.check_output(['git','status','--porcelain','--','src','Cargo.toml','Cargo.lock','benchmarks/runtime','tests/common/provider_emulator.rs','tests/conformance/agent_loop/runtime_benchmark.rs','tests/conformance/agent_loop/runtime_benchmark'],cwd=repo,text=True).strip()
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();tree=subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip();assert tree==ids['after']['production_tree']
 for n,b in [('before',before),('after',after)]:
  assert sha(b)==ids[n]['sha256']
  for f,h in ids[n]['harness'].items():assert sha(repo/f)==h
 return dict(head=head,production_tree=tree,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),fixtures={str(p.relative_to(repo)):sha(p) for p in sorted((repo/'benchmarks/runtime').rglob('*')) if p.is_file() and '__pycache__' not in p.parts})
command=[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(base/'direct-live'),'--pairs','7','--pair-offset','3','--observer-mode','live-subscriber','--case','short-small']
plan=dict(reason='Initial live short-small pair1 GH/F wall=3.666, many 472-739ms turns, CPU ratio1.117; no off-CPU evidence for attribution. Predeclare only this cell, retain original matrix and all confirmation values separately. Not a full nonregression/parity gate.',identities=ids,source_before=snapshot(),command=command,status='running',start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
def save():(base/'commands.json').write_text(json.dumps(plan,indent=2)+'\n')
save()
with (base/'cohort.stdout').open('w') as out,(base/'cohort.stderr').open('w') as err:r=subprocess.run(command,cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
plan.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=snapshot());save();r.check_returncode();print('confirmation',r.returncode,flush=True)
