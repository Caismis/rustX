GH independent evidence audit (prepared before formal measurement)

Files:
  audit-gh.py                    One compact validation + performance report.
  audit-gh-dependencies.json     SHA256 pins for the independent helpers below.
  recompute-pi.py                Previously reviewed stdlib raw-counter arithmetic.
  recompute-three-engine.py      Previously reviewed stdlib native SDK evidence audit.

No producer modules are imported. No commands execute Rust, Node, Cargo, tests,
profilers, native SDK, Zstd, or benchmarks. Strict mode only reads binaries/files
and invokes read-only Git commands. Seven tiny synthetic arithmetic/equality
assertions and Python AST syntax were checked while preparing this script; no
GH evidence audit or benchmark has been run by the author at preparation time.

After root confirms the direct cohort is complete:
  python3 audit-gh.py --stage direct --expected-harness-revision GH_FULL_COMMIT \
    --expect-rust-sha256 GH_BINARY_SHA256 --output gh-direct-audit.json

After root confirms all planned cohorts are complete:
  python3 audit-gh.py --stage all --expected-harness-revision GH_FULL_COMMIT \
    --expect-rust-sha256 GH_BINARY_SHA256 --output gh-audit.json

Expected matrices: direct F/GH 72 products and 846 compared requests; fresh
GH/Pi 72 products and 846 compared requests; SDK reference 36 products in three
Latin rotations with 12 Rust/Pi comparisons. Both live modes, all six paired
cases and all three pairs remain present. G and H are one measured candidate.
There is no attribution of separate G/H speedup and no >=7-pair parity claim.

The report retains each pair's numerator, denominator, difference and ratio,
including adverse results, zero and missing data. It calls out all-three-higher
groups. Zero ratios remain zero but have no log interval. Zero denominators
remain unavailable. Failed products/extras/missing records are inventoried and
prevent admission; existing raw files/audits are never changed. All check* retry
directories and failed command statuses remain visible. Final checks require
source-before/source-after file hashes; initial failed unbound runs are labelled.

Identity checks bind explicit F and GH records, actual ordinary O3 binaries,
compiler, Rust harness, complete runtime fixture snapshots, measured harness
revision, GH source tree/schema77, F source schema76, and the unchanged fixture
identity across before/after measurement snapshots. Schema evidence includes the source constant, successfully built artifact record,
and retained raw schema76/77 field, not a fresh re-open of a transient database. It is evidence consistency, not an attestation
or independently reproduced build.

For an extracted archive, explicitly supply local archived identity/build-log
paths and the native-source freeze file; raw-only never follows old binary or
Git paths:
  python3 audit-gh.py --root EXTRACTED_ROOT --raw-only --stage all \
    --baseline-identity ARCHIVED_F_BUILD/identity.json \
    --candidate-identity ARCHIVED_GH_BUILD/identity.json \
    --freeze ARCHIVED_DEEPSEEK_SETUP/final-source-identity.json \
    --expected-harness-revision GH_FULL_COMMIT \
    --expect-rust-sha256 GH_BINARY_SHA256 --output archive-gh-audit.json

Keep each identity's adjacent build.stdout, every check* directory, source
snapshots, plan.json, direct-cohorts, final-cohorts, this script and its pinned
helpers. Raw-only checks retained source/fixture identities and before/after
consistency, but marks actual binary/current-source verification false. Numeric
rows/groups are compared with saved strict recomputations; differing mode/path
identity metadata is not mistaken for a numeric mismatch.

DeepSeek native SDK idle does not acknowledge final JSONL fsync. Its independent
auditor checks the retained native close/reopen evidence and keeps this boundary
explicit. Its metrics are extra reference data, never equal-durability ratios.

Confirmation extension after the initial direct matrix:
  python3 audit-gh.py --stage confirmation --expected-harness-revision GH_FULL_COMMIT \
    --expect-rust-sha256 GH_BINARY_SHA256 --output gh-confirmation-audit.json

Final/all includes confirmation-cohorts when present (all requires it). It verifies
14 products, 7 comparisons, 280 requests, and pairs3..9 in the single live
short-small cell against its own recorded reason, command, manifest, alternating
execution order and bracketing source snapshots. It remains separate from the
original matrix. All seven raw ratios and adverse outcomes remain; no pooling,
trimming or inferred full parity gate. Confirmation summaries are descriptive
and do not use the old helper's interval fixed to three pairs. Preserve
confirmation-cohorts/cohort.stdout and commands.json in portable archives.
The four initial/direct and final/Pi cohort stdout files must also be retained
for independently checking execution order in raw-only mode.
