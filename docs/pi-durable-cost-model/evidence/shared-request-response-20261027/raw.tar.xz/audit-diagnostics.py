#!/usr/bin/env python3
"""Read-only diagnostic evidence audit. Does not run products or symbolize again."""
import argparse, datetime, hashlib, json, re, struct
from pathlib import Path


def load(path): return json.loads(path.read_text())
def sha(path):
    with Path(path).open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def require(ok, reason):
    if not ok: raise ValueError(reason)
def counters(point):
    process=point['process']; tail=process['stat'].rsplit(')',1)[1].split()
    io={k:int(v.strip()) for k,v in (line.split(':',1) for line in process['io'].splitlines())}
    return {'cpu_ticks':int(tail[11])+int(tail[12]), 'write_bytes':io['write_bytes']}
def product(directory, build, case, mode, argv):
    raw,proc=load(directory/'sample.json'),load(directory/'sample.process.json')
    require(proc['argv']==argv and proc['accepted'] is True and proc['product_exit']==proc['provider_exit']==0,'product argv/admission mismatch')
    require(raw['schema']==(76 if build['head'].startswith('2800be25') else 77) and raw['case']==case and raw['observer_mode']==mode,'product schema/case/mode')
    require(raw['oracle']=='passed' and raw['workload_version']==3 and raw['measurement_version']==4,'product oracle/version')
    history=8 if case=='short-small' else 64
    require(raw['history']==history and raw['measured']==32 and len(raw['samples'])==history+32,'product turn dimensions')
    require(all(s['turn']==i and s['measured'] is (i>=history) for i,s in enumerate(raw['samples'])),'product measured phase identities')
    provider=proc['provider_report'];n=history+32
    require(provider['complete'] is True and provider['ok'] is True and not provider['failures'] and provider['requestCount']==provider['stepsTotal']==provider['stepsMatched']==provider['stepsSettled']==n and provider['stepStates']==['settled']*n,'provider completion')
    require(raw['wire_requests']==provider['requests'] and raw['live_requests']==raw['reopened_requests'] and raw['verified_live_requests']==raw['verified_reopened_requests']==n,'persisted/reopened request admission')
    begin,end=counters(raw['samples'][history-1]),counters(raw['samples'][-1]);final=counters(raw['lifecycle'][-1])
    return {'accepted':True,'measured_turns':32,'history_turns':history,'request_count':n,'sample_sha256':sha(directory/'sample.json'),'process_sha256':sha(directory/'sample.process.json'),'mean_measured_turn_ms':sum(s['settled_us'] for s in raw['samples'][history:])/32000,'measured_phase_self_cpu_ms':(end['cpu_ticks']-begin['cpu_ticks'])*10,'measured_phase_process_write_bytes':end['write_bytes']-begin['write_bytes'],'full_self_cpu_ms':final['cpu_ticks']*10,'full_process_write_bytes':final['write_bytes']}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent);parser.add_argument('--raw-only',action='store_true');parser.add_argument('--output',type=Path);args=parser.parse_args();root=args.root
    report={'accepted':False,'mode':'raw-only' if args.raw_only else 'strict','actual_binary_and_preload_verified':False,'script_sha256':sha(__file__),'errors':[],'profiles':[],'columns':[]}
    def check(label,fn):
        try:return fn()
        except Exception as e:report['errors'].append(f'{label}: {type(e).__name__}: {e}');return None
    verified={}
    def verify_build(build):
        key=build['sha256']
        require(build['verified'] is True and build['build_exit']==0,'build unsuccessful')
        expected={'2800be25a650305d5daf9f543ffbf7d8f62ea79b':'7ca19d99e1a241e5e33627819fe837a81788d26609072d8c41a1a0ab805ef109','063ef7a9b713e76efad6dc4e6b7122454023c67f':'cce30715eed4b1700c5b3c5fee2a93db1fb4ca49c8847cf36dfe995e4470e9b0'}
        require(expected.get(build['head'])==key,'unexpected pinned source/binary')
        if key not in verified and not args.raw_only:require(sha(build['binary'])==key,'actual binary differs')
        verified[key]=build
    commands=load(root/'profile-commands.json');counts={r['name']:r for r in load(root/'cpu-counts.json')}
    require([r['name'] for r in commands]==['profile-f-live-large-control','profile-f-live-large-cpu','profile-gh-live-large-control','profile-gh-live-large-cpu'],'profile command order/count')
    require(all(r['status']=='complete' and r['exit']==0 for r in commands),'profile command failure')
    require(all(a['end_utc']<=b['start_utc'] for a,b in zip(commands,commands[1:])),'profile command overlap')
    needles={'read_with_trace':'ReadDomainCut>::read_with_trace','index_request_read_layouts':'index_request_read_layouts','sqlite_prepare':'sqlite3LockAndPrepare','publication_encode':'PublicationDraft>::encode'}
    for command in commands:
        def profile():
            name=command['name'];directory=root/name;build=command['build_identity'];verify_build(build);manifest=load(directory/'manifest.json');cpu=manifest['mode']=='cpu'
            require(manifest['binary_sha256']==build['sha256'] and manifest['case']=='short-large' and manifest['observer_mode']=='live-subscriber','profile manifest identity')
            require(command['command'][command['command'].index('--binary')+1]==build['binary'],'profile command binary')
            argv=manifest['argv'];require(argv[-5:]==[build['binary'],'agent_loop::runtime_benchmark::measure_runtime','--exact','--ignored','--nocapture'],'profile target argv')
            if cpu:
                require('CPUPROFILE_FREQUENCY=250' in argv and len(command['preload_sha256'])==2,'CPU frequency/preload count')
                preload=next(x.split('=',1)[1] for x in argv if x.startswith('LD_PRELOAD='));require(set(preload.split(':'))==set(command['preload_sha256']),'preload paths mismatch')
                if not args.raw_only:
                    require(all(sha(p)==s for p,s in command['preload_sha256'].items()),'actual preloaded library differs')
            else:require(not command['preload_sha256'] and len(argv)==5,'control unexpectedly preloaded')
            out={'name':name,'window':{k:command[k] for k in ['start_utc','end_utc']},'build_head':build['head'],'binary_sha256':build['sha256'],'preload_sha256':command['preload_sha256'],'product':product(directory,build,'short-large','live-subscriber',argv)}
            if cpu:
                rawpath=directory/'before_measured_turns.cpu';raw=rawpath.read_bytes();header=struct.unpack_from('<5Q',raw);require(header==(0,3,0,4000,0),'raw CPU header differs')
                pos,total,records=40,0,0
                while True:
                    n,depth=struct.unpack_from('<2Q',raw,pos);pos+=16;require(0<depth<10000,'invalid raw stack depth');pcs=struct.unpack_from(f'<{depth}Q',raw,pos);pos+=depth*8
                    if n==0 and pcs==(0,):break
                    require(n>0,'invalid sample count');total+=n;records+=1
                maps=raw[pos:].decode();require(build['binary'] in maps,'profile address map lacks measured binary')
                if not args.raw_only:require(all(str(Path(p).resolve()) in maps for p in command['preload_sha256']),'profile maps lack preload')
                lines=[line.rsplit(' ',1) for line in (directory/'steady-collapsed.txt').read_text().splitlines()];require(all(int(n)>0 for _,n in lines),'collapsed count invalid');collapsed=sum(int(n) for _,n in lines)
                record=counts[name];require(collapsed==total==record['samples'] and record['interval_us']==4000 and record['raw_sha256']==sha(rawpath),'raw/collapsed/counts totals differ')
                cum=(directory/'steady-cumulative.txt').read_text();require(cum.splitlines()[0]==f'Total: {total} samples','cumulative total differs')
                inclusive={}
                for label,needle in needles.items():
                    value=sum(int(n) for stack,n in lines if needle in stack);matches=[r for r in record['rows'] if needle in r['symbol']];require(len(matches)==1 and matches[0]['inclusive']==value,'inclusive counts differ: '+label)
                    matched=[line for line in cum.splitlines() if matches[0]['symbol'] in line];require(len(matched)==1 and int(matched[0].split()[3])==value,'cumulative report count differs')
                    inclusive[label]={'samples':value,'share_percent':100*value/total}
                require((directory/'after_turns.cpu').is_file(),'next phase profile missing')
                out['cpu']={'raw_header':header,'sample_records':records,'total_samples':total,'collapsed_total':collapsed,'raw_sha256':sha(rawpath),'collapsed_sha256':sha(directory/'steady-collapsed.txt'),'cumulative_sha256':sha(directory/'steady-cumulative.txt'),'inclusive':inclusive,'phase':'before_measured_turns boundary starts this file; after_turns boundary stops it. Includes32 measured turns plus between-turn counters/footprints and phase control overhead; all product threads, no off-CPU waits.'}
            return out
        row=check(command['name'],profile)
        if row:report['profiles'].append(row)
    audit=load(root/'gh-audit.json');require(audit['accepted'] and audit['strict_identity_verified'],'formal strict audit not accepted')
    windows=[dict(stage=stage,start_utc=q['source_before']['utc'],end_utc=q['source_after']['utc']) for stage,q in audit['queue_states'].items()]
    check('formal/profile windows',lambda:require(all(p['end_utc']<=f['start_utc'] or p['start_utc']>=f['end_utc'] for p in commands for f in windows),'diagnostic overlaps formal cohort'))
    report['formal_windows']=windows;report['formal_products']=194;report['profile_commands_sha256']=sha(root/'profile-commands.json')
    phase_names=['before_initialization','after_provider_start','after_initialization','before_measured_turns','after_turns','after_late_snapshot','after_verification','after_shutdown','after_driver_drop','after_final_writer_close','after_reopen_verification','after_cleanup']
    for rev in ['f','gh']:
        for case in ['short-small','short-large']:
            def columns():
                directory=root/f'columns-{rev}-{case}';build=load(directory/'identity-before.json')['build'];verify_build(build);require(load(directory/'phases.json')==phase_names,'column phase sequence')
                argv=[build['binary'],'agent_loop::runtime_benchmark::measure_runtime','--exact','--ignored','--nocapture'];prod=product(directory,build,case,'no-live-subscriber',argv)
                before,after=load(directory/'before_measured_turns.json'),load(directory/'after_turns.json');require(before['path']==after['path'] and before['tables'].keys()==after['tables'].keys(),'column database/table identity changed')
                delta={}
                for table,b in before['tables'].items():
                    a=after['tables'][table];require(b['column_value_bytes'].keys()==a['column_value_bytes'].keys(),'column identity changed')
                    cols={k:a['column_value_bytes'][k]-b['column_value_bytes'][k] for k in a['column_value_bytes']};delta[table]={'rows':a['rows']-b['rows'],'column_value_bytes':cols,'total_column_value_bytes':sum(cols.values())}
                require(delta['events']['rows']==256 and delta['request_snapshots']['rows']==32,'column native event/request counts')
                require(before['equal_event_observation_json']['rows']==before['tables']['events']['rows'] and after['equal_event_observation_json']['rows']==after['tables']['events']['rows'],'event duplicate-source extent differs')
                require(sum(k['rows'] for k in after['events_by_kind'])==after['tables']['events']['rows'],'event kind totals differ')
                return {'revision':rev,'case':case,'build_head':build['head'],'binary_sha256':build['sha256'],'product':prod,'before_sha256':sha(directory/'before_measured_turns.json'),'after_sha256':sha(directory/'after_turns.json'),'total_logical_delta':sum(t['total_column_value_bytes'] for t in delta.values()),'table_deltas':delta}
            row=check(f'columns-{rev}-{case}',columns)
            if row:report['columns'].append(row)
    report['column_comparison']=[]
    for case in ['short-small','short-large']:
        pair={r['revision']:r for r in report['columns'] if r['case']==case}
        if len(pair)!=2:continue
        fields={}
        for label,read in [('all_logical',lambda r:r['total_logical_delta']),('request_source_pages',lambda r:r['table_deltas']['request_source_pages']['total_column_value_bytes']),('native_snapshot_json',lambda r:r['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json']),('native_event_json',lambda r:r['table_deltas']['events']['column_value_bytes']['event_json'])]:
            f,gh=(read(pair[x]) for x in ['f','gh']);fields[label]={'F':f,'GH':gh,'difference':gh-f,'GH_over_F':gh/f}
        report['column_comparison'].append({'case':case,'logical_bytes':fields})
    report['packing_review']={'script_sha256':sha(root/'pack-evidence.py'),'method':'Read-only source rule review; packer not executed.','stdout_retained':['direct-cohorts/direct-no-live.stdout','direct-cohorts/direct-live.stdout','final-cohorts/pi-no-live.stdout','final-cohorts/pi-live.stdout','confirmation-cohorts/cohort.stdout'],'only_stdout_excluded':'final-cohorts/three-engine.stdout','external_baseline':'identity/build.stdout/build.stderr/clean logs','external_deepseek':'deepseek-setup/final-source-identity.json and setup.json','native_raw':'home/sessions including .zstd retained; raw .cpu, collapsed/cumulative and failure logs retained','raw_only_command':'Explicit archived F/GH identity paths, pinned expected revision/SHA, local freeze and helpers. All-stage consumes separate confirmation.','remaining_proof':'Packaging and subsequent extracted manifest/hash/raw-only recomputation are separate checks, not claimed here.'}
    report['limits']=['Single diagnostic execution per revision/mode,250Hz CPU signal sampling; samples are not timings or call counts. No causal G/H decomposition.','Inclusive stacks overlap and cannot be added as independent costs. Larger PublicationDraft share is observed, not proof it became slower; absolute sample counts depend on workload/sampling/scheduling.','CPU samples do not observe off-CPU stalls and cannot diagnose formal long tails. Control/CPU metrics are diagnostic, never pooled with formal194 products.','Column byte values are SUM length(CAST(value AS BLOB)) logical retained payload, including textual representations of numeric values; not row encoding, WAL frames, write_bytes or device traffic.','Column SQL snapshots use synchronous benchmark pause; timing is perturbed. Snapshot JSON bytes and event counts match across revisions; event_json lengths differ10/15B and are not claimed byte-identical.','Strict mode checks current binary/preload bytes against recorded hashes. Source/build relationship follows retained build identity, not independent reproducible-build attestation.','Raw-only retains recorded binary/preload hashes but does not follow missing host paths or claim actual-file verification.']
    report['accepted']=not report['errors'];report['actual_binary_and_preload_verified']=report['accepted'] and not args.raw_only
    output=args.output or root/'diagnostic-audit.json';output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'output':str(output),'accepted':report['accepted'],'errors':report['errors'],'profiles':len(report['profiles']),'columns':len(report['columns']),'column_comparison':report['column_comparison']},indent=2));return 0 if report['accepted'] else 1

if __name__=='__main__': raise SystemExit(main())
