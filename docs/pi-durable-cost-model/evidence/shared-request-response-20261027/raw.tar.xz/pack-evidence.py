#!/usr/bin/env python3
"""Package completed GH evidence without executing products, audits or builds.

Run only after root confirms that all products and evidence writers have stopped.
This script preserves raw inputs; it does not certify their experimental results.
The per-file manifest is inside raw.tar.xz, not duplicated beside the archive.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shlex
import stat
import tarfile
import tempfile


HIGH = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
BASELINE = Path('/home/capi/.cache/rustx-pr485-cost-reduction/candidate-f-build')
FREEZE = Path('/home/capi/.cache/rustx-pr485-next/deepseek-setup')
DESTINATION = REPO / 'docs/pi-durable-cost-model/evidence/shared-request-response-20261027'
DUPLICATE_STDOUT = {
    'final-cohorts/three-engine.stdout',
}
SKIP_DIRECTORIES = {'.git', 'target', 'node_modules', '__pycache__',
                    'archive', 'archives', 'extract', 'extracted', 'archive-check'}
RULES = {
    'include': [
        'HIGH plans, source comparison, stable-field and logical-column evidence',
        'all check* success/failure logs, commands and source snapshots',
        'both cohort stages, raw counters, identities, providers, wire and process logs',
        'all seven confirmation pairs, their 14 products, comparisons, commands and stdout',
        'DeepSeek profile.patch.json and home/sessions native logs, including .zstd',
        'CPU .cpu raw data, symbols, control runs, commands and identities',
        'build identity plus complete build.stdout/stderr and clean logs for F and GH',
        'audit scripts, dependency pins, results and explicit DeepSeek freeze metadata',
    ],
    'exclude': [
        'native compiled executables, object/library formats, conformance artifacts',
        '.git, target, node_modules, __pycache__, prior archive/extract directories',
        'old tar/zip/xz archives; native .zstd sessions and raw .cpu are retained',
        'product home contents outside home/sessions (runtime dependency/cache copies)',
        'only the SDK three-engine CLI stdout rendering; raw files and stderr remain',
        'symlinks and non-regular files; never follow them outside the input roots',
    ],
    'duplicate_stdout_paths': sorted(DUPLICATE_STDOUT),
}


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def load(path):
    return json.loads(path.read_text())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def sha_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def fingerprint(path):
    item = path.lstat()
    require(stat.S_ISREG(item.st_mode), f'not a regular file: {path}')
    return (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)


def skip_path(relative, directory=False):
    parts = relative.parts
    for part in parts if directory else parts[:-1]:
        if part in SKIP_DIRECTORIES or part.startswith(('archive-', 'extract-')):
            return 'dependency, compiled-output, or previous archive/extract directory'
    if 'home' in parts:
        tail = parts[parts.index('home') + 1:]
        if tail and tail[0] != 'sessions':
            return 'product home content outside native sessions'
    name = relative.name
    if name == 'conformance' or name.startswith('conformance-'):
        return 'compiled conformance artifact'
    if name.endswith(('.tar', '.tar.xz', '.tar.gz', '.tgz', '.zip', '.xz', '.pyc')):
        return 'previous archive or Python bytecode'
    if relative.as_posix() in DUPLICATE_STDOUT:
        return 'duplicate cohort CLI rendering; underlying raw output and stderr retained'
    return None


def compiled_format(path):
    # Detect executable/object formats, not arbitrary binary data. In particular,
    # gperftools .cpu and native Zstd session logs are required raw evidence.
    with path.open('rb') as stream:
        head = stream.read(64)
        if head.startswith((b'\x7fELF', b'!<arch>\n', b'\x00asm', b'BC\xc0\xde')):
            return True
        if head[:4] in (b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
                        b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
                        b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca',
                        b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca'):
            return True
        if head.startswith(b'MZ') and len(head) >= 64:
            stream.seek(int.from_bytes(head[60:64], 'little'))
            return stream.read(4) == b'PE\x00\x00'
    return False


def inventory(root, external):
    selected, excluded = {}, []

    def add(path, relative):
        reason = skip_path(relative)
        if path.is_symlink():
            reason = 'symlink; not followed'
        elif not path.is_file():
            reason = 'non-regular file'
        elif reason is None and compiled_format(path):
            reason = 'native compiled executable/object/library format'
        if reason:
            excluded.append({'path': relative.as_posix(), 'source': str(path), 'reason': reason})
        else:
            name = relative.as_posix()
            require(name not in selected and name != 'MANIFEST.json', f'archive name collision: {name}')
            selected[name] = path

    for directory, folders, files in os.walk(root, followlinks=False):
        directory = Path(directory)
        kept = []
        for name in sorted(folders):
            path = directory / name
            relative = path.relative_to(root)
            reason = 'symlink directory; not followed' if path.is_symlink() else skip_path(relative, directory=True)
            if reason:
                excluded.append({'path': relative.as_posix() + '/', 'source': str(path), 'reason': reason})
            else:
                kept.append(name)
        folders[:] = kept
        for name in sorted(files):
            path = directory / name
            add(path, path.relative_to(root))
    for relative, path in external.items():
        require(path.is_file(), f'missing required external evidence: {path}')
        add(path, Path(relative))
        require(relative in selected, f'required external evidence was excluded: {relative}')
    return dict(sorted(selected.items())), sorted(excluded, key=lambda item: item['path'])


def preflight(root, selected):
    required = [
        'plan.json', 'source-comparison.md', 'stable-native-fields.json',
        'audit-gh.py', 'audit-gh-dependencies.json', 'audit-gh-README.txt',
        'recompute-pi.py', 'recompute-three-engine.py', 'recompute-direct.py',
        'check-validation-audit.json', 'gh-audit.json', 'gh-confirmation-audit.json',
        'confirmation-cohorts/commands.json', 'confirmation-cohorts/cohort.stdout',
        'candidate-gh-build/identity.json', 'candidate-gh-build/build.stdout',
        'candidate-gh-build/build.stderr', 'baseline-f-build/identity.json',
        'baseline-f-build/build.stdout', 'baseline-f-build/build.stderr',
        'deepseek-setup/final-source-identity.json', 'deepseek-setup/setup.json',
        'direct-cohorts/commands.json', 'direct-cohorts/recomputed.json',
        'final-cohorts/commands.json', 'final-cohorts/pi-recomputed.json',
        'final-cohorts/three-engine-audit.json', 'profile-commands.json', 'cpu-counts.json',
    ]
    for revision in ('f', 'gh'):
        for case in ('short-small', 'short-large'):
            required.extend(f'columns-{revision}-{case}/{name}.json'
                            for name in ('before_measured_turns', 'after_turns', 'sample', 'phases'))
        for mode in ('control', 'cpu'):
            required.append(f'profile-{revision}-live-large-{mode}/manifest.json')
        required.extend(f'profile-{revision}-live-large-cpu/{name}' for name in
                        ('before_measured_turns.cpu', 'steady-cumulative.txt', 'steady-collapsed.txt'))
    missing = [name for name in required if name not in selected]
    require(not missing, f'missing evidence: {missing}')
    checks = sorted(root.glob('check*/check-build-commands.json'))
    require(checks, 'no correctness command inventory')
    statuses = {}
    for path in checks + [root / 'profile-commands.json']:
        rows = load(path)
        require(rows and all(row.get('status') in ('complete', 'failed', 'not_run') for row in rows),
                f'nonterminal or empty command record: {path}')
        statuses[str(path.relative_to(root))] = [
            {key: row[key] for key in ('name', 'label', 'status', 'exit') if key in row} for row in rows]
    for stage in ('direct', 'final'):
        path = root / f'{stage}-cohorts/commands.json'
        record = load(path)
        require(record.get('source_after'), f'unfinished cohort: {path}')
        require(record['steps'] and all(row.get('status') in ('complete', 'failed', 'not_run')
                                       for row in record['steps']), f'nonterminal cohort: {path}')
        statuses[str(path.relative_to(root))] = [
            {key: row[key] for key in ('name', 'status', 'exit') if key in row} for row in record['steps']]
    confirmation = load(root / 'confirmation-cohorts/commands.json')
    require(confirmation.get('source_after') and
            confirmation.get('status') in ('complete', 'failed', 'not_run'),
            'unfinished confirmation cohort')
    statuses['confirmation-cohorts/commands.json'] = {
        key: confirmation[key] for key in ('status', 'exit') if key in confirmation}
    final = load(root / 'final-cohorts/commands.json')
    candidate = load(root / 'candidate-gh-build/identity.json')
    return statuses, final['source_before']['head'], candidate['sha256']


def verify_archive(path, manifest_bytes, entries):
    seen = set()
    with tarfile.open(path, 'r|xz') as archive:
        for member in archive:
            require(member.isfile() and member.name not in seen, f'invalid archive member: {member.name}')
            seen.add(member.name)
            stream = archive.extractfile(member)
            require(stream is not None, f'missing member data: {member.name}')
            if member.name == 'MANIFEST.json':
                require(member.size == len(manifest_bytes) and stream.read() == manifest_bytes,
                        'archived manifest differs')
            else:
                expected = entries.get(member.name)
                require(expected is not None and member.size == expected['bytes'],
                        f'archive size/name differs: {member.name}')
                require(hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256'],
                        f'archive hash differs: {member.name}')
    require(seen == set(entries) | {'MANIFEST.json'}, 'archive member set differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HIGH)
    parser.add_argument('--output', type=Path, default=DESTINATION)
    parser.add_argument('--baseline-build', type=Path, default=BASELINE)
    parser.add_argument('--freeze-dir', type=Path, default=FREEZE)
    parser.add_argument('--repo', type=Path, default=REPO)
    args = parser.parse_args()
    root, output = args.root.resolve(), args.output.resolve()
    require(not output.is_relative_to(root), 'output must be outside the raw input tree')
    output.mkdir(parents=True, exist_ok=True)
    require(not any(output.iterdir()), f'refusing nonempty output directory: {output}')
    external = {f'baseline-f-build/{name}': args.baseline_build / name for name in
                ('identity.json', 'build.stdout', 'build.stderr', 'clean.stdout', 'clean.stderr')}
    external.update({f'deepseek-setup/{name}': args.freeze_dir / name for name in
                     ('final-source-identity.json', 'setup.json')})
    external['recompute-direct.py'] = args.repo / 'docs/pi-durable-cost-model/evidence/read-cache-trial-20261027/recompute-direct.py'
    selected, excluded = inventory(root, external)
    states, revision, binary_sha = preflight(root, selected)
    fingerprints, entries = {}, {}
    for name, path in selected.items():
        before = fingerprint(path)
        digest = sha_file(path)
        require(fingerprint(path) == before, f'input changed while hashing: {path}')
        fingerprints[name] = before
        entries[name] = {'source': str(path), 'bytes': before[2], 'sha256': digest}
    command = ['python3', 'audit-gh.py', '--root', '.', '--raw-only', '--stage', 'all',
               '--baseline-identity', 'baseline-f-build/identity.json',
               '--candidate-identity', 'candidate-gh-build/identity.json',
               '--freeze', 'deepseek-setup/final-source-identity.json',
               '--expected-harness-revision', revision, '--expect-rust-sha256', binary_sha,
               '--output', 'archive-gh-audit.json']
    created = datetime.now(timezone.utc).isoformat()
    manifest = {'format': 'rustx-gh-raw-evidence-v1', 'created_utc': created,
                'raw_root': str(root), 'rules': RULES, 'files': entries,
                'excluded': excluded, 'command_states': states,
                'raw_only_audit_command': command,
                'scope': 'Retained-file integrity and raw recomputation; excludes executable artifacts. '
                         'Not proof of reproducible builds or equivalent DeepSeek durability.'}
    manifest_bytes = encoded(manifest)
    fd, temporary = tempfile.mkstemp(prefix='.raw-', suffix='.tar.xz.partial', dir=output)
    os.close(fd)
    temporary = Path(temporary)
    try:
        with tarfile.open(temporary, 'w:xz', preset=0) as archive:
            for name, path in selected.items():
                require(fingerprint(path) == fingerprints[name], f'input changed before packing: {path}')
                info = tarfile.TarInfo(name)
                info.size = entries[name]['bytes']
                info.mode = 0o644
                with path.open('rb') as stream:
                    archive.addfile(info, stream)
                require(fingerprint(path) == fingerprints[name], f'input changed during packing: {path}')
            info = tarfile.TarInfo('MANIFEST.json')
            info.size, info.mode = len(manifest_bytes), 0o644
            archive.addfile(info, io.BytesIO(manifest_bytes))
        verify_archive(temporary, manifest_bytes, entries)
        current, current_excluded = inventory(root, external)
        require(current == selected and current_excluded == excluded, 'input file/exclusion inventory changed')
        require(all(fingerprint(path) == fingerprints[name] for name, path in selected.items()),
                'input changed after packing')
        summary = {'format': manifest['format'], 'created_utc': created, 'archive': 'raw.tar.xz',
                   'archive_bytes': temporary.stat().st_size, 'archive_sha256': sha_file(temporary),
                   'manifest_bytes': len(manifest_bytes), 'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
                   'raw_files': len(entries), 'raw_bytes': sum(item['bytes'] for item in entries.values()),
                   'excluded_entries': len(excluded), 'excluded_reasons': dict(Counter(item['reason'] for item in excluded)),
                   'stream_verified_all_members': True, 'compression': 'xz preset 0',
                   'harness_revision': revision, 'candidate_sha256': binary_sha,
                   'raw_only_audit_command': command}
        readme = f'''# Shared request/response evidence

`raw.tar.xz` contains the completed G/H raw evidence and all recorded failed and
successful check rounds. `summary.json` records the archive SHA256, byte counts,
and verification result. The full per-file SHA256/size/source manifest and exact
exclusion inventory are inside `MANIFEST.json`. No compiled product is included.

Extract into an empty directory and run the retained independent auditor:

```sh
mkdir raw
tar -xJf raw.tar.xz -C raw
cd raw
{shlex.join(command)}
```

F's identity and full Cargo build output are at `baseline-f-build/identity.json`
and `baseline-f-build/build.stdout`; G/H's are at `candidate-gh-build/`.
The pinned native source metadata is at
`deepseek-setup/final-source-identity.json` with `setup.json` beside it.
The auditor and both pinned helper scripts are at the archive root.

The only cohort CLI stdout exclusion is `final-cohorts/three-engine.stdout`,
enumerated in the manifest; its raw counters, commands, wire/process/provider
logs and stderr remain. The four direct/Pi CLI stdout files are retained because
the raw-only auditor uses them to verify actual execution order.
The separate confirmation cohort is retained in full, including its stdout,
commands, all 14 products, seven comparisons and independent audit result.
CPU `.cpu` data and native `.zstd` session logs are retained.
Build/check stdout is retained in full. Dependency caches, product-home files
outside native sessions, compiled formats, and old archives are excluded.

Raw-only recomputation does not execute products, decompress session logs, or
follow recorded old executable/Git paths. It checks retained identities and
arithmetic, while explicitly marking actual binary/current-source verification
false. CPU symbol reports remain diagnostic evidence; regenerating those symbols
would require the matching excluded executable. DeepSeek remains an additional
reference with its recorded durability boundary, not an equal-durability claim.
'''
        # All evidence and archive bytes were checked before publishing the output.
        os.link(temporary, output / 'raw.tar.xz')  # Atomic, refuses an existing destination.
        temporary.unlink()
        (output / 'summary.json').write_bytes(encoded(summary))
        (output / 'README.md').write_text(readme)
        print(json.dumps({key: summary[key] for key in
                          ('archive', 'archive_bytes', 'archive_sha256', 'raw_files', 'raw_bytes',
                           'stream_verified_all_members')}, indent=2))
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
