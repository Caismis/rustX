import subprocess,pathlib,json,struct,re,hashlib
root=pathlib.Path(__file__).resolve().parent
binaries={'f':'/home/capi/.cache/rustx-pr485-cost-reduction/candidate-f-build/conformance','gh':str(root/'candidate-gh-build/conformance')}
pprof='/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof'
records=[]
for d in sorted(root.glob('profile-*-cpu')):
 binary=binaries[d.name.split('-')[1]]
 raw=d/'before_measured_turns.cpu'; data=raw.read_bytes();header=struct.unpack_from('<5Q',data);assert header[:3]==(0,3,0);total=0;offset=40
 while True:
  n,depth=struct.unpack_from('<2Q',data,offset);offset+=16;pcs=struct.unpack_from(f'<{depth}Q',data,offset);offset+=8*depth
  if n==0 and pcs==(0,):break
  total+=n
 for name,args in [('steady-cumulative.txt',['--text','--cum','--nodecount=200']),('steady-collapsed.txt',['--collapsed'])]:
  r=subprocess.run([pprof,*args,'--no_strip_temp',binary,str(raw)],capture_output=True,text=True,check=True);(d/name).write_text(r.stdout);(d/(name+'.stderr')).write_text(r.stderr)
 rows=[]
 for line in (d/'steady-cumulative.txt').read_text().splitlines()[1:]:
  m=re.match(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)',line)
  if m:rows.append(dict(symbol=m[3],flat=int(m[1]),inclusive=int(m[2])))
 assert sum(int(l.rsplit(' ',1)[1]) for l in (d/'steady-collapsed.txt').read_text().splitlines())==total
 records.append(dict(name=d.name,samples=total,interval_us=header[3],rows=rows,raw_sha256=hashlib.file_digest(raw.open('rb'),'sha256').hexdigest()))
 print(d.name,total)
 print('\n'.join(f'{r["inclusive"]}/{total} {r["symbol"]}' for r in rows if any(p in r['symbol'] for p in ['sqlite3LockAndPrepare','capture_facts','persist_part','original_node_count','index_request_read_layouts','publication_terminal_tx','stage_frame_tx','seal_execution','PublicationDraft','read_with_trace','source::','encode_snapshot','index_frame','index_canonical'])))
(root/'cpu-counts.json').write_text(json.dumps(records,indent=2)+'\n')
