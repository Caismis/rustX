# Source comparison: remaining request and observation work

Read-only inspection, 2026-10-27. Pi Durable is pinned to `90d863f7c1183b965f099855715d6e88c7b8a52c`; DeepSeek Harness to `687f282e8625c6b8d11ff58211a90524be2e4317`. Rust references describe the G/H working-tree candidate based on `76a3dfb74ec79b569e4ac51edea2566a04f02654`, while correctness checks are in progress. This is a source-level account, not a performance result. Line numbers below refer to this inspection.

Source roots used below:

- **Pi**: `/home/capi/Documents/codes/pi-rustx-benchmark/`
- **DeepSeek**: `/home/capi/.cache/rustx-pr485-next/deepseek-checkout/`
- **Rust**: `/home/capi/.codex/worktrees/pr485-pi-performance/rustX/`

## Configuration and request construction

| Implementation | What unchanged configuration avoids | Work that still happens |
|---|---|---|
| Pi Durable | `planSystemEntries` emits no section/tool entry for an unchanged state. New heads can require a complete baseline; reordered tools can require removal and re-addition. | Sections are rendered and compared, current tools are replayed, and tool declarations are compared using `JSON.stringify` on both sides. Each request still commits its model/thinking/options/cutoff checkpoint. |
| DeepSeek | Ordinary unchanged requests omit a new `request/header`; `request/context` is appended only when its compared values change. Initial/resumed requests and new series deliberately record headers. | Header equality compares ordered tool schemas using `JSON.stringify`; the request is frozen and a new boundary message array is built. |
| Rust G | A previously admitted exact stable encoding reuses its byte and field-index fragments. It does not create another layout/index or rebuild the stable fields' authenticated pages. | It still encodes and hashes the stable inspection prototype, looks up and authenticates the descriptor, indexes the changing prefix, validates bounded complete scalar JSON, and persists each native request and composed root. |

Pi evidence: `packages/durable/src/harness/prompt.ts:66–118,122–141`; `packages/ai/src/utils/transcript.ts:58–65,140–141`; `packages/durable/src/harness/generation.ts:161–194`. Its request checkpoint retains `model`, `thinkingLevel`, `streamOptions` and immutable `cutoff` (`generation.ts:64–72`), rather than persisting a fresh complete tools declaration per ordinary request.

DeepSeek evidence: `packages/core/agent-loop/src/agent.ts:626–651,669–703`; `packages/core/session/src/request-header.ts:21–51`. Live header folding processes the newly added log suffix (`packages/core/session/src/index.ts:912–921`). This avoids repeated header persistence; it is not zero configuration CPU.

Rust's frozen serializer keeps one positive allowlist and ordered six-field prefix (`src/runtime_client/trace/frozen.rs:35–107`). The shared suffix includes model/protocol/limits/profile/options/system prompt, the `messages:[]` hole, tools, and the fixed request-outcome placeholders. Its identity is exact encoded content, not a mutable configuration ID or revision number. Changed values or tool order miss; old roots retain their original fragment references.

## G: precisely removed work on a hit

`src/durable/sqlite/observation_request/composed/scalar.rs:98–167` returns on a verified descriptor hit before `encoded.index()`, `geometry()` and `fragments::persist_part()`. Therefore the **stable suffix** no longer performs:

1. `LayoutParser`/small or SQLite layout-index construction and the field-geometry traversal.
2. `capture_facts`, per-field preview/JSON-header generation and F/C fact-spool construction (`composed/fragments.rs:101–205,206–241`).
3. Field/byte page encoding, per-page SHA-256, and `INSERT OR IGNORE INTO request_source_pages` attempts (`composed/index.rs:29–51`). Existing hash deduplication previously occurred **after** this work; even a duplicate page incurred encoding, hashing and an SQL attempt.

The miss consumes the same encoded carrier to build the index; it does not serialize the stable source twice. New versions remain eagerly indexed, using the existing fragment format and read implementation.

What G **does not remove**:

- Full stable inspection encoding and one content digest: `src/runtime/read_layout.rs:413–472`. Its byte carrier retains the existing 16 KiB residency/spill policy. Large stable encodings can still create scratch byte files on hits.
- The dynamic contribution/request/attempt/step/retry/assistant prefix and its F/C/byte pages. Full scalar JSON of at most 16 KiB still receives `original_node_count` validation, using this request's exact prefix plus suffix (`composed/scalar.rs:169–214`).
- Native snapshot cloning/encoding, integrity hashing and `request_snapshots` insertion. Only selected-message history is excluded from this JSON; frozen configuration/tools remain by value (`src/durable/sqlite.rs:1269–1285,13749–13763,13806–13832`).
- Native selected-input augmentation, path validation, occurrence length calculation, root metadata/checksum and `content_frontiers` insertion (`composed.rs:199–275`). Request summaries, trace/context/catalog indexing also remain (`src/durable/sqlite.rs:6115–6141`).
- Authenticated historical reads. A field still follows its bounded F/C pages; ranges still load/hash byte pages. G only adds prefix/suffix coordinate composition (`composed/read.rs:144–186,602–645`). It does not revive E's read-time Source/index reconstruction.

The preserved F samples support studying this path: `stable-native-fields.json` finds one combined native configuration value and one seven-tool order across 40 small-history and 96 large-history requests. The native subset is 11,269 canonical JSON bytes. This is value-equality evidence, not proof of exact frozen-inspection byte identity or a measured G hit rate.

## History and response reading

Pi reuses a previous context range: unchanged head/tail reuses the range, appended tails scan only new entries, and a changed head rebuilds. It still copies the returned entry/contribution/message arrays (`packages/durable/src/harness/context.ts:68–108`). Its SQLite entry scan reads and parses complete entry JSON rows (`packages/durable/src/storage/sqlite/storage.ts:348–382`). Thus the documented two bounded boundary reads do not make the entire context operation O(1).

DeepSeek derives only newly appended surface nodes while content generation is unchanged; a changed generation resets that derived state, and every call returns a copied array (`packages/core/session/src/index.ts:984–1004`). These native replay paths do not establish equivalence with Rust's authenticated arbitrary historical field/page/range inspection contract.

Before H, Rust's numeric response decoration independently requested process, response ownership, execution summary, model summary and response fields for each transcript entry; ownership could be queried twice for one final assistant (`src/runtime_client/response.rs` at base `76a3dfb`:405–490).

H sends the bounded page selections through one store call (`src/runtime_client/response.rs:405–446`) and one SQLite read transaction (`src/durable/sqlite.rs:2107–2116`). The reader validates the cut and shared member-hole witness once, then reuses decoded execution/member/process/inherited/response/identity results **within that call** (`src/durable/sqlite/observation_response.rs:16–74,84–145,262–376`). This removes repeated store entry/locking and repeated decoding/lookups of the same owners within a page. It adds no persistent cache and does not remove storage writes.

Remaining H costs include per-selection ledger/role/tool-proposal ownership queries, inherited membership checks, selected execution-hole/latest-owner validation, response locator checks, retry identity lookup, bounded result clones and statistics reading (`observation_response.rs:148–259,379–453`; `observation_execution.rs:79–101`). Separate page reads repeat their validation. A batch of distinct owners still requires their distinct facts; H is not one SQL statement or constant-time decoration.

## Durability is not the sole remaining explanation

Pi's Node SQLite backend uses WAL with `synchronous=NORMAL` and explicit `BEGIN IMMEDIATE`/`COMMIT` (`packages/durable/src/storage/sqlite/node.ts:144–158,183–197`). Rust also uses WAL/NORMAL (`src/durable/sqlite.rs:8099–8111`). G/H do not weaken this setting or eliminate native commits. Equal pragmas do not imply equal transaction counts, schemas or recovery contracts.

DeepSeek's checkpoint policy awaits flush before model dispatch, top-level tool execution and each pre-step (`packages/session/session-checkpoint-policy/src/index.ts:29–36,63–81`). Its JSONL backend writes and syncs appended batches (`packages/session/session-persistence-jsonl/src/index.ts:1411–1438`); an already materialized handle's flush can be a no-op because resolved appends are durable (`storage.ts:203–211`). Therefore neither “DeepSeek has no durability work” nor “every flush necessarily adds an fsync” follows from the source.

The principal remaining Rust-specific work visible here is native frozen metadata plus its derived inspection/index structures and ownership/read-cut validation. G targets repeated configuration-derived construction; H targets repeated observation reads. Their end-to-end value, cold-miss costs and any read regression remain questions for paired measurements.
