#!/usr/bin/env python3
"""Read-only GH evidence audit. Never runs products, builds, tests or decompression.

Reuses the pinned independent raw-counter arithmetic in recompute-pi.py and the
independent three-engine auditor. No producer/adapter/statistics modules imported.
Writes one compact report; raw evidence and existing audits are never modified.
Use --raw-only with explicit archived identities/freeze after moving an archive.
"""
import argparse
import collections
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import statistics
import subprocess
import sys
from types import SimpleNamespace
sys.dont_write_bytecode = True

BASELINE_HEAD = '2800be25a650305d5daf9f543ffbf7d8f62ea79b'
BASELINE_SHA = '7ca19d99e1a241e5e33627819fe837a81788d26609072d8c41a1a0ab805ef109'
BASELINE_TREE = 'a86302ed48b415de91cac782bd156dc935b8e517'
CASES = ['short-small', 'short-large', 'stream', 'large', 'tool', 'cancel']
RUST_TOOLS = ['read', 'write', 'edit', 'glob', 'grep', 'bash', 'todo']
PI_TOOLS = ['read', 'write', 'edit', 'bash']
HERE = Path(__file__).resolve().parent


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()


def same(left, right):
    if left is None or right is None:
        return left is right
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(same(left[k], right[k]) for k in left)
    if isinstance(left, (list, tuple)) and isinstance(right, (list, tuple)):
        return len(left) == len(right) and all(same(a, b) for a, b in zip(left, right))
    if type(left) in (int, float) and type(right) in (int, float):
        return math.isfinite(left) and math.isfinite(right) and math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12)
    return type(left) is type(right) and left == right


class Audit:
    def __init__(self):
        self.errors = []

    def attempt(self, label, fn):
        try:
            return fn()
        except Exception as error:
            self.errors.append(f'{label}: {type(error).__name__}: {error}')
            return None


def module(name, path, digest):
    require(sha(path) == digest, f'independent auditor changed: {path}')
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def identities(args, plan):
    before, after = load(args.baseline_identity), load(args.candidate_identity)
    for label, identity in [('F', before), ('GH', after)]:
        require(all(re.fullmatch('[0-9a-f]{40}', identity[key]) for key in ('head', 'production_tree')) and re.fullmatch('[0-9a-f]{64}', identity['sha256']), f'{label} malformed source/binary identity')
        require(identity['verified'] is True and identity['build_exit'] == 0, f'{label} unsuccessful build identity')
        require(identity.get('clean_exit') == 0, f'{label} ordinary build not cleaned')
        require(identity['commands'][-1] == ['cargo', 'test', '--release', '--locked', '--test', 'conformance', '--no-run', '--message-format=json'], f'{label} performance build command changed')
        require(identity['harness'] and identity['rustc'], f'{label} missing harness/compiler identity')
        build_path = (args.baseline_identity if label == 'F' else args.candidate_identity).parent / 'build.stdout'
        build_rows = [json.loads(line) for line in build_path.read_text().splitlines() if line.startswith('{')]
        require([row for row in build_rows if row.get('reason') == 'build-finished'] == [{'reason': 'build-finished', 'success': True}], f'{label} missing successful Cargo build record')
        root_artifacts = [row for row in build_rows if row.get('reason') == 'compiler-artifact' and row['target']['name'] in ('rustx', 'conformance')]
        require(root_artifacts and any(row['target']['name'] == 'conformance' and row['executable'] for row in root_artifacts), f'{label} missing ordinary benchmark artifact')
        require(all(row['profile']['opt_level'] == '3' and row['features'] == [] and row['fresh'] is False and not row['profile']['debug_assertions'] and not row['profile']['overflow_checks'] for row in root_artifacts), f'{label} ordinary O3/features/build-profile mismatch')
        if not args.raw_only:
            require(sha(identity['binary']) == identity['sha256'], f'{label} actual binary hash differs')
            require(git(args.repo, 'rev-parse', identity['head'] + ':src') == identity['production_tree'], f'{label} source tree differs')
            for path, digest in identity['harness'].items():
                require(sha(args.repo / path) == digest, f'{label} harness changed: {path}')
    require(before['head'] == BASELINE_HEAD and before['sha256'] == BASELINE_SHA and before['production_tree'] == BASELINE_TREE, 'baseline F identity differs')
    require(plan['baseline_source'] == BASELINE_HEAD and plan['baseline_sha256'] == BASELINE_SHA, 'predeclared baseline differs')
    require(before['harness'] == after['harness'] and before['rustc'] == after['rustc'] and before['cargo'] == after['cargo'], 'F/GH harness or toolchain differs')
    require(after['sha256'] != before['sha256'], 'F/GH binary is identical')
    if args.expect_rust_sha256:
        require(after['sha256'] == args.expect_rust_sha256, 'GH differs from explicit expected SHA')
    if not args.raw_only:
        require(git(args.repo, 'rev-parse', args.expected_harness_revision + ':src') == after['production_tree'], 'measurement HEAD source differs from GH build')
        require('pub const SQLITE_SCHEMA_VERSION: i64 = 77;' in git(args.repo, 'show', after['head'] + ':src/durable/sqlite.rs'), 'GH committed schema is not 77')
        require('pub const SQLITE_SCHEMA_VERSION: i64 = 76;' in git(args.repo, 'show', before['head'] + ':src/durable/sqlite.rs'), 'F committed schema is not 76')
        require(git(args.repo, 'rev-parse', 'HEAD:src') == after['production_tree'], 'current production source differs from GH')
        require(not git(args.repo, 'status', '--porcelain', '--', 'src', 'Cargo.toml', 'Cargo.lock', 'tests/common/provider_emulator.rs', 'tests/conformance/agent_loop/runtime_benchmark.rs', 'tests/conformance/agent_loop/runtime_benchmark', 'benchmarks/runtime'), 'current source/harness is dirty')
    return before, after


def command_plan(args, stage, before, after):
    base = args.root / (stage + '-cohorts')
    path = base / 'commands.json'
    record = load(path)
    require(record['stage'] == stage and record['identities'] == {'before': before, 'after': after}, f'{stage} identity/plan binding')
    expected = ['direct-no-live', 'direct-live', 'recompute'] if stage == 'direct' else ['pi-no-live', 'pi-live', 'three-engine', 'audit-pi', 'audit-three-engine']
    require([r['name'] for r in record['steps']] == expected, f'{stage} incomplete predeclared queue')
    start, end = record['source_before'], record.get('source_after')
    require(start['head'] == args.expected_harness_revision and start['production_tree'] == after['production_tree'] and start['schema'] == 77, f'{stage} source-before identity/schema')
    require(start['fixtures'], f'{stage} missing runtime fixture identity')
    if not args.raw_only:
        actual = {str(path.relative_to(args.repo)): sha(path) for path in sorted((args.repo / 'benchmarks/runtime').rglob('*')) if path.is_file() and '__pycache__' not in path.parts}
        require(start['fixtures'] == actual, f'{stage} actual runtime fixture set/hash differs')
    rows = record['steps']
    require(all(r['status'] == 'complete' and r.get('exit') == 0 for r in rows), f'{stage} incomplete/failed queue (all states retained separately)')
    require(all(a['end_utc'] <= b['start_utc'] for a, b in zip(rows, rows[1:])), f'{stage} overlapping/out-of-order commands')
    require(end and {k: v for k, v in start.items() if k != 'utc'} == {k: v for k, v in end.items() if k != 'utc'}, f'{stage} missing/different after source snapshot')
    require(start['utc'] <= rows[0]['start_utc'] and rows[-1]['end_utc'] <= end['utc'], f'{stage} snapshots do not bracket queue')
    return {'file': str(path.relative_to(args.root)), 'sha256': sha(path), 'start_utc': start['utc'], 'end_utc': end['utc'], 'schema': 77, 'harness_revision': start['head'], 'fixture_files': len(start['fixtures']), 'fixtures_sha256': hashlib.sha256(json.dumps(start['fixtures'], sort_keys=True).encode()).hexdigest()}


def counter_identity(data):
    points = data['samples'] + data['lifecycle']
    identities = set()
    for point in points:
        stat = point['process']['stat']
        if stat is not None:
            tail = stat.rsplit(')', 1)[1].split()
            identities.add((int(stat.split('(', 1)[0]), int(tail[19])))
    require(len(identities) <= 1, 'PID/start-time changed across self-counter endpoints')
    for series in (data['samples'], data['lifecycle']):
        for key in ('cpu_ticks', 'write_bytes'):
            values = [MATH.counters(p)[key] for p in series]
            available = [v for v in values if v is not None]
            require(available == sorted(available), f'{key} decreased in retained samples')


def comparison(path, case, mode, direct):
    data = load(path)
    require(data['case'] == case and data['observer_mode'] == mode and data['workload_version'] == 3 and data['model_time'] == MATH.MODEL_TIME, 'comparison fixture identity')
    rows = data['checked']
    count = {'short-small': 40, 'short-large': 96, 'tool': 2}.get(case, 1)
    require(len(rows) == count and [r['index'] for r in rows] == list(range(count)), 'comparison request coverage')
    for row in rows:
        require(row['coreSemanticEqual'] is True and row['fullSemanticRequestEqual'] is direct, 'request equivalence boundary changed')
        require(row['rustToolNames'] == RUST_TOOLS and row['piToolNames'] == (RUST_TOOLS if direct else PI_TOOLS), 'native tool roster differs')
        require((row['rustToolsSha256'] == row['piToolsSha256']) is direct, 'native schema equivalence changed')
        require(all(re.fullmatch('[0-9a-f]{64}', row[k]) for k in ('rustToolsSha256', 'piToolsSha256')), 'invalid native tool schema digest')
    return count


def paired_dataset(args, audit, stage, before, after):
    direct = stage == 'direct'
    prefix = 'direct' if direct else 'pi'
    base = args.root / (stage + '-cohorts')
    original_path = base / ('recomputed.json' if direct else 'pi-recomputed.json')
    original = audit.attempt(str(original_path), lambda: load(original_path))
    if original is not None:
        audit.attempt(str(original_path) + ' admission', lambda: require(original['verified'] is True and original['accepted_products'] == 72 and original['request_comparisons'] == 846, 'saved recomputation did not admit complete matrix'))
    original_products = {} if original is None else {r['file']: r for r in original['products']}
    products, pairs, groups, comparisons, inventory = [], [], [], [], []
    numerator, denominator = ('after', 'before') if direct else ('rust', 'pi')
    for label, mode in [('no-live', 'no-live-subscriber'), ('live', 'live-subscriber')]:
        cohort = prefix + '-' + label
        directory = base / cohort
        manifest = audit.attempt(cohort + '/manifest', lambda: load(directory / 'manifest.json'))
        if manifest is None:
            continue
        def manifest_check():
            require(manifest['cases'] == CASES and manifest['pairs'] == 3 and manifest.get('pair_offset', 0) == 0 and manifest['clock_ticks'] == 100 and manifest['observer_mode'] == mode, 'matrix/mode/clock differs')
            if direct:
                require(manifest['head'] == args.expected_harness_revision, 'measurement harness HEAD differs')
                for engine, identity in [('before', before), ('after', after)]:
                    require(manifest['executables'][engine] == {'path': identity['binary'], 'sha256': identity['sha256']}, 'direct executable differs')
            else:
                require(manifest['rust'] == after['binary'] and manifest['rust_sha256'] == after['sha256'], 'Pi-cohort GH executable differs')
        audit.attempt(cohort + '/manifest identity', manifest_check)
        expected = {f'{pair}-{case}-{engine}' for pair in range(3) for case in CASES for engine in (numerator, denominator)}
        observed = {p.name[:-len('.process.json')] for p in directory.glob('*.process.json')}
        audit.attempt(cohort + '/process matrix', lambda: require(observed == expected, f'missing={sorted(expected-observed)} extras={sorted(observed-expected)}'))
        observed_raw = {p.stem for engine in (numerator, denominator) for p in directory.glob(f'*-{engine}.json')}
        audit.attempt(cohort + '/raw matrix', lambda: require(observed_raw == expected, f'missing={sorted(expected-observed_raw)} extras={sorted(observed_raw-expected)}'))
        expected_comp = {f'{pair}-{case}-comparison.json' for pair in range(3) for case in CASES}
        audit.attempt(cohort + '/comparison matrix', lambda: require({p.name for p in directory.glob('*-comparison.json')} == expected_comp, 'comparison files missing/extra'))
        failed_logs = [str(p.relative_to(args.root)) for p in directory.glob('*-comparison-error.log')]
        audit.attempt(cohort + '/comparison failures', lambda: require(not failed_logs, str(failed_logs)))
        records = []
        for stem in sorted(expected | observed):
            proc_path, raw_path = directory / (stem + '.process.json'), directory / (stem + '.json')
            proc = audit.attempt(str(proc_path), lambda: load(proc_path))
            # Retain admission state for failures/extras, even when no metrics can be derived.
            inventory.append({'file': str(proc_path.relative_to(args.root)), 'sha256': sha(proc_path) if proc_path.exists() else None, 'raw_exists': raw_path.exists(), 'accepted': None if proc is None else proc.get('accepted'), 'product_exit': None if proc is None else proc.get('product_exit'), 'provider_exit': None if proc is None else proc.get('provider_exit'), 'expected': stem in expected})
            if proc is not None:
                records.append(proc)
        def verify_order():
            logs = [json.loads(line) for line in (base / (cohort + '.stdout')).read_text().splitlines() if line.startswith('{')]
            expected_order = [(case, engine) for pair in range(3) for case in CASES for engine in ((denominator, numerator) if direct and pair % 2 == 0 else (numerator, denominator) if direct else ('rust', 'pi') if pair % 2 == 0 else ('pi', 'rust'))]
            require(len(logs) == len(expected_order), 'execution log count differs')
            for row, (case, engine) in zip(logs, expected_order):
                require(row['case'] == case and row['accepted'] is True and row['observer_mode'] == mode, 'recorded execution order/admission differs')
                require((row['argv'][0] == 'node') is (engine == 'pi'), 'recorded engine order differs')
                if engine != 'pi':
                    require(row['argv'][0] == (before['binary'] if engine == 'before' else after['binary']), 'recorded Rust engine order differs')
        audit.attempt(cohort + '/execution order', verify_order)
        by_group = collections.defaultdict(list)
        for case in CASES:
            for pair in range(3):
                values = {}
                for engine in (numerator, denominator):
                    stem = f'{pair}-{case}-{engine}'
                    raw_path, proc_path = directory / (stem + '.json'), directory / (stem + '.process.json')
                    def derive():
                        raw, proc = load(raw_path), load(proc_path)
                        if engine != 'pi':
                            require(raw['schema'] == (76 if engine == 'before' else 77), 'actual raw database schema differs')
                        provider = proc['provider_report']
                        require(provider['complete'] is True and not provider['failures'] and provider['stepsMatched'] == provider['stepsSettled'] == provider['stepsTotal'] == provider['requestCount'] and provider['stepStates'] == ['settled'] * provider['requestCount'], 'provider completion mismatch')
                        counter_identity(raw)
                        result = MATH.derive(raw, proc, case, mode, engine, manifest)
                        old = original_products.get(f'{cohort}/{stem}.json')
                        require(old is not None and old['raw_sha256'] == sha(raw_path) and old['process_sha256'] == sha(proc_path) and same(result['metrics'], old['metrics']), 'saved independent recomputation differs from raw arithmetic')
                        return result['metrics']
                    metric = audit.attempt(f'{cohort}/{stem}', derive)
                    if metric is not None:
                        values[engine] = metric
                        products.append({'cohort': cohort, 'case': case, 'pair': pair, 'engine': engine, 'metrics': metric})
                comp_path = directory / f'{pair}-{case}-comparison.json'
                count = audit.attempt(str(comp_path), lambda: comparison(comp_path, case, mode, direct))
                if count is not None:
                    comparisons.append({'file': str(comp_path.relative_to(args.root)), 'sha256': sha(comp_path), 'requests': count})
                for metric in (next(iter(values.values())).keys() if values else []):
                    a, b = values.get(numerator, {}).get(metric), values.get(denominator, {}).get(metric)
                    ratio, reason = MATH.paired_ratio(a, b)
                    row = {'pair': pair, 'numerator': a, 'denominator': b, 'ratio': ratio, 'ratio_unavailable_reason': reason, 'difference': None if a is None or b is None else a-b}
                    by_group[(case, metric)].append(row)
        for (case, metric), rows in by_group.items():
            if len(rows) != 3:
                audit.errors.append(f'{cohort}/{case}/{metric}: fewer than all three pairs; not admitted')
                summary = {'state': 'incomplete_not_admitted', 'n': len(rows)}
            else:
                summary = MATH.summary([r['ratio'] for r in rows])
            differences = [r['difference'] for r in rows]
            groups.append({'cohort': cohort, 'case': case, 'metric': metric, 'pairs': rows, 'summary': summary, 'numerator_lower': sum(v is not None and v < 0 for v in differences), 'equal': sum(v == 0 for v in differences), 'numerator_higher': sum(v is not None and v > 0 for v in differences), 'all_three_higher': len(differences) == 3 and all(v is not None and v > 0 for v in differences)})
    require_count = lambda: require(len(products) == 72 and len(comparisons) == 36 and sum(r['requests'] for r in comparisons) == 846, 'expected 72 products, 36 comparisons, 846 requests')
    audit.attempt(stage + '/total coverage', require_count)
    return {'derived_products': len(products), 'valid_comparisons': len(comparisons), 'checked_requests': sum(r['requests'] for r in comparisons), 'original_audit_file': str(original_path.relative_to(args.root)), 'original_audit_sha256': sha(original_path) if original_path.exists() else None, 'product_inventory': inventory, 'groups': groups, 'raw_metric_comparison_scope': 'Every saved product metric independently rederived; pairs keep all three values, zero, missing and unfavorable outcomes. Existing direct auditor suppresses zero ratios; this report retains arithmetic zero and marks log intervals unavailable.'}


def confirmation_dataset(args, audit, before, after):
    """Keep the post-hoc cell confirmation separate from the initial matrix."""
    base = args.root / 'confirmation-cohorts'
    directory = base / 'direct-live'
    queue = load(base / 'commands.json')
    manifest = load(directory / 'manifest.json')
    mode, case = 'live-subscriber', 'short-small'
    expected = {f'{pair}-{case}-{engine}' for pair in range(3, 10) for engine in ('before', 'after')}
    def check_plan():
        require(queue['status'] == 'complete' and queue['exit'] == 0 and queue['reason'], 'confirmation failed/incomplete/unexplained')
        require(queue['identities'] == {'before': before, 'after': after}, 'confirmation build binding')
        start, end = queue['source_before'], queue['source_after']
        require(start['head'] == args.expected_harness_revision and start['production_tree'] == after['production_tree'], 'confirmation source binding')
        require({k: v for k, v in start.items() if k != 'utc'} == {k: v for k, v in end.items() if k != 'utc'}, 'confirmation source changed')
        require(start['utc'] <= queue['start_utc'] <= queue['end_utc'] <= end['utc'], 'confirmation source snapshots do not bracket command')
        require(start['fixtures'], 'confirmation missing fixtures')
        if not args.raw_only:
            actual = {str(p.relative_to(args.repo)): sha(p) for p in sorted((args.repo / 'benchmarks/runtime').rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
            require(start['fixtures'] == actual, 'confirmation fixture set/hash differs')
        command = queue['command']
        require(Path(command[0]).name.startswith('python') and command[1:] == ['benchmarks/runtime/compare-revisions.py', '--before', before['binary'], '--after', after['binary'], '--output', str(Path(command[command.index('--output') + 1])), '--pairs', '7', '--pair-offset', '3', '--observer-mode', mode, '--case', case], 'confirmation command scope differs')
        require(Path(command[command.index('--output') + 1]).parts[-2:] == ('confirmation-cohorts', 'direct-live'), 'confirmation output directory differs')
        require(manifest['head'] == args.expected_harness_revision and manifest['observer_mode'] == mode and manifest['clock_ticks'] == 100 and manifest['cases'] == [case] and manifest['pairs'] == 7 and manifest['pair_offset'] == 3, 'confirmation manifest scope differs')
        require(manifest['executables'] == {engine: {'path': identity['binary'], 'sha256': identity['sha256']} for engine, identity in [('before', before), ('after', after)]}, 'confirmation manifest binaries differ')
        require({p.name[:-13] for p in directory.glob('*.process.json')} == expected, 'confirmation process matrix missing/extra')
        require({p.stem for engine in ('before', 'after') for p in directory.glob(f'*-{engine}.json')} == expected, 'confirmation raw matrix missing/extra')
        require({p.name for p in directory.glob('*-comparison.json')} == {f'{pair}-{case}-comparison.json' for pair in range(3, 10)}, 'confirmation comparison matrix missing/extra')
        require(not list(directory.glob('*-comparison-error.log')), 'confirmation failure logs retained; dataset rejected')
        logs = [json.loads(line) for line in (base / 'cohort.stdout').read_text().splitlines() if line.startswith('{')]
        order = [engine for pair in range(3, 10) for engine in (('after', 'before') if pair % 2 else ('before', 'after'))]
        require(len(logs) == len(order), 'confirmation order length')
        for row, engine in zip(logs, order):
            require(row['case'] == case and row['observer_mode'] == mode and row['accepted'] is True and row['argv'][0] == (before if engine == 'before' else after)['binary'], 'confirmation execution order/admission differs')
    audit.attempt('confirmation queue/inventory/order', check_plan)
    products, comparisons, inventory, paired = [], [], [], collections.defaultdict(list)
    observed = {p.name[:-13] for p in directory.glob('*.process.json')}
    for stem in sorted(expected | observed):
        proc_path = directory / (stem + '.process.json')
        proc = audit.attempt(stem + '/admission', lambda: load(proc_path))
        inventory.append({'file': str(proc_path.relative_to(args.root)), 'expected': stem in expected, 'sha256': sha(proc_path) if proc_path.exists() else None, 'accepted': None if proc is None else proc.get('accepted'), 'product_exit': None if proc is None else proc.get('product_exit'), 'provider_exit': None if proc is None else proc.get('provider_exit')})
    for pair in range(3, 10):
        values = {}
        for engine in ('before', 'after'):
            raw_path = directory / f'{pair}-{case}-{engine}.json'
            proc_path = directory / f'{pair}-{case}-{engine}.process.json'
            def derive():
                raw, proc = load(raw_path), load(proc_path)
                require(raw['schema'] == (76 if engine == 'before' else 77), 'confirmation actual database schema differs')
                provider = proc['provider_report']
                require(provider['complete'] is True and not provider['failures'] and provider['stepsMatched'] == provider['stepsSettled'] == provider['stepsTotal'] == provider['requestCount'] and provider['stepStates'] == ['settled'] * provider['requestCount'], 'confirmation provider incomplete')
                counter_identity(raw)
                return MATH.derive(raw, proc, case, mode, engine, manifest)['metrics']
            metric = audit.attempt(str(raw_path), derive)
            if metric is not None:
                values[engine] = metric
                products.append({'file': str(raw_path.relative_to(args.root)), 'raw_sha256': sha(raw_path), 'process_sha256': sha(proc_path), 'pair': pair, 'engine': engine, 'metrics': metric})
        cp = directory / f'{pair}-{case}-comparison.json'
        count = audit.attempt(str(cp), lambda: comparison(cp, case, mode, True))
        if count is not None:
            comparisons.append({'file': str(cp.relative_to(args.root)), 'sha256': sha(cp), 'requests': count})
        for metric in next(iter(values.values())).keys() if values else []:
            a, b = values.get('after', {}).get(metric), values.get('before', {}).get(metric)
            ratio, reason = MATH.paired_ratio(a, b)
            paired[metric].append({'pair': pair, 'numerator': a, 'denominator': b, 'ratio': ratio, 'ratio_unavailable_reason': reason, 'difference': None if a is None or b is None else a-b})
    groups = []
    for metric, rows in paired.items():
        require(len(rows) == 7, 'confirmation group incomplete')
        ratios = [row['ratio'] for row in rows]
        available = [v for v in ratios if v is not None]
        differences = [row['difference'] for row in rows]
        groups.append({'cohort': 'confirmation-direct-live', 'case': case, 'metric': metric, 'pairs': rows, 'summary': {'state': 'complete' if len(available) == 7 else 'missing_ratios_retained', 'n': 7, 'values': ratios, 'available': len(available), 'median': statistics.median(available) if available else None, 'minimum': min(available) if available else None, 'maximum': max(available) if available else None, 'interval': None, 'interval_unavailable_reason': 'Descriptive post-hoc cell confirmation; do not reuse the independent helper interval fixed to three pairs or claim a full parity gate.'}, 'numerator_lower': sum(v is not None and v < 0 for v in differences), 'equal': sum(v == 0 for v in differences), 'numerator_higher': sum(v is not None and v > 0 for v in differences), 'all_seven_higher': all(v is not None and v > 0 for v in differences)})
    audit.attempt('confirmation coverage', lambda: require(len(products) == 14 and len(comparisons) == 7 and sum(c['requests'] for c in comparisons) == 280, 'confirmation expected 14 products/7 comparisons/280 requests'))
    return {'derived_products': len(products), 'valid_comparisons': len(comparisons), 'checked_requests': sum(c['requests'] for c in comparisons), 'command_record_sha256': sha(base / 'commands.json'), 'reason': queue['reason'], 'window': {'start_utc': queue['source_before']['utc'], 'end_utc': queue['source_after']['utc']}, 'product_inventory': inventory, 'products': products, 'comparisons': comparisons, 'groups': groups, 'limits': ['Original three-pair matrix and 3.666x sample remain unchanged; confirmation is a separate post-hoc cell and does not replace them.', 'All seven confirmation ratios retained; no trim, censoring or pooling with initial data.', 'Seven pairs in one selected cell are not the complete >=7-pair parity/nonregression gate.']}


def validation(args, audit):
    results = []
    for commands_path in sorted(args.root.glob('check*/check-build-commands.json')):
        rows = load(commands_path)
        directory = commands_path.parent
        result = {'directory': str(directory.relative_to(args.root)), 'commands_sha256': sha(commands_path), 'steps': [], 'source_snapshots': {}}
        snapshots = {}
        for name in ('source-before.json', 'source-after.json'):
            path = directory / name
            if path.exists():
                snapshot = load(path)
                snapshots[name] = snapshot
                result['source_snapshots'][name] = {'sha256': sha(path), 'utc': snapshot.get('utc'), 'head': snapshot.get('head'), 'files': len(snapshot.get('files', {})), 'scope': snapshot.get('scope')}
            else:
                result['source_snapshots'][name] = None
        result['source_binding'] = 'unavailable; no historical identity invented'
        if len(snapshots) == 2:
            source_before, source_after = snapshots['source-before.json'], snapshots['source-after.json']
            if source_before.get('files') == source_after.get('files') and source_before.get('files'):
                result['source_binding'] = 'recorded before/after file hashes equal'
        for row in rows:
            label = row['label']
            out = directory / (label + '.stdout')
            entry = {'label': label, 'status': row['status'], 'exit': row.get('exit'), 'stdout_sha256': sha(out) if out.exists() else None, 'stderr_sha256': sha(directory / (label + '.stderr')) if (directory / (label + '.stderr')).exists() else None}
            if label == 'tests-build' and row.get('exit') == 0:
                def check_artifacts():
                    require(row['command'] == ['cargo', 'test', '--release', '--config', 'profile.release.package.rustx.opt-level=0', '--locked', '--all-features', '--lib', '--test', 'durable', '--test', 'process', '--no-run', '--message-format=json'], 'correctness build command differs')
                    build = [json.loads(line) for line in out.read_text().splitlines() if line.startswith('{')]
                    require([r for r in build if r.get('reason') == 'build-finished'] == [{'reason': 'build-finished', 'success': True}], 'no successful correctness build marker')
                    artifacts = [r for r in build if r.get('reason') == 'compiler-artifact' and r['target']['name'] in ('rustx', 'durable', 'process', 'bash-supervisor', 'interactive-supervisor')]
                    require(artifacts and all(r['profile']['opt_level'] == '0' and r['features'] == ['issue-387-profile', 'mcp-fixture'] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts), 'correctness root O0/all-feature profile differs')
                    return [{'name': r['target']['name'], 'kind': r['target']['kind'], 'executable': r['executable'], 'fresh': r['fresh']} for r in artifacts]
                entry['root_artifacts'] = audit.attempt(str(out) + ' artifact identity', check_artifacts)
            if label.startswith('tests-') and label != 'tests-build' and out.exists():
                text = out.read_text()
                tests = re.findall(r'^test (\S+) \.\.\. (ok|ignored|FAILED)', text, re.M)
                summary = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
                entry.update(test_status_counts=dict(collections.Counter(v for _, v in tests)), failed=[n for n, v in tests if v == 'FAILED'], ignored=[n for n, v in tests if v == 'ignored'], summary=summary)
                if summary:
                    last = summary[-1]
                    audit.attempt(str(out), lambda: require(len(summary) == 1 and len({n for n, _ in tests}) == len(tests) and collections.Counter(v for _, v in tests) == collections.Counter({'ok': int(last[1]), 'FAILED': int(last[2]), 'ignored': int(last[3])}), 'test names and summary disagree'))
                    if row.get('exit') == 0:
                        audit.attempt(str(out) + ' success status', lambda: require(last[0] == 'ok' and int(last[2]) == 0 and int(last[4]) == 0, 'exit-zero test output reports failure/measured tests'))
                elif row.get('exit') == 0:
                    audit.errors.append(f'{out}: exit-zero test queue has no libtest summary')
                entry['gh_tests'] = [n for n, _ in tests if '::shared_scalar_' in n or '::bounded_response_page_' in n]
            result['steps'].append(entry)
        if rows and all(row.get('exit') == 0 for row in rows) and rows[-1]['label'] == 'clippy':
            def source_binding():
                require(len(snapshots) == 2, 'successful check queue has no complete source snapshots')
                left, right = snapshots['source-before.json'], snapshots['source-after.json']
                require(left['files'] == right['files'] and left['files'], 'test source changed during correctness queue')
                require(left['utc'] <= rows[0]['start_utc'] and rows[-1]['end_utc'] <= right['utc'], 'test source snapshots do not bracket checks')
                if not args.raw_only:
                    require(all(sha(args.repo / path) == digest for path, digest in left['files'].items()), 'tested source file differs from current committed GH source')
                    expected_src = set(git(args.repo, 'ls-tree', '-r', '--name-only', 'HEAD', '--', 'src').splitlines())
                    require({p for p in left['files'] if p.startswith('src/')} == expected_src, 'source snapshot file set is incomplete')
                return 'before/after identical; current GH committed bytes verified' if not args.raw_only else 'before/after identical retained hashes only; current/source commit bytes not checked'
            result['source_binding'] = audit.attempt(str(directory) + ' test source binding', source_binding)
        results.append(result)
    required = {'fmt', 'tests-build', 'tests-sqlite', 'tests-client', 'tests-conversation-runtime', 'tests-read-layout', 'tests-content', 'tests-durable', 'tests-process', 'clippy'}
    complete = [r for r in results if {s['label'] for s in r['steps']} >= required and all(s['status'] == 'complete' and s['exit'] == 0 for s in r['steps'])]
    audit.attempt('correctness checks', lambda: require(complete, 'no complete successful recorded correctness/fmt/Clippy queue'))
    if complete:
        tested = [name for step in complete[-1]['steps'] for name in step.get('gh_tests', [])]
        audit.attempt('new differential test coverage', lambda: require(sum('::shared_scalar_' in n for n in tested) >= 7 and sum('::bounded_response_page_' in n for n in tested) >= 9, 'G/H differential tests missing from successful selected suite'))
    return {'runs': results, 'successful_complete_queues': [r['directory'] for r in complete], 'source_binding_limit': 'Initial failed runs without source snapshots are retained and explicitly unbound. Successful final checks require before/after file hashes; strict mode matches those bytes to the clean current GH source. This is evidence consistency, not a reproducible-build proof.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=HERE)
    parser.add_argument('--repo', type=Path, default=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX'))
    parser.add_argument('--stage', choices=['direct', 'confirmation', 'final', 'all'], default='all')
    parser.add_argument('--baseline-identity', type=Path, default=Path('/home/capi/.cache/rustx-pr485-cost-reduction/candidate-f-build/identity.json'))
    parser.add_argument('--candidate-identity', type=Path)
    parser.add_argument('--expected-harness-revision', required=True)
    parser.add_argument('--expect-rust-sha256')
    parser.add_argument('--freeze', type=Path, default=Path('/home/capi/.cache/rustx-pr485-next/deepseek-setup/final-source-identity.json'))
    parser.add_argument('--output', type=Path)
    parser.add_argument('--raw-only', action='store_true')
    args = parser.parse_args()
    args.candidate_identity = args.candidate_identity or args.root / 'candidate-gh-build/identity.json'
    output = args.output or args.root / 'gh-audit.json'
    audit = Audit()
    report = {'accepted': False, 'mode': 'raw-only' if args.raw_only else 'strict', 'strict_identity_verified': False, 'script_sha256': sha(__file__), 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'errors': audit.errors, 'datasets': {}, 'queue_states': {}}
    global MATH
    dependencies = load(HERE / 'audit-gh-dependencies.json')
    MATH = module('gh_independent_math', HERE / 'recompute-pi.py', dependencies['files']['recompute-pi.py'])
    ds = module('gh_independent_three', HERE / 'recompute-three-engine.py', dependencies['files']['recompute-three-engine.py'])
    report['independent_dependencies'] = dependencies
    plan = audit.attempt('predeclared plan', lambda: load(args.root / 'plan.json'))
    report['predeclared_plan_sha256'] = sha(args.root / 'plan.json') if plan else None
    ids = audit.attempt('retained build records', lambda: (load(args.baseline_identity), load(args.candidate_identity)))
    verified_ids = audit.attempt('build/source identities', lambda: identities(args, plan)) if plan else None
    report['identities'] = None if ids is None else {key: {field: value.get(field) for field in ('head', 'production_tree', 'sha256', 'harness', 'rustc')} for key, value in zip(('F', 'GH'), ids)}
    report['recorded_build_identity_verified'] = verified_ids is not None
    report['actual_build_identity_verified'] = verified_ids is not None and not args.raw_only
    report['validation'] = audit.attempt('validation log audit', lambda: validation(args, audit))
    stages = ['direct', 'final'] if args.stage == 'all' else [] if args.stage == 'confirmation' else [args.stage]
    windows = []
    for stage in stages:
        queue = args.root / (stage + '-cohorts/commands.json')
        report['queue_states'][stage] = audit.attempt(stage + ' recorded full queue', lambda: load(queue))
        if ids is None:
            continue
        record = audit.attempt(stage + ' plan validation', lambda: command_plan(args, stage, *ids))
        if record:
            windows.append(record)
        report['datasets'][stage] = audit.attempt(stage + ' raw arithmetic', lambda: paired_dataset(args, audit, stage, *ids))
        if stage == 'final':
            dsargs = SimpleNamespace(dataset=args.root / 'final-cohorts/three-engine', harness_root=args.repo, freeze=args.freeze, expected_rust_sha256=ids[1]['sha256'], expected_harness_revision=args.expected_harness_revision, raw_only=args.raw_only)
            result = audit.attempt('three-engine raw audit', lambda: ds.audit(dsargs))
            if result is not None:
                original = audit.attempt('saved three-engine audit', lambda: load(args.root / 'final-cohorts/three-engine-audit.json'))
                audit.attempt('three-engine acceptance', lambda: require(result['accepted'] and result['derived_products'] == 36 and result['valid_comparisons'] == 12, str(result['errors'])))
                if original is not None:
                    audit.attempt('three-engine numerical equality', lambda: require(same(result['rows'], original['rows']) and same(result['groups'], original['groups']), 'rows/groups differ from saved strict recomputation'))
                report['datasets']['three-engine'] = {k: result[k] for k in ('accepted', 'mode', 'strict_identity_verified', 'derived_products', 'valid_comparisons', 'groups', 'errors', 'limitations')}
                records_path = dsargs.dataset / 'records.json'
                records = audit.attempt('three-engine retained admissions', lambda: load(records_path))
                if records is not None:
                    report['datasets']['three-engine']['records_sha256'] = sha(records_path)
                    report['datasets']['three-engine']['admissions'] = [{k: row.get(k) for k in ('repetition', 'case', 'engine', 'accepted', 'error')} for row in records]
    if args.stage in ('confirmation', 'all') or (args.stage == 'final' and (args.root / 'confirmation-cohorts').exists()):
        report['queue_states']['confirmation'] = audit.attempt('confirmation recorded full queue', lambda: load(args.root / 'confirmation-cohorts/commands.json'))
        if ids is not None:
            report['datasets']['confirmation'] = audit.attempt('confirmation raw arithmetic', lambda: confirmation_dataset(args, audit, *ids))
    if len(windows) == 2:
        audit.attempt('serial cohort groups', lambda: require(windows[0]['end_utc'] <= windows[1]['start_utc'], 'direct/final groups overlap'))
    report['measurement_windows'] = windows
    report['limits'] = ['No products/builds/tests/profilers/decompression run by this script.', 'Recorded semantic oracle outcomes checked, not independently reimplemented.', 'No failed or unfavorable sample is discarded. Missing counters and zero denominators stay unavailable; arithmetic zero remains zero.', '100 Hz CPU has 10 ms granularity; memory is sampled PSS, not a continuous peak; process write_bytes is not device traffic.', 'Three pairs support exploratory ratios, not the unchanged >=7-pair parity gate. G and H run as one candidate: no individual causal speed attribution.', 'DeepSeek idle is not durable settlement; no cross-engine equal-durability claim.', 'Raw-only verifies retained identities and evidence; actual binary files/current Git/source schema are not revalidated.']
    report['accepted'] = not audit.errors
    report['strict_identity_verified'] = report['accepted'] and report['actual_build_identity_verified'] and not args.raw_only
    output.write_text(json.dumps(report, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(output), 'accepted': report['accepted'], 'mode': report['mode'], 'errors': audit.errors, 'datasets': {k: None if v is None else {f: v.get(f) for f in ('derived_products', 'valid_comparisons', 'checked_requests')} for k, v in report['datasets'].items()}}, indent=2))
    return 0 if report['accepted'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
