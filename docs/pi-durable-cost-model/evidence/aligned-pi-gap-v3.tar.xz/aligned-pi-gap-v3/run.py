from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

repo = Path('/workspace/rustX-pi-durable')
root = Path('/workspace/issue-481-evidence/aligned-pi-gap-v3')
pi = Path('/workspace/pi-481')
binary = Path('/workspace/issue-481-evidence/native-statement-reuse-build/conformance')
sys.path.insert(0, str(repo/'benchmarks/runtime'))
from controller import CASES, TEST, run

identity = json.loads((binary.parent/'identity.json').read_text())
assert identity['head'] == 'b87ae908b17dc9b63c2e6993a0c81d10c0960177' and identity['verified']
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == identity['sha256']
assert all(hashlib.file_digest((repo/p).open('rb'), 'sha256').hexdigest() == sha for p, sha in identity['harness'].items())
git = lambda path, *args: subprocess.check_output(['git', *args], cwd=path, text=True).strip()
assert git(pi, 'rev-parse', 'HEAD') == '90d863f7c1183b965f099855715d6e88c7b8a52c'
assert not git(pi, 'diff', '--name-only')
assert subprocess.check_output(['node', '--version'], text=True).strip() == 'v24.19.0'
assert not os.environ.get('LD_PRELOAD') and not os.environ.get('CPUPROFILE') and not os.environ.get('HEAPPROFILE')
procs = subprocess.check_output(['ps', '-eo', 'stat=,comm='], text=True)
assert not [p for p in procs.splitlines() if not p.strip().startswith('Z') and p.split()[-1] in ['rustc', 'clippy-driver', 'cargo', 'xz', 'gzip', 'strace', 'perf']]
assert shutil.disk_usage('/workspace').free > 1_800*1024**2
root.mkdir(exist_ok=False)
native = {}
for name in ['rustx', 'bash-supervisor', 'interactive-supervisor']:
    source = Path('/tmp/issue481-sql-candidate-native/release')/name
    target = Path('/workspace/issue-481-target/release')/name
    digest = hashlib.file_digest(source.open('rb'), 'sha256').hexdigest()
    shutil.copy2(source, target)
    assert hashlib.file_digest(target.open('rb'), 'sha256').hexdigest() == digest
    native[name] = dict(source=str(source), target=str(target), sha256=digest)
manifest = dict(measured_source=identity['head'], measured_production_tree=identity['production_tree'],
                published_reporting_head='300c8d2b32efb0b9d278871ad36ff5afe6de4b5e',
                current_unmeasured_source=git(repo, 'rev-parse', 'HEAD'),
                rust_binary=str(binary), rust_sha256=identity['sha256'], build_identity=identity,
                native_executables=native, pi=str(pi), pi_revision=git(pi,'rev-parse','HEAD'),
                node=subprocess.check_output(['node','--version'],text=True).strip(),
                clock_ticks=os.sysconf('SC_CLK_TCK'), pairs=3, cases=CASES,
                workload_version=3, model_time='2026-10-19 00:00:00',
                scope='Current published Rust production b87/300 versus actual pinned Pi Durable SQLite; newer checkpoint proof is excluded. Both production adapters use the same controller-owned sibling HTTP/SSE provider through product cleanup. Driver/verification included, evidence output follows cleanup. Preliminary diagnostic comparison, not parity acceptance.')
(root/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
(root/'environment.json').write_text(json.dumps(dict(cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text(),cpuinfo=Path('/proc/cpuinfo').read_text(),uname=os.uname()._asdict() if hasattr(os.uname(),'_asdict') else list(os.uname()),free_workspace_bytes=shutil.disk_usage('/workspace').free),indent=2)+'\n')
for mode in ['no-live-subscriber','live-subscriber']:
    (root/mode).mkdir()
    (root/mode/'manifest.json').write_text(json.dumps(manifest|dict(observer_mode=mode),indent=2)+'\n')
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])}
env['UV_CACHE_DIR'] = '/workspace/.uv-cache'
failed = False
began = time.monotonic_ns()
with (root/'progress.jsonl').open('x') as progress:
    for pair in range(3):
        modes = ['no-live-subscriber','live-subscriber'] if pair%2 == 0 else ['live-subscriber','no-live-subscriber']
        for mode in modes:
            for case in CASES:
                accepted = []
                for engine in (['rust','pi'] if pair%2 == 0 else ['pi','rust']):
                    stem = root/mode/f'{pair}-{case}-{engine}'
                    child_env = env | dict(RUSTX_BENCH_OBSERVER_MODE=mode, RUSTX_BENCH_CASE=case, RUSTX_BENCH_OUTPUT=str(stem.with_suffix('.json')))
                    argv = [str(binary),TEST,'--exact','--ignored','--nocapture'] if engine == 'rust' else ['node','--conditions=source','benchmarks/runtime/pi-http.mjs',str(pi),case,str(stem.with_suffix('.json'))]
                    result = run(argv, stem, case, child_env, repo/'test-support/fake-provider')
                    accepted.append(result['accepted'])
                    failed |= not result['accepted']
                comparison = subprocess.run(['node','benchmarks/runtime/compare-http.mjs',str(root/mode/f'{pair}-{case}-rust.json'),str(root/mode/f'{pair}-{case}-pi.json'),str(root/mode/f'{pair}-{case}-comparison.json')],cwd=repo,capture_output=True,text=True)
                if comparison.returncode:
                    (root/mode/f'{pair}-{case}-comparison-error.log').write_text(comparison.stderr)
                    failed = True
                row = dict(pair=pair,mode=mode,case=case,products_accepted=accepted,comparison_exit=comparison.returncode,elapsed_seconds=(time.monotonic_ns()-began)/1e9)
                progress.write(json.dumps(row)+'\n');progress.flush()
                print(json.dumps(row),flush=True)
(root/'completion.json').write_text(json.dumps(dict(failed=failed,elapsed_seconds=(time.monotonic_ns()-began)/1e9),indent=2)+'\n')
raise SystemExit(int(failed))
