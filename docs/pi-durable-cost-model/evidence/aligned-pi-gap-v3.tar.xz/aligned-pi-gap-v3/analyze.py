from pathlib import Path
import csv,importlib.util,json,math,statistics,sys
repo=Path('/workspace/rustX-pi-durable'); root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'))
spec=importlib.util.spec_from_file_location('metrics',repo/'benchmarks/runtime/summarize-http.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
keys=['mean_turn_ms','turn_cpu_ms_per_turn','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib','max_sampled_anon_pss_mib']
rows=[];groups=[];requests=0;core=0;full=0
for mode in ['no-live-subscriber','live-subscriber']:
 for case in ['short-small','short-large','stream','large','tool','cancel']:
  values={k:[] for k in keys}
  for pair in range(3):
   costs={}
   for engine in ['rust','pi']:
    p=root/mode/f'{pair}-{case}-{engine}.json';s=json.loads(p.read_text());status=json.loads(p.with_name(p.stem+'.process.json').read_text());assert status['accepted'];requests+=s['requests'] if isinstance(s['requests'],int) else len(s['requests']);costs[engine]=m.sample(p)
   checks=json.loads((root/mode/f'{pair}-{case}-comparison.json').read_text())['checked'];assert all(r['coreSemanticEqual'] for r in checks);core+=len(checks);full+=sum(r['fullSemanticRequestEqual'] for r in checks)
   for k in keys:
    r,p=costs['rust'][k],costs['pi'][k];ratio=r/p if r is not None and p is not None and r>0 and p>0 else None
    rows.append(dict(mode=mode,case=case,pair=pair,metric=k,rust=r,pi=p,ratio=ratio));values[k].append(ratio)
  for k,v in values.items():
   rec=dict(mode=mode,case=case,metric=k,ratios=v,n=3)
   if all(x is not None for x in v):
    logs=list(map(math.log,v));mean=statistics.mean(logs);w=2.919985580355516*statistics.stdev(logs)/math.sqrt(3);rec.update(median=statistics.median(v),geometric_mean=math.exp(mean),lower90=math.exp(mean-w),upper90_one_sided95=math.exp(mean+w))
   else:rec.update(state='indeterminate: zero/unavailable CPU or other metric; all pairs retained')
   groups.append(rec)
  print(mode,case,'ratios',[round(statistics.median(values[k]),4) if all(x is not None for x in values[k]) else None for k in keys])
(root/'paired-costs.json').write_text(json.dumps(rows,indent=2)+'\n');(root/'paired-uncertainty.json').write_text(json.dumps(groups,indent=2)+'\n')
with (root/'paired-costs.csv').open('w',newline='') as out:
 w=csv.DictWriter(out,fieldnames=list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows)
counts=dict(accepted_products=72,case_pairs=36,requests=requests,core_semantic_pairs=core,full_semantic_request_equal=full,expected_native_tool_schema_difference_pairs=core-full,elapsed_seconds=json.loads((root/'completion.json').read_text())['elapsed_seconds'])
(root/'counts.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts))
