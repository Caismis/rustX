# Current implementation and evidence scope

Implementation commit: a664c5a96546c3e49c5638c3c959b08df3c77fec.

Private head-bindings/source-frontiers/live-frontiers use existing imbl::OrdMap
sharing. Public read-cut map values use MetadataFragment<ReadCutMap<V>>, whose
transparent JSON/schema remains a plain ordered map. Public Rust field types
change; no compatibility decoder, migration or schema/storage change is added.
ContentMetadata and DomainSources were already persistent before this round.
Unchanged map owners reuse exact/safe-integer size certificates; every mutation
invalidates certificates even with a unique Arc owner, and old cuts remain
immutable. PreparedMetadata binds the size from the same synchronous capture.

Source-frontier merging indexes borrowed names and preserves first-output and
source-key order, including duplicate-domain cases. A bounded one-entry raw
evidence merge cache binds exact ordered owners/heads. Current source resolution
runs after cache reuse. No persistent facts or integrity checks are skipped.

WAL/NORMAL, schema 87 and original commit boundaries are unchanged. The formal
matrix is not an isolated attribution for any one optimization. Stream CPU and
wall increases remain adverse evidence; code-path sharing tests prove removed
work, not universal latency/CPU improvement. Separate counterfactual ablations
change only prior-round knobs, not these new metadata knobs. Their batch does
not stably reproduce the prior approximately 5% long-history regression, but
does not explain away or remove the previous adverse matrix. No Pi/DeepSeek reruns.

The formal auditor inventory correction is disclosed in audit-correction.json;
all 17 originally frozen hashes still match and original failed evidence remains.
