#!/usr/bin/env python3
"""Read-only audit of the fixed 144-product long-history diagnostic experiment."""
import argparse,collections,datetime,hashlib,importlib.util,json,os,statistics,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
support=HERE/'ablation-audit-support';sys.path.insert(0,str(support))
def module(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=module('ablation_original_audit',support/'direct-audit.py');old.MATH=module('ablation_math',support/'recompute-pi.py')
def load(p):return json.loads(p.read_text())
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=HERE);p.add_argument('--raw-only',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();require(not a.output.exists(),'retain previous audit');root=a.root;plan=load(root/'ablation-cohorts/commands.json');errors=[];products=[];comparisons=[]
 try:
  protocol=plan['protocol'];require(protocol['products']==144 and protocol['pairs']==6 and protocol['request_pairs']==6912 and protocol['cpu_affinity']==[2,8],'protocol');require(plan.get('completed_utc') and len(plan['steps'])==72,'complete matrix')
  require(plan['control']['sha256']=='8b19873c647647f9eda7a331e071539a18d07f1266ec0e2d1130f8515fc0d2ce','control pin')
  for k in ['affinity_before','affinity_after']:old.validate_affinity(plan[k])
  require(plan['affinity_before']['topology']==plan['affinity_after']['topology'],'topology changed')
  if not a.raw_only:
   for build in [plan['control'],*plan['variants'].values()]:require(sha(Path(build['binary']))==build['sha256'],'actual binary changed')
   repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');require(all(sha(repo/f)==h for f,h in plan['harness'].items()),'harness changed')
  for label in plan['variants']:
   if label=='pre-round-rust-control':continue
   d=root/'ablations'/label;j=load(d/'identity.json');require(j==plan['variants'][label] and sha(d/'variant.patch')==j['patch_sha256'],'ablation identity/patch changed')
   require(j['end_utc']<=plan['started_utc'] and j['verified'] and all(c['status']=='complete' and c['exit']==0 for c in j['commands']),'build overlaps experiment')
   cargo=[json.loads(l) for l in (d/'build.stdout').read_text().splitlines() if l.startswith('{')];artifacts=[r for r in cargo if r.get('reason')=='compiler-artifact' and r['target']['src_path'].startswith(str(root/'worktrees'/label))]
   # In portable mode source paths are retained provenance, not lookup inputs.
   if a.raw_only:artifacts=[r for r in cargo if r.get('reason')=='compiler-artifact' and r['target']['src_path'].startswith(str(Path(j['commands'][0].get('cwd', '/unused'))))] or [r for r in cargo if r.get('reason')=='compiler-artifact' and '/worktrees/'+label+'/' in r['target']['src_path']]
   require(artifacts and all(r['features']==[] and r['profile']['opt_level']=='3' and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts),'ordinary O3/default-feature profile')
  groups=collections.defaultdict(list)
  for step in plan['steps']:
   label,mode,pair=step['label'],step['mode'],step['pair'];require(step['status']=='complete' and step['comparison_exit']==0 and step['order']==(['before','after'] if pair%2==0 else ['after','before']),'step order/status')
   d=root/'ablation-cohorts'/label/mode;manifest=load(d/'manifest.json');require(manifest['executables']['before']['sha256']==plan['control']['sha256'] and manifest['executables']['after']['sha256']==plan['variants'][label]['sha256'],'manifest pin')
   current={}
   for engine in ['before','after']:
    path=d/f'{pair}-short-large-{engine}.json';procpath=path.with_suffix('.process.json');raw,proc=load(path),load(procpath);require(raw['schema']==(86 if engine=='after' and label=='pre-round-rust-control' else 87),'schema')
    r=old.derived_product(raw,proc,'short-large',mode,engine,manifest);products.append({'label':label,'mode':mode,'pair':pair,'engine':engine,'file':str(path.relative_to(root)),'sha256':sha(path),'process_sha256':sha(procpath),**r});current[engine]=r
   c=d/f'{pair}-short-large-comparison.json';require(old.comparison(c,'short-large',mode,True)==96,'request comparison');comparisons.append({'label':label,'mode':mode,'pair':pair,'file':str(c.relative_to(root)),'sha256':sha(c)})
   for metric,before in current['before']['metrics'].items():
    after=current['after']['metrics'][metric];change=None if before in (None,0) or after is None else (after/before-1)*100;groups[label,mode,metric].append({'pair':pair,'before':before,'after':after,'percent':change})
  require(len(products)==144 and len(comparisons)==72,'coverage')
  metrics=[]
  for (label,mode,metric),pairs in groups.items():
   require(len(pairs)==6 and {r['pair'] for r in pairs}==set(range(6)),'cell coverage');values=[r['percent'] for r in pairs if r['percent'] is not None];metrics.append({'label':label,'mode':mode,'metric':metric,'pairs':pairs,'median_percent':statistics.median(values) if values else None,'range_percent':[min(values),max(values)] if values else None,'lower':sum(v<0 for v in values),'equal':sum(v==0 for v in values),'higher':sum(v>0 for v in values)})
 except Exception as e:errors.append(f'{type(e).__name__}: {e}');metrics=[]
 result={'accepted':not errors,'errors':errors,'raw_only':a.raw_only,'products':products,'comparisons':comparisons,'request_pairs':len(comparisons)*96,'groups':metrics,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Targeted single-knob counterfactuals plus older-Rust replication control; neither promoted production nor new Pi/DeepSeek products. Negative changes mean disabling that optimization was faster. Six pairs per cell; no confidence interval or isolated wall-time causal proof beyond these counterfactual builds.'}
 a.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'accepted':result['accepted'],'errors':errors,'products':len(products),'request_pairs':result['request_pairs']}));return int(bool(errors))
if __name__=='__main__':raise SystemExit(main())
