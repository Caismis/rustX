#!/usr/bin/env python3
"""Strict Rust-only diagnostics: four columns and four WAL. This auditor runs no products."""
import argparse, ast, collections, datetime, hashlib, json, math, re, struct, subprocess, sys
from pathlib import Path
from fixture_binding import capture as capture_fixtures, FORMAL_PROTOCOL, validate_affinity
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
REPO=Path("/home/capi/.codex/worktrees/pr485-pi-performance/rustX")
BASELINE_HEAD="2184461af208af8480a53497a91aabb059c44e16"
BASELINE_TREE="9f7652ed98ab2149da718153c239e5466b3576fb"
BASELINE_SHA="8b19873c647647f9eda7a331e071539a18d07f1266ec0e2d1130f8515fc0d2ce"

TEST = 'agent_loop::runtime_benchmark::measure_runtime'

PHASES = ['before_initialization', 'after_provider_start', 'after_initialization',
          'before_measured_turns', 'after_turns', 'after_late_snapshot',
          'after_verification', 'after_shutdown', 'after_driver_drop',
          'after_final_writer_close', 'after_reopen_verification', 'after_cleanup']

LIFECYCLE = [phase for phase in PHASES if phase != 'before_measured_turns']



def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def integer(value, label, minimum=0):
    require(type(value) is int and value >= minimum, f'invalid {label}')
    return value

def utc(value):
    result = datetime.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None and result.utcoffset() == datetime.timedelta(0),
            'timestamp is not explicitly UTC')
    return result

def window(start, end):
    begin, finish = utc(start), utc(end)
    require(begin < finish, 'empty/reversed command window')
    return begin, finish

def disjoint(left, right):
    return left[1] <= right[0] or right[1] <= left[0]

def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

def verify_build(args, label):
    path = args.baseline_identity if label == 'baseline' else args.candidate_identity
    build = load(path)
    require(all(re.fullmatch('[0-9a-f]{40}', build[key]) for key in ('head', 'production_tree'))
            and re.fullmatch('[0-9a-f]{64}', build['sha256']), f'{label} malformed identity')
    require(build['verified'] is True and build['build_exit'] == build['clean_exit'] == 0, 'ordinary build failed')
    require(build['commands'] == [['cargo','clean','--release','--package','rustx'],
        ['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json']], 'build commands differ')
    require(build['harness'] and build['rustc'] and build['cargo'], 'missing toolchain/harness')
    require(all(re.fullmatch('[0-9a-f]{64}', v) for v in build['harness'].values()), 'bad harness hash')
    stdout = path.parent / 'build.stdout'
    rows = [json.loads(line) for line in stdout.read_text().splitlines() if line.startswith('{')]
    require([r for r in rows if r.get('reason') == 'build-finished'] == [{'reason':'build-finished','success':True}], 'Cargo success missing')
    artifacts = [r for r in rows if r.get('reason') == 'compiler-artifact' and r['target']['name'] in ('rustx','conformance')]
    require(any(r['target']['name'] == 'conformance' and r['executable'] for r in artifacts), 'conformance missing')
    require(all(r['profile']['opt_level']=='3' and r['features']==[] and not r['fresh'] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts), 'ordinary O3 artifacts differ')
    if label == 'baseline':
        require((build['head'],build['production_tree'],build['sha256']) == (BASELINE_HEAD,BASELINE_TREE,BASELINE_SHA), 'pinned baseline differs')
    if label == 'complete' and args.expect_rust_sha256:
        require(build['sha256'] == args.expect_rust_sha256, 'candidate SHA differs')
    if not args.raw_only:
        require(sha(build['binary']) == build['sha256'], 'actual binary differs')
        require(git(args.repo,'rev-parse',build['head']+':src') == build['production_tree'], 'source tree differs')
        for source,digest in build['harness'].items():
            require(sha(args.repo/source)==digest, 'current harness differs: '+source)
        schema=87
        require(f'pub const SQLITE_SCHEMA_VERSION: i64 = {schema};' in git(args.repo,'show',build['head']+':src/durable/sqlite.rs'), 'schema differs')
    return build, {'file':str(path),'sha256':sha(path),'cargo_stdout_sha256':sha(stdout)}

def counters(point):
    process = point['process']
    stat = process['stat']
    tail = stat.rsplit(')', 1)[1].split()
    io = {key: int(value.strip()) for key, value in
          (line.split(':', 1) for line in process['io'].splitlines())}
    return {'identity': (int(stat.split('(', 1)[0]), int(tail[19])),
            'cpu_ticks': int(tail[11]) + int(tail[12]), 'write_bytes': io['write_bytes']}

def product(directory, revision, build, case, observer, argv):
    raw, proc = load(directory / 'sample.json'), load(directory / 'sample.process.json')
    require(proc['argv'] == argv and proc['accepted'] is True and
            proc['product_exit'] == proc['provider_exit'] == 0, 'product argv/admission differs')
    require(proc['case'] == raw['case'] == case and proc['observer_mode'] ==
            raw['observer_mode'] == observer, 'product case/observer differs')
    require(raw['schema'] == 87, 'product schema differs')
    require(raw['oracle'] == 'passed' and raw['workload_version'] == 3
            and raw['measurement_version'] == 4, 'product oracle/version differs')
    history, measured = {'short-small': (8, 32), 'short-large': (64, 32), 'tool': (0, 1)}[case]
    count = history + measured
    requests = count + int(case == 'tool')
    require(raw['history'] == history and raw['measured'] == measured and len(raw['samples']) == count,
            'product turn dimensions differ')
    require(all(s['turn'] == i and s['measured'] is (i >= history)
                and s['observer_mode'] == observer for i, s in enumerate(raw['samples'])),
            'product measured phase identities differ')
    require([point['phase'] for point in raw['lifecycle']] == LIFECYCLE, 'product lifecycle differs')
    elapsed = [point['elapsed_us'] for point in raw['lifecycle']]
    require(all(type(value) is int and value >= 0 for value in elapsed) and elapsed == sorted(elapsed),
            'lifecycle times invalid/decreased')
    provider = proc['provider_report']
    require(provider['complete'] is True and provider['ok'] is True and not provider['failures']
            and provider['requestCount'] == provider['stepsTotal'] == provider['stepsMatched'] ==
            provider['stepsSettled'] == requests and provider['stepStates'] == ['settled'] * requests,
            'provider completion differs')
    require(raw['wire_requests'] == provider['requests'] and raw['live_requests'] == raw['reopened_requests']
            and raw['verified_live_requests'] == raw['verified_reopened_requests'] == requests,
            'persisted/reopened request admission differs')
    points = raw['samples'] + raw['lifecycle']
    require(len({counters(point)['identity'] for point in points}) == 1,
            'self PID/start-time changed between counters')
    for series in (raw['samples'], raw['lifecycle']):
        for key in ('cpu_ticks', 'write_bytes'):
            values = [counters(point)[key] for point in series]
            require(min(values) >= 0 and values == sorted(values), f'{key} invalid/decreased')
    begin, end, final = (counters(raw['samples'][history - 1] if history else {'process': raw['initial_process']}),
                         counters(raw['samples'][-1]), counters(raw['lifecycle'][-1]))
    settled = [sample['settled_us'] for sample in raw['samples'][history:]]
    require(all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in settled),
            'invalid settled counter')
    logs = {suffix: sha(directory / ('sample'+suffix)) for suffix in ('.log','.provider.log','.provider.stdout')}
    return {'accepted': True, 'logs_sha256': logs, 'schema': raw['schema'], 'history_turns': history,
            'measured_turns': measured, 'request_count': requests,
            'sample_sha256': sha(directory / 'sample.json'),
            'process_sha256': sha(directory / 'sample.process.json'),
            'mean_measured_turn_ms': sum(settled) / (measured * 1000),
            'measured_phase_self_cpu_ticks': end['cpu_ticks'] - begin['cpu_ticks'],
            'measured_phase_self_cpu_ms_at_100hz': (end['cpu_ticks'] - begin['cpu_ticks']) * 10,
            'measured_phase_process_write_bytes': end['write_bytes'] - begin['write_bytes'],
            'full_self_cpu_ticks': final['cpu_ticks'], 'full_self_cpu_ms_at_100hz': final['cpu_ticks'] * 10,
            'full_process_write_bytes': final['write_bytes'],
            'clock_ticks_note': 'Raw ticks are primary; milliseconds use the formal cohort 100 Hz clock convention.'}




def validate_snapshot(snapshot, revision):
    tables = snapshot['tables']
    require(tables and 'request_configurations' in tables,
            'schema-specific request_configurations presence differs')
    for name, table in tables.items():
        integer(table['rows'], name + ' rows')
        require(table['column_value_bytes'], name + ' has no column values')
        for column, value in table['column_value_bytes'].items():
            integer(value, name + '.' + column + ' bytes')
    require(not any(name in tables for name in ('event_observation_readiness', 'transcript_observation_readiness')), 'connection-local readiness must not appear in main storage')
    frontier_columns=tables['content_frontiers']['column_value_bytes']
    expected_frontier={'source_kind','source_id','block_index','representation','revision','readable_end','bytes'}
    require(set(frontier_columns)==expected_frontier,'content frontier columns differ from revision')
    layout=snapshot['content_layout'];inline=layout['frontier_inline']
    integer(layout['segment_first_rows'],'first segment rows')
    require(layout['segment_first_rows']<=tables['content_segments']['rows'],'first segment rows exceed all segments')
    require(inline['status']=='measured','inline bytes are not measured')
    integer(inline['rows'],'inline frontier rows');integer(inline['value_bytes'],'inline frontier bytes')
    require(inline['rows']<=tables['content_frontiers']['rows'] and inline['value_bytes']==frontier_columns['bytes'],'inline storage byte/row accounting differs')
    event_columns = tables['events']['column_value_bytes']
    require({'observation_statistics', 'observation_execution', 'event_json'} <=
            event_columns.keys(), 'missing native/derived event columns')
    require('observation_json' not in event_columns,
            'retired event observation layout differs from the recorded revision')
    require('observation_source_overlay' in event_columns and not any(name in event_columns for name in ('observation_source_inline', 'observation_source_inline_bytes')), 'native-body overlay schema differs')
    require('snapshot_json' in tables['request_snapshots']['column_value_bytes'], 'missing native snapshot column')
    if 'request_configurations' in tables:
        require(set(tables['request_configurations']['column_value_bytes']) == {'digest', 'configuration_json'},
                'request_configurations column shape differs')
    kinds = snapshot['events_by_kind']
    require(len({row['kind'] for row in kinds}) == len(kinds), 'duplicate event kind')
    require(all(row['column_value_bytes'].keys() == tables['events']['column_value_bytes'].keys()
                for row in kinds), 'event kind column shape differs')
    for row in kinds:
        integer(row['rows'], 'event kind rows')
        for column, value in row['column_value_bytes'].items():
            integer(value, 'event kind ' + column)
    require(sum(row['rows'] for row in kinds) == tables['events']['rows'], 'event kind rows do not sum')
    require(all(sum(row['column_value_bytes'][column] for row in kinds) == value
                for column, value in tables['events']['column_value_bytes'].items()),
            'event kind byte values do not sum')
    duplicate = snapshot['equal_event_observation_json']
    require(duplicate == {'status': 'retired_layout_absent', 'table': 'events',
                          'column': 'observation_json', 'rows': None, 'native_bytes': None},
            'retired event observation column must be absent, not reported as a measured zero')
    require(snapshot.get('scope') == 'main_database_only; connection-local TEMP owner state and virtual generated columns are outside this read-only connection measurement',
            'column snapshot must declare main-only storage scope')
    names = []
    for name, pages, payload, count in snapshot['dbstat']:
        names.append(name)
        integer(pages, 'dbstat page bytes')
        integer(payload, 'dbstat payload bytes')
        integer(count, 'dbstat page count')
        require(payload <= pages, 'dbstat payload exceeds allocated page bytes')
    require(len(set(names)) == len(names), 'duplicate dbstat object')

def row_delta(before, after):
    require(before['column_value_bytes'].keys() == after['column_value_bytes'].keys(), 'column identity changed')
    values = {column: after['column_value_bytes'][column] - value
              for column, value in before['column_value_bytes'].items()}
    return {'rows': after['rows'] - before['rows'], 'column_value_bytes': values,
            'total_column_value_bytes': sum(values.values())}

def affinity_pair(args, before, after):
    for snapshot in (before,after):
        validate_affinity(snapshot)
    require(before['pid']==after['pid'],'collector/runner affinity identity changed')
    require(utc(before['utc'])<=utc(after['utc']),'affinity receipt times decreased')
    require(before['topology']==after['topology'] and before['online_cpus']==after['online_cpus'],'CPU topology/online set changed')
    preregistered=load(args.root/'premeasurement.json')['host_affinity']
    require(before['topology']==preregistered['topology'],'CPU topology differs from premeasurement')
    return {'verified':True,'observed_scope':FORMAL_PROTOCOL['affinity_scope']}

def collector_receipt(args, directory, label, build, case, kind):
    before=load(directory/'identity-before.json');after=load(directory/'identity-after.json')
    name='run-wal-rust.py' if kind=='wal' else 'columns-complete.py'
    argv=[build['binary'],TEST,'--exact','--ignored','--nocapture']
    require(before['build']==build and before['binary_sha256']==after['binary_sha256']==build['sha256'],'collector build/binary changed')
    require(before['runner_sha256']==after['runner_sha256']==sha(args.root/name),'collector script changed')
    require(before['argv']==argv,'collector product command differs')
    original_directory=Path(build['binary']).parent.parent/directory.name
    expected=(['strace','-f','-yy','-s','96','-e','trace=pwrite64,write,writev,sendto,sendmsg,fsync,fdatasync','-o',str(original_directory/'calls.strace'),'--',*argv] if kind=='wal' else argv)
    require(before['executed_argv']==expected,'collector actual command differs')
    affinity=affinity_pair(args,before['affinity'],after['affinity'])
    producer=next(row for row in load(args.root/'diagnostic-commands.json') if row['name']==kind+'-'+label)
    span=window(producer['start_utc'],producer['end_utc'])
    require(span[0]<=utc(before['affinity']['utc'])<=utc(after['affinity']['utc'])<=span[1], 'collector receipts outside producer window')
    return {'before_sha256':sha(directory/'identity-before.json'),'after_sha256':sha(directory/'identity-after.json'),'affinity':affinity,'executed_argv':expected}

def collector_record(args, directory, label, case, kind, points):
    path=args.root/f'{kind}-records-{label}.json';records=load(path)
    require([(r['case'],r['engine']) for r in records]==[(c,'rust') for c in ('short-small','short-large')],'collector product inventory differs')
    require(all(r['accepted'] is True and r['error'] is None and r['diagnostic_error']==[] and 0<r['start_ns']<r['end_ns'] for r in records),'collector product failed')
    require(records[0]['end_ns']<=records[1]['start_ns'],'collector products overlap')
    record=next(r for r in records if r['case']==case)
    require(record['start_ns']<=points[0]['monotonic_ns']<points[-1]['monotonic_ns']<=record['end_ns'],'collector phases outside product')
    return {**record,'records_sha256':sha(path)}

def columns(args, revision, case, identities):
    directory = args.root / f'columns-{revision}-{case}'
    build = identities[revision]
    receipt = collector_receipt(args, directory, revision, build, case, 'columns')
    points, _ = phase_points(directory / 'phases.json')
    record = collector_record(args, directory, revision, case, 'columns', points)
    argv = [build['binary'], TEST, '--exact', '--ignored', '--nocapture']
    prod = product(directory, revision, build, case, 'no-live-subscriber', argv)
    before, after = load(directory / 'before_measured_turns.json'), load(directory / 'after_turns.json')
    for snapshot in (before, after):
        validate_snapshot(snapshot, revision)
    require(before['path'] == after['path'] and before['tables'].keys() == after['tables'].keys(),
            'column database/table identity changed during measured phase')
    delta = {name: row_delta(table, after['tables'][name]) for name, table in before['tables'].items()}
    require(delta['events']['rows'] == 256 and delta['request_snapshots']['rows'] == 32,
            'measured native event/request count differs')
    before_kinds, after_kinds = ({row['kind']: row for row in snapshot['events_by_kind']}
                                for snapshot in (before, after))
    kinds = {}
    empty = {'rows': 0, 'column_value_bytes': dict.fromkeys(before['tables']['events']['column_value_bytes'], 0)}
    for name in sorted(before_kinds.keys() | after_kinds.keys(), key=str):
        kinds[str(name)] = row_delta(before_kinds.get(name, empty), after_kinds.get(name, empty))
    totals = {label: sum(sum(table['column_value_bytes'].values()) for table in snapshot['tables'].values())
              for label, snapshot in [('before', before), ('after', after)]}
    total_delta = sum(row['total_column_value_bytes'] for row in delta.values())
    require(total_delta == totals['after'] - totals['before'], 'logical total arithmetic differs')
    configurations = {label: snapshot['tables'].get('request_configurations')
                      for label, snapshot in [('before', before), ('after', after)]}
    return {'revision': revision, 'case': case, 'build_head': build['head'], 'binary_sha256': build['sha256'],
            'product': prod, 'collector': receipt, 'command': record, 'before_sha256': sha(directory / 'before_measured_turns.json'),
            'after_sha256': sha(directory / 'after_turns.json'), 'phases_sha256': sha(directory / 'phases.json'),
            'logical_totals': totals, 'total_logical_delta': total_delta, 'table_deltas': delta,
            'event_kind_deltas': kinds, 'request_configurations_retained': configurations,
            'content_layout':{label:snapshot['content_layout'] for label,snapshot in [('before',before),('after',after)]},
            'equal_event_observation_json': {label: snapshot['equal_event_observation_json']
                                            for label, snapshot in [('before', before), ('after', after)]},
            'timing_isolation': 'Synchronous phase acknowledgments and exact phase order verified. '
                                'The separately audited serial wrapper brackets this column producer with UTC timestamps; no timing values are mixed with formal products.'}

def comparison(before, after):
    return {'baseline': before, 'complete': after, 'difference': after - before,
            'complete_over_baseline': None if before == 0 else after / before}

def column_comparisons(rows):
    result = []
    for case in ('short-small', 'short-large'):
        pair = {row['revision']: row for row in rows if row['case'] == case}
        if pair.keys() != {'baseline', 'complete'}:
            continue
        before, after = pair['baseline'], pair['complete']
        fields = {'all_logical': comparison(before['total_logical_delta'], after['total_logical_delta'])}
        selected = [('request_snapshots_all', 'request_snapshots', None),
                    ('request_source_pages', 'request_source_pages', None),
                    ('native_snapshot_json', 'request_snapshots', 'snapshot_json'),
                    ('native_event_json', 'events', 'event_json'),
                    ('observation_event_json', 'events', 'observation_json'),
                    ('event_statistics', 'events', 'observation_statistics'),
                    ('event_execution', 'events', 'observation_execution')]
        for label, table, column in selected:
            def value(row):
                data = row['table_deltas'][table]
                return data['total_column_value_bytes'] if column is None else data['column_value_bytes'][column]
            if column is not None and column not in after['table_deltas'][table]['column_value_bytes']:
                require((table, column) == ('events', 'observation_json'),
                        'unexpected missing comparison column')
                fields[label] = {'baseline': (value(before) if column in before['table_deltas'][table]['column_value_bytes'] else None), 'complete': None, 'difference': None,
                                 'complete_over_baseline': None, 'status': 'retired_layout_absent',
                                 'note': 'Final events schema omits this former column; absence is not a measured zero. Total logical bytes include only actual stored columns.'}
            else:
                fields[label] = comparison(value(before), value(after))
        # Both revisions inline first immutable chunks. Counting only
        # content_segments.bytes would falsely report removed payload bytes.
        def content_payload(row):
            d=row['table_deltas']
            return d['content_segments']['column_value_bytes']['bytes']+d['content_frontiers']['column_value_bytes'].get('bytes',0)
        fields['content_payload_all_locations']=comparison(content_payload(before),content_payload(after))
        fields['content_segments_all']=comparison(before['table_deltas']['content_segments']['total_column_value_bytes'],after['table_deltas']['content_segments']['total_column_value_bytes'])
        fields['content_frontiers_all']=comparison(before['table_deltas']['content_frontiers']['total_column_value_bytes'],after['table_deltas']['content_frontiers']['total_column_value_bytes'])
        fields['content_frontier_inline_payload']=comparison(before['table_deltas']['content_frontiers']['column_value_bytes']['bytes'],after['table_deltas']['content_frontiers']['column_value_bytes']['bytes'])
        # Both schemas retain shared configuration. Include each revision's
        # actual measured configuration delta in its native snapshot total.
        config = after['table_deltas']['request_configurations']['total_column_value_bytes']
        fields['native_snapshot_and_configuration'] = comparison(
            before['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + before['table_deltas']['request_configurations']['total_column_value_bytes'],
            after['table_deltas']['request_snapshots']['column_value_bytes']['snapshot_json'] + config)
        all_tables = {}
        for table in sorted(before['table_deltas'].keys() | after['table_deltas'].keys()):
            b, a = before['table_deltas'].get(table), after['table_deltas'].get(table)
            values = (comparison(b['total_column_value_bytes'], a['total_column_value_bytes']) if b is not None and a is not None else
                      {'baseline': None if b is None else b['total_column_value_bytes'], 'complete': None if a is None else a['total_column_value_bytes'],
                       'difference': None, 'complete_over_baseline': None, 'status': 'outside_measured_main_layout',
                       'note': 'Table absence from main is explicit. Connection-local TEMP memory/state is not observable from this collector and is not assigned zero.'})
            all_tables[table] = {'present_in_baseline': b is not None, 'present_in_complete': a is not None, **values}
        result.append({'case': case, 'logical_bytes': fields, 'all_table_logical_bytes': all_tables,
                       'shared_configuration_measured_delta': {'baseline': before['table_deltas']['request_configurations']['total_column_value_bytes'], 'complete': config},
                       'shared_configuration_note': 'Both revision retained totals are in columns; '
                                                    'seeded shared payload is not charged again as a measured-turn insertion; both schemas retain it.'})
    return result

def phase_points(path, expected=PHASES):
    points = load(path)
    require([p['phase'] for p in points] == expected, 'synchronous phase inventory differs')
    ticks = [integer(p['monotonic_ns'], 'phase time', 1) for p in points]
    require(all(a < b for a,b in zip(ticks,ticks[1:])), 'phase times not strictly increasing')
    return points, {p['phase']:p['monotonic_ns'] for p in points}

def wal_frames(directory, before, after, expected_phases):
    owners=collections.defaultdict(set)
    for snapshot in (before,after):
        require(snapshot['counts'] and snapshot['pages'] and snapshot['tables'],'empty database snapshot')
        for name,page,kind,cells,payload in snapshot['pages']:
            integer(page,'page',1);integer(cells,'cells');integer(payload,'payload');owners[page].add(name)
    require(before['path']==after['path'],'WAL target database changed')
    frames=collections.Counter();commits=0;pending={};phase='startup';allcommits=collections.Counter();txpages=[];tx=collections.Counter();active=False;seen=[];payloads=0;frame_bytes=0
    with (directory/'calls.strace').open() as stream:
        for line in stream:
            m=re.match(r'(\d+)\s+(.*)',line)
            if not m:continue
            pid,call=m.groups()
            if '<unfinished ...>' in call:
                require(pid not in pending,'duplicate unfinished syscall');pending[pid]=call.split('<unfinished ...>')[0];continue
            m=re.match(r'<\.\.\. \w+ resumed>(.*)',call)
            if m:
                require(pid in pending,'resumed syscall has no start');call=pending.pop(pid)+m[1]
            if 'UNIX-STREAM' in call:
                for boundary in expected_phases:
                    if '"'+boundary+'"' in call or '"'+boundary+'\\n"' in call:
                        seen.append(boundary)
                        if boundary=='before_measured_turns':phase='steady';active=True
                        elif boundary=='after_turns':phase='after_turns';active=False
                        break
            m=re.match(r'pwrite64\(\d+<([^>]+-wal)>, (.*), (\d+), (\d+)\) = (\d+)$',call)
            if not m:continue
            target,quoted,n,offset,ret=m.groups();n,offset,ret=map(int,(n,offset,ret));require(ret==n,'short WAL write')
            if active:
                require(target==before['path']+'-wal','unexpected measured WAL target')
                require(n in (24,32,4096),'unsupported measured WAL write shape')
                if n==4096:payloads+=1;require((offset-56)%4120==0,'WAL payload misaligned')
            if n!=24:continue
            data=ast.literal_eval('b'+quoted);require(len(data)==24,'bad frame header bytes')
            page,size=struct.unpack('>II',data[:8]);require(page>0 and (offset-32)%4120==0,'bad WAL frame geometry')
            if active:frames[page]+=1;tx[page]+=1;frame_bytes+=4120
            if size:
                allcommits[phase]+=1
                if active:commits+=1;txpages.append(sum(tx.values()));tx.clear()
    require(not pending and not tx and phase=='after_turns' and commits>0,'unclosed trace/transaction or missing measured commits')
    require(seen==expected_phases,'strace boundary phase inventory differs')
    require(payloads==sum(frames.values()),'WAL frame headers and page payload counts differ')
    bytable=collections.Counter()
    for page,n in frames.items():bytable['|'.join(sorted(owners[page])) or '<unmapped>']+=n
    delta={k:after['counts'][k]-before['counts'].get(k,0) for k in after['counts'] if after['counts'][k]!=before['counts'].get(k,0)}
    return {'steady_turns':32,'wal_write_commits':commits,'wal_frames':sum(frames.values()),'wal_frame_bytes':frame_bytes,
            'commits_by_phase':dict(allcommits),'wal_frames_by_snapshot_page_owner':dict(bytable.most_common()),
            'net_row_count_changes':delta,'transaction_page_counts':txpages,
            'raw_sha256':sha(directory/'calls.strace'),'matched_page_payloads':payloads,
            'limits':'WAL commit markers exclude read-only commits. Snapshot page owners are endpoint classifications, not exact ownership at each write; mixed and unmapped owners remain explicit. WAL bytes are not process write_bytes/device traffic and are not attributed CPU time.'}

def wal_diagnostic(args, label, build, case):
    directory=args.root/f'wal-{label}-{case}-rust'
    receipt=collector_receipt(args,directory,label,build,case,'wal')
    identity=load(directory/'identity-before.json');whole=load(args.root/f'wal-identity-{label}.json')
    require(whole['rust_sha256']==build['sha256'] and whole['rust_source']==build['head'], 'WAL whole-run identity differs')
    argv=[build['binary'],TEST,'--exact','--ignored','--nocapture']
    prod=product(directory,label,build,case,'no-live-subscriber',argv)
    points,_=phase_points(directory/'phases.json')
    record=collector_record(args,directory,label,case,'wal',points)
    before=load(directory/'before_measured_turns-database.json');after=load(directory/'after_turns-database.json')
    require(len(before)==len(after)==1, 'WAL database inventory differs')
    derived=wal_frames(directory,before[0],after[0],PHASES)
    retained=load(args.root/f'wal-summary-{label}.json')[case+'-rust']
    require(set(retained)==(set(derived)-{'raw_sha256','matched_page_payloads','limits'})|{'limitations'}, 'WAL summary field inventory differs')
    require(all(k in derived and retained[k]==derived[k] for k in retained if k!='limitations'), 'WAL summary arithmetic differs')
    return {'label':label,'case':case,'engine':'rust','product':prod,'summary':derived,'identity':identity,'collector':receipt,
            'phases':points,'command':record,'identity_sha256':sha(directory/'identity-before.json'),
            'before_sha256':sha(directory/'before_measured_turns-database.json'),'after_sha256':sha(directory/'after_turns-database.json'),
            'phases_sha256':sha(directory/'phases.json'),'whole_identity_sha256':sha(args.root/f'wal-identity-{label}.json')}

def producer_windows(args, identities):
    rows=load(args.root/'diagnostic-commands.json')
    expected=['columns-baseline','columns-complete','wal-baseline','wal-summary-baseline','wal-complete','wal-summary-complete']
    require([r['name'] for r in rows]==expected, 'diagnostic producer inventory/order differs')
    commands={}
    for label,build in identities.items():
        commands['columns-'+label]=('columns-complete.py',['--binary',build['binary'],'--label',label])
        commands['wal-'+label]=('run-wal-rust.py',['--binary',build['binary'],'--label',label])
        commands['wal-summary-'+label]=('analyze-wal-verified.py',['--label',label])
    original_roots={Path(build['binary']).parent.parent for build in identities.values()}
    require(len(original_roots)==1,'recorded build evidence roots differ')
    original_root=next(iter(original_roots))
    for row in rows:
        require(row['status']=='complete' and row['exit']==0, 'diagnostic producer failed')
        command=row['command'];require(command[:3]==['taskset','-c','2,8'] and len(command)>=5 and Path(command[3]).name.startswith('python'), 'invalid diagnostic affinity/interpreter')
        name=Path(command[4]).name
        require(command[4]==str(original_root/name) and (name,command[5:])==commands[row['name']], 'unexpected diagnostic producer/arguments')
        affinity_pair(args,row['runner_affinity_before'],row['runner_affinity_after'])
        require(row['producer_sha256']==sha(args.root/name), 'diagnostic producer hash differs')
        require(all((args.root/(row['name']+suffix)).is_file() for suffix in ('.stdout','.stderr')), 'missing diagnostic command logs')
    spans=[window(r['start_utc'],r['end_utc']) for r in rows]
    require(all(a[1]<=b[0] for a,b in zip(spans,spans[1:])), 'diagnostic producers overlap')
    left,right=(load(args.root/f'diagnostic-source-{side}.json') for side in ('before','after'))
    require({k:v for k,v in left.items() if k not in ('utc','affinity')}=={k:v for k,v in right.items() if k not in ('utc','affinity')}, 'diagnostic sources changed')
    affinity_pair(args,left['affinity'],right['affinity'])
    require(left['protocol']==FORMAL_PROTOCOL, 'diagnostic protocol differs')
    require(left['files']==identities['complete']['source_files'] and left['head']==identities['complete']['head'], 'diagnostic source identity differs')
    require(left['runner_sha256']==sha(args.root/'run-diagnostics.py'), 'diagnostic wrapper changed')
    require(utc(left['utc'])<=spans[0][0] and spans[-1][1]<=utc(right['utc']), 'diagnostic source snapshots do not bracket products')
    preflight=load(args.root/'premeasurement.json')
    require(preflight['accepted'] is True and utc(preflight['completed_utc'])<=utc(left['utc']), 'diagnostics predate successful premeasurement')
    require(preflight['protocol']==FORMAL_PROTOCOL, 'preregistered protocol differs')
    require(all(sha(args.root/name)==digest for name,digest in preflight['scripts'].items()), 'frozen scripts changed')
    formal=load(args.root/'direct-cohorts/commands.json')
    require(left['fixtures']==formal['source_before']['fixtures']==preflight['fixtures'], 'formal/diagnostic/premeasurement fixtures differ')
    if not args.raw_only:
        require(all(sha(args.repo/path)==value for path,value in left['files'].items()), 'diagnostic current source differs')
        actual=capture_fixtures(args.repo)
        require(actual==left['fixtures'], 'diagnostic current fixtures differ')
    return {'verified':True,'wrappers':rows,'sha256':sha(args.root/'diagnostic-commands.json'),
            'logs_sha256':{row['name']+suffix:sha(args.root/(row['name']+suffix)) for row in rows for suffix in ('.stdout','.stderr')},
            'source_before_sha256':sha(args.root/'diagnostic-source-before.json'),'source_after_sha256':sha(args.root/'diagnostic-source-after.json')}

def formal_binding(args, identities, producers):
    formal=load(args.formal_audit)
    require(formal['accepted'] is True and formal['errors']==[] and formal['datasets']['direct']['derived_products']==FORMAL_PROTOCOL['products'], 'direct formal audit incomplete')
    require(formal['script_sha256']==sha(args.root/'direct-audit.py'), 'formal auditor identity differs')
    require(formal['mode'] in ('strict','raw-only'), 'unknown formal audit mode')
    if not args.raw_only:require(formal['mode']=='strict' and formal['strict_identity_verified'] is True, 'formal strict identity missing')
    for key,label in [('before','baseline'),('after','complete')]:
        require(formal['identities'][key]=={k:identities[label][k] for k in ('head','production_tree','sha256')}, 'formal diagnostic build differs')
    plan=load(args.root/'direct-cohorts/commands.json')
    require(formal['identities']['commands_sha256']==sha(args.root/'direct-cohorts/commands.json'), 'formal queue changed')
    span=window(plan['source_before']['utc'],plan['source_after']['utc'])
    require(all(disjoint(span,window(r['start_utc'],r['end_utc'])) for r in producers['wrappers']), 'formal and diagnostic products overlap')
    return {'file':str(args.formal_audit),'sha256':sha(args.formal_audit),'mode':formal['mode'],'products':FORMAL_PROTOCOL['products'],
            'scope':'Fresh paired Rust-only formal products; eight diagnostic products (four columns and four WAL) remain separate. All producer UTC windows are disjoint from the formal source window.'}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,default=HERE);parser.add_argument('--repo',type=Path,default=REPO)
    parser.add_argument('--raw-only',action='store_true');parser.add_argument('--expect-rust-sha256');parser.add_argument('--formal-audit',type=Path)
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    require(not args.output.exists(), 'retain previous audit; choose another output')
    args.baseline_identity=args.root/'baseline-build/identity.json';args.candidate_identity=args.root/'candidate-complete-build/identity.json'
    args.formal_audit=args.formal_audit or args.root/'direct-audit.json'
    report={'accepted':False,'mode':'raw-only' if args.raw_only else 'strict','errors':[],'columns':[],'wal':[],'identities':{},'build_receipts':{},'script_sha256':sha(__file__)}
    def check(name,fn):
        try:return fn()
        except Exception as error:report['errors'].append(f'{name}: {type(error).__name__}: {error}');return None
    identities={}
    for label in ('baseline','complete'):
        result=check(label+' build',lambda label=label:verify_build(args,label))
        if result:
            build,receipt=result;identities[label]=build;report['build_receipts'][label]=receipt
            report['identities'][label]={k:build[k] for k in ('head','production_tree','sha256','harness','rustc','cargo')}
    if len(identities)==2:
        check('same build harness/toolchain',lambda:require(all(identities['baseline'][k]==identities['complete'][k] for k in ('harness','rustc','cargo')) and identities['baseline']['sha256']!=identities['complete']['sha256'], 'build pair differs'))
        report['producer_windows']=check('producer windows',lambda:producer_windows(args,identities))
    for label,build in identities.items():
        for case in ('short-small','short-large'):
            row=check(f'columns-{label}-{case}',lambda label=label,case=case:columns(args,label,case,identities))
            if row:report['columns'].append(row)
            row=check(f'wal-{label}-{case}',lambda label=label,build=build,case=case:wal_diagnostic(args,label,build,case))
            if row:report['wal'].append(row)
    report['column_comparison']=check('column arithmetic',lambda:column_comparisons(report['columns']))
    report['overlay_comparison']=[]
    for case in ('short-small','short-large'):
        pair={r['revision']:r for r in report['columns'] if r['case']==case}
        if pair.keys()=={'baseline','complete'}:
            old=pair['baseline']['table_deltas']['events']['column_value_bytes'];new=pair['complete']['table_deltas']['events']['column_value_bytes']
            report['overlay_comparison'].append({'case':case,'stored_derived_source_bytes':comparison(old['observation_source_overlay'],new['observation_source_overlay']), 'scope':'Both revisions retain the same native-body overlay representation; values are independently measured in each product.'})
    if report.get('producer_windows') and len(identities)==2:
        report['formal_audit']=check('formal binding',lambda:formal_binding(args,identities,report['producer_windows']))
    report['accepted']=not report['errors'] and all(len(report[k])==4 for k in ('columns','wal')) and report.get('formal_audit') is not None
    report['recorded_build_identity_verified']=len(identities)==2 and report['accepted']
    report['strict_identity_verified']=report['actual_binary_verified']=report['accepted'] and not args.raw_only
    report['product_count']=sum(len(report[k]) for k in ('columns','wal'))
    report['limits']=['Diagnostics are isolated from formal products, not pooled into timing statistics.', 'Endpoint dbstat page ownership is not exact per-write table attribution.', 'Main-only logical values exclude TEMP and transient/deleted values and are not WAL or process write bytes.', 'Raw-only follows only selected retained paths, never embedded absolute binary or database paths.', 'No CPU profile/control, Pi or DeepSeek product executes in this round.', FORMAL_PROTOCOL['affinity_scope']]
    args.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'accepted':report['accepted'],'product_count':report['product_count'],'errors':report['errors']},indent=2))
    return int(not report['accepted'])

if __name__=='__main__':raise SystemExit(main())
