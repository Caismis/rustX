import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');previous=Path('/home/capi/.cache/rustx-pr485-incremental-attempt-20261102')
sys.path.insert(0,str(repo/'benchmarks/runtime'));sys.path.insert(0,str(previous));sys.dont_write_bytecode=True
from controller import run,TEST
from fixture_binding import affinity_snapshot,validate_affinity
os.sched_setaffinity(0,{2,8});topology=affinity_snapshot();validate_affinity(topology)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
control=json.loads((previous/'candidate-complete-build/identity.json').read_text());assert control['sha256']==sha(Path(control['binary']))=='8b19873c647647f9eda7a331e071539a18d07f1266ec0e2d1130f8515fc0d2ce'
assert all(sha(repo/p)==h for p,h in control['harness'].items())
variants={p.parent.name:json.loads(p.read_text()) for p in sorted((root/'ablations').glob('*/identity.json'))}
assert len(variants)==5 and all(v['verified'] and v['rustc']==control['rustc'] and v['cargo']==control['cargo'] and sha(Path(v['binary']))==v['sha256'] for v in variants.values())
old=json.loads((previous/'baseline-build/identity.json').read_text());variants['pre-round-rust-control']=old
labels=list(variants)
base=root/'ablation-cohorts';base.mkdir(exist_ok=False)
plan={'scope':'Targeted diagnostic ablations, not promoted production or the six-case formal matrix. Five single-knob counterfactuals plus the older Rust code as a replication control. All products use unchanged controller/provider fixtures. No Pi/DeepSeek execution.','control':control,'variants':variants,'harness':control['harness'],'clock_ticks':os.sysconf('SC_CLK_TCK'),'affinity_before':topology,'protocol':{'case':'short-large','observer_modes':['no-live-subscriber','live-subscriber'],'pairs':6,'products':144,'request_pairs':6912,'cpu_affinity':[2,8],'order':['before_after','after_before']*3,'variant_order':'cyclic rotation by pair; mode order reversed on odd pairs'},'started_utc':now(),'steps':[]}
assert plan['clock_ticks']==100
def save():(base/'commands.json').write_text(json.dumps(plan,indent=2)+'\n')
save()
for pair in range(6):
 modes=['no-live-subscriber','live-subscriber']
 if pair%2:modes.reverse()
 for mode in modes:
  order=labels[pair%len(labels):]+labels[:pair%len(labels)]
  for label in order:
   d=base/label/mode;d.mkdir(parents=True,exist_ok=True)
   manifest={'executables':{name:{'path':build['binary'],'sha256':build['sha256']} for name,build in [('before',control),('after',variants[label])]},'clock_ticks':100}
   if not (d/'manifest.json').exists():(d/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
   record={'label':label,'pair':pair,'mode':mode,'order':['before','after'] if pair%2==0 else ['after','before'],'status':'running','start_utc':now(),'products':[]};plan['steps'].append(record);save()
   for engine in record['order']:
    binary=Path(manifest['executables'][engine]['path']);assert sha(binary)==manifest['executables'][engine]['sha256']
    stem=d/f'{pair}-short-large-{engine}';env=os.environ|{'UV_OFFLINE':'1','RUSTX_BENCH_CASE':'short-large','RUSTX_BENCH_OBSERVER_MODE':mode,'RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json'))}
    argv=[str(binary),TEST,'--exact','--ignored','--nocapture'];r=run(argv,stem,'short-large',env,repo/'test-support/fake-provider')
    record['products'].append({'engine':engine,'stem':str(stem.relative_to(root)),'argv':argv,'accepted':r['accepted']});save();assert r['accepted'],(label,mode,pair,engine)
   compare=['node','benchmarks/runtime/compare-http.mjs',str(d/f'{pair}-short-large-before.json'),str(d/f'{pair}-short-large-after.json'),str(d/f'{pair}-short-large-comparison.json')]
   with (d/f'{pair}-comparison.stdout').open('x') as out,(d/f'{pair}-comparison.stderr').open('x') as err:r=subprocess.run(compare,cwd=repo,stdout=out,stderr=err)
   record.update(comparison_command=compare,comparison_exit=r.returncode,status='complete' if r.returncode==0 else 'failed',end_utc=now());save();assert r.returncode==0
  print(pair,mode,'complete',flush=True)
plan['affinity_after']=affinity_snapshot();validate_affinity(plan['affinity_after']);assert plan['affinity_after']['topology']==topology['topology'];assert all(sha(repo/p)==h for p,h in control['harness'].items());plan['completed_utc']=now();save()
