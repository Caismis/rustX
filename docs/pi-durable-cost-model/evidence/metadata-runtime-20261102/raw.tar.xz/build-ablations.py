import concurrent.futures,datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
base='02529c6c2604edb1957eba14acca408fd06030f1'
labels=['deep-attempt-detach','eager-attempt','full-attempt-budget','uncached-fold','explicit-sequence-index']
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(path,*args):return subprocess.check_output(['git',*args],cwd=path,text=True).strip()
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def edit(path,before,after,count=1):
 s=path.read_text();assert s.count(before)==count,(path,before,s.count(before));path.write_text(s.replace(before,after,count))
def source(path):return {str(p.relative_to(path)):sha(p) for folder in ['src','tests'] for p in sorted((path/folder).rglob('*')) if p.is_file()}|{name:sha(path/name) for name in ['Cargo.toml','Cargo.lock']}
root.joinpath('ablations').mkdir();root.joinpath('worktrees').mkdir();root.joinpath('targets').mkdir()
for label in labels:
 d=root/'ablations'/label;d.mkdir();wt=root/'worktrees'/label
 with (d/'setup.stdout').open('w') as out,(d/'setup.stderr').open('w') as err:subprocess.run(['git','worktree','add','--detach',str(wt),base],cwd=repo,check=True,stdout=out,stderr=err)
 p=wt/'src/runtime_client/projection.rs'
 if label=='deep-attempt-detach':
  f=wt/'src/runtime_client/projection/shared_attempt.rs'
  edit(f,'#[derive(Debug, Clone, PartialEq, Serialize)]\npub(crate) struct SharedAttempt','#[derive(Debug, PartialEq, Serialize)]\npub(crate) struct SharedAttempt')
  edit(f,'impl From<RuntimeClientAttempt> for SharedAttempt {','impl Clone for SharedAttempt {\n    fn clone(&self) -> Self { self.owned().into() }\n}\nimpl From<RuntimeClientAttempt> for SharedAttempt {')
 elif label=='eager-attempt':
  edit(p,'        budget.value("settings_evidence", &source.settings_evidence);','        let attempt = attempt.map(attempt_view::AttemptView::into_owned);\n        budget.value("settings_evidence", &source.settings_evidence);')
  edit(p,'                    attempt: attempt.map(attempt_view::AttemptView::into_owned),','                    attempt,')
 elif label=='full-attempt-budget':
  edit(p,'''        budget.field(
            "attempt",
            attempt.as_ref().map_or(Some(4), |value| {
                value.fit.and_then(|budget| budget.checked_add(1))
            }),
        );''','''        budget.value("attempt", &attempt);''')
  edit(p,'            view.fit = view.measure(&prepared, foreground_budget);','            let _ = foreground_budget;\n            view.fit = None;')
  q=wt/'src/runtime_client/projection/prepared_attempt.rs'
  edit(q,'''fn output_budget(value: &impl serde::Serialize) -> Option<usize> {
    #[cfg(test)]
    BUDGET_WORK.with(|work| work.set(work.get() + 1));
    crate::runtime_client::preflight::required_safe_integer_budget(
        value,
        crate::runtime_client::checkpoint::CHECKPOINT_TARGET_BYTES,
    )
}''','''fn output_budget(_value: &impl serde::Serialize) -> Option<usize> { None }''')
 elif label=='uncached-fold':
  q=wt/'src/durable/sqlite/event_insert.rs';edit(q,'Some(&guard.statistics)','None');edit(q,'Some(&guard.execution)','None')
 elif label=='explicit-sequence-index':
  changes=json.loads(Path('/home/capi/.cache/rustx-pr485-incremental-attempt-20261102/index-changes-final.json').read_text())['occurrences']
  # Identical DDL literals may occur multiple times in one file; restore every
  # copy once, without turning an already-restored literal into another change.
  done=set()
  for r in changes:
   key=r['path'],r['after']
   if key in done:continue
   done.add(key);q=wt/r['path'];s=q.read_text();assert r['after'] in s,key;q.write_text(s.replace(r['after'],r['before']))
 subprocess.run(['cargo','fmt','--all'],cwd=wt,check=True,stdout=subprocess.DEVNULL)
 (d/'variant.patch').write_text(subprocess.check_output(['git','diff','--','src'],cwd=wt,text=True))
 subprocess.run(['git','add','src'],cwd=wt,check=True)
 subprocess.run(['git','commit','-m',f'Diagnostic ablation only: {label}'],cwd=wt,check=True,stdout=subprocess.DEVNULL)
 subprocess.run(['cp','-a','--reflink=auto','/home/capi/.cache/rustx-pr485-target',str(root/'targets'/label)],check=True)
 print('prepared',label,flush=True)

# Ordinary O3/default-feature builds, separate target/worktree for each variant.
# These are experimental counterfactuals, not promoted production revisions.
def build(label):
 wt=root/'worktrees'/label;d=root/'ablations'/label;target=root/'targets'/label
 env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2'}
 assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS') and not any(k.startswith('CARGO_PROFILE_') for k in env)
 record={'scope':'Diagnostic source ablation, not promoted production. Full previous candidate remains the production control.','label':label,'base':base,'head':git(wt,'rev-parse','HEAD'),'production_tree':git(wt,'rev-parse','HEAD:src'),'start_utc':now(),'source_files':source(wt),'patch_sha256':sha(d/'variant.patch'),'rustc':subprocess.check_output(['rustc','-vV'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True),'commands':[]}
 def save():(d/'identity.json').write_text(json.dumps(record,indent=2)+'\n')
 for name,cmd in [('clean',['cargo','clean','--release','--package','rustx']),('build',['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json'])]:
  row={'name':name,'argv':cmd,'start_utc':now(),'status':'running'};record['commands'].append(row);save()
  with (d/(name+'.stdout')).open('w') as out,(d/(name+'.stderr')).open('w') as err:r=subprocess.run(cmd,cwd=wt,env=env,stdout=out,stderr=err)
  row.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=now());save()
  if r.returncode:return label,r.returncode
 rows=[json.loads(l) for l in (d/'build.stdout').read_text().splitlines() if l.startswith('{')]
 artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['src_path'].startswith(str(wt))]
 assert artifacts and all(not r['fresh'] and r['features']==[] and r['profile']['opt_level']=='3' and not r['profile']['debug_assertions'] for r in artifacts)
 exe=next(Path(r['executable']) for r in artifacts if r['target']['name']=='conformance' and r.get('executable'));shutil.copy2(exe,d/'conformance')
 assert source(wt)==record['source_files'] and not git(wt,'status','--porcelain')
 record.update(binary=str(d/'conformance'),sha256=sha(d/'conformance'),verified=True,end_utc=now());save();return label,0
with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
 results=list(pool.map(build,labels))
(root/'ablation-build-results.json').write_text(json.dumps({'results':results,'completed_utc':now()},indent=2)+'\n');print(results,flush=True)
assert all(code==0 for _,code in results)
