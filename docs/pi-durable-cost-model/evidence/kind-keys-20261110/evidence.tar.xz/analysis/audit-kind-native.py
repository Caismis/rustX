from pathlib import Path
import json,sys,importlib,statistics,sqlite3,hashlib
r=Path(__file__).resolve().parent
sys.path.insert(0,str(Path.cwd()/'benchmarks/runtime'));m=importlib.import_module('summarize-http')
commands=json.loads((r/'kind-native-commands-v3.json').read_text());assert len(commands)==8
rows=[]
for c in commands:
 d=Path(c['command'][c['command'].index('--output')+1]);done=json.loads((d/'completed.json').read_text());assert done['accepted'] and done['requests']==1283
 a=json.loads((d/'active-4.json').read_text());n=sum(len(row['turns']) for row in a['rows']);assert n==256
 phases=json.loads((d/'phases.json').read_text());phase={p['phase']:p for p in phases}
 points=[p for row in a['rows'] if not row['held'] for p in row['turns']]
 host=json.loads((r/(d.name+'-host.json')).read_text())
 start=min(p['began_monotonic_ns'] for row in a['rows'] for p in row['turns']);end=phase['active_finished_4']['monotonic_ns']
 overlap=[p for p in host if start<=p['monotonic_ns']<=end and p['compiler_pids']]
 native=json.loads((d/'native-closed.json').read_text());assert len(native)==128
 for v in native:
  path=d/'native-snapshots'/f"{v['session_index']:04}.sqlite";assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==v['consistent_backup_sha256']
  conn=sqlite3.connect(f'file:{path}?mode=ro',uri=True);assert conn.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert conn.execute('PRAGMA foreign_key_check').fetchall()==[]
  messages=[json.loads(row[0]) for row in conn.execute('SELECT message_json FROM message_ledger ORDER BY position')];conn.close();assert len(messages)==v['messages']
  users=[v for v in messages if v['role']=='user'];assistants=[v for v in messages if v['role']=='assistant'];i=v['session_index'];expected=done['turn_counts'][str(i)]
  assert len(users)==expected and len(assistants)==expected-int(i==0)
  for t,user in enumerate(users):assert user['content']==[{'type':'text','text':f'capacity turn session={i:04} turn={t:04}'}]
  for t,msg in enumerate(assistants):assert msg['content']==[{'type':'text','text':('S'*32768 if i==127 and t==len(assistants)-1 else 'capacity response')}]
 row={k:c[k] for k in ['family','pair','side','sha256','observed_compiler_overlap']}
 row.update(directory=d.name,active_measured_turns=n,cpu_ms_per_turn=m.delta({'process':a['before']},{'process':a['after']},'cpu_ms')/n,write_kib_per_turn=m.delta({'process':a['before']},{'process':a['after']},'write_bytes')/1024/n,p50_ms=statistics.median(p['settled_us']/1000 for p in points),p95_ms=sorted(p['settled_us']/1000 for p in points)[int(.95*len(points))],retirement_checks=sum(p['retirement_checks'] for row in a['rows'] for p in row['turns']),active_compiler_samples=overlap)
 for name in ['empty_server','all_subscribed_empty','seeded_history_8','all_unloaded']:
  ctr=m.counters(phase[name]);row[name]={'anon_pss_mib':ctr['anon_pss_kib']/1024,'pss_mib':ctr['pss_kib']/1024}
 rows.append(row)
result={'scope':'Two balanced independent pairs each for fixed/rotating four concurrency. 128 named sessions x 8 seed turns, then 256 active turns. Only native server PID counters. CPU includes explicit native-idle retirement reads; per-turn settled time ends at terminal delivery. Compiler monitoring is sampled, not an exclusivity guarantee. Every native backup/hash, integrity/FK, message count and exact content is independently checked.','rows':rows,'paired':{}}
for family in ['fixed','rotating']:
 pair_results=[]
 for pair in [0,1]:
  a,b=[next(row for row in rows if row['family']==family and row['pair']==pair and row['side']==side) for side in ['before','after']]
  pair_results.append({k:(b[k]-a[k])/a[k]*100 for k in ['cpu_ms_per_turn','write_kib_per_turn','p50_ms','p95_ms']})
 result['paired'][family]={'values':pair_results,'medians':{k:statistics.median(v[k] for v in pair_results) for k in pair_results[0]}}
(r/'kind-native-audit.json').write_text(json.dumps(result,indent=2)+'\n')
for family,v in result['paired'].items():print(family,v)
for side in ['before','after']:
 print(side,{name:round(statistics.median(v[name]['anon_pss_mib'] for v in rows if v['side']==side),2) for name in ['all_subscribed_empty','seeded_history_8','all_unloaded']})
print('Compiler samples in active windows:',sum(len(v['active_compiler_samples']) for v in rows))
