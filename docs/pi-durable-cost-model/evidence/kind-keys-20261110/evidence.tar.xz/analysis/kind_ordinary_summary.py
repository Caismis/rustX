"""Revalidate paired ordinary runs and retain each per-product observation."""
import csv
from importlib import import_module
import json
import math
from pathlib import Path
import statistics
import sys

root=Path(sys.argv[1])
sys.path.insert(0,str(Path.cwd()/'benchmarks/runtime'))
from controller import validate_sample
summ=import_module('summarize-http')
def load(path): return json.loads(path.read_text())
dir=root/'kind-ordinary'
before,after=[load(root/name) for name in ('baseline-write-ledger.json','candidate-write-ledger.json')]
empty={'before':before[0]['empty_opened_conversation']['page_count']*2048,
       'after':after[0]['empty_opened_conversation']['page_count']*2048}
cases=('short-small','short-large','large','stream')
rows=[]
summary={}
def count_delta(samples,key,history):
    return samples[-1][key]-(samples[history-1][key] if history else 0)
for case in cases:
    for rep in range(4):
        cmp=load(dir/f'{rep}-{case}-comparison.json')
        assert all(check['coreSemanticEqual'] and check['fullSemanticRequestEqual'] for check in cmp['checked'])
        for side in ('before','after'):
            stem=dir/f'{rep}-{case}-{side}'
            path=stem.with_suffix('.json')
            raw=load(path)
            validate_sample(load(stem.with_suffix('.process.json')),raw,case,stem.with_suffix('.log').read_text())
            stage=summ.validate_lifecycle(raw)
            points=raw['samples']
            warm=[s for s in points if s['measured']]
            history,n=raw['history'],len(warm)
            window=summ.sample(path)
            latency=sorted(p['settled_us']/1000 for p in warm)
            first=[p['first_consumed_publication_us']/1000 for p in warm if p['first_consumed_publication_us'] is not None]
            data=raw['late_snapshot']['checkpoint']['read_cut']['source_cut']['read']
            closed=sum(f['logical'] for f in raw['checkpoint_footprint'] if f['path'].endswith('/conversation.sqlite'))
            assert closed>=empty[side]
            rows.append({'case':case,'rep':rep,'side':side,'history':history,'measured':n,
                         'p50_ms':statistics.median(latency),'p95_ms':latency[math.ceil(.95*n)-1],
                         'first_consumed_ms':statistics.median(first) if first else None,'first_consumed_count':len(first),
                         'cpu_ms_per_turn':window['turn_cpu_ms_per_turn'],
                         'process_write_kib_per_turn':window['turn_write_mib_per_turn']*1024,
                         'process_write_mib_through_close':summ.delta(stage['before_initialization'],stage['after_final_writer_close'],'write_bytes')/2**20,
                         'max_sampled_hot_pss_mib':max(summ.counters(p)['pss_kib'] for p in warm)/1024,
                         'main_file_kib_above_empty':(closed-empty[side])/1024,
                         'hot_notification_records':count_delta(points,'notification_records',history),
                         'final_journal_through':data['journal'],'canonical_records_total':len(raw['canonical']),
                         'requests_total':raw['requests']})
    groups={}
    for side in ('before','after'):
        rs=[r for r in rows if r['side']==side and r['case']==case]
        groups[side]={k:{'median':statistics.median(vs),'range':[min(vs),max(vs)]}
                      for k in rs[0] if k not in ('side','rep','case')
                      if (vs:=[r[k] for r in rs if r[k] is not None])}
    keys=('p50_ms','p95_ms','first_consumed_ms','cpu_ms_per_turn','process_write_kib_per_turn',
          'process_write_mib_through_close','max_sampled_hot_pss_mib','main_file_kib_above_empty')
    paired={}
    for key in keys:
        vs=[]
        for rep in range(4):
            a,b=[next(r[key] for r in rows if r['rep']==rep and r['case']==case and r['side']==s) for s in ('before','after')]
            if a and b is not None:
                vs.append((b-a)/a*100)
        if vs:
            paired[key]={'values':vs,'median':statistics.median(vs)}
    groups['paired_percent_changes']=paired
    summary[case]=groups
assert len(rows)==32
(root/'kind-ordinary-summary.json').write_text(json.dumps({'summary':summary,'samples':rows},indent=2)+'\n')
with (root/'kind-ordinary-per-run.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
for case,g in summary.items():
    print(case)
    for key in ('p50_ms','p95_ms','first_consumed_ms','cpu_ms_per_turn','process_write_kib_per_turn','process_write_mib_through_close','max_sampled_hot_pss_mib','main_file_kib_above_empty'):
        if key not in g['paired_percent_changes']:continue
        print(key,*(round(g[s][key]['median'],3) for s in ('before','after')),round(g['paired_percent_changes'][key]['median'],2),
              [round(n,2) for n in g['paired_percent_changes'][key]['values']])
