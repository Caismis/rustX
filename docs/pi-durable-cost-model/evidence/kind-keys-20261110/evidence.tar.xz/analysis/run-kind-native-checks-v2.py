from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time
r=Path(__file__).resolve().parent
w=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
bins={'before':r/'baseline-build/rustx','after':r/'kind-build/rustx'}
commands=[]
waits=[]
for family in ['fixed','rotating']:
 for pair in range(2):
  for side in (['before','after'] if pair%2==0 else ['after','before']):
   name=f'kind-native-v2-{family}-{pair}-{side}';out=r/name
   cmd=[sys.executable,str(w/'benchmarks/runtime/app-server-capacity.py'),'--binary',str(bins[side]),'--output',str(out),'--sessions','128','--history','8','--widths','4','--rounds','64']
   if family=='rotating':cmd+=['--rotate-active']
   row={'family':family,'pair':pair,'side':side,'command':cmd,'sha256':hashlib.file_digest(bins[side].open('rb'),'sha256').hexdigest(),'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
   deadline=time.monotonic()+600
   while True:
    running=subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True)
    if running.returncode!=0: break
    waits.append({'time':datetime.datetime.now(datetime.timezone.utc).isoformat(),'live_compiler_pids':running.stdout.split(),'next_product':name})
    (r/'kind-native-verified-waits.json').write_text(json.dumps(waits,indent=2)+'\n')
    assert time.monotonic()<deadline
    time.sleep(2)
   host=[]
   with (r/(name+'.log')).open('x') as log:
    product=subprocess.Popen(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
    while product.poll() is None:
     host.append({'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'compiler_pids':subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True).stdout.split()})
     time.sleep(.5)
   (r/(name+'-host.json')).write_text(json.dumps(host,indent=2)+'\n')
   res=product

   row.update(observed_compiler_overlap=any(h['compiler_pids'] for h in host),exit=res.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat());commands.append(row)
   (r/'kind-native-commands-v2.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,res.returncode,flush=True)
   assert res.returncode==0 and json.loads((out/'completed.json').read_text())['accepted']
