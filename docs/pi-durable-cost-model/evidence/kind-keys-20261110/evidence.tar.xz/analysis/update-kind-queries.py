from pathlib import Path
import re,json
codes={'inbound_turn_adopted':1,'attempt_started':2,'turn_started':3,'model_request_started':4,'model_request_completed':5,'assistant_message_committed':6,'turn_completed':7,'attempt_completed':8}
files=['reading.rs','observation.rs','observation_turn.rs','observation_trace/event.rs','observation_trace/request.rs','projection/tests.rs','observation/tests/trace.rs','reading/tests.rs']
root=Path('src/durable/sqlite')
token=re.compile(r'"(?:\\.|[^"\\])*"',re.S)
kind=re.compile(r"(json_extract\((?:e\.)?event_json,\s*'\$\.event\.type'\)|observation_kind)\s*=\s*('(?:[^']|'')*'|\?\d+)")
for name in files:
 p=root/name;s=p.read_text();count=[0]
 def change(m):
  raw=m[0][1:-1]
  if 'INDEXED BY events_kind_idx' not in raw and 'INDEXED BY events_primary_trace_kind_idx' not in raw:return m[0]
  assert '\\' not in raw,(name,raw)
  parts=[];at=0
  for k in kind.finditer(raw):
   indexes=re.findall(r'INDEXED BY (\w+)',raw[:k.start()])
   if not indexes or indexes[-1] not in ['events_kind_idx','events_primary_trace_kind_idx']:continue
   parts.append(json.dumps(raw[at:k.start()]))
   column=k[1]
   parts.append('crate::durable::sqlite::event_kind_key::sql!('+json.dumps(column)+')')
   value=k[2]
   if value.startswith("'") and value[1:-1] in codes:value="x'00%02x'"%codes[value[1:-1]]
   parts.append(json.dumps('='+value));at=k.end();count[0]+=1
  if not at:return m[0]
  parts.append(json.dumps(raw[at:]));return 'concat!('+','.join(parts)+')'
 s=token.sub(change,s);p.write_text(s);print(name,count[0])
# Bind the global point lookup with the same typed key as its expression index.
p=root/'observation.rs';s=p.read_text();needle='''FROM events INDEXED BY events_kind_idx''';a=s.index(needle,s.index('fn latest_') if 'fn latest_' in s else 0);a=s.index('rusqlite::types::Value::Text(kind.into())',a);s=s[:a]+s[a:].replace('rusqlite::types::Value::Text(kind.into())','super::event_kind_key::parameter(kind)',1);p.write_text(s)
