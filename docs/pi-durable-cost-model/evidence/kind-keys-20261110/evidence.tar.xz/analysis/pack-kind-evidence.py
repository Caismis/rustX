from pathlib import Path
import hashlib,json,tarfile,subprocess
r=Path(__file__).resolve().parent;w=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');out=w/'docs/pi-durable-cost-model/evidence/kind-keys-20261110';files={}
def add(path,name):
 path=Path(path)
 if path.is_file():
  assert name not in files,name
  files[name]=path
for name in ['baseline-build','kind-build']:
 for path in (r/name).iterdir():
  if path.suffix in ['.json','.stdout','.stderr']:add(path,'builds/'+name+'/'+path.name)
for name in ['kind-ordinary','kind-functional']:
 for path in (r/name).iterdir():
  if path.is_file():add(path,'raw/'+name+'/'+path.name)
for name in ['kind-traced','kind-fresh-baseline-traced']:
 for path in (r/name).rglob('*'):
  if path.is_file() and not any(v.startswith('.tmp') for v in path.relative_to(r/name).parts):add(path,'physical/'+name+'/'+str(path.relative_to(r/name)))
products=[Path(c['command'][c['command'].index('--output')+1]) for c in json.loads((r/'kind-native-commands-v3.json').read_text())]
products += [r/n for n in ['capacity-v76-memory-1','capacity-v76-memory-128','kind-capacity-memory-128','capacity-v76-smoke-1','capacity-v76-smoke-2','capacity-v76-smoke-3','capacity-v76-retirement-smoke','kind-native-v2-fixed-0-before']]
for root in products:
 for path in root.glob('*'):
  if path.is_file() and path.name!='token':add(path,'capacity/'+root.name+'/'+path.name)
 for path in (root/'native-snapshots').glob('*.sqlite'):add(path,'capacity/'+root.name+'/native-snapshots/'+path.name)
for path in (r/'capacity-v76-heap-128').glob('*'):
 if path.is_file() and path.name!='token':add(path,'heap/'+path.name)
for path in r.glob('*'):
 if path.is_file() and (path.suffix in ['.json','.py','.patch'] or path.suffix=='.log'):
  if path.name.startswith(('prototype-', 'kind-pack')) or path.name in ['baseline-identity.json']:continue
  add(path,'analysis/'+path.name)
for name in ['app-server-capacity.py','app-server-capacity-provider.py','controller.py','summarize-http.py','compare-revisions.py','build-revision.py']:
 path=w/'benchmarks/runtime'/name;add(path,'frozen-inputs/'+name)
old=r/'capacity-before-retirement.py';old.write_bytes(subprocess.check_output(['git','show','2ce90ee46:benchmarks/runtime/app-server-capacity.py'],cwd=w));add(old,'frozen-inputs/capacity-before-retirement.py')
for name in ['trace_products.py','replay_wal.py','ledger_summary.py']:
 add(Path('/home/capi/.cache/rustx-pr485-canonical-coordinates-20261109')/name,'helpers/'+name)
add('/home/capi/.cache/rustx-pr485-memory-writes-20261103/heap-sample.cc','helpers/heap-sample.cc')
manifest={'scope':'Included raw records, SQL images and checks retain their native units. Excludes executables, dependencies, mutable runtime/workspaces and token files. Helper command paths are historical identities; this is not a portable product runner.','members':{}}
for name,path in sorted(files.items()):manifest['members'][name]={'bytes':path.stat().st_size,'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest()}
print('Selected',len(files),'files',round(sum(v['bytes'] for v in manifest['members'].values())/1048576,2),'MiB',flush=True)
archive=out/'evidence.tar.xz'
with archive.open('wb') as output:
 compressor=subprocess.Popen(['xz','-T8','-6','-c'],stdin=subprocess.PIPE,stdout=output)
 with tarfile.open(fileobj=compressor.stdin,mode='w|') as tar:
  for name,path in sorted(files.items()):tar.add(path,arcname=name,recursive=False)
 compressor.stdin.close()
 assert compressor.wait()==0
manifest['archive']={'bytes':archive.stat().st_size,'sha256':hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()}
with tarfile.open(archive,'r:xz') as tar:
 names=set()
 for member in tar:
  assert member.isfile() and member.name in manifest['members'];names.add(member.name);expected=manifest['members'][member.name]
  assert member.size==expected['bytes'] and hashlib.file_digest(tar.extractfile(member),'sha256').hexdigest()==expected['sha256']
 assert names==set(manifest['members'])
manifest['all_members_verified_after_pack']=True
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Verified archive',round(archive.stat().st_size/1048576,2),'MiB',flush=True)
