from pathlib import Path
import subprocess,sys,json,hashlib,datetime
r=Path(__file__).resolve().parent
w=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
bins={'before':r/'baseline-build/rustx','after':r/'kind-build/rustx'}
commands=[]
for family in ['fixed','rotating']:
 for pair in range(2):
  for side in (['before','after'] if pair%2==0 else ['after','before']):
   name=f'kind-native-{family}-{pair}-{side}';out=r/name
   cmd=[sys.executable,str(w/'benchmarks/runtime/app-server-capacity.py'),'--binary',str(bins[side]),'--output',str(out),'--sessions','128','--history','8','--widths','4','--rounds','64']
   if family=='rotating':cmd+=['--rotate-active']
   row={'family':family,'pair':pair,'side':side,'command':cmd,'sha256':hashlib.file_digest(bins[side].open('rb'),'sha256').hexdigest(),'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
   with (r/(name+'.log')).open('x') as log:res=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
   row.update(exit=res.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat());commands.append(row)
   (r/'kind-native-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(name,res.returncode,flush=True)
   assert res.returncode==0 and json.loads((out/'completed.json').read_text())['accepted']
