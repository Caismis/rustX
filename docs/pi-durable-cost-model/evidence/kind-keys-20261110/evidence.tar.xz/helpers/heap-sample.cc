#include "malloc_extension.h"
#include <atomic>
#include <csignal>
#include <cstdlib>
#include <fstream>
#include <string>
#include <unistd.h>
#include <pthread.h>
static int wakeup[2];
static void trigger(int) { const char value=1; const auto unused=write(wakeup[1],&value,1); (void)unused; }
static void *worker(void*) {
  unsigned counter=0; char value;
  while(read(wakeup[0],&value,1)==1) {
    auto *extension=MallocExtension::instance();
    std::string profile; extension->GetHeapSample(&profile);
    const std::string prefix=std::string(std::getenv("RUSTX_SAMPLE_PREFIX"))+"-"+std::to_string(++counter);
    {std::ofstream file(prefix+".heap"); file<<profile;}
    std::string().swap(profile);
    char stats[32768]; extension->GetStats(stats,sizeof(stats));
    {std::ofstream file(prefix+".stats"); file<<stats;}
    size_t allocated=0,heap=0,page_free=0,page_unmapped=0,thread_free=0,central_free=0;
    extension->GetNumericProperty("generic.current_allocated_bytes",&allocated);
    extension->GetNumericProperty("generic.heap_size",&heap);
    extension->GetNumericProperty("tcmalloc.pageheap_free_bytes",&page_free);
    extension->GetNumericProperty("tcmalloc.pageheap_unmapped_bytes",&page_unmapped);
    extension->GetNumericProperty("tcmalloc.current_total_thread_cache_bytes",&thread_free);
    extension->GetNumericProperty("tcmalloc.central_cache_free_bytes",&central_free);
    {std::ofstream file(prefix+".json"); file<<"{\"allocated\":"<<allocated<<",\"heap\":"<<heap<<",\"page_free\":"<<page_free<<",\"page_unmapped\":"<<page_unmapped<<",\"thread_free\":"<<thread_free<<",\"central_free\":"<<central_free<<"}\n";}
  }
  return nullptr;
}
__attribute__((constructor)) static void setup() {
  if(!std::getenv("RUSTX_SAMPLE_PREFIX"))return;
  if(pipe(wakeup)!=0)_exit(90);
  struct sigaction action{};action.sa_handler=trigger;sigemptyset(&action.sa_mask);if(sigaction(SIGUSR2,&action,nullptr)!=0)_exit(91);
  pthread_t thread;if(pthread_create(&thread,nullptr,worker,nullptr)!=0)_exit(92);pthread_detach(thread);
}
