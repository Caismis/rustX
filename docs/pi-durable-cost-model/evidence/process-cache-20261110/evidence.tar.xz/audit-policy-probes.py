"""Report structural policy calibration; never treat these as headline timing."""
from pathlib import Path
import importlib
import json
import statistics
import sys

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0, str(repo / 'benchmarks/runtime'))
metrics = importlib.import_module('summarize-http')

def io(point):
    return {key: int(value) for line in point['io'].splitlines() for key, value in [line.split(':', 1)]}

rows = []
failures = []
for command in json.loads((root / 'probe-commands.json').read_text()):
    if command['exit'] != 0:
        failures.append(command)
        continue
    directory = Path(command['command'][command['command'].index('--output') + 1])
    assert command['exit'] == 0 and json.loads((directory / 'completed.json').read_text())['accepted']
    phases = {point['phase']: point for point in json.loads((directory / 'phases.json').read_text())}
    bindings = [json.loads(path.read_text()) for path in sorted(directory.glob('sample-*-binding.json'))]
    assert all(point['stats']['sqlite_soft_heap_limit'] == command['soft_limit_mib'] * 2**20 for point in bindings)
    assert all(point['stats']['sqlite_hard_heap_limit'] == 0 for point in bindings)
    active = json.loads((directory / 'active-4.json').read_text())
    count = sum(len(row['turns']) for row in active['rows'])
    assert count == 256
    times = [point['settled_us'] / 1000 for row in active['rows'] if not row['held'] for point in row['turns']]
    a, b = map(io, [active['before'], active['after']])
    start = min(point['began_monotonic_ns'] for row in active['rows'] for point in row['turns'])
    end = phases['active_finished_4']['monotonic_ns']
    host = json.loads((root / (directory.name + '-host.json')).read_text())
    row = {key: command[key] for key in ['sessions', 'history', 'soft_limit_mib']}
    row.update(directory=directory.name, phase_stats={point['phase']: point['stats'] for point in bindings},
               anon_pss_mib={name: metrics.counters(point)['anon_pss_kib'] / 1024 for name, point in phases.items()
                             if name == 'all_subscribed_empty' or name.startswith('seeded_history_')},
               diagnostic_cpu_ms_per_turn=metrics.delta({'process': active['before']}, {'process': active['after']}, 'cpu_ms') / count,
               diagnostic_p50_ms=statistics.median(times),
               write_kib_per_turn=(b['write_bytes'] - a['write_bytes']) / 1024 / count,
               rchar_kib_per_turn=(b['rchar'] - a['rchar']) / 1024 / count,
               read_bytes_kib_per_turn=(b['read_bytes'] - a['read_bytes']) / 1024 / count,
               read_calls_per_turn=(b['syscr'] - a['syscr']) / count,
               active_compiler_samples=[point for point in host if start <= point['monotonic_ns'] <= end and point['compiler_pids']])
    rows.append(row)
(root / 'probe-summary.json').write_text(json.dumps({'scope': 'One diagnostic GNU-allocator product per workload/policy. Same verified baseline ELF, startup-only soft-limit injection, phase counter reads and unchanged hard limit. Source fixture exact-content and reopen checks passed. Unbalanced one-per-cell diagnostics are not headline timing or statistical claims. Original 256-session product hit inherited 1024 soft NOFILE limit; v2 wrappers set 4096 for all 256-session policies, without changing the host limit.', 'rows': rows, 'failed_products': failures}, indent=2) + '\n')
for row in rows:
    final = 'seeded_history_' + str(row['history'])
    print(row['directory'], 'PSS', round(row['anon_pss_mib'][final], 2),
          'SQLite', round(row['phase_stats'][final]['sqlite_memory_used'] / 2**20, 2),
          'CPU', round(row['diagnostic_cpu_ms_per_turn'], 2),
          'rcharKiB', round(row['rchar_kib_per_turn'], 2),
          'reads', round(row['read_calls_per_turn'], 2),
          'writesKiB', round(row['write_kib_per_turn'], 2),
          'compilerSamples', len(row['active_compiler_samples']))
