#!/bin/sh
ulimit -n 4096
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-process-cache-20261110/sqlite-probe.so
export RUSTX_SAMPLE_PREFIX=/home/capi/.cache/rustx-pr485-process-cache-20261110/probe-v2-256-008-000/native-sample
export RUSTX_SQLITE_SET_SOFT_BYTES=0
export RUSTX_SQLITE_HARD_OFFSET=00000000078a6130
export RUSTX_SQLITE_MEMORY_OFFSET=00000000078bd470
export RUSTX_SQLITE_SOFT_OFFSET=00000000078ff530
exec /home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/rustx "$@"
