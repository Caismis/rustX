"""Calibrate SQLite's existing global policy, without rebuilding reference code.

These are diagnostic products, not headline timings. The same GNU-allocated
baseline CLI receives only a startup soft-limit setting and phase counter reads.
"""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
binary = Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/rustx')
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == '5c27b2671920f687ed520243e285b38fb3f7a15807ddc006905d59ced8f0b699'
assert 'DYN' in subprocess.check_output(['readelf', '-h', str(binary)], text=True)
names = {'sqlite3_memory_used': 'RUSTX_SQLITE_MEMORY_OFFSET',
         'sqlite3_soft_heap_limit64': 'RUSTX_SQLITE_SOFT_OFFSET',
         'sqlite3_hard_heap_limit64': 'RUSTX_SQLITE_HARD_OFFSET'}
symbols = {names[parts[2]]: parts[0] for line in subprocess.check_output(['nm', '-n', str(binary)], text=True).splitlines()
           if len(parts := line.split()) == 3 and parts[2] in names}
assert len(symbols) == 3
source = (repo / 'benchmarks/runtime/app-server-capacity.py').read_text()
source = source.replace('REPO = Path(__file__).resolve().parents[2]', f'REPO = Path({str(repo)!r})')
source = source.replace('str(path.relative_to(REPO))', 'str(path.resolve())')
source = source.replace("Path(__file__).with_name('app-server-capacity-provider.py')", "REPO / 'benchmarks/runtime/app-server-capacity-provider.py'")
source = source.replace('    process = None\n', '    process = None\n    probe_sequence = 0\n', 1)
needle = "            write(out / 'phases.json', phases)\n"
assert source.count(needle) == 1
source = source.replace(needle, needle + '''            nonlocal probe_sequence
            if name in ['empty_server', 'all_subscribed_empty', 'active_finished_4', 'all_unloaded'] or name.startswith('seeded_history_'):
                probe_sequence += 1
                process.send_signal(signal.SIGUSR2)
                deadline = time.monotonic() + 30
                while True:
                    try:
                        stats = json.loads((out / f'native-sample-{probe_sequence}.json').read_text())
                        break
                    except (OSError, json.JSONDecodeError):
                        assert time.monotonic() < deadline
                        await asyncio.sleep(0.01)
                write(out / f'sample-{probe_sequence}-binding.json', {'phase': name, 'pid': process.pid, 'stats': stats})
''')
fixture = root / 'probe-capacity.py'
fixture.write_text(source)
library = root / 'sqlite-probe.so'
identity = {'scope': __doc__, 'binary': str(binary), 'binary_sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
            'library_sha256': hashlib.file_digest(library.open('rb'), 'sha256').hexdigest(), 'elf_symbol_offsets': symbols,
            'fixture_sha256': hashlib.sha256(source.encode()).hexdigest(), 'policy_mib': [0, 192, 256],
            'workloads': [[128, 32], [256, 8]], 'ordinary_allocator': 'unchanged GNU allocator'}
(root / 'probe-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
rows = json.loads((root / 'probe-commands.json').read_text())
for sessions, history in [(256, 8)]:
    for limit in [0, 192, 256]:
        name = f'probe-v2-{sessions:03}-{history:03}-{limit:03}'
        output = root / name
        wrapper = root / (name + '.sh')
        wrapper.write_text('#!/bin/sh\nulimit -n 4096\nexport LD_PRELOAD=' + str(library)
                           + '\nexport RUSTX_SAMPLE_PREFIX=' + str(output / 'native-sample')
                           + '\nexport RUSTX_SQLITE_SET_SOFT_BYTES=' + str(limit * 2**20)
                           + ''.join('\nexport ' + key + '=' + value for key, value in symbols.items())
                           + '\nexec ' + str(binary) + ' "$@"\n')
        wrapper.chmod(0o755)
        command = [sys.executable, str(fixture), '--binary', str(wrapper), '--output', str(output),
                   '--sessions', str(sessions), '--history', str(history), '--widths', '4', '--rounds', '64', '--rotate-active']
        if history == 32:
            command += ['--history-checkpoints', '8', '16']
        host = []
        deadline = time.monotonic() + 900
        while subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True).returncode == 0:
            assert time.monotonic() < deadline
            time.sleep(2)
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        with (root / (name + '.log')).open('x') as log:
            child = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
            while child.poll() is None:
                host.append({'monotonic_ns': time.monotonic_ns(), 'loadavg': Path('/proc/loadavg').read_text(),
                             'compiler_pids': subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True, text=True).stdout.split()})
                time.sleep(.5)
        (root / (name + '-host.json')).write_text(json.dumps(host, indent=2) + '\n')
        rows.append({'sessions': sessions, 'history': history, 'soft_limit_mib': limit, 'command': command,
                     'native_soft_nofile': 4096, 'start': started, 'exit': child.returncode, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat()})
        (root / 'probe-commands.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(name, child.returncode, flush=True)
        assert child.returncode == 0 and json.loads((output / 'completed.json').read_text())['accepted']
