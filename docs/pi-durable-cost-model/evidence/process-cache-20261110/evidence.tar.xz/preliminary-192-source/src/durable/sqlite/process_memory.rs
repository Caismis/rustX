//! The standalone App Server shares a soft SQLite working-memory budget.
//! Connection-local plans, proof owners and the existing idle policy are unchanged.
use super::{ConversationStoreError, storage};

// The measured 128-session working set contains about 126 MiB of schema,
// compiled statements and lookaside before reclaimable pages. Leave the active
// connections room while SQLite retires unused pages from the aggregate LRU.
const SQLITE_SOFT_HEAP_BYTES: i64 = 192 * 1024 * 1024;

pub(crate) fn configure_process_memory_budget() -> Result<(), ConversationStoreError> {
    #[allow(unsafe_code)]
    // SAFETY: SQLite documents this process-wide API as internally synchronized.
    // It takes no pointers, initializes SQLite if necessary, and only asks its
    // existing cache to release nonessential memory. It does not set a hard
    // allocation limit or change connections, transactions, facts or sync policy.
    let previous = unsafe { rusqlite::ffi::sqlite3_soft_heap_limit64(SQLITE_SOFT_HEAP_BYTES) };
    if previous < 0 {
        return Err(storage("cannot initialize SQLite process memory budget"));
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::durable::sqlite::{SqliteConversationStore, test_support::user_message};
    use crate::durable::store::canonical::CanonicalStore;
    use crate::durable::store::observation::ObservationStore;
    use crate::runtime::identity::ConversationId;
    use std::sync::Arc;

    #[allow(unsafe_code)]
    fn page_bytes(connection: &rusqlite::Connection) -> i32 {
        let (mut used, mut peak) = (0, 0);
        // Test owns this connection for the entire SQLite status read.
        unsafe {
            assert_eq!(
                rusqlite::ffi::sqlite3_db_status(
                    connection.handle(),
                    rusqlite::ffi::SQLITE_DBSTATUS_CACHE_USED,
                    &raw mut used,
                    &raw mut peak,
                    0,
                ),
                rusqlite::ffi::SQLITE_OK
            );
        }
        used
    }

    #[test]
    #[allow(clippy::too_many_lines)] // One isolated pressure, proof, corruption and rollback sequence.
    fn aggregate_budget_reclaims_clean_pages_and_preserves_native_proofs() {
        const CHILD: &str = "RUSTX_PROCESS_MEMORY_TEST_CHILD";
        if std::env::var_os(CHILD).is_none() {
            // Process-global SQLite policy must never affect parallel tests.
            let result = std::process::Command::new(std::env::current_exe().unwrap())
                .args([
                    "--exact",
                    "durable::sqlite::process_memory::tests::aggregate_budget_reclaims_clean_pages_and_preserves_native_proofs",
                    "--nocapture",
                ])
                .env(CHILD, "1")
                .output()
                .unwrap();
            assert!(
                result.status.success(),
                "{}\n{}",
                String::from_utf8_lossy(&result.stdout),
                String::from_utf8_lossy(&result.stderr)
            );
            return;
        }
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("conversation.sqlite");
        let store = SqliteConversationStore::open(ConversationId::generate(), &path).unwrap();
        let control = rusqlite::Connection::open(&path).unwrap();
        let limit = |name| {
            control
                .pragma_query_value(None, name, |row| row.get::<_, i64>(0))
                .unwrap()
        };
        assert_eq!(
            limit("soft_heap_limit"),
            0,
            "opening a store is not process policy"
        );
        let hard = limit("hard_heap_limit");
        configure_process_memory_budget().unwrap();
        assert_eq!(limit("soft_heap_limit"), SQLITE_SOFT_HEAP_BYTES);
        assert_eq!(limit("hard_heap_limit"), hard);
        assert_eq!(
            control
                .query_row(
                    "SELECT sqlite_compileoption_used('ENABLE_MEMORY_MANAGEMENT')",
                    [],
                    |row| row.get::<_, i64>(0)
                )
                .unwrap(),
            1
        );

        store
            .initialize(&[user_message("budget-native", "exact original 水")])
            .unwrap();
        let cut = store.observation_read_cut().unwrap();
        let before = store
            .observation_checkpoint_head(&cut, cut.read.journal, 32)
            .unwrap();
        let original = serde_json::to_vec(&before.transcript).unwrap();
        let manifest = Arc::clone(&store.conn.manifest);
        let response = Arc::clone(&store.conn.response);
        store.lock().unwrap().execute_batch("CREATE TEMP TABLE preserved_native_fact(id INTEGER PRIMARY KEY, value TEXT); INSERT INTO preserved_native_fact VALUES(1,'retained proof')").unwrap();

        let peers = (0..2).map(|index| {
            let connection = rusqlite::Connection::open(root.path().join(format!("peer-{index}.sqlite"))).unwrap();
            connection.execute_batch("PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL; PRAGMA cache_size=-4096; CREATE TABLE payload(id INTEGER PRIMARY KEY, bytes BLOB); INSERT INTO payload VALUES(1,zeroblob(2097152));").unwrap();
            connection.query_row("SELECT sum(length(bytes)) FROM payload", [], |row| row.get::<_, i64>(0)).unwrap();
            connection
        }).collect::<Vec<_>>();
        let cached_before: i32 = peers.iter().map(page_bytes).sum();
        #[allow(unsafe_code)]
        // Force pressure in this child only; the production budget remains fixed.
        unsafe {
            rusqlite::ffi::sqlite3_soft_heap_limit64(1024 * 1024)
        };
        let cached_after: i32 = peers.iter().map(page_bytes).sum();
        assert!(
            cached_after < cached_before / 2,
            "{cached_before} -> {cached_after}"
        );
        peers[0]
            .execute_batch(
                "BEGIN IMMEDIATE; INSERT INTO payload VALUES(2,zeroblob(4194304)); ROLLBACK;",
            )
            .unwrap();
        assert_eq!(
            peers[0]
                .query_row("SELECT count(*) FROM payload", [], |row| row
                    .get::<_, i64>(0))
                .unwrap(),
            1
        );
        assert_eq!(
            store
                .lock()
                .unwrap()
                .query_row(
                    "SELECT value FROM preserved_native_fact WHERE id=1",
                    [],
                    |row| row.get::<_, String>(0)
                )
                .unwrap(),
            "retained proof"
        );
        assert!(Arc::ptr_eq(&manifest, &store.conn.manifest));
        assert!(Arc::ptr_eq(&response, &store.conn.response));
        let current = store
            .observation_checkpoint_head(&cut, cut.read.journal, 32)
            .unwrap();
        assert_eq!(serde_json::to_vec(&current.transcript).unwrap(), original);

        let header: Vec<u8> = control
            .query_row(
                "SELECT header_json FROM observation_headers LIMIT 1",
                [],
                |row| row.get(0),
            )
            .unwrap();
        control
            .execute("UPDATE observation_headers SET header_json=x'7b'", [])
            .unwrap();
        assert!(
            store
                .observation_checkpoint_head(&cut, cut.read.journal, 32)
                .is_err()
        );
        control
            .execute("UPDATE observation_headers SET header_json=?1", [&header])
            .unwrap();
        assert_eq!(
            serde_json::to_vec(
                &store
                    .observation_checkpoint_head(&cut, cut.read.journal, 32)
                    .unwrap()
                    .transcript
            )
            .unwrap(),
            original
        );
        assert_eq!(
            limit("hard_heap_limit"),
            hard,
            "soft pressure never introduces an allocation failure policy"
        );
    }
}
