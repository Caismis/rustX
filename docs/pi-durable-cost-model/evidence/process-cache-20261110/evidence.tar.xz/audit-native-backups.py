"""Independently authenticate every accepted soft-budget product's native backups."""
from pathlib import Path
import hashlib
import json
import sqlite3

root = Path(__file__).resolve().parent
rows = []
for product in json.loads((root / 'probe-commands.json').read_text()):
    if product['exit']:
        continue
    directory = Path(product['command'][product['command'].index('--output') + 1])
    completed = json.loads((directory / 'completed.json').read_text())
    assert completed['accepted']
    backups = json.loads((directory / 'native-closed.json').read_text())
    assert len(backups) == product['sessions']
    for backup in backups:
        index = backup['session_index']
        path = directory / 'native-snapshots' / f'{index:04}.sqlite'
        assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == backup['consistent_backup_sha256']
        with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as connection:
            assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
            assert connection.execute('PRAGMA foreign_key_check').fetchall() == []
            assert connection.execute('SELECT schema_version FROM rustx_store').fetchone()[0] == 105
            messages = [json.loads(value) for value, in connection.execute('SELECT message_json FROM message_ledger ORDER BY position')]
        assert len(messages) == backup['messages']
        users = [message for message in messages if message['role'] == 'user']
        answers = [message for message in messages if message['role'] == 'assistant']
        expected = completed['turn_counts'][str(index)]
        assert len(users) == expected and len(answers) == expected - int(index == 0)
        for turn, user in enumerate(users):
            assert user['content'] == [{'type': 'text', 'text': f'capacity turn session={index:04} turn={turn:04}'}]
        for turn, answer in enumerate(answers):
            text = 'S' * 32768 if index == product['sessions'] - 1 and turn == len(answers) - 1 else 'capacity response'
            assert answer['content'] == [{'type': 'text', 'text': text}]
    rows.append({'directory': directory.name, 'backups': len(backups), 'provider_requests': completed['requests']})
report = {'scope': 'Accepted diagnostic products only. Every consistent native backup hash, SQLite integrity/FK, schema, exact canonical body, order, counts and cancelled-request absence are independently checked. The NOFILE failure remains excluded.', 'products': rows, 'backup_count': sum(row['backups'] for row in rows), 'request_count': sum(row['provider_requests'] for row in rows)}
(root / 'native-backup-audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
