// Diagnostic only. GNU allocator stays unchanged; policy is selected before
// the old reference executable opens stores. The final candidate is measured
// separately without this preload and without a runtime policy switch.
#include <atomic>
#include <csignal>
#include <cstdlib>
#include <fstream>
#include <string>
#include <unistd.h>
#include <pthread.h>
#include "sqlite-status.h"

static int wakeup[2];
static void trigger(int) {
  const char value = 1;
  const auto unused = write(wakeup[1], &value, 1);
  (void)unused;
}
static void* worker(void*) {
  unsigned index = 0;
  char value;
  while (read(wakeup[0], &value, 1) == 1) {
    const auto fields = sqlite_fields();
    std::ofstream output(std::string(std::getenv("RUSTX_SAMPLE_PREFIX")) + "-" + std::to_string(++index) + ".json");
    output << "{\"diagnostic\":true" << fields << "}\n";
  }
  return nullptr;
}
__attribute__((constructor)) static void setup() {
  if (!std::getenv("RUSTX_SAMPLE_PREFIX")) return;
  MainExecutable main;
  if (!dl_iterate_phdr(main_executable, &main) || !main.headers) _exit(96);
  using SetLimit = long long (*)(long long);
  const auto soft = reinterpret_cast<SetLimit>(sqlite_address(main, "RUSTX_SQLITE_SOFT_OFFSET"));
  const char* limit = std::getenv("RUSTX_SQLITE_SET_SOFT_BYTES");
  if (!limit) _exit(97);
  char* end = nullptr;
  const auto bytes = std::strtoll(limit, &end, 10);
  if (!end || *end || bytes < 0 || soft(bytes) < 0) _exit(98);
  if (pipe(wakeup) != 0) _exit(90);
  struct sigaction action{};
  action.sa_handler = trigger;
  sigemptyset(&action.sa_mask);
  if (sigaction(SIGUSR2, &action, nullptr) != 0) _exit(91);
  pthread_t thread;
  if (pthread_create(&thread, nullptr, worker, nullptr) != 0) _exit(92);
  pthread_detach(thread);
}
