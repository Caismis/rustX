"""Check headroom after 192/256 MiB caused cache thrashing at 256 sessions."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
identity = json.loads((root / 'probe-identity.json').read_text())
binary = Path(identity['binary'])
assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == identity['binary_sha256']
library = root / 'sqlite-probe.so'
assert hashlib.file_digest(library.open('rb'), 'sha256').hexdigest() == identity['library_sha256']
fixture = root / 'probe-capacity.py'
assert hashlib.file_digest(fixture.open('rb'), 'sha256').hexdigest() == identity['fixture_sha256']
identity.update(policy_mib=[320], reason='192 and 256 MiB leave about 301 MiB of necessary SQLite memory at 256 sessions and raise read calls sharply. Test 320 MiB with room for active pages; do not choose a policy from only the 128-session result.')
(root / 'probe-320-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
rows = json.loads((root / 'probe-commands.json').read_text())
for sessions, history in [(128, 32), (256, 8)]:
    name = f'probe-v3-{sessions:03}-{history:03}-320'
    output = root / name
    wrapper = root / (name + '.sh')
    wrapper.write_text('#!/bin/sh\n' + ('ulimit -n 4096\n' if sessions == 256 else '')
                       + 'export LD_PRELOAD=' + str(library)
                       + '\nexport RUSTX_SAMPLE_PREFIX=' + str(output / 'native-sample')
                       + '\nexport RUSTX_SQLITE_SET_SOFT_BYTES=' + str(320 * 2**20)
                       + ''.join('\nexport ' + key + '=' + value for key, value in identity['elf_symbol_offsets'].items())
                       + '\nexec ' + str(binary) + ' "$@"\n')
    wrapper.chmod(0o755)
    command = [sys.executable, str(fixture), '--binary', str(wrapper), '--output', str(output),
               '--sessions', str(sessions), '--history', str(history), '--widths', '4', '--rounds', '64', '--rotate-active']
    if history == 32:
        command += ['--history-checkpoints', '8', '16']
    deadline = time.monotonic() + 900
    while subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True).returncode == 0:
        assert time.monotonic() < deadline
        time.sleep(2)
    host = []
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (root / (name + '.log')).open('x') as log:
        child = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
        while child.poll() is None:
            host.append({'monotonic_ns': time.monotonic_ns(), 'loadavg': Path('/proc/loadavg').read_text(),
                         'compiler_pids': subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True, text=True).stdout.split()})
            time.sleep(.5)
    (root / (name + '-host.json')).write_text(json.dumps(host, indent=2) + '\n')
    rows.append({'sessions': sessions, 'history': history, 'soft_limit_mib': 320, 'command': command,
                 'native_soft_nofile': 4096 if sessions == 256 else 1024,
                 'start': started, 'exit': child.returncode, 'end': datetime.datetime.now(datetime.timezone.utc).isoformat()})
    (root / 'probe-commands.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, child.returncode, flush=True)
    assert child.returncode == 0 and json.loads((output / 'completed.json').read_text())['accepted']
