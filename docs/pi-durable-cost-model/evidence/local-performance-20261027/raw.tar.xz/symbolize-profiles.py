import hashlib,json,re,struct,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
pprof=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof')
records=[]
for directory in sorted(root.glob('profile-*-cpu')):
    manifest=json.loads((directory/'manifest.json').read_text())
    binary=manifest['argv'][-5]
    assert Path(binary).name=='conformance',binary
    raw=directory/'before_measured_turns.cpu'
    report=directory/'steady-cumulative.txt'
    cmd=[str(pprof),'--text','--cum','--no_strip_temp','--nodecount=200',binary,str(raw)]
    with report.open('w') as out,(directory/'symbolize.stderr').open('w') as err:
        subprocess.run(cmd,stdout=out,stderr=err,check=True)
    data=raw.read_bytes();header=struct.unpack_from('<5Q',data);assert header[:3]==(0,3,0)
    offset=40;total=0
    while True:
        count,depth=struct.unpack_from('<2Q',data,offset);offset+=16
        assert 0<depth<=1024
        pcs=struct.unpack_from(f'<{depth}Q',data,offset);offset+=8*depth
        if count==0 and pcs==(0,):break
        total+=count
    lines=report.read_text().splitlines();assert total==int(re.fullmatch(r'Total: (\d+) samples',lines[0])[1])
    rows=[]
    for line in lines[1:]:
        m=re.match(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)',line)
        if m:rows.append(dict(symbol=m[3],flat_samples=int(m[1]),cumulative_samples=int(m[2])))
    digest=lambda path:hashlib.file_digest(path.open('rb'),'sha256').hexdigest()
    records.append(dict(name=directory.name,manifest=manifest,command=cmd,phase='before_measured_turns -> after_turns',measured_turns=32,denominator_samples=total,requested_interval_us=header[3],raw_sha256=digest(raw),report_sha256=digest(report),rows=rows))
    print(directory.name,total,flush=True)
(root/'cpu-counts.json').write_text(json.dumps(dict(scope='Signal CPU samples, including product threads and benchmark driver. Cumulative rows overlap and cannot be summed. Counts independently checked against complete raw profile records; not elapsed percentages.',profiles=records),indent=2)+'\n')
