import datetime,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
before=root/'baseline-build/conformance'
after=root/'candidate-final-build/conformance'
commands=[]
for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
 commands.append(('revision-'+label,['python3','benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(root/('revision-'+label)),'--pairs','3','--observer-mode',mode]))
for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
 commands.append(('pi-'+label,['python3','benchmarks/runtime/controller.py','--rust',str(after),'--pi','/home/capi/Documents/codes/pi-rustx-benchmark','--output',str(root/('pi-'+label)),'--pairs','3','--observer-mode',mode]))
for cold in [False,True]:
 name='append-cold' if cold else 'append-warm'
 commands.append((name,['python3','benchmarks/runtime/compare-append.py','--before',str(before),'--after',str(after),'--output',str(root/name),'--pairs','3',*(['--cold'] if cold else [])]))
records=[]
for name,command in commands:
 record={'name':name,'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'}
 records.append(record)
 (root/'measurement-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 with (root/(name+'.log')).open('w') as log:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'UV_OFFLINE':'1'})
 record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete',exit=result.returncode)
 (root/'measurement-commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode: raise SystemExit(result.returncode)
