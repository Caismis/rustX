import datetime,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
profiler=Path('/home/capi/.cache/rustx-pr485-profilers')
records=[]
for engine,binary in [('baseline',root/'baseline-build/conformance'),('candidate',root/'candidate-final-build/conformance')]:
 for observer,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
  for case,short in [('short-small','small'),('short-large','large')]:
   for mode in ['control','cpu']:
    name=f'profile-{engine}-{label}-{short}-{mode}'
    command=['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root',str(profiler),'--output',str(root/name),'--mode',mode,'--case',case,'--observer-mode',observer]
    record={'name':name,'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'}
    records.append(record)
    (root/'profile-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    with (root/(name+'.log')).open('w') as log:
     result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'UV_OFFLINE':'1'})
    record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete',exit=result.returncode)
    (root/'profile-commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,result.returncode,flush=True)
    if result.returncode:raise SystemExit(result.returncode)
