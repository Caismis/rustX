import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

repo = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
out = Path('/home/capi/.cache/rustx-pr485-evidence/frontend')
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN', 'SECRET', 'CREDENTIAL', 'API_KEY'))}
env['UV_OFFLINE'] = '1'
records = []

def run(name, args, cwd, timeout=600):
    began = time.time()
    with (out / f'{name}.stdout').open('w') as stdout, (out / f'{name}.stderr').open('w') as stderr:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=stdout, stderr=stderr, check=False, timeout=timeout)
    record = {'name': name, 'argv': args, 'cwd': str(cwd), 'exit_code': result.returncode, 'start_unix': began, 'end_unix': time.time(), 'performance_eligible': False}
    records.append(record)
    (out / 'commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return result.returncode == 0

for name, directory in [('protocol', 'protocol/app-server'), ('tui', 'tui'), ('web', 'web-console')]:
    if not run(f'{name}-install', ['pnpm', 'install', '--frozen-lockfile', '--ignore-scripts'], repo / directory):
        raise SystemExit(1)

for name, directory in [('protocol', 'protocol/app-server'), ('tui', 'tui'), ('web', 'web-console')]:
    run(f'{name}-typecheck', ['pnpm', 'typecheck'], repo / directory)

run('tui-tests', ['pnpm', 'test'], repo / 'tui')
if run('web-build-host', ['pnpm', 'build:host'], repo / 'web-console'):
    test_dir = repo / 'web-console/test'
    explicit = {'client.test.ts', 'session-lifecycle.test.ts', 'root-checkpoint.test.ts', 'incremental-client.test.ts', 'incremental-equivalence.test.ts', 'projection-history.test.tsx', 'tool-trace-location.test.ts', 'source-repair-fields.test.ts', 'agent-trace.test.ts', 'trajectory.test.tsx', 'model-retry.test.tsx', 'request-lifetime.test.ts'}
    selected = sorted(str(p.relative_to(repo / 'web-console')) for p in test_dir.iterdir() if p.name in explicit or (p.name.startswith('trace-') or 'scroll.test' in p.name) and '.test.' in p.name)
    run('web-recovery-tests', ['pnpm', 'exec', 'vitest', 'run', '--maxWorkers=2', *selected], repo / 'web-console')

temp = out / 'protocol-generation'
temp.mkdir(exist_ok=True)
protocol = repo / 'protocol/app-server'
for name in ['generate.mjs', 'v52.schema.json', 'fixtures.json']:
    shutil.copy2(protocol / name, temp / name)
if not (temp / 'node_modules').exists():
    (temp / 'node_modules').symlink_to(protocol / 'node_modules', target_is_directory=True)
if run('protocol-node-generation', ['node', 'generate.mjs'], temp):
    comparisons = {}
    for name in ['v52.ts', 'fixtures.ts']:
        actual = (temp / name).read_bytes()
        expected = (protocol / name).read_bytes()
        comparisons[name] = {'equal': actual == expected, 'expected_sha256': hashlib.sha256(expected).hexdigest(), 'actual_sha256': hashlib.sha256(actual).hexdigest()}
    (out / 'protocol-node-generation-comparison.json').write_text(json.dumps(comparisons, indent=2) + '\n')
    print(json.dumps({'node_generation_comparison': comparisons}), flush=True)
    if not all(row['equal'] for row in comparisons.values()):
        raise SystemExit(1)

raise SystemExit(0 if all(row['exit_code'] == 0 for row in records) else 1)
