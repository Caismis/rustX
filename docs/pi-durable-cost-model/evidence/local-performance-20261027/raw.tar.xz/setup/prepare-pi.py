import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path('/home/capi/.cache/rustx-pr485-evidence/setup')
pi = Path('/home/capi/Documents/codes/pi-rustx-benchmark')
rust = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN', 'SECRET', 'CREDENTIAL', 'API_KEY'))}
env['UV_OFFLINE'] = '1'
steps = [
    ('chord-build', ['npm', 'run', 'build', '--prefix', 'packages/chord'], pi),
    ('telemetry-build', ['npm', 'run', 'build', '--prefix', 'packages/telemetry'], pi),
    ('ai-benchmark-build', ['node_modules/.bin/tsc', '-p', 'packages/ai/tsconfig.benchmark.json'], pi),
    ('python-harness-tests', ['python3', '-m', 'unittest', 'discover', '-s', 'benchmarks/runtime', '-p', 'test_*.py', '-v'], rust),
    ('node-harness-tests', ['node', '--test', *[str(p.relative_to(rust)) for p in sorted((rust / 'benchmarks/runtime').glob('*.test.mjs'))]], rust),
    ('fake-provider-cli', ['uv', 'run', '--project', 'test-support/fake-provider', '--frozen', 'fake-provider', '--help'], rust),
]
records = []
for name, command, cwd in steps:
    began = time.time()
    with (root / f'{name}.stdout').open('w') as stdout, (root / f'{name}.stderr').open('w') as stderr:
        result = subprocess.run(command, cwd=cwd, env=env, stdout=stdout, stderr=stderr, check=False)
    record = {'name': name, 'argv': command, 'cwd': str(cwd), 'exit_code': result.returncode, 'start_unix': began, 'end_unix': time.time(), 'performance_eligible': False}
    records.append(record)
    (root / 'setup-commands.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode != 0:
        print((root / f'{name}.stderr').read_text(), flush=True)
        sys.exit(result.returncode)
