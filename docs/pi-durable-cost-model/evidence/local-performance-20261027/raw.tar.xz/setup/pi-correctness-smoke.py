import json
import os
from pathlib import Path
import signal
import sys

rust = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
pi = Path('/home/capi/Documents/codes/pi-rustx-benchmark')
output = Path('/home/capi/.cache/rustx-pr485-evidence/setup')
sys.path.insert(0, str(rust / 'benchmarks/runtime'))
from controller import run

os.chdir(rust)
env = {k: v for k, v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN', 'SECRET', 'CREDENTIAL', 'API_KEY'))}
env.update(UV_OFFLINE='1', RUSTX_BENCH_OBSERVER_MODE='live-subscriber', RUSTX_BENCH_CASE='short-small')
stem = output / 'pi-smoke-short-small'
env['RUSTX_BENCH_OUTPUT'] = str(stem.with_suffix('.json'))
argv = ['node', '--conditions=source', 'benchmarks/runtime/pi-http.mjs', str(pi), 'short-small', env['RUSTX_BENCH_OUTPUT']]

def deadline(signum, frame):
    raise TimeoutError('correctness smoke exceeded 120 seconds')

signal.signal(signal.SIGALRM, deadline)
signal.alarm(120)
result = run(argv, stem, 'short-small', env, rust / 'test-support/fake-provider')
signal.alarm(0)
summary = {k: v for k, v in result.items() if k not in ('provider_report',)}
summary.update(performance_eligible=False, reason='Correctness-only setup smoke, overlapping Rust baseline compilation')
(output / 'pi-smoke-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2), flush=True)
raise SystemExit(0 if result['accepted'] else 1)
