#!/usr/bin/env python3
"""Recompute diagnostic profile/control overhead and raw inclusive CPU counts. No benchmarks."""
import hashlib, importlib.util, json, os, statistics, struct, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
HELPER=REPO/'benchmarks/runtime/summarize-http.py'
sys.path.insert(0,str(HELPER.parent))
spec=importlib.util.spec_from_file_location('summarize_http',HELPER)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def ticks(point):
 fields=point['process']['stat'].rsplit(')',1)[1].split()
 return int(fields[11])+int(fields[12])
clock=read(ROOT/'revision-live/manifest.json')['clock_ticks']
assert clock==os.sysconf('SC_CLK_TCK')==100
counts=read(ROOT/'cpu-counts.json')
profile_records={x['name']:x for x in counts['profiles']}
results=[]
for revision in ['baseline','candidate']:
 for mode in ['no-live','live']:
  for size in ['small','large']:
   runs={}
   for kind in ['control','cpu']:
    directory=ROOT/f'profile-{revision}-{mode}-{size}-{kind}'
    m=read(directory/'manifest.json');s=read(directory/'sample.json');p=read(directory/'sample.process.json')
    assert p['accepted'] and p['product_exit']==p['provider_exit']==0
    assert p['provider_report']['ok'] and p['provider_report']['complete']
    assert s['oracle']=='passed' and s['measured']==32
    assert s['history']==(8 if size=='small' else 64)
    assert m['mode']==kind and p['case']==m['case']==s['case']==f'short-{size}'
    observer='no-live-subscriber' if mode=='no-live' else 'live-subscriber'
    assert p['observer_mode']==m['observer_mode']==s['observer_mode']==observer
    assert all(x['observer_mode']==observer for x in s['samples'])
    assert s['measurement_version']==4 and s['workload_version']==3 and s['oracle_version']==2
    assert p['provider_report']['stepsTotal']==p['provider_report']['stepsMatched']==p['provider_report']['stepsSettled']==p['provider_report']['requestCount']==s['history']+32
    measured=[x for x in s['samples'] if x['measured']];assert len(measured)==32
    start=s['samples'][s['history']-1];end=s['samples'][-1]
    life=helper.validate_lifecycle(s);initial=life['before_initialization'];final=life['after_cleanup']
    metric=helper.sample(directory/'sample.json');assert abs(metric['turn_cpu_ms_per_turn']-(ticks(end)-ticks(start))/clock*1000/32)<1e-9
    runs[kind]={'directory':directory.name,'accepted':True,'binary_sha256':m['binary_sha256'],
     'sample_sha256':digest(directory/'sample.json'),'process_sha256':digest(directory/'sample.process.json'),
     'raw':{'measured_turns':32,'history':s['history'],'sum_settled_us':sum(x['settled_us'] for x in measured),'median_settled_us':statistics.median(x['settled_us'] for x in measured),'start_cpu_ticks':ticks(start),'end_cpu_ticks':ticks(end),'lifecycle_start_cpu_ticks':ticks(initial),'lifecycle_end_cpu_ticks':ticks(final),'lifecycle_start_elapsed_us':initial['elapsed_us'],'lifecycle_end_elapsed_us':final['elapsed_us']},
     'metrics':{k:v for k,v in metric.items() if k not in ['file','phases']}}
   assert runs['control']['binary_sha256']==runs['cpu']['binary_sha256']
   overhead={k:{'control':runs['control']['metrics'][k],'cpu':runs['cpu']['metrics'][k],'cpu_div_control':runs['cpu']['metrics'][k]/runs['control']['metrics'][k]} for k in ['mean_turn_ms','turn_cpu_ms_per_turn','lifecycle_ms','lifecycle_cpu_ms']}
   results.append({'revision':revision,'mode':mode,'case':size,'runs':runs,'overhead':overhead})
patterns={'sqlite_prepare':'sqlite3LockAndPrepare','publish_attempt':'RuntimeInner>::publish_attempt::{closure#5}','publication_encode':'PublicationDraft>::encode','read_domain_cut':'ReadDomainCut>::read_with_trace','request_read_layouts':'rustx::durable::sqlite::index_request_read_layouts','persist_event':'rustx::durable::sqlite::persist_event_tx_internal','checkpoint_unfitted':'CheckpointSeed>::checkpoint_unfitted','decorate_numeric':'rustx::runtime_client::response::decorate_numeric','source_persist_part':'rustx::durable::sqlite::observation_request::composed::fragments::persist_part','source_scalar':'rustx::durable::sqlite::observation_request::composed::fragments::scalar','source_capture_ensure':'composed::nodes::Capture>::ensure','fact_spool_insert':'FactSpool>::disk_insert','response_identity_source':'ConversationStore>::response_identity_source','execution_read':'ConversationStore>::observation_execution_at','selected_execution':'rustx::durable::sqlite::observation_execution::selected_layout','execution_layout_at':'rustx::durable::sqlite::observation_execution::layout_at'}
profiles=[]
for p in counts['profiles']:
 raw=ROOT/p['name']/'before_measured_turns.cpu'
 assert digest(raw)==p['raw_sha256']
 assert digest(ROOT/p['name']/'steady-cumulative.txt')==p['report_sha256']
 binary=raw.read_bytes();header=struct.unpack_from('<5Q',binary);assert header[:3]==(0,3,0)
 offset=40;denominator=0
 while True:
  count,depth=struct.unpack_from('<2Q',binary,offset);offset+=16
  assert 0<depth<=1024
  pcs=struct.unpack_from(f'<{depth}Q',binary,offset);offset+=8*depth
  if count==0 and pcs==(0,):break
  denominator+=count
 assert denominator==p['denominator_samples'] and header[3]==p['requested_interval_us']==4000
 selected={} 
 for key,pat in patterns.items():
  matches=[r for r in p['rows'] if r['symbol'].endswith(pat)]
  if len(matches)>1:raise ValueError((p['name'],key,matches))
  selected[key]=None if not matches else dict(matches[0],denominator_samples=p['denominator_samples'])
 profiles.append({'name':p['name'],'denominator_samples':p['denominator_samples'],'requested_interval_us':p['requested_interval_us'],'raw_sha256':p['raw_sha256'],'report_sha256':p['report_sha256'],'symbols':selected})
output={'scope':'Fresh diagnostic CPU signals (product threads plus benchmark driver), 32 measured turns, one run per cell. Inclusive rows overlap; fractions must not be added and are not wall-clock percentages. Missing rows mean not reported, not zero. Profile/control ratios are perturbation diagnostics, not formal performance effect estimates.',
 'provenance':{'clock_ticks':clock,'helper':str(HELPER),'helper_sha256':digest(HELPER),'cpu_counts_sha256':digest(ROOT/'cpu-counts.json'),'analysis_script_sha256':digest(Path(__file__))},'accepted_runs':16,'overhead':results,'profiles':profiles}
patterns={'response_identity':'ConversationStore>::response_identity_source','execution_selected':'rustx::durable::sqlite::observation_execution::selected_layout','transcript_process':'rustx::durable::sqlite::observation_members::transcript_process','event_witness':'rustx::durable::sqlite::observation_event::witness','completion_at':'rustx::durable::sqlite::projection::completion_at','execution_layout':'rustx::durable::sqlite::observation_execution::layout<','source_facts':'FactSpool>::disk_insert','request_layouts':'rustx::durable::sqlite::index_request_read_layouts'}
intersections=[]
for path in sorted(ROOT.glob('profile-candidate-*-cpu/steady-collapsed.txt')):
 all_counts={key:0 for key in patterns};prepare_counts={key:0 for key in patterns};total=0;prepare=0;live_union=0;common_union=0
 for line in path.read_text().splitlines():
  stack,n=line.rsplit(' ',1);n=int(n);total+=n
  found={key for key,pat in patterns.items() if pat in stack}
  for key in found:all_counts[key]+=n
  if 'sqlite3LockAndPrepare' in stack:
   prepare+=n
   for key in found:prepare_counts[key]+=n
   if found & {'response_identity','execution_selected','transcript_process'}:live_union+=n
   if found & {'event_witness','completion_at'}:common_union+=n
 p=profile_records[path.parent.name]
 assert total==p['denominator_samples']
 assert prepare==next(x['cumulative_samples'] for x in p['rows'] if x['symbol']=='sqlite3LockAndPrepare')
 intersections.append({'profile':path.parent.name,'collapsed_sha256':digest(path),'command':['/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof','--collapsed','--no_strip_temp',p['manifest']['argv'][-5],str(path.parent/'before_measured_turns.cpu')],'denominator_samples':total,'sqlite_prepare_samples':prepare,'path_samples':all_counts,'prepare_intersection_samples':prepare_counts,'deduplicated_prepare_union_samples':{'live_read_chain':live_union,'witness_or_completion':common_union}})
output['candidate_prepare_stack_intersections']=intersections
output['findings']=json.loads((ROOT/'profile-analysis-findings.json').read_text())
(ROOT/'profile-analysis.json').write_text(json.dumps(output,indent=2)+'\n')
for r in results:
 print(r['revision'],r['mode'],r['case'],' '.join(f'{k}: {v["control"]:.4f}->{v["cpu"]:.4f} ({v["cpu_div_control"]:.3f}x)' for k,v in r['overhead'].items()))
