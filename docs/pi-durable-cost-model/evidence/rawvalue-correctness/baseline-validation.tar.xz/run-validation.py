from pathlib import Path
import os,subprocess,json,datetime,hashlib,re
repo=Path('/workspace/rustX-rawvalue-validation');out=Path('/workspace/issue-481-evidence/rawvalue-p2');patch=Path('/workspace/rustX-pi-durable/docs/pi-durable-cost-model/evidence/rawvalue-correctness/correctness.patch')
env={k:v for k,v in os.environ.items() if not any(x in k.upper() for x in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])};env.update(PATH='/workspace/.cargo/bin:'+env['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_TARGET_DIR='/workspace/issue-481-target-debug',CARGO_BUILD_JOBS='1',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',BINDGEN_EXTRA_CLANG_ARGS='-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include',RUSTX_REQUIRE_PROVIDER_EMULATOR='1',UV_CACHE_DIR='/workspace/.uv-cache')
def git(*a):return subprocess.check_output(['git',*a],cwd=repo,text=True).strip()
assert git('rev-parse','HEAD^')=='b5840bd903d2508e693e1a4f80c3dc6173c9e29b';assert not git('status','--porcelain')
assert 'pub const SQLITE_SCHEMA_VERSION: i64 = 73;' in (repo/'src/durable/sqlite.rs').read_text()
record={'baseline':git('rev-parse','HEAD^'),'tested_head':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD:src'),'patch_sha256':hashlib.sha256(patch.read_bytes()).hexdigest(),'schema_gate':73,'scope':'Actual corrected artifact was applied to the two restored baseline files; resulting complete worktree matches the committed validation tree. Fresh debug/test target, real full library test compilation, no benchmark timings.','rustc':subprocess.check_output(['rustc','--version','--verbose'],env=env,text=True),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':[]}
try:
 for label,filter_name,count in [('state-preview','durable::sqlite::observation_request::state_preview_tests::',6),('read-layout','runtime::read_layout::',26)]:
  cmd=['cargo','test','--offline','--locked','--all-features','--lib',filter_name,'--','--nocapture'];print(label,'START',flush=True)
  log=out/(label+'.log')
  with log.open('w') as f:r=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT)
  ok=r.returncode==0 and f'test result: ok. {count} passed; 0 failed; 0 ignored;' in log.read_text()
  record['checks'].append({'label':label,'command':cmd,'exit':r.returncode,'expected_passed':count,'verified':ok});print(label,'EXIT',r.returncode,'VERIFIED',ok,flush=True);assert ok, label
 assert git('rev-parse','HEAD')==record['tested_head'] and not git('status','--porcelain');record['verified']=True
finally:
 record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'validation.json').write_text(json.dumps(record,indent=2)+'\n')
