import argparse,json,subprocess,hashlib,os,datetime
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('stage');p.add_argument('before');p.add_argument('after');a=p.parse_args()
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-pi-durable')
identities={side:json.loads((root/name/'identity.json').read_text()) for side,name in [('before',a.before),('after',a.after)]}
for side,name in [('before',a.before),('after',a.after)]:
 v=identities[side];assert v['verified'];assert hashlib.file_digest((root/name/'conformance').open('rb'),'sha256').hexdigest()==v['sha256']
for k in ['harness','rustc','cargo','build_environment']:
 assert identities['before'][k]==identities['after'][k],k
(root/(a.stage+'-identity-check.json')).write_text(json.dumps({'verified':True,'before':identities['before'],'after':identities['after'],'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
commands=[('formal',['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/a.before/'conformance'),'--after',str(root/a.after/'conformance'),'--output',str(root/(a.stage+'-matrix'))]),('summary',['python3','benchmarks/runtime/summarize-comparisons.py',str(root/(a.stage+'-matrix'))]),('profile',['python3',str(root/(a.stage+'-profile')/'run.py')]),('profile-analysis',['python3',str(root/(a.stage+'-profile')/'analyze.py')])]
for label,cmd in commands:
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),a.stage,label,'START',flush=True)
 with (root/(a.stage+('-summary.json' if label=='summary' else '-'+label+'.log'))).open('w') as log:
  r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'UV_CACHE_DIR':'/workspace/.uv-cache'})
 print(datetime.datetime.now(datetime.timezone.utc).isoformat(),a.stage,label,'EXIT',r.returncode,flush=True);r.check_returncode()
 if label=='profile':
  observed=json.loads((root/(a.stage+'-profile')/'identity.json').read_text())['binaries']
  for side in ['before','after']:assert observed[side]['sha256']==identities[side]['sha256'], ('profile identity differs from formal comparison',side)

