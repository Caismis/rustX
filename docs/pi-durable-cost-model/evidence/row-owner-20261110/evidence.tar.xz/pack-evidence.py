"""Archive immutable evidence, excluding binaries, credentials and live roots."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
destination = repo / 'docs/pi-durable-cost-model/evidence/row-owner-20261110'
destination.mkdir(parents=True, exist_ok=True)
excluded_parts = {'runtime', 'workspaces', '__pycache__'}
excluded_names = {'conformance', 'rustx', 'token', 'pack.log', 'pack-evidence.log'}
files = sorted(path for path in root.rglob('*') if path.is_file()
               and not (set(path.relative_to(root).parts) & excluded_parts)
               and path.name not in excluded_names)
members = [{'path': str(path.relative_to(root)), 'bytes': path.stat().st_size,
            'sha256': hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()} for path in files]
archive = destination / 'evidence.tar.xz'
with archive.open('wb') as output:
    compression = subprocess.Popen(['xz', '-T8', '-6', '-c'], stdin=subprocess.PIPE, stdout=output)
    with tarfile.open(mode='w|', fileobj=compression.stdin) as tar:
        for path in files:
            tar.add(path, arcname=str(path.relative_to(root)), recursive=False)
    compression.stdin.close()
    assert compression.wait() == 0
expected = {item['path']: item for item in members}
seen = set()
with tarfile.open(archive, mode='r|xz') as tar:
    for member in tar:
        assert member.isfile() and member.name in expected and member.name not in seen
        assert member.size == expected[member.name]['bytes']
        assert hashlib.file_digest(tar.extractfile(member), 'sha256').hexdigest() == expected[member.name]['sha256']
        seen.add(member.name)
assert seen == expected.keys()
manifest = {'scope': 'Historical evidence; helpers retain original absolute paths and are not claimed to be a portable replay bundle. Includes every accepted/failed product, independently checked native backups, ordinary records, separate diagnostic profiles and exact build/test identities. Actual executables, dependency trees, live runtime/workspace roots and bearer files excluded.',
            'archive_bytes': archive.stat().st_size, 'archive_sha256': hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest(),
            'member_count': len(members), 'total_raw_bytes': sum(item['bytes'] for item in members),
            'verified_every_archived_member': True, 'members': members}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: value for key, value in manifest.items() if key != 'members'}, indent=2))
