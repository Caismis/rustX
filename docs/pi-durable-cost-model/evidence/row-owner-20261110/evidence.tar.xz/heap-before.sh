#!/bin/sh
export LD_PRELOAD=/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4.5.16:/home/capi/.cache/rustx-pr485-memory-writes-20261103/heap-sample.so
export TCMALLOC_SAMPLE_PARAMETER=65536
export RUSTX_SAMPLE_PREFIX=/home/capi/.cache/rustx-pr485-row-owner-20261110/heap-before/native-sample
unset HEAPPROFILE HEAPPROFILESIGNAL
exec /home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/rustx "$@"
