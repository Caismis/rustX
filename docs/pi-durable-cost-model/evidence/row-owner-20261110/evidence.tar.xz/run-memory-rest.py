from pathlib import Path
import subprocess,sys,json,hashlib,datetime,time
r=Path(__file__).resolve().parent;w=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
bins={'before':Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/rustx'),'after':r/'candidate-build/rustx'}
rows=json.loads((r/'memory-commands.json').read_text());waits=[]
for family,pairs,sessions,history,extras in [('deep',1,16,64,[]),('idle',1,128,8,['--idle-seconds','32','130'])]:
 for pair in range(pairs):
  for side in (['before','after'] if pair%2==0 else ['after','before']):
   stem=f'{family}-v2-{pair}-'+('base' if side=='before' else 'next');out=r/stem
   # Preserve each planned sample; delay startup until known compiler work ends.
   deadline=time.monotonic()+900
   while subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode==0:
    waits.append({'next':stem,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pids':subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True).stdout.split()});(r/'memory-verified-waits.json').write_text(json.dumps(waits,indent=2)+'\n');assert time.monotonic()<deadline;time.sleep(2)
   cmd=[sys.executable,str(w/'benchmarks/runtime/app-server-capacity.py'),'--binary',str(bins[side]),'--output',str(out),'--sessions',str(sessions),'--history',str(history),'--memory-only',*extras]
   row={'family':family,'pair':pair,'side':side,'command':cmd,'sha256':hashlib.file_digest(bins[side].open('rb'),'sha256').hexdigest(),'start':datetime.datetime.now(datetime.timezone.utc).isoformat()}
   with (r/(stem+'.log')).open('x') as log:
    p=subprocess.run(cmd,cwd=w,stdout=log,stderr=subprocess.STDOUT)
   row.update(exit=p.returncode,end=datetime.datetime.now(datetime.timezone.utc).isoformat());rows.append(row);(r/'memory-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(stem,p.returncode,flush=True)
   assert p.returncode==0 and json.loads((out/'completed.json').read_text())['accepted']
