"""Keep ordinary, capacity and replacement-allocator products sequential."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
before = Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build')
after = root / 'candidate-build'
commands = []

def run(name, command, **fields):
    host = []
    waits = []
    deadline = time.monotonic() + 900
    while (current := subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True, text=True)).returncode == 0:
        waits.append({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'compiler_pids': current.stdout.split()})
        (root / (name + '-verified-waits.json')).write_text(json.dumps(waits, indent=2) + '\n')
        assert time.monotonic() < deadline
        time.sleep(2)
    row = {'name': name, 'command': command, 'start': datetime.datetime.now(datetime.timezone.utc).isoformat(), **fields}
    with (root / (name + '.log')).open('x') as log:
        product = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
        while product.poll() is None:
            host.append({'monotonic_ns': time.monotonic_ns(), 'loadavg': Path('/proc/loadavg').read_text(),
                         'compiler_pids': subprocess.run(['pgrep', '-x', 'rustc'], capture_output=True, text=True).stdout.split()})
            time.sleep(.5)
    (root / (name + '-host.json')).write_text(json.dumps(host, indent=2) + '\n')
    row.update(exit=product.returncode, observed_compiler_overlap=any(item['compiler_pids'] for item in host),
               end=datetime.datetime.now(datetime.timezone.utc).isoformat())
    commands.append(row)
    (root / 'checks-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    print(name, product.returncode, flush=True)
    assert product.returncode == 0

run('ordinary', ['taskset', '-c', '2,4,6,10', sys.executable, str(repo / 'benchmarks/runtime/compare-revisions.py'),
                '--before', str(before / 'conformance'), '--after', str(after / 'conformance'),
                '--output', str(root / 'ordinary'), '--pairs', '4', '--observer-mode', 'live-subscriber',
                '--case', 'short-small', '--case', 'short-large', '--case', 'large', '--case', 'stream'])
run('memory', [sys.executable, str(root / 'run-memory-pairs.py')])
for family in ['fixed', 'rotating']:
    for pair in range(2):
        for side in (['before', 'after'] if pair % 2 == 0 else ['after', 'before']):
            name = f'native-{family}-{pair}-' + ('base' if side == 'before' else 'next')
            binary = (before if side == 'before' else after) / 'rustx'
            command = [sys.executable, str(repo / 'benchmarks/runtime/app-server-capacity.py'), '--binary', str(binary),
                       '--output', str(root / name), '--sessions', '128', '--history', '8', '--widths', '4', '--rounds', '64']
            if family == 'rotating':
                command += ['--rotate-active']
            run(name, command, family=family, pair=pair, side=side,
                sha256=hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest())
for side in ['after', 'before']:
    name = 'heap-' + side
    run(name, [sys.executable, str(root / 'sample-capacity.py'), '--binary', str(root / (name + '.sh')),
               '--output', str(root / name), '--sessions', '128', '--history', '8', '--memory-only',
               '--idle-seconds', '32', '130'], side=side)
