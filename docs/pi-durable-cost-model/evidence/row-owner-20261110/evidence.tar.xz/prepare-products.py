"""Preserve the freshly built CLI and construct the independent heap probe."""
from pathlib import Path
import hashlib
import json
import shutil

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
build = root / 'candidate-build'
identity = json.loads((build / 'identity.json').read_text())
assert identity['verified'] and identity['head'].startswith('91a3ffb42')
records = [json.loads(line) for line in (build / 'build.stdout').read_text().splitlines() if line.startswith('{')]
artifact = next(record for record in records if record.get('reason') == 'compiler-artifact'
                and record.get('target', {}).get('kind') == ['bin']
                and record['target']['name'] == 'rustx')
assert not artifact['fresh'] and Path(artifact['target']['src_path']).resolve() == repo / 'src/main.rs'
destination = build / 'rustx'
shutil.copy2(artifact['executable'], destination)
identity['cli'] = {'binary': str(destination), 'sha256': hashlib.file_digest(destination.open('rb'), 'sha256').hexdigest(),
                   'artifact': artifact}
(build / 'cli-identity.json').write_text(json.dumps(identity, indent=2) + '\n')

source = (repo / 'benchmarks/runtime/app-server-capacity.py').read_text()
source = source.replace('REPO = Path(__file__).resolve().parents[2]', f'REPO = Path({str(repo)!r})')
assert f'REPO = Path({str(repo)!r})' in source
source = source.replace('str(path.relative_to(REPO))', 'str(path.resolve())')
source = source.replace("Path(__file__).with_name('app-server-capacity-provider.py')", "REPO / 'benchmarks/runtime/app-server-capacity-provider.py'")
source = source.replace("    process = None\n", "    process = None\n    heap_sequence = 0\n", 1)
needle = "            write(out / 'phases.json', phases)\n"
assert source.count(needle) == 1
injection = '''            nonlocal heap_sequence
            if name in ['empty_server', 'all_subscribed_empty', 'seeded_history_8', 'idle_32s', 'idle_130s', 'all_unloaded']:
                heap_sequence += 1
                process.send_signal(signal.SIGUSR2)
                deadline = time.monotonic() + 30
                while True:
                    try:
                        stats = json.loads((out / f'native-sample-{heap_sequence}.json').read_text())
                        break
                    except (OSError, json.JSONDecodeError):
                        assert time.monotonic() < deadline
                        await asyncio.sleep(0.01)
                write(out / f'sample-{heap_sequence}-binding.json', {'phase': name, 'pid': process.pid, 'stats': stats})
'''
source = source.replace(needle, needle + injection)
(root / 'sample-capacity.py').write_text(source)
libraries = [Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/lib/x86_64-linux-gnu/libtcmalloc.so.4.5.16'),
             Path('/home/capi/.cache/rustx-pr485-memory-writes-20261103/heap-sample.so')]
products = {'before': Path('/home/capi/.cache/rustx-pr485-history-growth-20261109/kind-build/rustx'), 'after': destination}
details = {}
for side, binary in products.items():
    output = root / ('heap-' + side)
    wrapper = root / ('heap-' + side + '.sh')
    wrapper.write_text('#!/bin/sh\nexport LD_PRELOAD=' + ':'.join(map(str, libraries))
                       + '\nexport TCMALLOC_SAMPLE_PARAMETER=65536\nexport RUSTX_SAMPLE_PREFIX=' + str(output / 'native-sample')
                       + '\nunset HEAPPROFILE HEAPPROFILESIGNAL\nexec ' + str(binary) + ' "$@"\n')
    wrapper.chmod(0o755)
    details[side] = {'binary': str(binary), 'sha256': hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest(),
                     'wrapper': str(wrapper), 'wrapper_sha256': hashlib.file_digest(wrapper.open('rb'), 'sha256').hexdigest()}
(root / 'heap-identity.json').write_text(json.dumps({'products': details, 'libraries': {
    str(path): hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() for path in libraries},
    'source_fixture_sha256': hashlib.sha256((repo / 'benchmarks/runtime/app-server-capacity.py').read_bytes()).hexdigest(),
    'diagnostic_fixture_sha256': hashlib.sha256(source.encode()).hexdigest(),
    'scope': 'Separate allocation diagnostics. No replacement-allocator measurement is an ordinary GNU PSS result.'}, indent=2) + '\n')
print(json.dumps({'cli_sha256': identity['cli']['sha256'], 'heap_products': details}, indent=2))
