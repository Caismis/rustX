//! The Rust launcher for the external scripted provider emulator.
//!
//! This module owns **process mechanics only**: command construction,
//! readiness parsing, the base URL, the control API, diagnostics capture,
//! and child cleanup. It contains no scenario semantics and no provider
//! protocol — those live in `test-support/fake-provider/`, and duplicating
//! either here would recreate the second provider implementation issue #47
//! exists to remove.
//!
//! ```text
//! Rust conformance test
//!   -> ProviderEmulator::start("scenario")   uv run fake-provider --port 0
//!   -> LocalConversationRuntime::compose     catalog baseUrl = emulator
//!   -> real adapter -> real HTTP/SSE ------> the Python process
//!   -> await_gate / release_gate / requests  the control API
//!   -> finish()                              assert the scenario report
//! ```

#![allow(dead_code)] // each helper is used by some conformance tests

use std::path::PathBuf;
use std::process::Stdio;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use tokio::io::{AsyncBufReadExt, BufReader};
use tokio::process::{Child, Command};

/// The environment variable that turns "uv is missing, skip" into a hard
/// failure for every uv-dependent boundary: the provider emulator and the
/// managed Python (`FastMCP`) children share the one uv + Python 3.12
/// toolchain. Every CI step that runs such a boundary sets it, so a broken
/// toolchain in the pipeline can never be reported as a green boundary run.
pub const REQUIRE_VARIABLE: &str = "RUSTX_REQUIRE_PROVIDER_EMULATOR";

/// The `uv` executable a uv-dependent boundary test needs.
///
/// `None` means the calling test must return without exercising its
/// boundary, which only a local checkout without the toolchain may do: with
/// [`REQUIRE_VARIABLE`] set, absence panics instead.
pub fn required_uv(boundary: &str) -> Option<PathBuf> {
    uv_prerequisite(
        std::env::var_os("PATH").as_deref(),
        std::env::var_os(REQUIRE_VARIABLE).is_some(),
        boundary,
    )
}

/// [`required_uv`] over explicit inputs, so the mandatory path is testable
/// without mutating the process environment.
pub fn uv_prerequisite(
    path: Option<&std::ffi::OsStr>,
    required: bool,
    boundary: &str,
) -> Option<PathBuf> {
    let uv = path.and_then(|path| {
        std::env::split_paths(path)
            .map(|dir| dir.join("uv"))
            .find(|candidate| candidate.is_file())
    });
    if uv.is_none() {
        assert!(
            !required,
            "{REQUIRE_VARIABLE} is set but uv is not on PATH; {boundary} cannot run"
        );
        eprintln!("uv unavailable; {boundary} was NOT exercised (skipped)");
    }
    uv
}

/// The upper bound on a control-plane barrier wait. Deadlock protection
/// only: ordering is always established by the observation itself, and a
/// scenario that starts child processes can take tens of seconds to reach a
/// gate while the whole suite shares the CPU and disk.
const AWAIT_TIMEOUT: Duration = Duration::from_secs(120);

/// A running scenario in the external provider process.
pub struct ProviderEmulator {
    child: Option<Child>,
    client: reqwest::Client,
    host: String,
    port: u16,
    scenario: String,
    stderr: Arc<Mutex<String>>,
}

impl ProviderEmulator {
    /// Attach a benchmark driver to the provider owned by its external controller.
    /// The controller alone starts, shuts down and reaps this sibling process.
    pub fn externally_owned(ready: &serde_json::Value, scenario: &str) -> Self {
        assert_eq!(ready["ready"], true);
        assert_eq!(ready["scenario"], scenario);
        assert_eq!(ready["host"], "127.0.0.1");
        Self {
            child: None,
            client: reqwest::Client::new(),
            host: "127.0.0.1".to_owned(),
            port: u16::try_from(ready["port"].as_u64().expect("provider port")).unwrap(),
            scenario: scenario.to_owned(),
            stderr: Arc::new(Mutex::new(String::new())),
        }
    }

    /// Starts one scenario on an ephemeral loopback port.
    ///
    /// Returns `None` when `uv` is not installed and the harness is not
    /// required, so a checkout without the Python toolchain still runs the
    /// rest of the suite.
    ///
    /// # Panics
    ///
    /// Panics when the process cannot be launched, does not print its
    /// readiness record, or reports a scenario the caller did not ask for.
    pub async fn start(scenario: &str) -> Option<Self> {
        Self::start_with_workspace(scenario, None).await
    }

    /// Starts the scenario with the workspace root of the runtime under test,
    /// substituting the `{workspace}` placeholder of scripted tool-call
    /// arguments. Scenarios may use it to exercise absolute paths while the
    /// native file tools also accept cwd-relative paths.
    pub async fn start_with_workspace(
        scenario: &str,
        workspace: Option<&std::path::Path>,
    ) -> Option<Self> {
        required_uv(&format!("the provider-emulator scenario {scenario}"))?;

        let project = project_root();
        let mut command = Command::new("uv");
        command
            .arg("run")
            .arg("--project")
            .arg(&project)
            .arg("--frozen")
            .arg("fake-provider")
            .arg("--scenario")
            .arg(scenario)
            .arg("--port")
            .arg("0");
        if let Some(workspace) = workspace {
            command
                .arg("--workspace")
                .arg(workspace.canonicalize().expect("workspace exists"));
        }
        let mut child = command
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            // Belt and braces beside the stdin-EOF contract: a panicking
            // test never leaves the provider running.
            .kill_on_drop(true)
            .spawn()
            .expect("spawn the provider emulator");

        let stderr = Arc::new(Mutex::new(String::new()));
        let sink = Arc::clone(&stderr);
        let mut diagnostics = BufReader::new(child.stderr.take().expect("stderr pipe")).lines();
        tokio::spawn(async move {
            while let Ok(Some(line)) = diagnostics.next_line().await {
                sink.lock().expect("stderr lock").push_str(&line);
                sink.lock().expect("stderr lock").push('\n');
            }
        });

        let mut stdout = BufReader::new(child.stdout.take().expect("stdout pipe"));
        let mut line = String::new();
        let read = tokio::time::timeout(AWAIT_TIMEOUT, stdout.read_line(&mut line))
            .await
            .expect("the provider emulator printed its readiness record in time")
            .expect("read the readiness record");
        assert!(
            read > 0,
            "the provider emulator exited before readiness: {}",
            stderr.lock().expect("stderr lock")
        );
        let ready: serde_json::Value =
            serde_json::from_str(&line).expect("the readiness record is one JSON object");
        assert_eq!(ready["ready"], serde_json::json!(true), "{ready}");
        assert_eq!(ready["scenario"], serde_json::json!(scenario), "{ready}");

        // The remaining stdout (the final report) is drained so the child
        // never blocks on a full pipe.
        let report_sink = Arc::clone(&stderr);
        tokio::spawn(async move {
            let mut rest = String::new();
            let _ = stdout.read_line(&mut rest).await;
            if !rest.trim().is_empty() {
                let mut sink = report_sink.lock().expect("stderr lock");
                sink.push_str("report: ");
                sink.push_str(&rest);
            }
        });

        Some(Self {
            child: Some(child),
            client: reqwest::Client::new(),
            host: ready["host"].as_str().expect("host").to_owned(),
            port: u16::try_from(ready["port"].as_u64().expect("port")).expect("port range"),
            scenario: scenario.to_owned(),
            stderr,
        })
    }

    /// The provider root, which is the Anthropic Messages `baseUrl`.
    #[must_use]
    pub fn base_url(&self) -> String {
        format!("http://{}:{}", self.host, self.port)
    }

    /// The OpenAI-family `baseUrl` (`.../v1`).
    #[must_use]
    pub fn openai_base_url(&self) -> String {
        format!("{}/v1", self.base_url())
    }

    /// Blocks until the provider reaches a named gate.
    ///
    /// This is a real barrier inside the provider process, not a poll: it
    /// returns only once the gate has been reached, so an action performed
    /// afterwards is provably ordered after everything the gate follows.
    ///
    /// # Panics
    ///
    /// Panics when the gate is never reached within the deadlock timeout.
    pub async fn await_gate(&self, name: &str) -> serde_json::Value {
        self.await_observation("gate_reached", Some(name)).await
    }

    /// Blocks until the provider observes the client closing the connection.
    ///
    /// # Panics
    ///
    /// Panics when no disconnect is observed within the deadlock timeout.
    pub async fn await_client_disconnect(&self) -> serde_json::Value {
        self.await_observation("client_disconnected", None).await
    }

    async fn await_observation(&self, kind: &str, name: Option<&str>) -> serde_json::Value {
        let url = format!(
            "{}/__control/observations/await?kind={kind}&timeoutMs={}{}",
            self.base_url(),
            AWAIT_TIMEOUT.as_millis(),
            name.map(|name| format!("&name={name}")).unwrap_or_default(),
        );
        let response = self.client.get(&url).send().await.expect("control request");
        let status = response.status();
        let body: serde_json::Value = response.json().await.expect("control JSON");
        assert!(
            status.is_success(),
            "the provider never reached {kind}{}: {body}\n{}",
            name.map(|name| format!(" ({name})")).unwrap_or_default(),
            self.diagnostics()
        );
        body
    }

    /// Releases a named gate, letting the suspended response continue.
    ///
    /// # Panics
    ///
    /// Panics when the scenario declares no such gate.
    pub async fn release_gate(&self, name: &str) {
        let response = self
            .client
            .post(format!(
                "{}/__control/gates/{name}/release",
                self.base_url()
            ))
            .send()
            .await
            .expect("control request");
        assert!(
            response.status().is_success(),
            "releasing the gate {name} failed: {}",
            response.text().await.unwrap_or_default()
        );
    }

    /// Every provider request the runtime actually sent, in arrival order.
    ///
    /// # Panics
    ///
    /// Panics when the control API is unreachable.
    pub async fn requests(&self) -> Vec<serde_json::Value> {
        let body: serde_json::Value = self
            .client
            .get(format!("{}/__control/requests", self.base_url()))
            .send()
            .await
            .expect("control request")
            .json()
            .await
            .expect("control JSON");
        body["requests"]
            .as_array()
            .expect("the request record is an array")
            .clone()
    }

    /// The captured provider diagnostics.
    #[must_use]
    pub fn diagnostics(&self) -> String {
        self.stderr.lock().expect("stderr lock").clone()
    }

    /// Shuts the provider down and asserts the scenario was satisfied:
    /// every declared step's request matched, in order, with no unexpected
    /// request, **and** every scripted response reached its terminal state.
    /// A response still suspended at an unreleased gate is not success.
    ///
    /// The child's exit status is asserted too, so a green report and a red
    /// exit code can never disagree silently.
    ///
    /// # Panics
    ///
    /// Panics when the scenario report is not `ok`, quoting the exact
    /// provider-side failures, or when the process exits unsuccessfully.
    pub async fn finish(mut self) {
        let report: serde_json::Value = self
            .client
            .post(format!("{}/__control/shutdown", self.base_url()))
            .send()
            .await
            .expect("control request")
            .json()
            .await
            .expect("control JSON");
        let child = self.child.take().expect("the child is taken once");
        let status = tokio::time::timeout(AWAIT_TIMEOUT, child.wait_with_output())
            .await
            .expect("the provider emulator exited in time")
            .expect("wait for the provider emulator");
        assert!(
            report["ok"].as_bool().unwrap_or(false),
            "the {} scenario was not satisfied: {}\n{}",
            self.scenario,
            serde_json::to_string_pretty(&report).unwrap_or_default(),
            self.diagnostics()
        );
        assert!(
            status.status.success(),
            "the provider emulator exited with {:?}\n{}",
            status.status,
            self.diagnostics()
        );
    }
}

impl Drop for ProviderEmulator {
    fn drop(&mut self) {
        if let Some(child) = self.child.as_mut() {
            // `kill_on_drop` handles the async runtime path; this covers a
            // drop that happens outside it (a panicking synchronous unwind).
            let _ = child.start_kill();
        }
    }
}

/// The uv project root of the emulator.
fn project_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("test-support/fake-provider")
}
