Baseline source: a66a26914 / Rust tree identical to 1920e5141; reused verified ordinary CLI and conformance artifacts from kind-build.
Candidate: unchanged schema 105. Exact immutable row presentation reuse after fresh native/Tool/body and response validation.
No Pi, pi-rust or DeepSeek executions. The native driver has protocol 76, explicit names and native-idle retirement checks.
Products: four immediate 128x8 balanced pairs; one 16x64 depth pair; one strict unchanged 128x8 32/130-second idle pair.
All observer/runtime actors stay loaded during idle endpoints. Manager diagnostics do not access conversation SQLite.
