"""Independently re-open every capacity backup and preserve paired endpoints."""
from pathlib import Path
import hashlib
import importlib
import json
import sqlite3
import statistics
import sys

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0, str(repo / 'benchmarks/runtime'))
metrics = importlib.import_module('summarize-http')

def load(path):
    return json.loads(path.read_text())

def verify(directory, sessions, memory_only):
    done = load(directory / 'completed.json')
    assert done['accepted']
    records = load(directory / 'native-closed.json')
    assert len(records) == sessions
    for record in records:
        index = record['session_index']
        path = directory / 'native-snapshots' / f'{index:04}.sqlite'
        assert hashlib.file_digest(path.open('rb'), 'sha256').hexdigest() == record['consistent_backup_sha256']
        connection = sqlite3.connect(f'file:{path}?mode=ro', uri=True)
        assert connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert not connection.execute('PRAGMA foreign_key_check').fetchall()
        assert connection.execute('SELECT schema_version FROM rustx_store').fetchone()[0] == 105
        messages = [json.loads(row[0]) for row in connection.execute('SELECT message_json FROM message_ledger ORDER BY position')]
        connection.close()
        users = [row for row in messages if row['role'] == 'user']
        assistants = [row for row in messages if row['role'] == 'assistant']
        assert len(messages) == record['messages']
        assert len(users) == done['turn_counts'][str(index)]
        assert len(assistants) == len(users) - int(not memory_only and index == 0)
        for turn, user in enumerate(users):
            assert user['content'] == [{'type': 'text', 'text': f'capacity turn session={index:04} turn={turn:04}'}]
        for turn, assistant in enumerate(assistants):
            text = 'S' * 32768 if not memory_only and index == sessions - 1 and turn == len(assistants) - 1 else 'capacity response'
            assert assistant['content'] == [{'type': 'text', 'text': text}]
    return {point['phase']: point for point in load(directory / 'phases.json')}

memory = []
failed = []
for command in load(root / 'memory-commands.json'):
    if command['exit'] != 0:
        failed.append(command)
        continue
    directory = Path(command['command'][command['command'].index('--output') + 1])
    sessions = int(command['command'][command['command'].index('--sessions') + 1])
    phases = verify(directory, sessions, True)
    endpoints = {}
    for name, point in phases.items():
        if name in ['empty_server', 'all_subscribed_empty', 'seeded_history_8', 'seeded_history_64', 'all_unloaded', 'idle_32s', 'idle_130s']:
            counters = metrics.counters(point)
            endpoints[name] = {'anon_pss_mib': counters['anon_pss_kib'] / 1024, 'pss_mib': counters['pss_kib'] / 1024}
    memory.append({key: command[key] for key in ['family', 'pair', 'side', 'sha256']} | {'directory': directory.name, 'sessions': sessions, 'endpoints': endpoints})
paired = {}
for family in ['memory', 'deep', 'idle']:
    values = []
    for pair in sorted({row['pair'] for row in memory if row['family'] == family}):
        before, after = [next(row for row in memory if row['family'] == family and row['pair'] == pair and row['side'] == side) for side in ['before', 'after']]
        values.append({name: (after['endpoints'][name]['anon_pss_mib'] / before['endpoints'][name]['anon_pss_mib'] - 1) * 100 for name in before['endpoints']})
    paired[family] = {'values': values, 'median_percent': {key: statistics.median(row[key] for row in values) for key in values[0]}}
(root / 'memory-audit.json').write_text(json.dumps({'scope': 'Ordinary GNU allocator. Four immediate 128x8 pairs, one 16x64 pair, one unchanged strict-idle 128x8 pair. Current storage integrity/FK/schema and exact canonical bytes independently verified in every backup. Immediate matrix uses frozen fixture v1; depth/idle use v2 metadata-lane correction. Failed v1 depth baseline is retained and excluded.', 'rows': memory, 'paired': paired, 'failed_products': failed}, indent=2) + '\n')
print(json.dumps({'memory_paired': paired}, indent=2))
if '--memory-only' in sys.argv:
    raise SystemExit(0)

native = []
for command in load(root / 'checks-commands.json'):
    if not command['name'].startswith('native-'):
        continue
    directory = root / command['name']
    phases = verify(directory, 128, False)
    active = load(directory / 'active-4.json')
    count = sum(len(row['turns']) for row in active['rows'])
    assert count == 256
    points = [point for row in active['rows'] if not row['held'] for point in row['turns']]
    start = min(point['began_monotonic_ns'] for row in active['rows'] for point in row['turns'])
    end = phases['active_finished_4']['monotonic_ns']
    overlap = [point for point in load(root / (command['name'] + '-host.json')) if start <= point['monotonic_ns'] <= end and point['compiler_pids']]
    native.append({key: command[key] for key in ['family', 'pair', 'side', 'sha256']} | {
        'directory': directory.name, 'cpu_ms_per_turn': metrics.delta({'process': active['before']}, {'process': active['after']}, 'cpu_ms') / count,
        'write_kib_per_turn': metrics.delta({'process': active['before']}, {'process': active['after']}, 'write_bytes') / 1024 / count,
        'p50_ms': statistics.median(point['settled_us'] / 1000 for point in points),
        'p95_ms': sorted(point['settled_us'] / 1000 for point in points)[int(.95 * len(points))],
        'active_compiler_samples': overlap})
native_paired = {}
for family in ['fixed', 'rotating']:
    changes = []
    for pair in range(2):
        before, after = [next(row for row in native if row['family'] == family and row['pair'] == pair and row['side'] == side) for side in ['before', 'after']]
        changes.append({key: (after[key] / before[key] - 1) * 100 for key in ['cpu_ms_per_turn', 'write_kib_per_turn', 'p50_ms', 'p95_ms']})
    native_paired[family] = {'values': changes, 'median_percent': {key: statistics.median(row[key] for row in changes) for key in changes[0]}}
(root / 'native-audit.json').write_text(json.dumps({'scope': 'Two balanced pairs per fixed/rotating four-concurrency group. Ordinary GNU allocator; server PID only; CPU includes native retirement status reads. Every backup authenticated and checked independently. Two pairs do not prove statistical significance.', 'rows': native, 'paired': native_paired}, indent=2) + '\n')
print(json.dumps({'native_paired': native_paired}, indent=2))
for side in ['before', 'after']:
    verify(root / ('heap-' + side), 128, True)
print('Both heap products also passed independent backup, integrity/FK, schema and exact content verification.')
