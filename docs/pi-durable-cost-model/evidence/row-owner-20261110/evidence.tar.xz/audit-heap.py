"""Check raw sampling coverage, symbolize, and keep distinct measurement units."""
from pathlib import Path
import collections
import hashlib
import json
import math
import re
import subprocess

root = Path(__file__).resolve().parent
identity = json.loads((root / 'heap-identity.json').read_text())
pprof = Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof')
products = []
for side in ['before', 'after']:
    directory = root / ('heap-' + side)
    binary = Path(identity['products'][side]['binary'])
    assert hashlib.file_digest(binary.open('rb'), 'sha256').hexdigest() == identity['products'][side]['sha256']
    assert json.loads((directory / 'completed.json').read_text())['accepted']
    for index in range(1, 7):
        profile = directory / f'native-sample-{index}.heap'
        lines = profile.read_text().splitlines()
        header = re.match(r'heap profile:\s+(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\] @ heap_v2/(\d+)', lines[0])
        assert header
        header = list(map(int, header.groups()))
        assert header[4] == 65536
        sums = [0] * 4
        weighted = 0.
        records = 0
        for line in lines[1:]:
            record = re.match(r'\s*(\d+):\s+(\d+)\s+\[\s*(\d+):\s+(\d+)\]\s+@', line)
            if not record:
                continue
            values = list(map(int, record.groups()))
            records += 1
            sums = [a + b for a, b in zip(sums, values)]
            assert values[0] > 0
            weighted += values[1] / -math.expm1(-values[1] / values[0] / header[4])
        assert sums == header[:4]
        collapsed = directory / f'sample-{index}-collapsed.txt'
        with collapsed.open('x') as output, (directory / f'sample-{index}-symbolize.log').open('x') as errors:
            subprocess.run([str(pprof), '--collapsed', '--no_strip_temp', str(binary), str(profile)], stdout=output, stderr=errors, check=True)
        stacks = []
        for line in collapsed.read_text().splitlines():
            if line.strip():
                stack, amount = line.rsplit(' ', 1)
                stacks.append((stack, int(amount)))
        total = sum(amount for _, amount in stacks)
        assert abs(total - weighted) < len(stacks) + 1
        categories = collections.Counter()
        sqlite = collections.Counter()
        for stack, amount in stacks:
            category = next((name for name, tokens in [
                ('schema_validation', ('jsonschema::',)),
                ('sqlite', ('sqlite3MemMalloc',)),
                ('checkpoint_capture', ('capture_checkpoint',)),
                ('other_observation', ('rustx::observation::', 'runtime_client::')),
                ('model', ('rustx::model::',)),
                ('local_runtime', ('local_runtime::',)),
            ] if any(token in stack for token in tokens)), 'other')
            categories[category] += amount
            if category == 'sqlite':
                part = next((name for name, tokens in [
                    ('pages', ('pcache1Alloc',)),
                    ('schema', ('sqlite3InitOne', 'sqlite3InitCallback')),
                    ('lookaside', ('setupLookaside',)),
                    ('statement_compilation', ('sqlite3Prepare',)),
                ] if any(token in stack for token in tokens)), 'other')
                sqlite[part] += amount
        assert sum(categories.values()) == total
        assert sum(sqlite.values()) == categories['sqlite']
        presence = {name: sum(amount for stack, amount in stacks if any(token in stack for token in tokens))
                    for name, tokens in [
                        ('prepared_transcript', ('observation::transcript::prepared',)),
                        ('response_cache', ('observation_response::cache',)),
                        ('checkpoint_capture', ('capture_checkpoint',)),
                    ]}
        binding = json.loads((directory / f'sample-{index}-binding.json').read_text())
        products.append({'side': side, 'sample': index, 'phase': binding['phase'],
                         'profile_sha256': hashlib.file_digest(profile.open('rb'), 'sha256').hexdigest(),
                         'raw_header': header, 'raw_sums': sums, 'raw_records': records,
                         'weighted_requested_bytes': weighted, 'collapsed_requested_bytes': total,
                         'priority_categories': categories, 'sqlite_priority_subgroups': sqlite,
                         'overlapping_presence': presence, 'allocator_numeric_properties': binding['stats'],
                         'largest_stacks': [{'requested_bytes': amount, 'stack': stack} for stack, amount in sorted(stacks, key=lambda value: value[1], reverse=True)[:12]]})
        print(side, binding['phase'], round(weighted / 2**20, 2), {key: round(value / 2**20, 2) for key, value in categories.items()}, flush=True)
assert len(products) == 12
(root / 'heap-audit.json').write_text(json.dumps({
    'scope': 'One separate replacement-tcmalloc product per side, six acknowledged phases including unchanged 128x8 at 32/130 seconds. Exact raw sampling headers and independent Poisson weights verified. Categories are disjoint allocation-stack origins, not PSS partitions or authoritative object ownership. Presence counters overlap. Requested estimates, allocator class charges, free spans and ordinary GNU PSS are different units.',
    'products': products}, indent=2) + '\n')
