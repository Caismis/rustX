import datetime,json,os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
source=repo/'docs/pi-durable-cost-model/evidence/read-cache-trial-20261027/recompute-direct.py'
s=source.read_text().replace("CASES = ['short-small', 'short-large', 'stream', 'large', 'tool', 'cancel']", "CASES = ['stream', 'cancel']\nPAIRS = 7").replace('2.919985580355516  # n=3, df=2;', '1.9431802805153022  # n=7, df=6;').replace('math.sqrt(3)','math.sqrt(len(values))').replace("n=3, values=values", "n=len(values), values=values").replace("manifest['pairs'] == 3", "manifest['pairs'] == PAIRS").replace('range(3)', 'range(PAIRS)')
(root/'recompute-confirmation.py').write_text(s)
base=root/'confirmation-cohorts';base.mkdir(exist_ok=False)
before=Path('/home/capi/.cache/rustx-pr485-next/candidate-d-build/conformance');after=root/'candidate-f-build/conformance'
plan=dict(reason='First 3-pair cohort had adverse no-live stream turn CPU and live cancel complete CPU in all pairs. Add 7 independent alternating pairs in both modes; preserve original and confirmation datasets, no replacement or selection.',cases=['stream','cancel'],pairs=7,products=56,source_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),steps=[])
for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
 name='direct-'+label
 plan['steps'].append(dict(name=name,command=[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(base/name),'--pairs','7','--observer-mode',mode,'--case','stream','--case','cancel']))
plan['steps'].append(dict(name='recompute',command=[sys.executable,str(root/'recompute-confirmation.py'),'--root',str(base)]))
def save():(base/'commands.json').write_text(json.dumps(plan,indent=2)+'\n')
save()
for step in plan['steps']:
 step.update(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');save()
 with (base/(step['name']+'.stdout' if step['name']!='recompute' else 'recomputed.json')).open('w') as out,(base/(step['name']+'.stderr')).open('w') as err:
  p=subprocess.run(step['command'],cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 step.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete' if p.returncode==0 else 'failed',exit=p.returncode);save();print(step['name'],p.returncode,flush=True);p.check_returncode()
