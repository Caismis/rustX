import json,subprocess,sys,shutil
from pathlib import Path
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
out=repo/'docs/pi-durable-cost-model/evidence/write-compute-20261027';out.mkdir(exist_ok=False)
plan=json.loads((root/'archive-plan.json').read_text());paths=sorted({str(p.relative_to(root)) for pattern in plan['patterns'] for p in root.glob(pattern) if p.is_file() and '__pycache__' not in p.parts})
subprocess.run([sys.executable,str(repo/'benchmarks/runtime/pack-evidence.py'),'--root',str(root),'--output',str(out/'raw.tar.xz'),*paths],check=True)
files={name:name for name in ['plan.json','host.json','paired-cohorts-audit.json','wal-f-audit.json','diagnostic-audit.json','validation-audit.json','f-retention-audit-notes.txt','rustx-transaction-cost-map.txt','pi-transaction-cost-map.txt','scalar-fragment-design.md','deepseek-cost-notes.txt','cpu-counts.json','wal-summary-d.json','wal-summary-f.json','diagnostic-audit-notes.txt','audit-paired-cohorts.py','audit-wal-f.py','audit-diagnostics.py','audit-validation.py','recompute-direct.py','recompute-confirmation.py','recompute-pi.py','audit-final-append.py','recompute-three-engine.py']}
files.update({'candidate-f-build/identity.json':'f-build-identity.json','baseline-d-build-identity.json':'d-build-identity.json','confirmation-cohorts/commands.json':'confirmation-commands.json','direct-cohorts/commands.json':'direct-commands.json','final-cohorts/commands.json':'final-commands.json','final-cohorts/pi-recomputed.json':'pi-recomputed.json','final-cohorts/append-audit.json':'append-audit.json','final-cohorts/three-engine-audit.json':'three-engine-audit.json'})
for src,dst in files.items():shutil.copy2(root/src,out/dst)
print('packaged',len(paths),'files',flush=True)
