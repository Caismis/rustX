import json,statistics
from pathlib import Path
r=Path(__file__).resolve().parent
out=[]
def p(s=''):out.append(s)
def load(name):return json.loads((r/name).read_text())
def ratio_table(d):
 keys=d['policy_metrics']; rows={}
 for s in d['summaries']:rows.setdefault((s['mode'],s['case']),{})[s['metric']]=s
 p('| Mode | Case | Turn wall | Turn CPU | Complete CPU | Complete writes | Sampled anon PSS |');p('| --- | --- | ---: | ---: | ---: | ---: | ---: |')
 for (mode,case),v in rows.items():p('| '+('no-live' if mode=='no-live-subscriber' else 'live')+' | '+case+' | '+' | '.join(f"{v[k]['median']:.4f}" for k in keys)+' |')
 p()
def ranged(s):return f"{s['median']:.3f} [{s['minimum']:.3f}, {s['maximum']:.3f}]"
p('## Same-engine F/D runtime comparison');p()
p('All ratios below are median within-pair F/D, lower favors F. The initial cohort has three alternating pairs per case and mode (72 products); complete counters run from exec through cleanup, including startup and verification. Short cases measure 32 turns after 8/64 history turns. The other cases measure one turn. The provider, full same-engine requests, native tools, late snapshot, historical inspection and close/reopen oracle are unchanged. All 846 initial paired requests passed.');p()
ratio_table(load('direct-cohorts/recomputed.json'))
p('The initial observations are mixed. Short-turn complete process writes fall about 2–2.5%; large first-output writes fall 4.39%, tool writes 1.88%, and stream/cancel writes are effectively unchanged. No-live short-large median wall/turn CPU are 1.020/1.027, live cancel wall is 1.207, and a live short-large pair reaches 2.852 for wall (1.304 for turn CPU). These samples remain included. No-live short-small, short-large and stream, and live short-large sampled anonymous PSS are higher in every initial pair, by 0.03–2.21% depending on the cell/pair. No universal speed or memory improvement is claimed.');p()
p('Initial no-live stream turn CPU is adverse in all three pairs: F 180/180/200 ms versus D 170/170/180 ms. Live cancel complete CPU is also adverse in all three: F 170/190/160 ms versus D 160/170/150 ms. This triggered a separately recorded seven-pair confirmation of stream and cancel in both modes (56 additional products, 28 paired requests). It does not replace the initial cohort or convert the selected follow-up into a predeclared global nonregression test.');p()
c=load('confirmation-cohorts/recomputed.json');rows={}
for s in c['summaries']:rows.setdefault((s['mode'],s['case']),{})[s['metric']]=s
p('Confirmation F/D medians **[complete seven-pair range]**:');p()
p('| Mode | Case | Turn wall | Turn CPU | Complete CPU | Complete writes | Sampled anon PSS |');p('| --- | --- | ---: | ---: | ---: | ---: | ---: |')
for (mode,case),v in rows.items():p('| '+('no-live' if mode=='no-live-subscriber' else 'live')+' | '+case+' | '+' | '.join(ranged(v[k]) for k in c['policy_metrics'])+' |')
p()
p('The two originally consistent adverse CPU cells are mixed in the confirmation, with median ratios 1.0. Their regression is not independently reproduced as a consistent effect; this is not proof of zero regression. CPU accounting has 10 ms resolution, material for the single-turn cases. All paired values, absolute counters, lifecycle wall, sampled total PSS/RSS and exploratory log-t intervals are retained in the raw recomputations.');p()
p('## Fresh F/Pi comparison');p()
p('These are newly measured F/Pi within-pair medians, three alternating pairs per case and mode. Historical D/Pi ratios are not multiplied by F/D. Rust/Pi use seven/four native tools and preserve their respective request/observation contracts; the core request oracle passes, while full cross-engine request equality is explicitly false.');p()
d=load('final-cohorts/pi-recomputed.json');ratio_table(d)
p('Absolute warm costs below are separate per-engine medians F / Pi, not the calculation used for paired ratios:');p()
p('| Mode | Case | Turn wall ms | Turn CPU ms | Complete writes MiB |');p('| --- | --- | ---: | ---: | ---: |')
for mode in ['no-live-subscriber','live-subscriber']:
 for case in ['short-small','short-large']:
  vals=[]
  for k in ['mean_turn_ms','turn_cpu_ms_per_turn','through_cleanup_process_write_mib']:
   rows=[x for x in d['paired_records'] if x['mode']==mode and x['case']==case and x['metric']==k]
   vals.append(f"{statistics.median(x['numerator'] for x in rows):.3f} / {statistics.median(x['denominator'] for x in rows):.3f}")
  p('| '+('no-live' if mode=='no-live-subscriber' else 'live')+' | '+case+' | '+' | '.join(vals)+' |')
p()
warm=[s for s in d['summaries'] if s['case'] in ['short-small','short-large']]
p('Warm short-turn paired medians remain '+', '.join(f"{min(s['median'] for s in warm if s['metric']==k):.2f}–{max(s['median'] for s in warm if s['metric']==k):.2f}× Pi {label}" for k,label in [('mean_turn_ms','wall'),('turn_cpu_ms_per_turn','turn CPU'),('through_cleanup_self_cpu_ms','complete CPU'),('through_cleanup_process_write_mib','complete process writes')])+'. Overall Pi parity is not achieved. Three pairs are exploratory and do not satisfy the seven-pair, per-case/per-mode uncertainty criterion in [comparison-policy.md](comparison-policy.md). Favorable first-request latency is not warm or overall parity.');p()
p('## Native DeepSeek Harness reference');p()
p('The additional reference uses pinned DeepSeek full SDK source `687f282e8625c6b8d11ff58211a90524be2e4317`, its native 25 tools, HTTP/SSE loop, compressed JSONL, checkpoint policy, notifications and native resume. Pi remains `90d863f7c1183b965f099855715d6e88c7b8a52c`. Three Latin-order rotations cover four supported cases (36 products). Tool and mid-turn cancellation remain unsupported by this adapter.');p()
p('DeepSeek `session/wait` idle does **not** await final flush/fsync. Prefix checkpoints are awaited before a model request; turn-end flush is asynchronous, and `allSettled` shutdown can suppress errors. Closed/resumed readability is checked, but is not proof of sync success or power-loss safety. Native prompt/tool/observation surfaces and CPU boundaries also differ. Consequently these are absolute native completion costs, with no equal-durability speedup ratio or full-lifecycle ranking. [Adapter and contract](../../benchmarks/runtime/deepseek-reference.md).');p()
p('Values are median **[three-repetition range]**. Wall is each product’s mean turn time, writes are per measured turn, and memory is maximum sampled turn anonymous PSS rather than peak. Rust/Pi count self CPU including in-process drivers; DeepSeek counts CLI/extant descendants and waited children, excluding its external Python driver.');p()
p('| Case | Engine | API completion ms | CPU ms/turn | Writes MiB/turn | Sampled anon PSS MiB |');p('| --- | --- | ---: | ---: | ---: | ---: |')
t=load('final-cohorts/three-engine-audit.json')
for g in t['groups']:
 vals=[]
 for k in ['mean_turn_ms','turn_cpu_ms_per_turn','turn_write_mib_per_turn','max_sampled_turn_anon_pss_mib']:
  lo,hi=g['ranges'][k];vals.append(f"{g['medians'][k]:.3f} [{lo:.3f}, {hi:.3f}]")
 p('| '+g['case']+' | '+{'rust':'rustX F','pi':'Pi Durable','deepseek':'DeepSeek SDK'}[g['engine']]+' | '+' | '.join(vals)+' |')
p()
p('## Canonical append control');p()
p('The 48 additional D/F products use histories 0/64/512/2048, 32 appends per product and three alternating pairs. Warm and reopened connections remain separate; reopened does not mean an evicted OS page cache. This control exercises canonical acceptance without provider request construction. F/D medians **[complete pair range]**:');p()
p('| Connection | History | Append wall | Append/reopen phase CPU | Complete CPU | Complete writes | Sampled anon PSS |');p('| --- | ---: | ---: | ---: | ---: | ---: | ---: |')
a=load('final-cohorts/append-audit.json')
for s in a['summaries']:
 p('| '+s['mode']+' | '+str(s['history'])+' | '+' | '.join(ranged(s['metrics'][k]['after_over_before']) for k in ['mean_append_ms','append_phase_cpu_ms','through_cleanup_self_cpu_ms','through_cleanup_process_write_mib','max_sampled_anon_pss_mib'])+' |')
p()
(r/'report-tables.md').write_text('\n'.join(out)+'\n')
