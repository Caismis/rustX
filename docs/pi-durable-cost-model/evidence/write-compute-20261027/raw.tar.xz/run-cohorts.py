import argparse,datetime,hashlib,json,os,subprocess,sys,shutil
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
before=Path('/home/capi/.cache/rustx-pr485-next/candidate-d-build/conformance')
after=root/'candidate-f-build/conformance'; pi=Path('/home/capi/Documents/codes/pi-rustx-benchmark')
p=argparse.ArgumentParser();p.add_argument('--stage',choices=['direct','final'],required=True);a=p.parse_args()
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def identity(binary):
 data=json.loads((binary.parent/'identity.json').read_text());assert data['verified'] and data['build_exit']==0 and data['sha256']==sha(binary)
 assert data['production_tree']==subprocess.check_output(['git','rev-parse',data['head']+':src'],cwd=repo,text=True).strip()
 for f,h in data['harness'].items():assert sha(repo/f)==h
 return data
ids={n:identity(b) for n,b in [('before',before),('after',after)]};assert ids['before']['harness']==ids['after']['harness'];assert ids['before']['rustc']==ids['after']['rustc'];assert ids['before']['sha256']!=ids['after']['sha256']
base=root/('direct-cohorts' if a.stage=='direct' else 'final-cohorts');base.mkdir(exist_ok=False)
steps=[]
def add(name,cmd,audit=False,out=None):steps.append(dict(name=name,command=cmd,kind='audit' if audit else 'cohort',stdout=str(out or base/(name+'.stdout')),stderr=str(base/(name+'.stderr')),status='pending'))
if a.stage=='direct':
 for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
  name='direct-'+label;add(name,[sys.executable,'benchmarks/runtime/compare-revisions.py','--before',str(before),'--after',str(after),'--output',str(base/name),'--pairs','3','--observer-mode',mode])
 add('recompute',[sys.executable,'docs/pi-durable-cost-model/evidence/read-cache-trial-20261027/recompute-direct.py','--root',str(base)],True,base/'recomputed.json')
else:
 for mode,label in [('no-live-subscriber','no-live'),('live-subscriber','live')]:
  name='pi-'+label;add(name,[sys.executable,'benchmarks/runtime/controller.py','--rust',str(after),'--pi',str(pi),'--output',str(base/name),'--pairs','3','--observer-mode',mode])
 for cold in [False,True]:
  name='append-cold' if cold else 'append-warm';add(name,[sys.executable,'benchmarks/runtime/compare-append.py','--before',str(before),'--after',str(after),'--output',str(base/name),'--pairs','3',*(['--cold'] if cold else [])])
 add('three-engine',[sys.executable,'benchmarks/runtime/deepseek-compare.py','--rust',str(after),'--pi',str(pi),'--deepseek','/home/capi/.cache/rustx-pr485-next/deepseek-checkout','--output',str(base/'three-engine'),'--repetitions','3'])
 for name in ['recompute-pi.py','audit-final-append.py','recompute-three-engine.py']:
  shutil.copy2(Path('/home/capi/.cache/rustx-pr485-next')/name,root/name)
 add('audit-pi',[sys.executable,str(root/'recompute-pi.py'),'--root',str(base),'--identity',str(after.parent/'identity.json'),'--expect-rust-sha256',ids['after']['sha256']],True,base/'pi-recomputed.json')
 add('audit-append',[sys.executable,str(root/'audit-final-append.py'),'--root',str(base),'--output',str(base/'append-audit.json'),'--binary-verification','strict','--before-identity',str(before.parent/'identity.json'),'--after-identity',str(after.parent/'identity.json'),'--expect-before-sha256',ids['before']['sha256'],'--expect-after-sha256',ids['after']['sha256']],True)
 add('audit-three-engine',[sys.executable,str(root/'recompute-three-engine.py'),'--dataset',str(base/'three-engine'),'--output',str(base/'three-engine-audit.json'),'--expected-rust-sha256',ids['after']['sha256'],'--expected-harness-revision',subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()],True)
plan=dict(stage=a.stage,identities=ids,steps=steps,explicit_environment={'UV_OFFLINE':'1'})
def save():(base/'commands.json').write_text(json.dumps(plan,indent=2)+'\n')
save()
for s in steps:
 s.update(status='running',start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
 with Path(s['stdout']).open('w') as out,Path(s['stderr']).open('w') as err:r=subprocess.run(s['command'],cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 s.update(status='complete' if r.returncode==0 else 'failed',exit=r.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save();print(s['name'],r.returncode,flush=True)
 r.check_returncode()
