from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys
repo=Path('/workspace/rustX-admission-diagnostics');root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import CASES,TEST,run
paths={'control':Path('/workspace/issue-481-evidence/checkpoint-admission-build-2/conformance'),'diagnostic':Path('/workspace/issue-481-evidence/checkpoint-admission-diagnostics-build/conformance')}
ids={k:json.loads((p.parent/'identity.json').read_text()) for k,p in paths.items()}
for k,p in paths.items():assert ids[k]['verified'] and hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==ids[k]['sha256']
(root/'build-identities.json').write_text(json.dumps(ids,indent=2)+'\n')
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ['TOKEN','SECRET','CREDENTIAL','API_KEY'])};env['UV_CACHE_DIR']='/workspace/.uv-cache'
records=[]
for mode in ['no-live-subscriber','live-subscriber']:
 for case in CASES:
  for name,binary in paths.items():
   stem=root/f'{mode}-{case}-{name}'
   result=run([str(binary),TEST,'--exact','--ignored','--nocapture'],stem,case,env|dict(RUSTX_BENCH_OBSERVER_MODE=mode,RUSTX_BENCH_CASE=case,RUSTX_BENCH_OUTPUT=str(stem.with_suffix('.json'))),repo/'test-support/fake-provider')
   assert result['accepted'],stem
  subprocess.run(['node','benchmarks/runtime/compare-http.mjs',str(root/f'{mode}-{case}-control.json'),str(root/f'{mode}-{case}-diagnostic.json'),str(root/f'{mode}-{case}-comparison.json')],cwd=repo,check=True)
  s=json.loads((root/f'{mode}-{case}-diagnostic.json').read_text());c=s['checkpoint_admission_diagnostics'];assert c['proved']+c['deferred']>0
  records.append(dict(mode=mode,case=case,**c));print(records[-1],flush=True)
(root/'proof-counts.json').write_text(json.dumps(records,indent=2)+'\n')
micro_env=env|dict(RUSTX_CHECKPOINT_DIAGNOSTIC_INPUT='/workspace/issue-481-evidence/checkpoint-admission-comparison/no-live-subscriber/0-short-large-after.json',RUSTX_CHECKPOINT_DIAGNOSTIC_OUTPUT=str(root/'predicate-micro.json'))
with (root/'predicate-micro.log').open('x') as log:
 subprocess.run([str(paths['diagnostic']),'agent_loop::runtime_benchmark::measure_checkpoint_admission_predicates','--exact','--ignored','--nocapture'],env=micro_env,cwd=repo,stdout=log,stderr=subprocess.STDOUT,check=True)
print('24 diagnostic/control products, 12 full comparisons and predicate microbenchmark passed',flush=True)
