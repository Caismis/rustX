import ast,collections,json,re,struct
from pathlib import Path
root=Path(__file__).resolve().parent
summary={}
for engine in ['before','after']:
 path=root/('complete-'+engine);before=json.loads((path/'before_measured_turns-database.json').read_text())[0];after=json.loads((path/'after_turns-database.json').read_text())[0]
 owners=collections.defaultdict(set)
 for snapshot in [before,after]:
  for name,page,*_ in snapshot['pages']:owners[page].add(name)
 frames=collections.Counter();commits=0;pending={};phase='startup';allcommits=collections.Counter();unresolved=0;datawrites=collections.Counter();txpages=[];tx=collections.Counter();active=False
 for line in (path/'calls.strace').read_text().splitlines():
  m=re.match(r'(\d+)\s+(.*)',line)
  if not m:continue
  pid,call=m.groups()
  if '<unfinished ...>' in call:
   assert pid not in pending;pending[pid]=call.split('<unfinished ...>')[0];continue
  m=re.match(r'<\.\.\. \w+ resumed>(.*)',call)
  if m:
   assert pid in pending,(pid,call);call=pending.pop(pid)+m[1]
  if 'UNIX-STREAM' in call and 'before_measured_turns' in call:phase='steady';active=True
  if 'UNIX-STREAM' in call and 'after_turns' in call:phase='after_turns';active=False
  m=re.match(r'pwrite64\(\d+<([^>]+-wal)>, ("(?:\\.|[^"\\])*"), (\d+), (\d+)\) = (\d+)$',call)
  if not m:continue
  fn,quoted,n,offset,ret=m.groups();n,offset,ret=map(int,(n,offset,ret));assert ret==n
  if active:assert fn==before['path']+'-wal',('unexpected steady WAL',fn)
  if n!=24:continue
  data=ast.literal_eval('b'+quoted);assert len(data)==24
  page,size=struct.unpack('>II',data[:8]);assert (offset-32)%4120==0
  if active:
   frames[page]+=1;tx[page]+=1
  if size:
   allcommits[phase]+=1
   if active:commits+=1;txpages.append(dict(tx));tx.clear()
 assert not pending;assert not tx;assert phase=='after_turns';assert commits>0
 bytable=collections.Counter()
 for page,n in frames.items():bytable['|'.join(sorted(owners[page])) or '<unmapped>']+=n
 delta={k:after['counts'][k]-before['counts'].get(k,0) for k in after['counts'] if after['counts'][k]!=before['counts'].get(k,0)}
 s={'steady_turns':32,'wal_write_commits':commits,'wal_frames':sum(frames.values()),'wal_frame_bytes':sum(frames.values())*4120,'commits_by_phase':allcommits,'wal_frames_by_snapshot_page_owner':dict(bytable.most_common()),'net_row_count_changes':delta,'transaction_page_counts':[sum(t.values()) for t in txpages],'limitations':'WAL write-commit markers, not read-only SQL commits. Snapshot dbstat ownership at endpoints; mixed owners or unmapped pages explicit, intermediate page reuse not excluded. No exclusive timing or semantic parity inference.'}
 summary[engine]=s
(root/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({e:{k:v for k,v in s.items() if k not in ['sql_counts','v8_cpu','transaction_page_counts']} for e,s in summary.items()},indent=2))
