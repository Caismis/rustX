import datetime,hashlib,json,os,re,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
def snap():
 return {str(p.relative_to(repo)):hashlib.sha256(p.read_bytes()).hexdigest() for f in ('src','tests') for p in sorted((repo/f).rglob('*')) if p.is_file()}
assert json.loads((root/'build-receipt.json').read_text())['exit']==0
assert snap()==json.loads((root/'source-candidate.json').read_text())
binaries={}
for line in (root/'build.stdout').read_text().splitlines():
 if not line.startswith('{'):continue
 v=json.loads(line)
 if v.get('reason')=='compiler-artifact' and v.get('executable') and v['target']['name'] in ('rustx','durable','process') and v['profile']['test']:binaries[v['target']['name']]=v['executable']
assert set(binaries)=={'rustx','durable','process'}
rows=[]
prior=json.loads(Path('/home/capi/.cache/rustx-pr485-content-20261102/checks-third/check-build-commands.json').read_text())
prior.insert(-1, {'label':'tests-artifact-lineage','command':[binaries['rustx'],'artifact_lineage_tests::','--test-threads=2']})
for old in prior:
 label=old['label'];cmd=old['command'].copy()
 if label=='tests-build':continue
 if label.startswith('tests-'):
  key='durable' if label=='tests-durable' else 'process' if label=='tests-process' else 'rustx'
  cmd[0]=binaries[key]
 item={'label':label,'command':cmd,'start_utc':now()};rows.append(item)
 with (root/(label+'.stdout')).open('x') as so,(root/(label+'.stderr')).open('x') as se:
  done=subprocess.run(cmd,cwd=repo,env=os.environ|{'CARGO_TARGET_DIR':'/home/capi/.cache/rustx-pr485-target','CARGO_BUILD_JOBS':'2'},stdout=so,stderr=se)
 item.update(exit=done.returncode,end_utc=now())
 (root/'checks.json').write_text(json.dumps(rows,indent=2)+'\n')
 print(label,done.returncode,flush=True)
 if done.returncode:
  print((root/(label+'.stdout')).read_text()[-6000:]);print((root/(label+'.stderr')).read_text()[-4000:]);raise SystemExit(done.returncode)
assert snap()==json.loads((root/'source-candidate.json').read_text())
summary={'accepted':True,'source_inputs_unchanged':True,'checks':len(rows),'tests':[]}
for item in rows:
 if item['label'].startswith('tests-'):
  text=(root/(item['label']+'.stdout')).read_text()
  matches=re.findall(r'test result: ok[.] (\d+) passed; (\d+) failed; (\d+) ignored;',text)
  assert len(matches)==1
  passed,failed,ignored=map(int,matches[0]);assert failed==0
  summary['tests'].append({'label':item['label'],'passed':passed,'failed':failed,'ignored':ignored})
summary['passed']=sum(v['passed'] for v in summary['tests'])
summary['ignored']=sum(v['ignored'] for v in summary['tests'])
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
