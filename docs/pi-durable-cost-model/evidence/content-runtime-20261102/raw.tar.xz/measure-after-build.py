import datetime,json,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
for attempt in range(720):
 p=r/'candidate-complete-build/identity.json'
 if p.exists() and json.loads(p.read_text()).get('verified') is True:break
 for name in ['candidate-build.stderr','candidate-complete-build/build.stderr']:
  p=r/name
  if p.exists() and ('Traceback (most recent call last)' in p.read_text() or 'error: could not compile' in p.read_text()):raise SystemExit('build failed; no measurement')
 time.sleep(5)
else:raise SystemExit('build wait timeout')
commands=[('premeasurement',['python3',str(r/'premeasurement.py'),'--output',str(r/'premeasurement.json')]),('formal',['python3',str(r/'run-cohorts.py'),'--stage','direct']),('diagnostics',['python3',str(r/'run-diagnostics.py')]),('formal-audit',['python3',str(r/'direct-audit.py'),'--output',str(r/'direct-audit.json')]),('diagnostic-audit',['python3',str(r/'diagnostic-audit.py'),'--output',str(r/'diagnostic-audit.json')]),('summary',['python3',str(r/'summarize-results.py')])]
rows=[]
for label,cmd in commands:
 row={'label':label,'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};rows.append(row)
 with (r/('workflow-'+label+'.stdout')).open('x') as out,(r/('workflow-'+label+'.stderr')).open('x') as err:done=subprocess.run(cmd,cwd=repo,stdout=out,stderr=err)
 row.update(exit=done.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(r/'measurement-workflow-commands.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,done.returncode,flush=True)
 if done.returncode:raise SystemExit(done.returncode)
