#!/usr/bin/env python3
"""Supplementary exploratory stream replication; raw arithmetic, no products."""
import argparse,datetime,hashlib,importlib.util,json,statistics,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ORIGINAL=Path('/home/capi/.cache/rustx-pr485-content-20261102')
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise ValueError(message)
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,default=HERE);p.add_argument('--raw-only',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();r=a.root
 require(not a.output.exists(),'retain previous attempt')
 spec=importlib.util.spec_from_file_location('direct',r/'direct-audit.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 m.MATH=m.module('replication_math',r/'recompute-pi.py','e2879454bd2c6ed1add046dd55d6ceaa3c7451087ee92e6e008afcbf7a7e1ac3')
 report={'accepted':False,'raw_only':a.raw_only,'errors':[],'script_sha256':sha(Path(__file__)),'products':[],'comparisons':[],'cells':[],'identities':{},'scope':'Exploratory replication before implementation. Separate from the final formal matrix; not premeasurement-preregistered and not pooled.'}
 try:
  for name,head,binary in [('pre-metadata','2184461af208af8480a53497a91aabb059c44e16','8b19873c647647f9eda7a331e071539a18d07f1266ec0e2d1130f8515fc0d2ce'),('baseline-build','a664c5a96546c3e49c5638c3c959b08df3c77fec','62c2e96a5a611de0df64e35065ae9bfd04a794bafef882a2214244ff1cb4587e')]:
   ident=load(r/name/'identity.json');require(ident['head']==head and ident['sha256']==binary and ident['verified'],'replication binary identity differs')
   if not a.raw_only:require(sha(Path(ident['binary']))==binary,'actual replication binary differs')
   report['identities'][name]={k:ident[k] for k in ('head','production_tree','sha256')}
  commands=load(r/'stream-replication-commands.json');require(len(commands)==2 and all(x['exit']==0 for x in commands),'replication producer failed')
  require(commands[0]['end_utc']<=commands[1]['start_utc'],'replication producers overlap')
  report['commands_sha256']=sha(r/'stream-replication-commands.json')
  for row,mode in zip(commands,['no-live-subscriber','live-subscriber']):
   folder='stream-replication-'+mode;d=r/folder;manifest=load(d/'manifest.json')
   expected=['taskset','--cpu-list','2,8','python3','benchmarks/runtime/compare-revisions.py','--before',str(ORIGINAL/'pre-metadata/conformance'),'--after',str(ORIGINAL/'baseline-build/conformance'),'--case','stream','--pairs','6','--observer-mode',mode,'--output',str(ORIGINAL/folder)]
   require(row['command']==expected,'replication argv differs')
   require(manifest['cases']==['stream'] and manifest['pairs']==6 and manifest['observer_mode']==mode and manifest['clock_ticks']==100,'replication manifest differs')
   require({k:v['sha256'] for k,v in manifest['executables'].items()}=={'before':report['identities']['pre-metadata']['sha256'],'after':report['identities']['baseline-build']['sha256']},'replication executable pin differs')
   paired={}
   for pair in range(6):
    values={}
    for engine in ['before','after']:
     rawpath=d/f'{pair}-stream-{engine}.json';procpath=rawpath.with_suffix('.process.json');raw,proc=load(rawpath),load(procpath)
     require(raw['schema']==87 and raw['history']==0 and raw['measured']==1,'replication workload differs')
     result=m.derived_product(raw,proc,'stream',mode,engine,manifest)
     report['products'].append({'file':str(rawpath.relative_to(r)),'sha256':sha(rawpath),'process_sha256':sha(procpath),'derived':result})
     values[engine]=result['metrics']
    cp=d/f'{pair}-stream-comparison.json';comparison=load(cp)
    require(comparison['observer_mode']==mode and comparison['case']=='stream' and len(comparison['checked'])==1 and all(x['coreSemanticEqual'] is True and x['fullSemanticRequestEqual'] is True for x in comparison['checked']),'replication semantic requests differ')
    report['comparisons'].append({'file':str(cp.relative_to(r)),'sha256':sha(cp)})
    for key in values['before']:
     b,c=values['before'][key],values['after'][key];delta=None if b in (None,0) or c is None else (c/b-1)*100
     paired.setdefault(key,[]).append(delta)
   report['cells'].append({'mode':mode,'metrics':{k:m.descriptive(v) for k,v in paired.items()},'manifest_sha256':sha(d/'manifest.json')})
  require(len(report['products'])==24 and len(report['comparisons'])==12,'replication count differs')
  report['accepted']=True
 except Exception as error:report['errors'].append(type(error).__name__+': '+str(error))
 a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'accepted':report['accepted'],'errors':report['errors']}));return int(not report['accepted'])
if __name__=='__main__':raise SystemExit(main())
