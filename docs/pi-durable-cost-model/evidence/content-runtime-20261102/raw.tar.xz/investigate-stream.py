import subprocess,os,json,datetime,hashlib
from pathlib import Path
r=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
rows=[]
for mode in ('no-live-subscriber','live-subscriber'):
 cmd=['taskset','--cpu-list','2,8','python3','benchmarks/runtime/compare-revisions.py','--before',str(r/'pre-metadata/conformance'),'--after',str(r/'baseline-build/conformance'),'--case','stream','--pairs','6','--observer-mode',mode,'--output',str(r/('stream-replication-'+mode))]
 row={'command':cmd,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()};rows.append(row)
 with (r/('replication-'+mode+'.stdout')).open('x') as out,(r/('replication-'+mode+'.stderr')).open('x') as err: result=subprocess.run(cmd,cwd=repo,stdout=out,stderr=err)
 row.update(exit=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());(r/'stream-replication-commands.json').write_text(json.dumps(rows,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
 print(mode,'complete',flush=True)
