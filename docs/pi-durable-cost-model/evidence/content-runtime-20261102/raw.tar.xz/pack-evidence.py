#!/usr/bin/env python3
"""Package completed content-indexing evidence; never execute products or auditors.

Run after all evidence writers stop and strict formal/diagnostic audits and the
summary have succeeded. Failed attempts remain payload, not successful results.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
import os
import re
from pathlib import Path, PurePosixPath
import shlex
import stat
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
DESTINATION = REPO / 'docs/pi-durable-cost-model/evidence/content-runtime-20261102'
FORMAT = 'rustx-content-runtime-raw-evidence-v1'
SKIP_DIRECTORIES = {'.git', 'target', 'node_modules', '__pycache__', '.venv', '.pytest_cache',
                    'archive', 'archives', 'extract', 'extracted', 'archive-check'}
COMMANDS = {
    'replication': ['python3', 'replication-audit.py', '--root', '.', '--raw-only', '--output', '../replication-raw-audit.json'],
    'formal': ['python3', 'direct-audit.py', '--root', '.', '--raw-only', '--output', '../direct-raw-audit.json'],
    'diagnostic': ['python3', 'diagnostic-audit-corrected.py', '--root', '.', '--raw-only', '--formal-audit', '../direct-raw-audit.json', '--output', '../diagnostic-raw-audit.json'],
    'summary': ['python3', 'summarize-results.py', '--root', '.', '--audit', '../direct-raw-audit.json', '--output', '../report-data.json', '--markdown', '../report-tables.md'],
}
RULES = {
    'include': ['All regular evidence under the current root, including failed checks/audits, all command/stdout/stderr/source snapshots and exploratory history if any.',
                'All 144 fresh Rust formal products, 24 separate exploratory stream-replication products and 8 isolated column/WAL products; no Pi/DeepSeek executes this round.',
                'Raw SQLite/database/WAL traces and other binary-format evidence are retained; no CPU profile products are planned.',
                'Fixed previous strict report, archive hash/summary and previous portable-verification receipt; old raw remains a separate pinned dependency.',
                'Exact build receipts and complete Cargo logs, all current source analysis, scripts, and hash-bound repository harness sources.'],
    'exclude': ['Compiled executable/object/library formats and conformance executable artifacts, not arbitrary binary data.',
                'Dependency/build caches, Python bytecode and archive/extraction directories.',
                'Tar/zip archive containers; raw compressed evidence such as .xz/.gz/.zstd is retained.',
                'Symlinks and nonregular filesystem nodes are recorded as exclusions and never followed.'],
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(Path(path).read_text())


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def safe_name(name):
    require(isinstance(name, str) and name and '\\' not in name and '\x00' not in name,
            'unsafe archive path: ' + repr(name))
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name and
            all(part not in ('', '.', '..') for part in name.split('/')), 'unsafe archive path: ' + name)


def fingerprint(path):
    item = Path(path).lstat()
    require(stat.S_ISREG(item.st_mode), 'not a regular file: ' + str(path))
    return item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns


def skip_path(relative, directory=False):
    for part in relative.parts if directory else relative.parts[:-1]:
        if part in SKIP_DIRECTORIES or part.startswith(('archive-', 'extract-')):
            return 'dependency/build/cache/archive/extract directory'
    name = relative.name
    if name == 'conformance':
        return 'compiled conformance artifact'
    if name.endswith(('.tar', '.tar.xz', '.tar.gz', '.tgz', '.zip', '.pyc')):
        return 'archive container or Python bytecode'
    return None


def compiled_format(path):
    # Raw binary evidence (SQLite, pprof .cpu/protobuf, WAL) is not executable.
    with Path(path).open('rb') as stream:
        head = stream.read(64)
        if head.startswith((b'\x7fELF', b'!<arch>\n', b'\x00asm', b'BC\xc0\xde')):
            return True
        if head[:4] in (b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe',
                        b'\xca\xfe\xba\xbe', b'\xbe\xba\xfe\xca', b'\xca\xfe\xba\xbf', b'\xbf\xba\xfe\xca'):
            return True
        if head.startswith(b'MZ') and len(head) == 64:
            stream.seek(int.from_bytes(head[60:64], 'little'))
            return stream.read(4) == b'PE\x00\x00'
    return False


def inventory(root, external):
    selected, excluded = {}, []
    def add(path, name):
        safe_name(name)
        require(name != 'MANIFEST.json', 'input conflicts with generated MANIFEST.json')
        relative = Path(name)
        item = path.lstat()
        reason = skip_path(relative)
        if stat.S_ISLNK(item.st_mode):
            reason = 'symlink; not followed'
        elif not stat.S_ISREG(item.st_mode):
            reason = 'nonregular file'
        elif reason is None and compiled_format(path):
            reason = 'compiled executable/object/library format'
        if reason:
            excluded.append({'path': name, 'source': str(path), 'reason': reason})
        else:
            require(name not in selected, 'archive name collision: ' + name)
            selected[name] = path
    for directory, folders, files in os.walk(root, followlinks=False):
        kept = []
        for name in sorted(folders):
            path = Path(directory) / name
            relative = path.relative_to(root)
            item = path.lstat()
            reason = 'symlink directory; not followed' if stat.S_ISLNK(item.st_mode) else skip_path(relative, True)
            if reason:
                excluded.append({'path': relative.as_posix() + '/', 'source': str(path), 'reason': reason})
            else:
                kept.append(name)
        folders[:] = kept
        for name in sorted(files):
            path = Path(directory) / name
            add(path, path.relative_to(root).as_posix())
    for name, path in sorted(external.items()):
        if name in selected:
            require(sha(selected[name]) == sha(path), 'external mount conflicts: ' + name)
        else:
            add(path, name)
        require(name in selected, 'required external evidence excluded: ' + name)
    return dict(sorted(selected.items())), sorted(excluded, key=lambda row: row['path'])


def harness_mount(root, repo):
    candidate = load(root / 'candidate-complete-build/identity.json')
    fixtures = load(root / 'direct-cohorts/commands.json')['source_before']['fixtures']
    require(isinstance(fixtures, dict) and fixtures and candidate['harness'], 'empty recorded harness inputs')
    expected = dict(fixtures)
    for name, digest in candidate['harness'].items():
        require(name not in expected or expected[name] == digest, 'harness/fixture hashes conflict')
        expected[name] = digest
    external = {}
    for name, digest in expected.items():
        safe_name(name)
        path = repo / name
        require(not path.is_symlink() and path.resolve().is_relative_to(repo.resolve()) and sha(path) == digest,
                'hash-bound harness missing or changed: ' + name)
        external['frozen-harness/' + name] = path
    return external


def verify_wal_parser_correction(root):
    receipt = load(root / 'wal-parser-correction.json')
    pre = load(root / 'premeasurement.json')
    require(receipt['all_original_frozen_scripts_unchanged'] is True and receipt['frozen_scripts'] == pre['scripts']
            and len(pre['scripts']) == 13 and receipt['premeasurement_sha256'] == sha(root / 'premeasurement.json')
            and all(sha(root / name) == digest for name,digest in pre['scripts'].items()), 'original frozen scripts changed')
    failed = load(root / 'diagnostic-audit.json')
    require(failed['accepted'] is False and failed['errors'] == ['wal-baseline-short-small: ValueError: WAL frame headers and page payload counts differ']
            and receipt['failed_diagnostic_audit_sha256'] == sha(root / 'diagnostic-audit.json'), 'original WAL audit differs')
    old = r'(\d+)\) = (\d+)$'
    new = r'(\d+)\s*\)\s*=\s*(\d+)$'
    import difflib
    require(set(receipt['patches']) == {'analyze-wal-verified.py','diagnostic-audit.py'}, 'WAL correction inventory differs')
    for original,corrected in [('analyze-wal-verified.py','analyze-wal-corrected.py'),('diagnostic-audit.py','diagnostic-audit-corrected.py')]:
        source = (root / original).read_text()
        expected = source.replace(old,new).replace("f'wal-summary-{label}.json'", "f'wal-summary-{label}-corrected.json'")
        item = receipt['patches'][original]
        require(source.count(old) == 1 and (root / corrected).read_text() == expected
                and item['corrected'] == corrected and item['original_sha256'] == sha(root / original)
                and item['corrected_sha256'] == sha(root / corrected), 'WAL correction exceeds parser whitespace and new summary names')
        require(item['diff'] == ''.join(difflib.unified_diff(source.splitlines(True),expected.splitlines(True),fromfile=original,tofile=corrected)), 'WAL correction diff differs')


def preflight(root, selected, repo):
    verify_wal_parser_correction(root)
    required = ['pack-evidence.py', 'verify-archive.py', 'direct-audit.py', 'diagnostic-audit-corrected.py', 'summarize-results.py',
                'direct-audit.json', 'diagnostic-audit-final.json', 'report-data.json', 'report-tables.md', 'premeasurement.json',
                'diagnostic-commands.json', 'direct-cohorts/commands.json', 'baseline-build/original-identity.json', 'origin.json',
                'reference-pins/fixed-references.json', 'reference-pins/previous-summary.json', 'reference-pins/previous-portable-verification.json']
    required += [folder + '/' + name for folder in ('baseline-build', 'candidate-complete-build')
                 for name in ('identity.json', 'build.stdout', 'build.stderr', 'clean.stdout', 'clean.stderr')]
    require(all(name in selected for name in required), 'required evidence excluded/missing: ' + ', '.join(name for name in required if name not in selected))
    formal, diagnostic, report = (load(root / name) for name in ('direct-audit.json', 'diagnostic-audit-final.json', 'report-data.json'))
    for value, script in ((formal, 'direct-audit.py'), (diagnostic, 'diagnostic-audit-corrected.py')):
        require(value['accepted'] is True and value['errors'] == [] and value['mode'] == 'strict'
                and value['strict_identity_verified'] is True, 'strict report not accepted')
        require(value['script_sha256'] == sha(root / script), 'strict auditor changed')
    require(formal['raw_only'] is False and set(formal['datasets']) == {'direct'}, 'formal scope differs')
    data = formal['datasets']['direct']
    require((data['derived_products'], data['valid_comparisons'], data['checked_requests']) == (144, 72, 1692)
            and len(data['products']) == 144 and len(data['comparisons']) == 72, 'formal coverage differs')
    require(formal['validation']['successful_complete_queues'] and formal['validation']['bound_directory'] in formal['validation']['successful_complete_queues'], 'candidate-bound successful correctness queue absent')
    candidate = load(root / 'candidate-complete-build/identity.json')
    binding = candidate['validation']
    require(binding['directory'] == formal['validation']['bound_directory'], 'candidate/strict correctness binding differs')
    safe_name(binding['directory'])
    require('/' not in binding['directory'], 'validation directory is not an immediate child')
    for name, digest in binding['files'].items():
        safe_name(name)
        require(sha(root / binding['directory'] / name) == digest, 'bound correctness file changed')
    require(diagnostic['recorded_build_identity_verified'] is True and diagnostic['actual_binary_verified'] is True
            and diagnostic['product_count'] == 8 and not diagnostic.get('profiles') and all(len(diagnostic[key]) == 4 for key in ('columns', 'wal')), 'diagnostic scope/identity differs')
    require(diagnostic['formal_audit']['mode'] == 'strict' and diagnostic['formal_audit']['sha256'] == sha(root / 'direct-audit.json'), 'diagnostic/formal binding differs')
    require(report['accepted'] is True and report['script_sha256'] == sha(root / 'summarize-results.py')
            and report['current_audit_sha256'] == sha(root / 'direct-audit.json'), 'summary binding differs')
    require((report['current_rust_products'], report['fresh_paired_products'], report['fixed_pi_products'], report['fixed_deepseek_products']) == (72, 144, 60, 12), 'summary product scope differs')
    protocol = load(root / 'direct-cohorts/commands.json')['protocol']
    require(protocol['cpu_affinity'] == [2, 8] and protocol['pairs_per_cell'] == 6
            and protocol['products'] == 144 and protocol['paired_comparisons'] == 72
            and protocol['checked_request_pairs'] == 1692
            and protocol['order'] == ['before_after', 'after_before'] * 3, 'formal protocol differs')
    premeasurement = load(root / 'premeasurement.json')
    require(premeasurement['accepted'] is True and premeasurement['errors'] == []
            and formal['premeasurement']['sha256'] == sha(root / 'premeasurement.json'), 'premeasurement binding differs')
    require(all(name in selected and sha(root / name) == digest for name, digest in premeasurement['scripts'].items()), 'frozen producer/auditor scripts changed')
    # Recheck the exact files referenced by the accepted strict results. Raw-only
    # verification after extraction independently re-derives all arithmetic.
    for row in data['products']:
        require(row['file'] in selected and sha(root / row['file']) == row['raw_sha256'], 'raw formal product changed')
        process = row['file'][:-5] + '.process.json'
        require(process in selected and sha(root / process) == row['process_sha256'], 'formal process evidence changed')
    for row in data['comparisons'] + data['manifests']:
        require(row['file'] in selected and sha(root / row['file']) == row['sha256'], 'formal comparison/manifest changed')
    pins = load(root / 'reference-pins/fixed-references.json')
    safe_name(pins['reference_audit'])
    require('/' not in pins['reference_audit'] and sha(root / 'reference-pins' / pins['reference_audit']) == pins['reference_audit_sha256'], 'fixed reference audit differs')
    require(report['reference_pin_sha256'] == sha(root / 'reference-pins/fixed-references.json') and report['references'] == pins, 'summary reference pins differ')
    previous, receipt = (load(root / 'reference-pins' / name) for name in ('previous-summary.json', 'previous-portable-verification.json'))
    require(receipt['accepted'] is True and receipt['errors'] == [] and receipt['strict_source_report_sha256'] == pins['reference_audit_sha256']
            and receipt['summary_sha256'] == sha(root / 'reference-pins/previous-summary.json'), 'prior portable receipt differs')
    require(previous['archive_sha256'] == receipt['archive_sha256'] == pins['reference_archive_sha256']
            and previous['archive_bytes'] == receipt['archive_bytes'] == pins['reference_archive_bytes']
            and previous['manifest_sha256'] == receipt['manifest_sha256'] == pins['archive_manifest_sha256'], 'prior archive pin differs')
    before = load(root / 'baseline-build/identity.json')
    require(before['head'] == 'a664c5a96546c3e49c5638c3c959b08df3c77fec' and before['sha256'] == '62c2e96a5a611de0df64e35065ae9bfd04a794bafef882a2214244ff1cb4587e', 'fresh Rust baseline identity differs')
    original = load(root / 'baseline-build/original-identity.json')
    require({key: value for key, value in before.items() if key != 'binary'}
            == {key: value for key, value in original.items() if key != 'binary'}, 'copied baseline differs from original receipt')
    require(before['production_tree'] == 'dd0b2c579159d532420979209157e94d32d80131', 'baseline source tree differs')
    replication = load(root / 'replication-audit-final.json')
    require(replication['accepted'] is True and replication['raw_only'] is False and not replication['errors']
            and len(replication['products']) == 24 and len(replication['comparisons']) == 12,
            'stream replication audit differs')
    require(replication['script_sha256'] == sha(root / 'replication-audit.py'), 'replication auditor changed')
    for row in replication['products']:
        require(row['file'] in selected and sha(root / row['file']) == row['sha256'], 'replication product changed')
        require(sha(root / (row['file'][:-5] + '.process.json')) == row['process_sha256'], 'replication process changed')
    phases = {'formal_products': 144, 'diagnostic_products': 8, 'new_pi_products': 0, 'new_deepseek_products': 0,
              'baseline_schema': 87, 'candidate_schema': 88,
              'paired_comparisons': 72, 'checked_request_pairs': 1692, 'cpu_affinity': [2, 8],
              'profile_products': 0, 'supplementary_products': 24,
              'baseline': {key: before[key] for key in ('head', 'production_tree', 'sha256')},
              'candidate': {key: candidate[key] for key in ('head', 'production_tree', 'sha256')},
              'scope': '144 fresh Rust formal products only. Eight isolated diagnostics and every failed/historical attempt remain separate. Fixed prior Pi/DeepSeek is a separately pinned dependency, not new paired products.'}
    return phases, pins


def verify_archive(path, manifest_bytes, entries):
    seen = set()
    with tarfile.open(path, 'r|xz') as archive:
        for member in archive:
            safe_name(member.name)
            require(member.type in (tarfile.REGTYPE, tarfile.AREGTYPE) and not member.issparse()
                    and member.name not in seen, 'invalid archive member: ' + member.name)
            seen.add(member.name)
            stream = archive.extractfile(member)
            require(stream is not None, 'missing member bytes')
            if member.name == 'MANIFEST.json':
                require(member.size == len(manifest_bytes) and stream.read() == manifest_bytes, 'archived manifest differs')
            else:
                expected = entries.get(member.name)
                require(expected is not None and member.size == expected['bytes']
                        and hashlib.file_digest(stream, 'sha256').hexdigest() == expected['sha256'], 'archive name/hash/size differs: ' + member.name)
    require(seen == set(entries) | {'MANIFEST.json'}, 'archive member set differs')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--repo', type=Path, default=REPO)
    parser.add_argument('--output', type=Path, default=DESTINATION)
    args = parser.parse_args()
    root, repo, output = args.root.resolve(), args.repo.resolve(), args.output.resolve()
    require(not output.is_relative_to(root) and not root.is_relative_to(output), 'output must be separate from input tree')
    require(not output.exists() or output.is_dir() and not any(output.iterdir()), 'refusing nonempty output directory')
    external = harness_mount(root, repo)
    selected, excluded = inventory(root, external)
    phases, pins = preflight(root, selected, repo)
    fingerprints, entries = {}, {}
    for name, path in selected.items():
        state = fingerprint(path)
        digest = sha(path)
        require(fingerprint(path) == state, 'input changed while hashing: ' + name)
        fingerprints[name] = state
        entries[name] = {'bytes': state[2], 'sha256': digest, 'source': str(path)}
    created = datetime.now(timezone.utc).isoformat()
    report_hashes = {name: sha(root / name) for name in ('direct-audit.json', 'diagnostic-audit-final.json', 'report-data.json', 'report-tables.md', 'replication-audit-final.json')}
    manifest = {'format': FORMAT, 'created_utc': created, 'raw_root': str(root), 'files': entries, 'excluded': excluded,
                'rules': RULES, 'phases': phases, 'reference_pins': pins, 'replay_commands': COMMANDS,
                'strict_report_sha256': report_hashes,
                'scope': 'Per-file integrity and retained raw recomputation, not fresh product execution, a reproducible-build proof, or new historical Pi/DeepSeek verification.'}
    manifest_bytes = encoded(manifest)
    output.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='.raw-', suffix='.tar.xz.partial', dir=output)
    os.close(fd)
    temporary = Path(temporary)
    try:
        with tarfile.open(temporary, 'w:xz', preset=0) as archive:
            for name, path in selected.items():
                require(fingerprint(path) == fingerprints[name], 'input changed before packing: ' + name)
                info = tarfile.TarInfo(name)
                info.size, info.mode = entries[name]['bytes'], 0o644
                with path.open('rb') as stream:
                    archive.addfile(info, stream)
                require(fingerprint(path) == fingerprints[name], 'input changed during packing: ' + name)
            info = tarfile.TarInfo('MANIFEST.json')
            info.size, info.mode = len(manifest_bytes), 0o644
            archive.addfile(info, io.BytesIO(manifest_bytes))
        verify_archive(temporary, manifest_bytes, entries)
        current, current_excluded = inventory(root, external)
        require(current == selected and current_excluded == excluded, 'evidence inventory/exclusions changed during packing')
        require(all(fingerprint(path) == fingerprints[name] for name, path in selected.items()), 'evidence changed after packing')
        summary = {'format': FORMAT, 'created_utc': created, 'archive': 'raw.tar.xz', 'archive_bytes': temporary.stat().st_size,
                   'archive_sha256': sha(temporary), 'manifest_bytes': len(manifest_bytes),
                   'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(), 'raw_files': len(entries),
                   'raw_bytes': sum(row['bytes'] for row in entries.values()), 'excluded_entries': len(excluded),
                   'excluded_reasons': dict(Counter(row['reason'] for row in excluded)), 'stream_verified_all_members': True,
                   'compression': 'xz preset 0', 'phases': phases, 'reference_pins': pins,
                   'replay_commands': COMMANDS, 'strict_report_sha256': report_hashes}
        commands = '\n'.join(shlex.join(COMMANDS[label]) for label in ('replication', 'formal', 'diagnostic', 'summary'))
        readme = f'''# Compact content indexing and bounded tail append evidence

This archive retains 144 fresh Rust products (two revisions × six cases × two
observer modes × six interleaved pairs) and eight separate diagnostics (four
columns and four WAL). The formal comparison covers 72 pairs and 1,692 matched
requests. All fresh products use CPUs 2,8, with three pairs in each execution
order per cell. Failed checks, audit attempts and other regular evidence remain
retained without being counted as successful products. No Pi or DeepSeek product
executes in this round. The baseline uses schema 87 and the candidate uses
schema 88. There are no profile products. A separate exploratory 24-product / 12-pair
stream replication compares the two preceding Rust revisions before this
implementation. It is not pooled with the formal matrix, and was not
preregistered under the final measurement gate. The archive contains 176 new Rust
products total, all retained without selecting favorable pairs.

The previous 60 Pi and 12 DeepSeek products are a fixed, separately measured
reference dependency. Its exact accepted report, archive SHA, summary, original
raw-only command and prior portable-verification receipt are in `reference-pins/`.
The old raw archive is not duplicated or re-audited here. Historical distributions
are presented separately; there are no new current/historical ratios. DeepSeek
SDK idle does not await flush/fsync; native exit CPU is separate and full-process
writes remain unavailable rather than zero.

`summary.json` binds the archive SHA/size and `MANIFEST.json` inside `raw.tar.xz`
binds every retained file's SHA/size and all exclusions. All members must be
regular files; duplicate, unsafe, missing or extra members are rejected by the
standalone `verify-archive.py`. Absolute captured paths are historical provenance,
not replay inputs. Compiled executables/libraries, dependency caches, bytecode
and prior archive/extraction trees are excluded; SQLite snapshots, WAL traces
and native compressed evidence remain included.

After extracting into a fresh `raw/` directory and changing into it, the exact
read-only replay commands are:

```sh
{commands}
```

Use the standalone verifier for safe extraction and complete manifest validation,
then all four commands and strict-result comparisons. Run `verify-archive.py
--help` for a fresh work directory and this evidence directory. Its output
`portable-verification.json` is written only after an actual verification attempt.
All replay outputs and logs are outside extracted `raw/`; a final full inventory
and hash pass detects any raw mutation. Python 3.11+ standard library suffices.
No product, compiler, profiler, database query or historical executable/source
lookup runs during replay. A portable pass does not claim fresh host identity.

`baseline-build/` retains both its unchanged original build receipt and a copy
with only the executable path relocated. Both revisions retain original Cargo
and clean logs. Candidate O3/default-feature inputs bind the separate successful
O0/all-features correctness queue, including tests and source hashes.
`frozen-harness/` holds hash-bound repository fixture/harness sources. Retained
strict reports are `direct-audit.json` and `diagnostic-audit-final.json`; `report-data.json`
contains all metric values, missing ratios and adverse pairs. Replayed complete
formal datasets, diagnostic columns/WAL and numerical tables must equal these
reports, allowing only explicit timestamp, raw-mode and relocated identity
fields. Diagnostic replay binds the newly recomputed formal report.

A post-measurement WAL parser correction is recorded in `wal-parser-correction.json`.
All 13 frozen scripts and the original failed diagnostic audit remain unchanged.
Corrected copies allow strace-resume whitespace and use new summary filenames;
all original traces are retained and no product was rerun. The packer and
portable verifier enforce those exact source transformations. The corrected
WAL scripts were not preregistration-frozen.

Main-only logical column bytes exclude connection-local TEMP readiness and are
not WAL, process write bytes, or device I/O. CPU affinity evidence records the
controller's observed mask and topology; it does not establish historical
per-thread CPU residency or remove every source of scheduling variation.
'''
        os.link(temporary, output / 'raw.tar.xz')
        temporary.unlink()
        with (output / 'summary.json').open('xb') as stream:
            stream.write(encoded(summary))
        with (output / 'README.md').open('x') as stream:
            stream.write(readme)
        print(json.dumps({key: summary[key] for key in ('archive', 'archive_bytes', 'archive_sha256', 'raw_files', 'raw_bytes')}, indent=2))
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    main()
