# Implementation and measurement scope

Baseline is a664c5a96546c3e49c5638c3c959b08df3c77fec, schema 87, ordinary
O3 binary 62c2e96a5a611de0df64e35065ae9bfd04a794bafef882a2214244ff1cb4587e.

The new schema 88 uses one-character private representation keys t/r/b/j and
short source keys cb/cm/oj for canonical block/message metadata and journal
source bytes. Public serde enum names and JSON/schema remain unchanged. No old
database migration or fallback reader is added. Content tables remain WITHOUT
ROWID with the same primary-key shapes and independent source domains.

A nonempty suffix into an existing segment now executes one cached guarded
UPDATE with a bounded rustx_append_content BLOB function. It borrows SQLite
input cells and allocates one exact combined buffer, without returning a
separate old-tail Vec or growing it. It rejects a missing, mistyped or wrong
length tail before publishing its next frontier. SQLite still reads/constructs
its concatenation and may rewrite pages. Initial text concatenation failed
the bundled-SQLite UTF-16 odd-byte regression and was removed; failure evidence
and the separate probe remain retained. This change alone does not establish
append-only device I/O. Incremental blob I/O requires rowid and cannot be applied
to the existing WITHOUT ROWID table without a larger storage redesign. Boundary,
arbitrary-byte, UTF-8/UTF-16, revision and rollback regressions use bundled SQLite.

Read-cut map keys use Arc<str> for persistent tree path sharing. Advancing an
existing domain does a borrowed lookup/update, without constructing a fresh key.
Exact size certificates still invalidate on mutation; old cuts and JSON/schema
remain intact. Revision overflow remains rejected.

The remaining event-array budget/length walks describe fresh event values on
each publication, so a revision- or cursor-keyed cache cannot authenticate them.
This round does not add a speculative event cache or skip final serialization.

Before implementation, a separate exploratory replication ran 24 Rust stream
products / 12 balanced pairs on CPUs 2,8 for the two preceding revisions. Its
observations are separate from final formal products and are not preregistered
under the final gate. Old and new adverse results remain retained. No Pi/DeepSeek
executes this round.

Reference docs: https://www.sqlite.org/lang_expr.html (CAST/concatenation),
https://www.sqlite.org/withoutrowid.html (incremental blob I/O limitation).
