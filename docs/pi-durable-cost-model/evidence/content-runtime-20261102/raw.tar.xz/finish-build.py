import datetime,hashlib,json,os,re,subprocess,time
from pathlib import Path
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');checks=r/'checks-third'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
for attempt in range(720):
 rows=json.loads((checks/'check-build-commands.json').read_text())
 if any(x.get('exit',0)!=0 for x in rows):raise SystemExit('correctness failed; no commit/build')
 if len(rows)==15 and rows[-1]['label']=='clippy' and rows[-1]['status']=='complete' and (checks/'source-after.json').exists():break
 time.sleep(5)
else:raise SystemExit('correctness timeout')
assert all(x['exit']==0 for x in rows)
expected=json.loads((checks/'source-after.json').read_text())['files']
assert expected==json.loads((checks/'source-before.json').read_text())['files']
assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==h for n,h in expected.items())
artifacts=[json.loads(line) for line in (checks/'tests-build.stdout').read_text().splitlines() if line.startswith('{')]
binary=next(x['executable'] for x in artifacts if x.get('reason')=='compiler-artifact' and x['target']['name']=='rustx' and x.get('executable') and x['profile']['test'])
cmd=[binary,'artifact_lineage_tests::','--test-threads=2'];meta={'command':cmd,'start_utc':now(),'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'source_files':expected}
with (r/'artifact-lineage.stdout').open('x') as out,(r/'artifact-lineage.stderr').open('x') as err:done=subprocess.run(cmd,cwd=repo,stdout=out,stderr=err)
meta.update(exit=done.returncode,end_utc=now());(r/'artifact-lineage-command.json').write_text(json.dumps(meta,indent=2)+'\n')
assert done.returncode==0 and re.search(r'test result: ok\. [1-9][0-9]* passed;', (r/'artifact-lineage.stdout').read_text())
assert all(hashlib.sha256((repo/n).read_bytes()).hexdigest()==h for n,h in expected.items())
with (r/'implementation-final.diff').open('x') as out:subprocess.run(['git','diff','--binary','--','src','tests','Cargo.toml','Cargo.lock'],cwd=repo,stdout=out,check=True)
subprocess.run(['git','add','src','tests','Cargo.toml','Cargo.lock'],cwd=repo,check=True)
with (r/'implementation-commit.stdout').open('x') as out:subprocess.run(['git','commit','-m','Compact content keys and merge streamed tail appends'],cwd=repo,stdout=out,check=True)
print('correctness and artifact lineage passed; source committed',flush=True)
with (r/'candidate-build.stdout').open('x') as out,(r/'candidate-build.stderr').open('x') as err:done=subprocess.run(['python3',str(r/'build-candidate.py'),'--checks-dir','checks-third'],cwd=repo,stdout=out,stderr=err)
print('candidate build',done.returncode,flush=True);raise SystemExit(done.returncode)
