from pathlib import Path
import hashlib,json,os,sys
repo=Path('/workspace/rustX-pi-durable');root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'));import controller
binary=Path('/workspace/issue-481-evidence/native-statement-reuse-build/conformance')
a=json.loads((binary.parent/'identity.json').read_text());b=json.loads(Path('/workspace/issue-481-evidence/observer-oracle-v2-build/identity.json').read_text())
assert a['verified'] and a['head']=='b87ae908b17dc9b63c2e6993a0c81d10c0960177' and a['harness']==b['harness']
assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==a['sha256']
env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))};env['UV_CACHE_DIR']='/workspace/.uv-cache'
records=[]
for mode in ['no-live-subscriber','live-subscriber']:
 for case in controller.CASES:
  stem=root/f'smoke-{mode}-{case}';assert not stem.with_suffix('.json').exists()
  record=controller.run([str(binary),controller.TEST,'--exact','--ignored','--nocapture'],stem,case,env|{'RUSTX_BENCH_CASE':case,'RUSTX_BENCH_OUTPUT':str(stem.with_suffix('.json')),'RUSTX_BENCH_OBSERVER_MODE':mode},repo/'test-support/fake-provider')
  records.append(record);print(mode,case,'accepted',record['accepted'],record.get('error',''),flush=True)
(root/'smoke-results.json').write_text(json.dumps(records,indent=2)+'\n')
raise SystemExit(int(any(not r['accepted'] for r in records)))
