import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
from fixture_binding import capture as capture_fixtures
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
binaries={'baseline':Path('/home/capi/.cache/rustx-pr485-merged-operations-final/candidate-complete-build/conformance'),'complete':root/'candidate-complete-build/conformance'}
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
builds={label:json.loads((binary.parent/'identity.json').read_text()) for label,binary in binaries.items()}
assert all(build['verified'] and sha(binaries[label])==build['sha256'] for label,build in builds.items())
assert builds['baseline']['harness']==builds['complete']['harness']
def source():
 assert not subprocess.check_output(['git','status','--porcelain','--','src','tests','Cargo.toml','Cargo.lock','benchmarks/runtime','test-support/fake-provider'],cwd=repo,text=True).strip()
 files={str(p.relative_to(repo)):sha(p) for folder in ('src','tests') for p in sorted((repo/folder).rglob('*')) if p.is_file()}
 files.update({p:sha(repo/p) for p in ('Cargo.toml','Cargo.lock')})
 assert files==builds['complete']['source_files']
 fixtures=capture_fixtures(repo)
 assert all(sha(repo/p)==h for p,h in builds['complete']['harness'].items())
 return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'files':files,'fixtures':fixtures,'runner_sha256':sha(__file__)}
steps=[]
for label,binary in binaries.items():steps.append((f'columns-{label}','columns-complete.py',['--binary',str(binary),'--label',label]))
steps.extend([('profiles','run-profiles.py',[]),('profile-reports','profile-reports.py',[])])
for label,binary in binaries.items():steps.extend([(f'wal-{label}','run-wal-rust.py',['--binary',str(binary),'--label',label]),(f'wal-summary-{label}','analyze-wal-verified.py',['--label',label])])
ledger=root/'diagnostic-commands.json';assert not ledger.exists(), 'retain previous attempt; choose a new evidence root instead of overwriting'
initial=source()
premeasurement=json.loads((root/'premeasurement.json').read_text())
assert premeasurement['accepted'] is True and not premeasurement['errors'] and initial['fixtures']==premeasurement['fixtures'], 'diagnostic fixtures differ from accepted premeasurement'
(root/'diagnostic-source-before.json').write_text(json.dumps(initial,indent=2)+'\n')
records=[dict(name=name,command=[sys.executable,str(root/script),*args],producer_sha256=sha(root/script),status='pending') for name,script,args in steps]
def save():ledger.write_text(json.dumps(records,indent=2)+'\n')
save()
for index,record in enumerate(records):
 source();assert all(sha(binary)==builds[label]['sha256'] for label,binary in binaries.items())
 record.update(start_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='running');save()
 with (root/(record['name']+'.stdout')).open('w') as out,(root/(record['name']+'.stderr')).open('w') as err:
  result=subprocess.run(record['command'],cwd=repo,env=os.environ|{'UV_OFFLINE':'1'},stdout=out,stderr=err)
 record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete' if result.returncode==0 else 'failed',exit=result.returncode);save();print(record['name'],result.returncode,flush=True)
 assert sha(Path(record['command'][1]))==record['producer_sha256']
 current=source();assert {k:v for k,v in current.items() if k!='utc'}=={k:v for k,v in initial.items() if k!='utc'}
 assert all(sha(binary)==builds[label]['sha256'] for label,binary in binaries.items())
 if result.returncode:
  for pending in records[index+1:]:pending.update(status='not_run',reason='prior diagnostic failed')
  save();(root/'diagnostic-source-after.json').write_text(json.dumps(current,indent=2)+'\n');raise SystemExit(result.returncode)
final=source();(root/'diagnostic-source-after.json').write_text(json.dumps(final,indent=2)+'\n')
