"""Read-only current measurement fixtures; never used to run a product.

The provider is a Python source project, separate from the Rust build inputs.
Keep its tracked inputs with the runtime harness without copying its venv or
bytecode caches. Raw-only auditors compare retained maps and never call here.
"""
import hashlib
from pathlib import Path
import subprocess

PROVIDER = 'test-support/fake-provider'
ROOTS = ('benchmarks/runtime', PROVIDER)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def capture(repo):
    repo = Path(repo)
    require(not git(repo, 'status', '--porcelain', '--untracked-files=all', '--', *ROOTS),
            'measurement fixture source is dirty or contains untracked inputs')
    provider = git(repo, 'ls-tree', '-r', '--name-only', 'HEAD', '--', PROVIDER).splitlines()
    require(len(provider) == len(set(provider)) and
            {PROVIDER + '/pyproject.toml', PROVIDER + '/uv.lock',
             PROVIDER + '/src/fake_provider/__main__.py'} <= set(provider),
            'provider tracked input inventory is incomplete')
    # Git intentionally ignores bytecode and environments. An extra importable
    # source/legacy .pyc under src must still not escape the measured inventory.
    actual_src = {p.relative_to(repo).as_posix()
                  for p in (repo / PROVIDER / 'src').rglob('*')
                  if p.is_file() and '__pycache__' not in p.parts}
    require(actual_src == {p for p in provider if p.startswith(PROVIDER + '/src/')},
            'untracked or ignored importable provider input outside the tracked inventory')
    paths = sorted(p for p in (repo / 'benchmarks/runtime').rglob('*')
                   if p.is_file() and '__pycache__' not in p.parts)
    paths += [repo / name for name in provider]
    require(all(not p.is_symlink() and p.resolve().is_relative_to(repo.resolve()) for p in paths),
            'measurement fixture input is a symlink or outside the repository')
    return {p.relative_to(repo).as_posix(): sha(p) for p in paths}


def provider_proof(repo, baseline_head, candidate_head, fixtures):
    """Bind this round's provider to both Rust commits, not an old Pi run."""
    repo = Path(repo)
    trees = {label: git(repo, 'rev-parse', head + ':' + PROVIDER)
             for label, head in (('baseline', baseline_head), ('candidate', candidate_head))}
    require(trees['baseline'] == trees['candidate'], 'provider differs across Rust source commits')
    names = git(repo, 'ls-tree', '-r', '--name-only', baseline_head, '--', PROVIDER).splitlines()
    values = {name: fixtures[name] for name in names}
    require(set(values) == {name for name in fixtures if name.startswith(PROVIDER + '/')},
            'provider recorded/tracked inventory differs')
    for name, digest in values.items():
        contents = subprocess.check_output(['git', 'show', baseline_head + ':' + name], cwd=repo)
        require(hashlib.sha256(contents).hexdigest() == digest,
                'provider working bytes differ from the fixed Rust baseline: ' + name)
    return {'baseline_head': baseline_head, 'candidate_head': candidate_head,
            'trees': trees, 'files': values,
            'scope': 'Provider bytes used by this round match both Rust commits. '
                     'This does not add a provider binding to prior Pi/DeepSeek measurements.'}
