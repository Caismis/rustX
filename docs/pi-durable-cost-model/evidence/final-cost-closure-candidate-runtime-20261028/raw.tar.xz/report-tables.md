# Final cost closure performance evidence

Fresh Rust comparison: five interleaved pairs per cell. Historical Pi/DeepSeek rows are fixed, separate batches; their ratios are ratios of medians, not paired results.

| Mode | Case | Paired median wall % [min,max] | Full CPU % | Full write bytes % | Sample anon PSS % | Sample RSS % |
|---|---|---:|---:|---:|---:|---:|
| no-live-subscriber | short-small | -10.405 [-16.902,67.587] | -3.650 | -10.365 | 0.830 | 0.719 |
| no-live-subscriber | short-large | 9.998 [-50.612,49.805] | -2.703 | -9.494 | 0.313 | 0.527 |
| no-live-subscriber | stream | 0.250 [-2.377,2.061] | 0.000 | -4.308 | 0.934 | 1.019 |
| no-live-subscriber | large | -8.536 [-37.071,22.383] | 0.000 | -4.481 | 0.881 | 0.773 |
| no-live-subscriber | tool | 2.901 [-12.777,35.235] | -5.556 | -6.993 | 1.433 | 1.397 |
| no-live-subscriber | cancel | 12.288 [-9.388,36.878] | 13.333 | -4.485 | 1.732 | 1.255 |
| live-subscriber | short-small | -10.361 [-44.541,38.014] | -7.602 | -10.390 | 1.203 | 0.906 |
| live-subscriber | short-large | 14.677 [-45.672,46.030] | -9.190 | -9.493 | 0.445 | 0.506 |
| live-subscriber | stream | 0.448 [-3.937,1.359] | 3.571 | -4.308 | 1.247 | 0.559 |
| live-subscriber | large | -2.909 [-15.524,32.090] | 6.250 | -4.481 | 1.447 | 1.220 |
| live-subscriber | tool | 18.398 [-1.156,37.512] | 5.882 | -6.993 | 1.418 | 1.621 |
| live-subscriber | cancel | 8.028 [1.849,26.926] | 6.667 | -4.485 | 1.716 | 1.127 |

| Mode | Case | Mean wall / old Pi | Median wall / old Pi | Full CPU / old Pi | Full writes / old Pi |
|---|---|---:|---:|---:|---:|
| no-live-subscriber | short-small | 4.347 | 4.967 | 1.394 | 4.252 |
| no-live-subscriber | short-large | 4.603 | 5.364 | 2.780 | 4.732 |
| no-live-subscriber | stream | 0.924 | 0.924 | 0.264 | 3.836 |
| no-live-subscriber | large | 0.411 | 0.411 | 0.271 | 4.337 |
| no-live-subscriber | tool | 0.405 | 0.405 | 0.270 | 3.879 |
| no-live-subscriber | cancel | 0.364 | 0.364 | 0.262 | 4.553 |
| live-subscriber | short-small | 4.371 | 4.929 | 1.619 | 4.252 |
| live-subscriber | short-large | 3.360 | 3.699 | 2.767 | 4.733 |
| live-subscriber | stream | 0.909 | 0.909 | 0.252 | 3.836 |
| live-subscriber | large | 0.396 | 0.396 | 0.271 | 4.337 |
| live-subscriber | tool | 0.571 | 0.571 | 0.302 | 3.879 |
| live-subscriber | cancel | 0.359 | 0.359 | 0.267 | 4.553 |

Warm measured windows (per-product statistic, then median [minimum,maximum] across five Rust/Pi products; each has 32 measured turns):

| Mode | History | Engine/batch | Mean ms/turn | Median ms/turn | CPU ms/turn | Write bytes/turn |
|---|---:|---|---:|---:|---:|---:|
| no-live-subscriber | 8 | current Rust | 15.761 [12.982,16.820] | 15.570 [14.002,15.771] | 17.812 [15.000,19.062] | 966016.000 [965632.000,966272.000] |
| no-live-subscriber | 8 | fixed old Pi | 3.625 [3.524,4.546] | 3.135 [3.014,3.328] | 7.188 [6.875,9.688] | 224512.000 [224512.000,224512.000] |
| no-live-subscriber | 64 | current Rust | 17.017 [10.273,18.163] | 17.695 [9.604,18.352] | 18.125 [11.875,20.625] | 1152640.000 [1152128.000,1154176.000] |
| no-live-subscriber | 64 | fixed old Pi | 3.697 [3.667,3.911] | 3.299 [3.159,3.524] | 6.250 [5.938,6.875] | 224384.000 [224384.000,224384.000] |
| live-subscriber | 8 | current Rust | 17.194 [12.699,18.011] | 16.857 [10.314,17.447] | 25.000 [18.750,25.938] | 966016.000 [965760.000,966400.000] |
| live-subscriber | 8 | fixed old Pi | 3.934 [3.784,4.165] | 3.420 [3.309,3.699] | 7.500 [7.188,8.438] | 224512.000 [224512.000,224512.000] |
| live-subscriber | 64 | current Rust | 13.402 [11.626,17.382] | 13.095 [10.901,18.084] | 19.688 [16.562,25.000] | 1152512.000 [1151616.000,1153920.000] |
| live-subscriber | 64 | fixed old Pi | 3.989 [3.827,4.233] | 3.541 [3.482,3.679] | 6.875 [6.250,7.188] | 224384.000 [224384.000,224384.000] |

| Live case | Current mean ms/turn | Fixed DS mean ms/turn | Wall ratio | CPU ratio | Measured write ratio |
|---|---:|---:|---:|---:|---:|
| short-small | 17.194 | 15.541 | 1.106 | 1.379 | 44.923 |
| short-large | 13.402 | 15.450 | 0.867 | 1.125 | 53.916 |
| stream | 1578.194 | 1583.218 | 0.997 | 0.500 | 47.143 |
| large | 35.572 | 165.613 | 0.215 | 0.200 | 31.857 |

DeepSeek exit/flush CPU remains separate from measured turns and from Rust full-lifecycle CPU; full DeepSeek process write bytes remain unavailable. The JSON retains the exact wait4 metrics and source-specific limits.

All adverse metrics (including individual fresh paired reversals):

| Comparison | Mode | Case | Metric | Median % or cross-batch ratio | Adverse pairs |
|---|---|---|---|---:|---|
| fresh_paired_rust | no-live-subscriber | short-small | mean_turn_ms | -4.752 | 4:+58.571% |
| fresh_paired_rust | no-live-subscriber | short-small | turn_cpu_ms_per_turn | -1.639 | 4:+50.000% |
| fresh_paired_rust | no-live-subscriber | short-small | through_cleanup_self_cpu_ms | -3.650 | 4:+24.762% |
| fresh_paired_rust | no-live-subscriber | short-small | lifecycle_ms | -2.804 | 4:+20.889% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_anon_pss_mib | 0.830 | 0:+0.932%,2:+0.658%,3:+1.301%,4:+0.830% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_pss_mib | 0.673 | 0:+0.457%,1:+0.186%,2:+0.767%,3:+0.785%,4:+0.673% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_rss_mib | 0.719 | 0:+0.501%,1:+0.184%,2:+0.802%,3:+0.849%,4:+0.719% |
| fresh_paired_rust | no-live-subscriber | short-small | median_measured_turn_ms | -10.405 | 4:+67.587% |
| fresh_paired_rust | no-live-subscriber | short-small | lifecycle_self_cpu_ms | -3.650 | 4:+24.762% |
| fresh_paired_rust | no-live-subscriber | short-small | measured_turn_cpu_ms | -1.639 | 4:+50.000% |
| fresh_paired_rust | no-live-subscriber | short-small | max_sampled_turn_rss_mib | 1.012 | 0:+0.904%,1:+0.190%,2:+1.012%,3:+1.112%,4:+1.294% |
| fresh_paired_rust | no-live-subscriber | short-small | through_product_exit_wall_ms | -2.934 | 4:+20.134% |
| fresh_paired_rust | no-live-subscriber | short-small | complete_harness_lifecycle_wall_ms | -3.272 | 4:+19.676% |
| fresh_paired_rust | no-live-subscriber | short-large | mean_turn_ms | 6.343 | 0:+6.343%,2:+30.701%,3:+11.788% |
| fresh_paired_rust | no-live-subscriber | short-large | turn_cpu_ms_per_turn | 5.455 | 0:+5.455%,2:+28.571%,3:+11.864% |
| fresh_paired_rust | no-live-subscriber | short-large | through_cleanup_self_cpu_ms | -2.703 | 0:+10.423% |
| fresh_paired_rust | no-live-subscriber | short-large | lifecycle_ms | -1.753 | 0:+9.664%,4:+16.331% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_anon_pss_mib | 0.313 | 0:+0.578%,1:+0.313%,3:+0.282%,4:+0.941% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_pss_mib | 0.492 | 0:+0.670%,1:+0.492%,3:+0.483%,4:+1.006% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_rss_mib | 0.527 | 0:+0.640%,1:+0.527%,3:+0.524%,4:+1.023% |
| fresh_paired_rust | no-live-subscriber | short-large | median_measured_turn_ms | 9.998 | 0:+45.588%,2:+49.805%,3:+9.998% |
| fresh_paired_rust | no-live-subscriber | short-large | lifecycle_self_cpu_ms | -2.703 | 0:+10.423% |
| fresh_paired_rust | no-live-subscriber | short-large | measured_turn_cpu_ms | 5.455 | 0:+5.455%,2:+28.571%,3:+11.864% |
| fresh_paired_rust | no-live-subscriber | short-large | max_sampled_turn_rss_mib | 0.896 | 0:+1.095%,1:+0.313%,3:+0.896%,4:+1.552% |
| fresh_paired_rust | no-live-subscriber | short-large | through_product_exit_wall_ms | -1.314 | 0:+9.022%,4:+15.498% |
| fresh_paired_rust | no-live-subscriber | short-large | complete_harness_lifecycle_wall_ms | -1.120 | 0:+8.401%,4:+15.106% |
| fresh_paired_rust | no-live-subscriber | short-large | closed_logical_bytes | 0.723 | 0:+1.145%,1:+0.723%,2:+1.184% |
| fresh_paired_rust | no-live-subscriber | short-large | closed_allocated_bytes | 0.718 | 0:+1.138%,1:+0.718%,2:+1.176% |
| fresh_paired_rust | no-live-subscriber | stream | mean_turn_ms | 0.250 | 0:+2.061%,3:+0.250%,4:+1.711% |
| fresh_paired_rust | no-live-subscriber | stream | turn_cpu_ms_per_turn | -6.250 | 0:+5.882% |
| fresh_paired_rust | no-live-subscriber | stream | through_cleanup_self_cpu_ms | 0.000 | 2:+11.111%,4:+8.000% |
| fresh_paired_rust | no-live-subscriber | stream | lifecycle_ms | 0.707 | 0:+1.599%,2:+0.707%,4:+1.632% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_anon_pss_mib | 0.934 | 0:+1.156%,1:+0.616%,2:+0.934%,3:+0.461%,4:+2.415% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_pss_mib | 1.011 | 0:+0.925%,1:+1.344%,2:+1.011%,4:+1.436% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_rss_mib | 1.019 | 0:+0.922%,1:+1.393%,2:+1.019%,4:+1.375% |
| fresh_paired_rust | no-live-subscriber | stream | median_measured_turn_ms | 0.250 | 0:+2.061%,3:+0.250%,4:+1.711% |
| fresh_paired_rust | no-live-subscriber | stream | lifecycle_self_cpu_ms | 0.000 | 2:+11.111%,4:+8.000% |
| fresh_paired_rust | no-live-subscriber | stream | measured_turn_cpu_ms | -6.250 | 0:+5.882% |
| fresh_paired_rust | no-live-subscriber | stream | max_sampled_turn_rss_mib | 0.776 | 0:+0.417%,1:+1.446%,2:+0.776%,3:+0.072%,4:+1.123% |
| fresh_paired_rust | no-live-subscriber | stream | through_product_exit_wall_ms | 0.720 | 0:+1.768%,2:+0.720%,4:+1.791% |
| fresh_paired_rust | no-live-subscriber | stream | complete_harness_lifecycle_wall_ms | 0.808 | 0:+1.557%,2:+0.808%,4:+2.049% |
| fresh_paired_rust | no-live-subscriber | large | mean_turn_ms | -8.536 | 0:+4.190%,1:+22.383% |
| fresh_paired_rust | no-live-subscriber | large | turn_cpu_ms_per_turn | 0.000 | 0:+33.333%,1:+33.333% |
| fresh_paired_rust | no-live-subscriber | large | through_cleanup_self_cpu_ms | 0.000 | 1:+13.333% |
| fresh_paired_rust | no-live-subscriber | large | lifecycle_ms | -4.711 | 0:+4.203%,1:+8.933% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_anon_pss_mib | 0.881 | 0:+1.120%,1:+0.798%,2:+1.892%,3:+0.881%,4:+0.841% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_pss_mib | 0.818 | 0:+0.818%,1:+1.016%,2:+1.378%,3:+0.755%,4:+0.290% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_rss_mib | 0.773 | 0:+0.773%,1:+0.987%,2:+1.417%,3:+0.749%,4:+0.269% |
| fresh_paired_rust | no-live-subscriber | large | median_measured_turn_ms | -8.536 | 0:+4.190%,1:+22.383% |
| fresh_paired_rust | no-live-subscriber | large | lifecycle_self_cpu_ms | 0.000 | 1:+13.333% |
| fresh_paired_rust | no-live-subscriber | large | measured_turn_cpu_ms | 0.000 | 0:+33.333%,1:+33.333% |
| fresh_paired_rust | no-live-subscriber | large | max_sampled_turn_rss_mib | 0.758 | 0:+0.707%,1:+0.758%,2:+1.422%,3:+0.879%,4:+0.399% |
| fresh_paired_rust | no-live-subscriber | large | through_product_exit_wall_ms | -3.261 | 0:+4.334%,1:+9.022% |
| fresh_paired_rust | no-live-subscriber | large | complete_harness_lifecycle_wall_ms | -3.603 | 0:+4.124%,1:+10.257% |
| fresh_paired_rust | no-live-subscriber | tool | mean_turn_ms | 2.901 | 0:+35.235%,1:+8.021%,2:+2.901% |
| fresh_paired_rust | no-live-subscriber | tool | turn_cpu_ms_per_turn | 25.000 | 0:+75.000%,3:+25.000%,4:+25.000% |
| fresh_paired_rust | no-live-subscriber | tool | through_cleanup_self_cpu_ms | -5.556 | 0:+17.647%,1:+6.250% |
| fresh_paired_rust | no-live-subscriber | tool | lifecycle_ms | -1.591 | 0:+7.019%,2:+1.865% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_anon_pss_mib | 1.433 | 0:+1.433%,1:+4.177%,2:+1.184%,3:+2.411%,4:+0.871% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_pss_mib | 1.419 | 0:+1.394%,1:+2.490%,2:+1.419%,3:+1.954%,4:+0.958% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_rss_mib | 1.397 | 0:+1.389%,1:+2.449%,2:+1.397%,3:+1.969%,4:+0.955% |
| fresh_paired_rust | no-live-subscriber | tool | median_measured_turn_ms | 2.901 | 0:+35.235%,1:+8.021%,2:+2.901% |
| fresh_paired_rust | no-live-subscriber | tool | lifecycle_self_cpu_ms | -5.556 | 0:+17.647%,1:+6.250% |
| fresh_paired_rust | no-live-subscriber | tool | measured_turn_cpu_ms | 25.000 | 0:+75.000%,3:+25.000%,4:+25.000% |
| fresh_paired_rust | no-live-subscriber | tool | max_sampled_turn_rss_mib | 1.585 | 0:+1.585%,1:+2.660%,2:+1.139%,3:+1.665%,4:+1.190% |
| fresh_paired_rust | no-live-subscriber | tool | through_product_exit_wall_ms | -1.555 | 0:+6.630%,2:+3.301% |
| fresh_paired_rust | no-live-subscriber | tool | complete_harness_lifecycle_wall_ms | -1.865 | 0:+5.930%,2:+3.292% |
| fresh_paired_rust | no-live-subscriber | cancel | mean_turn_ms | 12.288 | 0:+12.288%,2:+12.088%,3:+13.062%,4:+36.878% |
| fresh_paired_rust | no-live-subscriber | cancel | turn_cpu_ms_per_turn | 0.000 | 1:+33.333%,4:+33.333% |
| fresh_paired_rust | no-live-subscriber | cancel | through_cleanup_self_cpu_ms | 13.333 | 0:+13.333%,2:+14.286%,4:+20.000% |
| fresh_paired_rust | no-live-subscriber | cancel | lifecycle_ms | 9.071 | 0:+16.396%,2:+9.071%,3:+3.498%,4:+15.085% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_anon_pss_mib | 1.732 | 0:+1.085%,1:+1.732%,2:+2.337%,3:+1.542%,4:+1.956% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_pss_mib | 1.286 | 0:+0.837%,1:+1.414%,2:+1.741%,3:+0.759%,4:+1.286% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_rss_mib | 1.255 | 0:+0.808%,1:+1.350%,2:+1.725%,3:+0.767%,4:+1.255% |
| fresh_paired_rust | no-live-subscriber | cancel | median_measured_turn_ms | 12.288 | 0:+12.288%,2:+12.088%,3:+13.062%,4:+36.878% |
| fresh_paired_rust | no-live-subscriber | cancel | lifecycle_self_cpu_ms | 13.333 | 0:+13.333%,2:+14.286%,4:+20.000% |
| fresh_paired_rust | no-live-subscriber | cancel | measured_turn_cpu_ms | 0.000 | 1:+33.333%,4:+33.333% |
| fresh_paired_rust | no-live-subscriber | cancel | max_sampled_turn_rss_mib | 0.854 | 0:+0.854%,1:+0.613%,2:+1.046%,3:+0.747%,4:+1.227% |
| fresh_paired_rust | no-live-subscriber | cancel | through_product_exit_wall_ms | 8.326 | 0:+16.410%,2:+8.326%,3:+0.850%,4:+15.027% |
| fresh_paired_rust | no-live-subscriber | cancel | complete_harness_lifecycle_wall_ms | 7.740 | 0:+17.132%,2:+7.740%,4:+13.239% |
| fresh_paired_rust | live-subscriber | short-small | mean_turn_ms | -14.476 | 1:+35.299% |
| fresh_paired_rust | live-subscriber | short-small | turn_cpu_ms_per_turn | -17.526 | 1:+25.758% |
| fresh_paired_rust | live-subscriber | short-small | through_cleanup_self_cpu_ms | -7.602 | 1:+11.644% |
| fresh_paired_rust | live-subscriber | short-small | lifecycle_ms | -5.374 | 1:+10.569% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_anon_pss_mib | 1.203 | 0:+1.606%,1:+0.392%,2:+1.203%,3:+1.384%,4:+0.726% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_pss_mib | 0.870 | 0:+0.906%,1:+0.473%,2:+0.870%,3:+1.306%,4:+0.052% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_rss_mib | 0.906 | 0:+0.912%,1:+0.469%,2:+0.906%,3:+1.274%,4:+0.093% |
| fresh_paired_rust | live-subscriber | short-small | median_measured_turn_ms | -10.361 | 1:+38.014% |
| fresh_paired_rust | live-subscriber | short-small | lifecycle_self_cpu_ms | -7.602 | 1:+11.644% |
| fresh_paired_rust | live-subscriber | short-small | measured_turn_cpu_ms | -17.526 | 1:+25.758% |
| fresh_paired_rust | live-subscriber | short-small | max_sampled_turn_rss_mib | 1.290 | 0:+1.290%,1:+0.714%,2:+1.578%,3:+1.667%,4:+0.830% |
| fresh_paired_rust | live-subscriber | short-small | through_product_exit_wall_ms | -5.459 | 1:+10.592% |
| fresh_paired_rust | live-subscriber | short-small | complete_harness_lifecycle_wall_ms | -5.802 | 1:+10.650% |
| fresh_paired_rust | live-subscriber | short-large | mean_turn_ms | 12.024 | 1:+12.024%,2:+13.187%,4:+41.664% |
| fresh_paired_rust | live-subscriber | short-large | turn_cpu_ms_per_turn | 4.000 | 1:+8.621%,2:+4.000%,4:+35.593% |
| fresh_paired_rust | live-subscriber | short-large | through_cleanup_self_cpu_ms | -9.190 | 2:+11.422%,4:+4.740% |
| fresh_paired_rust | live-subscriber | short-large | lifecycle_ms | -5.562 | 2:+10.251%,4:+5.487% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_anon_pss_mib | 0.445 | 0:+0.530%,1:+0.445%,2:+1.268%,3:+0.264%,4:+0.006% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_pss_mib | 0.510 | 0:+0.510%,1:+0.299%,2:+0.901%,3:+0.562% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_rss_mib | 0.506 | 0:+0.506%,1:+0.310%,2:+0.925%,3:+0.602% |
| fresh_paired_rust | live-subscriber | short-large | median_measured_turn_ms | 14.677 | 1:+14.677%,2:+36.613%,4:+46.030% |
| fresh_paired_rust | live-subscriber | short-large | lifecycle_self_cpu_ms | -9.190 | 2:+11.422%,4:+4.740% |
| fresh_paired_rust | live-subscriber | short-large | measured_turn_cpu_ms | 4.000 | 1:+8.621%,2:+4.000%,4:+35.593% |
| fresh_paired_rust | live-subscriber | short-large | max_sampled_turn_rss_mib | 0.484 | 0:+0.484%,1:+0.363%,2:+1.483%,3:+1.055%,4:+0.073% |
| fresh_paired_rust | live-subscriber | short-large | through_product_exit_wall_ms | -5.236 | 2:+9.631%,4:+5.022% |
| fresh_paired_rust | live-subscriber | short-large | complete_harness_lifecycle_wall_ms | -5.103 | 2:+9.246%,4:+4.666% |
| fresh_paired_rust | live-subscriber | short-large | closed_logical_bytes | 0.494 | 0:+0.494%,1:+0.418%,2:+1.220%,4:+0.647% |
| fresh_paired_rust | live-subscriber | short-large | closed_allocated_bytes | 0.490 | 0:+0.490%,1:+0.415%,2:+1.176%,4:+0.604% |
| fresh_paired_rust | live-subscriber | stream | mean_turn_ms | 0.448 | 1:+1.359%,2:+0.964%,3:+0.448% |
| fresh_paired_rust | live-subscriber | stream | turn_cpu_ms_per_turn | 6.667 | 1:+14.286%,2:+7.143%,3:+6.667% |
| fresh_paired_rust | live-subscriber | stream | through_cleanup_self_cpu_ms | 3.571 | 1:+11.538%,2:+4.000%,3:+3.571% |
| fresh_paired_rust | live-subscriber | stream | lifecycle_ms | 0.034 | 1:+1.100%,2:+1.552%,3:+0.034% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_anon_pss_mib | 1.247 | 0:+1.428%,1:+0.813%,2:+1.247%,3:+0.704%,4:+1.352% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_pss_mib | 0.510 | 0:+1.357%,1:+0.358%,2:+1.291%,3:+0.510%,4:+0.032% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_rss_mib | 0.559 | 0:+1.350%,1:+0.342%,2:+1.277%,3:+0.559% |
| fresh_paired_rust | live-subscriber | stream | median_measured_turn_ms | 0.448 | 1:+1.359%,2:+0.964%,3:+0.448% |
| fresh_paired_rust | live-subscriber | stream | lifecycle_self_cpu_ms | 3.571 | 1:+11.538%,2:+4.000%,3:+3.571% |
| fresh_paired_rust | live-subscriber | stream | measured_turn_cpu_ms | 6.667 | 1:+14.286%,2:+7.143%,3:+6.667% |
| fresh_paired_rust | live-subscriber | stream | max_sampled_turn_rss_mib | 0.925 | 0:+1.248%,1:+0.776%,2:+1.180%,3:+0.925% |
| fresh_paired_rust | live-subscriber | stream | through_product_exit_wall_ms | -0.206 | 1:+1.009%,2:+1.619% |
| fresh_paired_rust | live-subscriber | stream | complete_harness_lifecycle_wall_ms | 0.062 | 1:+1.027%,2:+1.462%,3:+0.062% |
| fresh_paired_rust | live-subscriber | large | mean_turn_ms | -2.909 | 0:+32.090%,3:+8.415% |
| fresh_paired_rust | live-subscriber | large | turn_cpu_ms_per_turn | 0.000 | 0:+100.000% |
| fresh_paired_rust | live-subscriber | large | through_cleanup_self_cpu_ms | 6.250 | 0:+6.250%,2:+6.667%,3:+13.333% |
| fresh_paired_rust | live-subscriber | large | lifecycle_ms | 4.356 | 0:+5.885%,2:+4.356%,3:+7.965% |
| fresh_paired_rust | live-subscriber | large | max_sampled_anon_pss_mib | 1.447 | 0:+1.519%,1:+1.447%,2:+1.054%,3:+1.546%,4:+1.435% |
| fresh_paired_rust | live-subscriber | large | max_sampled_pss_mib | 1.236 | 0:+1.460%,1:+1.236%,2:+1.481%,3:+0.986%,4:+1.055% |
| fresh_paired_rust | live-subscriber | large | max_sampled_rss_mib | 1.220 | 0:+1.432%,1:+1.220%,2:+1.447%,3:+0.987%,4:+1.077% |
| fresh_paired_rust | live-subscriber | large | median_measured_turn_ms | -2.909 | 0:+32.090%,3:+8.415% |
| fresh_paired_rust | live-subscriber | large | lifecycle_self_cpu_ms | 6.250 | 0:+6.250%,2:+6.667%,3:+13.333% |
| fresh_paired_rust | live-subscriber | large | measured_turn_cpu_ms | 0.000 | 0:+100.000% |
| fresh_paired_rust | live-subscriber | large | max_sampled_turn_rss_mib | 1.268 | 0:+1.268%,1:+1.493%,2:+1.652%,3:+0.921%,4:+1.010% |
| fresh_paired_rust | live-subscriber | large | through_product_exit_wall_ms | 3.866 | 0:+6.250%,2:+3.866%,3:+8.815%,4:+0.306% |
| fresh_paired_rust | live-subscriber | large | complete_harness_lifecycle_wall_ms | 4.318 | 0:+5.565%,2:+4.318%,3:+8.105%,4:+0.036% |
| fresh_paired_rust | live-subscriber | tool | mean_turn_ms | 18.398 | 1:+25.551%,2:+37.512%,3:+18.398%,4:+7.717% |
| fresh_paired_rust | live-subscriber | tool | turn_cpu_ms_per_turn | 16.667 | 1:+16.667%,2:+60.000%,3:+25.000% |
| fresh_paired_rust | live-subscriber | tool | through_cleanup_self_cpu_ms | 5.882 | 0:+10.000%,1:+5.556%,2:+5.263%,3:+6.250%,4:+5.882% |
| fresh_paired_rust | live-subscriber | tool | lifecycle_ms | 5.077 | 0:+4.144%,1:+5.077%,2:+10.283%,3:+5.186%,4:+2.246% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_anon_pss_mib | 1.418 | 0:+1.049%,1:+1.101%,2:+2.166%,3:+1.418%,4:+3.294% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_pss_mib | 1.559 | 0:+1.420%,1:+1.887%,2:+1.446%,3:+1.559%,4:+2.398% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_rss_mib | 1.621 | 0:+1.358%,1:+1.865%,2:+1.416%,3:+1.621%,4:+2.381% |
| fresh_paired_rust | live-subscriber | tool | median_measured_turn_ms | 18.398 | 1:+25.551%,2:+37.512%,3:+18.398%,4:+7.717% |
| fresh_paired_rust | live-subscriber | tool | lifecycle_self_cpu_ms | 5.882 | 0:+10.000%,1:+5.556%,2:+5.263%,3:+6.250%,4:+5.882% |
| fresh_paired_rust | live-subscriber | tool | measured_turn_cpu_ms | 16.667 | 1:+16.667%,2:+60.000%,3:+25.000% |
| fresh_paired_rust | live-subscriber | tool | max_sampled_turn_rss_mib | 1.825 | 0:+1.334%,1:+2.001%,2:+1.511%,3:+1.825%,4:+2.460% |
| fresh_paired_rust | live-subscriber | tool | through_product_exit_wall_ms | 5.952 | 0:+6.047%,1:+3.672%,2:+11.270%,3:+5.952%,4:+3.071% |
| fresh_paired_rust | live-subscriber | tool | complete_harness_lifecycle_wall_ms | 5.971 | 0:+5.815%,1:+5.971%,2:+10.786%,3:+6.448%,4:+3.780% |
| fresh_paired_rust | live-subscriber | cancel | mean_turn_ms | 8.028 | 0:+4.201%,1:+1.849%,2:+8.028%,3:+20.515%,4:+26.926% |
| fresh_paired_rust | live-subscriber | cancel | turn_cpu_ms_per_turn | 33.333 | 1:+33.333%,3:+66.667%,4:+33.333% |
| fresh_paired_rust | live-subscriber | cancel | through_cleanup_self_cpu_ms | 6.667 | 0:+6.667%,3:+13.333%,4:+6.667% |
| fresh_paired_rust | live-subscriber | cancel | lifecycle_ms | 4.529 | 0:+6.413%,2:+0.191%,3:+8.871%,4:+4.529% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_anon_pss_mib | 1.716 | 0:+1.242%,1:+1.942%,2:+0.653%,3:+1.958%,4:+1.716% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_pss_mib | 1.194 | 0:+1.194%,1:+1.113%,2:+0.746%,3:+1.373%,4:+1.628% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_rss_mib | 1.127 | 0:+1.127%,1:+1.118%,2:+0.800%,3:+1.360%,4:+1.590% |
| fresh_paired_rust | live-subscriber | cancel | median_measured_turn_ms | 8.028 | 0:+4.201%,1:+1.849%,2:+8.028%,3:+20.515%,4:+26.926% |
| fresh_paired_rust | live-subscriber | cancel | lifecycle_self_cpu_ms | 6.667 | 0:+6.667%,3:+13.333%,4:+6.667% |
| fresh_paired_rust | live-subscriber | cancel | measured_turn_cpu_ms | 33.333 | 1:+33.333%,3:+66.667%,4:+33.333% |
| fresh_paired_rust | live-subscriber | cancel | max_sampled_turn_rss_mib | 1.246 | 0:+1.602%,1:+1.246%,2:+0.757%,3:+1.241%,4:+1.627% |
| fresh_paired_rust | live-subscriber | cancel | through_product_exit_wall_ms | 4.934 | 0:+8.994%,2:+0.851%,3:+10.019%,4:+4.934% |
| fresh_paired_rust | live-subscriber | cancel | complete_harness_lifecycle_wall_ms | 4.916 | 0:+10.134%,3:+9.757%,4:+4.916% |
| prior_pi | no-live-subscriber | short-small | closed_allocated_bytes | 43.500 | cross-batch |
| prior_pi | no-live-subscriber | short-small | closed_logical_bytes | 43.407 | cross-batch |
| prior_pi | no-live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 1.969 | cross-batch |
| prior_pi | no-live-subscriber | short-small | lifecycle_ms | 3.007 | cross-batch |
| prior_pi | no-live-subscriber | short-small | lifecycle_self_cpu_ms | 2.569 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_anon_pss_mib | 1.121 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_pss_mib | 1.468 | cross-batch |
| prior_pi | no-live-subscriber | short-small | max_sampled_rss_mib | 1.072 | cross-batch |
| prior_pi | no-live-subscriber | short-small | mean_turn_ms | 4.347 | cross-batch |
| prior_pi | no-live-subscriber | short-small | measured_turn_cpu_ms | 2.478 | cross-batch |
| prior_pi | no-live-subscriber | short-small | measured_turn_write_bytes | 4.303 | cross-batch |
| prior_pi | no-live-subscriber | short-small | median_measured_turn_ms | 4.967 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_process_write_bytes | 4.252 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_process_write_mib | 4.252 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_cleanup_self_cpu_ms | 1.394 | cross-batch |
| prior_pi | no-live-subscriber | short-small | through_product_exit_wall_ms | 1.973 | cross-batch |
| prior_pi | no-live-subscriber | short-small | turn_cpu_ms_per_turn | 2.478 | cross-batch |
| prior_pi | no-live-subscriber | short-small | turn_write_bytes_per_turn | 4.303 | cross-batch |
| prior_pi | no-live-subscriber | short-large | closed_allocated_bytes | 44.417 | cross-batch |
| prior_pi | no-live-subscriber | short-large | closed_logical_bytes | 44.337 | cross-batch |
| prior_pi | no-live-subscriber | short-large | complete_harness_lifecycle_wall_ms | 3.532 | cross-batch |
| prior_pi | no-live-subscriber | short-large | lifecycle_ms | 4.708 | cross-batch |
| prior_pi | no-live-subscriber | short-large | lifecycle_self_cpu_ms | 3.960 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_anon_pss_mib | 1.278 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_pss_mib | 1.513 | cross-batch |
| prior_pi | no-live-subscriber | short-large | max_sampled_rss_mib | 1.199 | cross-batch |
| prior_pi | no-live-subscriber | short-large | mean_turn_ms | 4.603 | cross-batch |
| prior_pi | no-live-subscriber | short-large | measured_turn_cpu_ms | 2.900 | cross-batch |
| prior_pi | no-live-subscriber | short-large | measured_turn_write_bytes | 5.137 | cross-batch |
| prior_pi | no-live-subscriber | short-large | median_measured_turn_ms | 5.364 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_process_write_bytes | 4.732 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_process_write_mib | 4.732 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_cleanup_self_cpu_ms | 2.780 | cross-batch |
| prior_pi | no-live-subscriber | short-large | through_product_exit_wall_ms | 3.636 | cross-batch |
| prior_pi | no-live-subscriber | short-large | turn_cpu_ms_per_turn | 2.900 | cross-batch |
| prior_pi | no-live-subscriber | short-large | turn_write_bytes_per_turn | 5.137 | cross-batch |
| prior_pi | no-live-subscriber | stream | closed_allocated_bytes | 15.906 | cross-batch |
| prior_pi | no-live-subscriber | stream | closed_logical_bytes | 15.807 | cross-batch |
| prior_pi | no-live-subscriber | stream | max_sampled_pss_mib | 1.244 | cross-batch |
| prior_pi | no-live-subscriber | stream | measured_turn_write_bytes | 2.619 | cross-batch |
| prior_pi | no-live-subscriber | stream | through_cleanup_process_write_bytes | 3.836 | cross-batch |
| prior_pi | no-live-subscriber | stream | through_cleanup_process_write_mib | 3.836 | cross-batch |
| prior_pi | no-live-subscriber | stream | turn_write_bytes_per_turn | 2.619 | cross-batch |
| prior_pi | no-live-subscriber | large | closed_allocated_bytes | 10.579 | cross-batch |
| prior_pi | no-live-subscriber | large | closed_logical_bytes | 10.479 | cross-batch |
| prior_pi | no-live-subscriber | large | lifecycle_ms | 1.214 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_anon_pss_mib | 1.089 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_pss_mib | 1.543 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_rss_mib | 1.044 | cross-batch |
| prior_pi | no-live-subscriber | large | max_sampled_turn_rss_mib | 1.042 | cross-batch |
| prior_pi | no-live-subscriber | large | measured_turn_write_bytes | 3.097 | cross-batch |
| prior_pi | no-live-subscriber | large | through_cleanup_process_write_bytes | 4.337 | cross-batch |
| prior_pi | no-live-subscriber | large | through_cleanup_process_write_mib | 4.337 | cross-batch |
| prior_pi | no-live-subscriber | large | turn_write_bytes_per_turn | 3.097 | cross-batch |
| prior_pi | no-live-subscriber | tool | closed_allocated_bytes | 17.969 | cross-batch |
| prior_pi | no-live-subscriber | tool | closed_logical_bytes | 17.850 | cross-batch |
| prior_pi | no-live-subscriber | tool | lifecycle_ms | 1.163 | cross-batch |
| prior_pi | no-live-subscriber | tool | max_sampled_pss_mib | 1.377 | cross-batch |
| prior_pi | no-live-subscriber | tool | max_sampled_turn_rss_mib | 1.056 | cross-batch |
| prior_pi | no-live-subscriber | tool | measured_turn_write_bytes | 2.712 | cross-batch |
| prior_pi | no-live-subscriber | tool | through_cleanup_process_write_bytes | 3.879 | cross-batch |
| prior_pi | no-live-subscriber | tool | through_cleanup_process_write_mib | 3.879 | cross-batch |
| prior_pi | no-live-subscriber | tool | turn_write_bytes_per_turn | 2.712 | cross-batch |
| prior_pi | no-live-subscriber | cancel | closed_allocated_bytes | 13.100 | cross-batch |
| prior_pi | no-live-subscriber | cancel | closed_logical_bytes | 12.972 | cross-batch |
| prior_pi | no-live-subscriber | cancel | lifecycle_ms | 1.179 | cross-batch |
| prior_pi | no-live-subscriber | cancel | max_sampled_pss_mib | 1.394 | cross-batch |
| prior_pi | no-live-subscriber | cancel | max_sampled_turn_rss_mib | 1.033 | cross-batch |
| prior_pi | no-live-subscriber | cancel | measured_turn_write_bytes | 3.194 | cross-batch |
| prior_pi | no-live-subscriber | cancel | through_cleanup_process_write_bytes | 4.553 | cross-batch |
| prior_pi | no-live-subscriber | cancel | through_cleanup_process_write_mib | 4.553 | cross-batch |
| prior_pi | no-live-subscriber | cancel | turn_write_bytes_per_turn | 3.194 | cross-batch |
| prior_pi | live-subscriber | short-small | closed_allocated_bytes | 43.500 | cross-batch |
| prior_pi | live-subscriber | short-small | closed_logical_bytes | 43.407 | cross-batch |
| prior_pi | live-subscriber | short-small | complete_harness_lifecycle_wall_ms | 1.992 | cross-batch |
| prior_pi | live-subscriber | short-small | lifecycle_ms | 3.030 | cross-batch |
| prior_pi | live-subscriber | short-small | lifecycle_self_cpu_ms | 2.907 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_anon_pss_mib | 1.196 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_pss_mib | 1.540 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_rss_mib | 1.119 | cross-batch |
| prior_pi | live-subscriber | short-small | max_sampled_turn_rss_mib | 1.007 | cross-batch |
| prior_pi | live-subscriber | short-small | mean_turn_ms | 4.371 | cross-batch |
| prior_pi | live-subscriber | short-small | measured_turn_cpu_ms | 3.333 | cross-batch |
| prior_pi | live-subscriber | short-small | measured_turn_write_bytes | 4.303 | cross-batch |
| prior_pi | live-subscriber | short-small | median_measured_turn_ms | 4.929 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_process_write_bytes | 4.252 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_process_write_mib | 4.252 | cross-batch |
| prior_pi | live-subscriber | short-small | through_cleanup_self_cpu_ms | 1.619 | cross-batch |
| prior_pi | live-subscriber | short-small | through_product_exit_wall_ms | 1.996 | cross-batch |
| prior_pi | live-subscriber | short-small | turn_cpu_ms_per_turn | 3.333 | cross-batch |
| prior_pi | live-subscriber | short-small | turn_write_bytes_per_turn | 4.303 | cross-batch |
| prior_pi | live-subscriber | short-large | closed_allocated_bytes | 44.400 | cross-batch |
| prior_pi | live-subscriber | short-large | closed_logical_bytes | 44.337 | cross-batch |
| prior_pi | live-subscriber | short-large | complete_harness_lifecycle_wall_ms | 3.260 | cross-batch |
| prior_pi | live-subscriber | short-large | lifecycle_ms | 4.298 | cross-batch |
| prior_pi | live-subscriber | short-large | lifecycle_self_cpu_ms | 3.915 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_anon_pss_mib | 1.282 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_pss_mib | 1.513 | cross-batch |
| prior_pi | live-subscriber | short-large | max_sampled_rss_mib | 1.203 | cross-batch |
| prior_pi | live-subscriber | short-large | mean_turn_ms | 3.360 | cross-batch |
| prior_pi | live-subscriber | short-large | measured_turn_cpu_ms | 2.864 | cross-batch |
| prior_pi | live-subscriber | short-large | measured_turn_write_bytes | 5.136 | cross-batch |
| prior_pi | live-subscriber | short-large | median_measured_turn_ms | 3.699 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_process_write_bytes | 4.733 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_process_write_mib | 4.733 | cross-batch |
| prior_pi | live-subscriber | short-large | through_cleanup_self_cpu_ms | 2.767 | cross-batch |
| prior_pi | live-subscriber | short-large | through_product_exit_wall_ms | 3.332 | cross-batch |
| prior_pi | live-subscriber | short-large | turn_cpu_ms_per_turn | 2.864 | cross-batch |
| prior_pi | live-subscriber | short-large | turn_write_bytes_per_turn | 5.136 | cross-batch |
| prior_pi | live-subscriber | stream | closed_allocated_bytes | 15.906 | cross-batch |
| prior_pi | live-subscriber | stream | closed_logical_bytes | 15.807 | cross-batch |
| prior_pi | live-subscriber | stream | max_sampled_pss_mib | 1.255 | cross-batch |
| prior_pi | live-subscriber | stream | measured_turn_write_bytes | 2.619 | cross-batch |
| prior_pi | live-subscriber | stream | through_cleanup_process_write_bytes | 3.836 | cross-batch |
| prior_pi | live-subscriber | stream | through_cleanup_process_write_mib | 3.836 | cross-batch |
| prior_pi | live-subscriber | stream | turn_write_bytes_per_turn | 2.619 | cross-batch |
| prior_pi | live-subscriber | large | closed_allocated_bytes | 10.579 | cross-batch |
| prior_pi | live-subscriber | large | closed_logical_bytes | 10.479 | cross-batch |
| prior_pi | live-subscriber | large | lifecycle_ms | 1.152 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_anon_pss_mib | 1.093 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_pss_mib | 1.548 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_rss_mib | 1.047 | cross-batch |
| prior_pi | live-subscriber | large | max_sampled_turn_rss_mib | 1.046 | cross-batch |
| prior_pi | live-subscriber | large | measured_turn_write_bytes | 3.097 | cross-batch |
| prior_pi | live-subscriber | large | through_cleanup_process_write_bytes | 4.337 | cross-batch |
| prior_pi | live-subscriber | large | through_cleanup_process_write_mib | 4.337 | cross-batch |
| prior_pi | live-subscriber | large | turn_write_bytes_per_turn | 3.097 | cross-batch |
| prior_pi | live-subscriber | tool | closed_allocated_bytes | 17.969 | cross-batch |
| prior_pi | live-subscriber | tool | closed_logical_bytes | 17.850 | cross-batch |
| prior_pi | live-subscriber | tool | lifecycle_ms | 1.271 | cross-batch |
| prior_pi | live-subscriber | tool | max_sampled_pss_mib | 1.368 | cross-batch |
| prior_pi | live-subscriber | tool | max_sampled_turn_rss_mib | 1.056 | cross-batch |
| prior_pi | live-subscriber | tool | measured_turn_write_bytes | 2.712 | cross-batch |
| prior_pi | live-subscriber | tool | through_cleanup_process_write_bytes | 3.879 | cross-batch |
| prior_pi | live-subscriber | tool | through_cleanup_process_write_mib | 3.879 | cross-batch |
| prior_pi | live-subscriber | tool | turn_write_bytes_per_turn | 2.712 | cross-batch |
| prior_pi | live-subscriber | cancel | closed_allocated_bytes | 13.100 | cross-batch |
| prior_pi | live-subscriber | cancel | closed_logical_bytes | 12.972 | cross-batch |
| prior_pi | live-subscriber | cancel | lifecycle_ms | 1.205 | cross-batch |
| prior_pi | live-subscriber | cancel | max_sampled_pss_mib | 1.387 | cross-batch |
| prior_pi | live-subscriber | cancel | max_sampled_turn_rss_mib | 1.032 | cross-batch |
| prior_pi | live-subscriber | cancel | measured_turn_write_bytes | 3.194 | cross-batch |
| prior_pi | live-subscriber | cancel | through_cleanup_process_write_bytes | 4.553 | cross-batch |
| prior_pi | live-subscriber | cancel | through_cleanup_process_write_mib | 4.553 | cross-batch |
| prior_pi | live-subscriber | cancel | turn_write_bytes_per_turn | 3.194 | cross-batch |
| prior_deepseek | live-subscriber | short-small | mean_turn_ms | 1.106 | cross-batch |
| prior_deepseek | live-subscriber | short-small | median_measured_turn_ms | 1.141 | cross-batch |
| prior_deepseek | live-subscriber | short-small | turn_cpu_ms_per_turn | 1.379 | cross-batch |
| prior_deepseek | live-subscriber | short-small | turn_write_bytes_per_turn | 44.923 | cross-batch |
| prior_deepseek | live-subscriber | short-large | turn_cpu_ms_per_turn | 1.125 | cross-batch |
| prior_deepseek | live-subscriber | short-large | turn_write_bytes_per_turn | 53.916 | cross-batch |
| prior_deepseek | live-subscriber | stream | turn_write_bytes_per_turn | 47.143 | cross-batch |
| prior_deepseek | live-subscriber | large | turn_write_bytes_per_turn | 31.857 | cross-batch |

- Only the fresh old/new Rust products are interleaved pairs. Pi/DeepSeek use fixed previous batches and separate descriptive ratios of medians; no causal parity or paired confidence claim.
- /proc CPU counters use 100 ticks/s; each cumulative endpoint has 10 ms granularity. This is not profiler sampling.
- A product measured-turn median and a product measured-turn mean are different estimands. Across products we report median and range of those statistics, not pooled turns.
- DeepSeek SDK idle does not await flush/fsync. Native wait4 CPU covers exit/flush and verification separately; full process write_bytes is unavailable, not zero. No equivalent lifecycle ratio is constructed.
- All recorded adverse pairs and all unavailable ratios are retained, including reversals hidden by a favorable group median.

Unavailable ratio records, all per-product values, and reference hashes are retained in report-data.json.
