import datetime,json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
profiler=Path('/home/capi/.cache/rustx-pr485-profilers')
binaries={'baseline':Path('/home/capi/.cache/rustx-pr485-merged-operations-final/candidate-complete-build/conformance'),'complete':root/'candidate-complete-build/conformance'}
records=[]
for revision,binary in binaries.items():
 for observer,label,case,short in [('live-subscriber','live','short-large','large'),('no-live-subscriber','no-live','short-large','large'),('no-live-subscriber','no-live','tool','tool')]:
  for mode in ['control','cpu']:
   name=f'profile-{revision}-{label}-{short}-{mode}'
   command=['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root',str(profiler),'--output',str(root/name),'--mode',mode,'--case',case,'--observer-mode',observer]
   record={'name':name,'command':command,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running'}
   build=json.loads((binary.parent/'identity.json').read_text());import hashlib
   assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==build['sha256']
   record['build_identity']=build
   record['preload_sha256']={str(path):hashlib.file_digest(path.open('rb'),'sha256').hexdigest() for path in [profiler/'bridge.so',profiler/'unpacked/usr/lib/x86_64-linux-gnu/libprofiler.so.0']} if mode=='cpu' else {}
   records.append(record);(root/'profile-commands.json').write_text(json.dumps(records,indent=2)+'\n')
   with (root/(name+'.log')).open('w') as log:
    result=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT,env=os.environ|{'UV_OFFLINE':'1'})
   record.update(end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status='complete',exit=result.returncode)
   (root/'profile-commands.json').write_text(json.dumps(records,indent=2)+'\n')
   print(name,result.returncode,flush=True)
   if result.returncode:raise SystemExit(result.returncode)
