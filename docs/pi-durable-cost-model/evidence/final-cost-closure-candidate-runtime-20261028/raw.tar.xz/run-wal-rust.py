import sys,os,json,threading,socket,sqlite3,subprocess,time,hashlib,tempfile,argparse
from pathlib import Path
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run,TEST
parser=argparse.ArgumentParser();parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--label',required=True);args=parser.parse_args()
binary=args.binary.resolve();label=args.label
build=json.loads((binary.parent/'identity.json').read_text());assert build['verified'] and build['sha256']==hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()
original=subprocess.Popen
records=[]
for case in ['short-small','short-large']:
 for engine in ['rust']:
  root=out/f'wal-{label}-{case}-{engine}'
  root.mkdir(exist_ok=False)
  sock=Path(tempfile.mkdtemp(prefix='rxwal-'))/'control.sock';server=socket.socket(socket.AF_UNIX);server.bind(str(sock));server.listen(1);ready=threading.Event();state={};phases=[];fail=[]
  def serve():
   conn=None
   try:
    ready.wait()
    while True:
     conn,_=server.accept();line=b''
     while not line.endswith(b'\n'):
      chunk=conn.recv(128)
      if not chunk:raise RuntimeError('EOF before newline')
      line+=chunk
     phase=line.decode().strip();phases.append({'phase':phase,'monotonic_ns':time.monotonic_ns()})
     if phase in ['before_measured_turns','after_turns']:
      children=Path(f'/proc/{state["pid"]}/task/{state["pid"]}/children').read_text().split();assert len(children)==1,children
      pid=children[0];paths=set()
      for fd in Path(f'/proc/{pid}/fd').iterdir():
       try:p=os.readlink(fd)
       except OSError:continue
       if p.endswith(('.sqlite','.db')) and Path(p).exists():paths.add(p)
      snapshots=[]
      for path in sorted(paths):
       c=sqlite3.connect(f'file:{path}?mode=ro',uri=True);tables=c.execute("SELECT name,sql,rootpage FROM sqlite_schema WHERE type='table'").fetchall();s={'path':path,'tables':tables,'counts':{name:c.execute('SELECT count(*) FROM "'+name.replace('"','""')+'"').fetchone()[0] for name,_,_ in tables},'pages':c.execute('SELECT name,pageno,pagetype,ncell,payload FROM dbstat').fetchall()}
       if any(t[0]=='request_source_nodes' for t in tables):s['source_nodes']=[{'id':i,'metadata_bytes':len(m if isinstance(m,bytes) else m.encode()),'metadata_sha256':hashlib.sha256(m if isinstance(m,bytes) else m.encode()).hexdigest()} for i,m in c.execute('SELECT native_id,metadata FROM request_source_nodes')]
       c.close()
       if path.endswith('conversation.db') or any(t[0]=='events' for t in tables):snapshots.append(s)
      assert len(snapshots)==1,[s['path'] for s in snapshots]
      (root/(phase+'-database.json')).write_text(json.dumps(snapshots,indent=2))
     conn.sendall(b'K');conn.close()
     if phase=='after_cleanup':break
   except Exception as e:
    fail.append(repr(e))
    if conn is not None:conn.close()
  thread=threading.Thread(target=serve,daemon=True);thread.start()
  argv=[str(binary),TEST,'--exact','--ignored','--nocapture']
  def start(args,*a,**kw):
   if args==argv:
    wrapped=['strace','-f','-yy','-s','96','-e','trace=pwrite64,write,writev,sendto,sendmsg,fsync,fdatasync','-o',str(root/'calls.strace'),'--',*args]
    product=original(wrapped,*a,**kw);state['pid']=product.pid;ready.set();return product
   return original(args,*a,**kw)
  (root/'identity-before.json').write_text(json.dumps(dict(build=build,binary_sha256=hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),runner_sha256=hashlib.file_digest(Path(__file__).open('rb'),'sha256').hexdigest(),argv=argv),indent=2))
  subprocess.Popen=start
  env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))};env.update(UV_OFFLINE='1',RUSTX_BENCH_CASE=case,RUSTX_BENCH_OBSERVER_MODE='no-live-subscriber',RUSTX_BENCH_OUTPUT=str(root/'sample.json'),RUSTX_BENCH_PROFILE_SOCKET=str(sock))
  start_ns=time.monotonic_ns();result=run(argv,root/'sample',case,env,repo/'test-support/fake-provider');subprocess.Popen=original
  thread.join(5);server.close();sock.unlink();sock.parent.rmdir();(root/'phases.json').write_text(json.dumps(phases,indent=2));records.append(dict(engine=engine,case=case,accepted=result['accepted'],error=result.get('error'),diagnostic_error=fail,start_ns=start_ns,end_ns=time.monotonic_ns()))
  (out/f'wal-records-{label}.json').write_text(json.dumps(records,indent=2));print(records[-1],flush=True)
  assert not fail,fail;assert not thread.is_alive();assert result['accepted'],result.get('error')
  assert build['sha256']==hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()
(out/f'wal-identity-{label}.json').write_text(json.dumps({'rust_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'rust_source':build['head'],'scope':'Rust-only diagnostic WAL counts. No timing claims. External strace parent, sibling provider; dbstat snapshots at synchronous boundaries. Unmodified production binary.'},indent=2))
