import sys,os,json,threading,socket,sqlite3,subprocess,time,hashlib,tempfile,argparse
from pathlib import Path
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX');out=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/runtime'));from controller import run,TEST
parser=argparse.ArgumentParser();parser.add_argument('--binary',type=Path,required=True);parser.add_argument('--label',choices=['baseline','complete'],required=True);args=parser.parse_args()
binary=args.binary.resolve();build=json.loads((binary.parent/'identity.json').read_text());assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==build['sha256']
original=subprocess.Popen
for case in ['short-small','short-large']:
 root=out/('columns-'+args.label+'-'+case);root.mkdir(exist_ok=False)
 sock=Path(tempfile.mkdtemp(prefix='rxcols-'))/'control.sock';server=socket.socket(socket.AF_UNIX);server.bind(str(sock));server.listen(1);ready=threading.Event();state={};fail=[];phases=[]
 def serve():
  conn=None
  try:
   ready.wait()
   while True:
    conn,_=server.accept();line=b''
    while not line.endswith(b'\n'):
     chunk=conn.recv(128)
     if not chunk:raise RuntimeError('boundary EOF')
     line+=chunk
    phase=line.decode().strip();phases.append(phase)
    if phase in ['before_measured_turns','after_turns']:
     paths=set()
     for fd in Path(f'/proc/{state["pid"]}/fd').iterdir():
      try:p=os.readlink(fd)
      except OSError:continue
      if p.endswith(('.sqlite','.db')) and Path(p).exists():paths.add(p)
     snapshots=[]
     for path in sorted(paths):
      c=sqlite3.connect(f'file:{path}?mode=ro',uri=True);tables=c.execute("SELECT name FROM sqlite_schema WHERE type='table'").fetchall()
      if not any(name=='events' for (name,) in tables):c.close();continue
      quote=lambda name:'"'+name.replace('"','""')+'"'
      allcols={}
      for (name,) in tables:
       info=c.execute('PRAGMA table_info('+quote(name)+')').fetchall();cols=[row[1] for row in info]
       exprs=[f'coalesce(sum(length(cast({quote(col)} as blob))),0)' for col in cols]
       row=c.execute('SELECT count(*),'+','.join(exprs)+' FROM '+quote(name)).fetchone()
       allcols[name]={'rows':row[0],'column_value_bytes':dict(zip(cols,row[1:]))}
      cols=[row[1] for row in c.execute('PRAGMA table_info(events)')]
      exprs=[f'coalesce(sum(length(cast({quote(col)} as blob))),0)' for col in cols]
      kinds=[{'kind':row[0],'rows':row[1],'column_value_bytes':dict(zip(cols,row[2:]))} for row in c.execute("SELECT json_extract(event_json,'$.event.type'),count(*),"+','.join(exprs)+" FROM events GROUP BY json_extract(event_json,'$.event.type')")]
      if 'observation_json' in cols:
       duplicate=c.execute('SELECT count(*),coalesce(sum(length(event_json)),0) FROM events WHERE observation_json IS NOT NULL AND cast(observation_json as text)=event_json').fetchone()
       duplicate_record={'status':'measured','rows':duplicate[0],'native_bytes':duplicate[1]}
      else:
       duplicate_record={'status':'retired_layout_absent','table':'events','column':'observation_json','rows':None,'native_bytes':None}
      snapshots.append({'scope':'main_database_only; connection-local TEMP owner state and virtual generated columns are outside this read-only connection measurement', 'path':path,'tables':allcols,'events_by_kind':kinds,'equal_event_observation_json':duplicate_record,'dbstat':c.execute('SELECT name,sum(pgsize),sum(payload),count(*) FROM dbstat GROUP BY name').fetchall()});c.close()
     assert len(snapshots)==1
     (root/(phase+'.json')).write_text(json.dumps(snapshots[0],indent=2))
    conn.sendall(b'K');conn.close()
    if phase=='after_cleanup':break
  except Exception as e:
   fail.append(repr(e))
   if conn is not None:conn.close()
 thread=threading.Thread(target=serve,daemon=True);thread.start();argv=[str(binary),TEST,'--exact','--ignored','--nocapture']
 def start(args,*a,**kw):
  p=original(args,*a,**kw)
  if args==argv:state['pid']=p.pid;ready.set()
  return p
 (root/'identity-before.json').write_text(json.dumps({'build':build,'scope':'Read-only synchronized SQL column logical-byte diagnostics, not WAL/device bytes or timing results. Exact recorded ordinary O3 binary; main database only, TEMP state unavailable from this connection.'},indent=2))
 subprocess.Popen=start
 env={k:v for k,v in os.environ.items() if not any(s in k.upper() for s in ('TOKEN','SECRET','CREDENTIAL','API_KEY'))};env.update(UV_OFFLINE='1',RUSTX_BENCH_CASE=case,RUSTX_BENCH_OBSERVER_MODE='no-live-subscriber',RUSTX_BENCH_OUTPUT=str(root/'sample.json'),RUSTX_BENCH_PROFILE_SOCKET=str(sock))
 result=run(argv,root/'sample',case,env,repo/'test-support/fake-provider');subprocess.Popen=original
 thread.join(5);server.close();sock.unlink();sock.parent.rmdir();(root/'phases.json').write_text(json.dumps(phases));print(case,result['accepted'],fail,flush=True);assert result['accepted'] and not fail and not thread.is_alive()
