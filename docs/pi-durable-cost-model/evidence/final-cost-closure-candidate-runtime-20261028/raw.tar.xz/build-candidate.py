import argparse,datetime,hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-pi-performance/rustX')
target=Path('/home/capi/.cache/rustx-pr485-target')
parser=argparse.ArgumentParser();parser.add_argument('--checks-dir',required=True);args=parser.parse_args()
check_name=Path(args.checks_dir);assert not check_name.is_absolute() and len(check_name.parts)==1 and check_name.name.startswith('checks'), 'checks-dir must name one local retained correctness directory'
checks=root/check_name
build=root/'candidate-complete-build';build.mkdir(exist_ok=False)
def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def files():
 inputs=sorted(p for folder in ('src','tests') for p in (repo/folder).rglob('*') if p.is_file())+[repo/'Cargo.toml',repo/'Cargo.lock']
 return {str(p.relative_to(repo)):sha(p) for p in inputs}
assert not git('status','--porcelain','--','src','Cargo.toml','Cargo.lock','tests','benchmarks/runtime')
harness=json.loads(Path('/home/capi/.cache/rustx-pr485-complete-costs-final/candidate-complete-build/identity.json').read_text())['harness']
assert all(sha(repo/p)==h for p,h in harness.items())
source=files()
check_rows=json.loads((checks/'check-build-commands.json').read_text())
assert check_rows and check_rows[-1]['label']=='clippy' and all(row['status']=='complete' and row['exit']==0 for row in check_rows)
required_checks={'fmt','tests-build','tests-sqlite','tests-client','tests-app-server','tests-conversation-runtime','tests-read-layout','tests-content','tests-agent','tests-tool-registry','tests-recovery','tests-process-death','tests-durable','tests-process','clippy'}
assert len(check_rows)==len(required_checks) and {row['label'] for row in check_rows}==required_checks, 'incomplete or duplicate correctness queue'
assert all((checks/(row['label']+suffix)).is_file() for row in check_rows for suffix in ('.stdout','.stderr')), 'missing correctness command evidence'
assert json.loads((checks/'source-before.json').read_text())['files']==json.loads((checks/'source-after.json').read_text())['files']==source
validated_checks={'directory':str(check_name),'files':{name:sha(checks/name) for name in ('check-build-commands.json','source-before.json','source-after.json')}}
commands=[['cargo','clean','--release','--package','rustx'],['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json']]
record={'head':git('rev-parse','HEAD'),'production_tree':git('rev-parse','HEAD:src'),'harness':harness,'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':commands,'rustc':subprocess.check_output(['rustc','-vV'],cwd=repo,text=True),'cargo':subprocess.check_output(['cargo','-V'],cwd=repo,text=True),'build_environment':{'CARGO_BUILD_JOBS':'2'},'source_files':source,'validation':validated_checks}
env=os.environ|{'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'2'}
assert not any(k.startswith('CARGO_PROFILE_') for k in env)
assert not env.get('RUSTFLAGS') and not env.get('CARGO_ENCODED_RUSTFLAGS')
for name,cmd in zip(['clean','build'],commands):
 with (build/(name+'.stdout')).open('w') as out,(build/(name+'.stderr')).open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 record[name+'_exit']=r.returncode;(build/'identity.json').write_text(json.dumps(record,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
rows=[json.loads(l) for l in (build/'build.stdout').read_text().splitlines() if l.startswith('{')]
assert [r for r in rows if r.get('reason')=='build-finished']==[{'reason':'build-finished','success':True}]
artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r['target']['src_path'].startswith(str(repo))]
record['root_artifacts']=[{'name':r['target']['name'],'kind':r['target']['kind'],'source_path':r['target']['src_path'],'fresh':r['fresh']} for r in artifacts]
assert artifacts and all(not r['fresh'] and r['profile']['opt_level']=='3' and r['features']==[] and not r['profile']['debug_assertions'] and not r['profile']['overflow_checks'] for r in artifacts), 'ordinary O3/default-feature artifacts required'
exe=next(Path(r['executable']) for r in artifacts if r['target']['name']=='conformance' and r.get('executable'))
lib=next(Path(p) for r in artifacts if r['target']['kind']==['lib'] for p in r['filenames'] if p.endswith('.rlib'))
binary=build/'conformance';shutil.copy2(exe,binary)
assert source==files() and record['head']==git('rev-parse','HEAD')
assert not git('status','--porcelain','--','src','Cargo.toml','Cargo.lock','tests','benchmarks/runtime')
assert all(sha(repo/p)==h for p,h in harness.items())
assert all(sha(checks/name)==digest for name,digest in validated_checks['files'].items())
record.update(binary=str(binary),sha256=sha(binary),library_sha256=sha(lib),verified=True,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(build/'identity.json').write_text(json.dumps(record,indent=2)+'\n');print('binary',record['sha256'],flush=True)
