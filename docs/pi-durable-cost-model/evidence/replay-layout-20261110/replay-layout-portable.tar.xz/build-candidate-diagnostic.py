"""Bind the phase-only diagnostic CLI to fresh exact-checkout artifacts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
output = root / 'candidate-diagnostic-build'
output.mkdir(exist_ok=False)
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
assert not git('status', '--porcelain', '--', 'src', 'Cargo.toml', 'Cargo.lock')
command = ['cargo', 'build', '--release', '--locked', '--features', 'issue-387-profile', '--bin', 'rustx', '--message-format=json']
identity = {'head': git('rev-parse', 'HEAD'), 'rust_tree': git('rev-parse', 'HEAD:src'), 'command': command,
            'begin_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'rustc': subprocess.check_output(['rustc', '--version', '--verbose'], text=True),
            'scope': 'Non-default profiling feature. Owner census only, no headline elapsed-time or PSS claim.'}
env = os.environ | {'CARGO_TARGET_DIR': '/home/capi/.cache/rustx-pr485-main-integration-target', 'CARGO_BUILD_JOBS': '8'}
with (output / 'build.jsonl').open('w') as stdout, (output / 'build.log').open('w') as stderr:
    result = subprocess.run(command, cwd=repo, env=env, stdout=stdout, stderr=stderr)
identity['exit'] = result.returncode
if result.returncode == 0:
    rows = [json.loads(line) for line in (output / 'build.jsonl').read_text().splitlines() if line.startswith('{')]
    artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('target', {}).get('name') == 'rustx']
    assert len(artifacts) == 2 and all(row['fresh'] is False for row in artifacts)
    binary = next(row for row in artifacts if row['target']['kind'] == ['bin'])
    library = next(row for row in artifacts if row['target']['kind'] == ['lib'])
    assert binary['target']['src_path'] == str(repo / 'src/main.rs')
    assert library['target']['src_path'] == str(repo / 'src/lib.rs')
    shutil.copy2(binary['executable'], output / 'rustx')
    identity.update(binary_sha256=hashlib.file_digest((output / 'rustx').open('rb'), 'sha256').hexdigest(),
                    library_sha256=hashlib.file_digest(Path(next(path for path in library['filenames'] if path.endswith('.rlib'))).open('rb'), 'sha256').hexdigest(),
                    profile=binary['profile'], verified=True)
assert git('rev-parse', 'HEAD') == identity['head']
assert not git('status', '--porcelain', '--', 'src', 'Cargo.toml', 'Cargo.lock')
identity['end_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(output / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity, indent=2))
result.check_returncode()
