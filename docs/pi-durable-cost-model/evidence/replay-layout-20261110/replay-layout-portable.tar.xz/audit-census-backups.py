from pathlib import Path
import hashlib,json,sqlite3
r=Path(__file__).resolve().parent;rows=[]
for side in ['baseline','candidate']:
 d=r/(side+'-census-128x32');backups=json.loads((d/'native-closed.json').read_text());assert len(backups)==128
 assert json.loads((d/'retained-all_unloaded.json').read_text())==[]
 for backup in backups:
  index=backup['session_index'];p=d/'native-snapshots'/f'{index:04}.sqlite';digest=hashlib.file_digest(p.open('rb'),'sha256').hexdigest();assert digest==backup['consistent_backup_sha256']
  with sqlite3.connect(p.as_uri()+'?mode=ro',uri=True) as c:
   assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok';assert c.execute('PRAGMA foreign_key_check').fetchall()==[];assert c.execute('SELECT schema_version FROM rustx_store WHERE id=1').fetchone()[0]==106
   messages=[json.loads(v) for v, in c.execute('SELECT message_json FROM message_ledger ORDER BY position')]
  assert len(messages)==64
  for turn in range(32):
   user,answer=messages[turn*2:turn*2+2];assert user['role']=='user' and user['content']==[{'type':'text','text':f'capacity turn session={index:04} turn={turn:04}'}];assert answer['role']=='assistant' and answer['content']==[{'type':'text','text':'capacity response'}]
  rows.append({'side':side,'session':index,'sha256':digest,'schema':106,'messages':64,'integrity':'ok','foreign_keys':[],'exact_ordered_content':True})
(r/'census-backup-audit.json').write_text(json.dumps({'scope':'Independent audit of all diagnostic backup hashes, native messages and relational integrity; not performance data. Retained graph after unload is separately empty on both sides.','rows':rows},indent=2)+'\n');print('verified',len(rows),'backups')
