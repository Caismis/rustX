from pathlib import Path
import hashlib,importlib,json,sqlite3,subprocess,sys,time
root=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');sys.path.insert(0,str(repo/'benchmarks/runtime'));metrics=importlib.import_module('summarize-http');fixture=repo/'benchmarks/runtime/app-server-capacity.py';records=[]
for side,binary in [('after',root/'candidate-build/rustx'),('before',Path('/home/capi/.cache/rustx-pr485-block-coordinates-20261110/build/rustx'))]:
 assert subprocess.run(['pgrep','-x','rustc|clippy-driver|cargo|rust-lld|ld.lld'],capture_output=True).returncode!=0
 directory=root/('deep-16x64-'+side);command=[sys.executable,str(fixture),'--binary',str(binary),'--output',str(directory),'--sessions','16','--history','64','--history-checkpoints','8','32','--memory-only'];host=[]
 with (root/(directory.name+'.log')).open('x') as log:
  process=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  while process.poll() is None:
   host.append({'monotonic_ns':time.monotonic_ns(),'compiler_pids':subprocess.run(['pgrep','-x','rustc|clippy-driver|cargo|rust-lld|ld.lld'],capture_output=True,text=True).stdout.split()});time.sleep(.5)
 assert process.returncode==0
 (root/(directory.name+'-host.json')).write_text(json.dumps(host,indent=2)+'\n');complete=json.loads((directory/'completed.json').read_text());assert complete['accepted'] and complete['requests']==1024
 backups=json.loads((directory/'native-closed.json').read_text());assert len(backups)==16
 for backup in backups:
  index=backup['session_index'];p=directory/'native-snapshots'/f'{index:04}.sqlite';assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==backup['consistent_backup_sha256']
  with sqlite3.connect(p.as_uri()+'?mode=ro',uri=True) as c:
   assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok' and c.execute('PRAGMA foreign_key_check').fetchall()==[];assert c.execute('SELECT schema_version FROM rustx_store WHERE id=1').fetchone()[0]==106;messages=[json.loads(v) for v, in c.execute('SELECT message_json FROM message_ledger ORDER BY position')]
  assert len(messages)==128
  for turn in range(64):
   user,answer=messages[turn*2:turn*2+2];assert user['role']=='user' and user['content']==[{'type':'text','text':f'capacity turn session={index:04} turn={turn:04}'}];assert answer['role']=='assistant' and answer['content']==[{'type':'text','text':'capacity response'}]
 phases={v['phase']:v for v in json.loads((directory/'phases.json').read_text())};records.append({'side':side,'command':command,'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest(),'fixture_sha256':hashlib.file_digest(fixture.open('rb'),'sha256').hexdigest(),'anon_pss_mib':metrics.counters(phases['seeded_history_64'])['anon_pss_kib']/1024,'verified_backups':16,'requests':1024,'compiler_overlap_samples':sum(bool(x['compiler_pids']) for x in host)})
 (root/'deep-summary.json').write_text(json.dumps({'scope':'One supplementary reverse-order 16x64 pair; ordinary GNU allocator, native server PID. Every backup hash, exact content/order, schema, integrity and FK checked. Not a four-pair capacity or timing estimate.','rows':records},indent=2)+'\n');print(side,records[-1]['anon_pss_mib'],flush=True)
