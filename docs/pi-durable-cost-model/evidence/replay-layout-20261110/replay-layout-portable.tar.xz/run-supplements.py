from pathlib import Path
import datetime,hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');names=['run-native-resume.py','audit-native.py','run-deep-wait.py'];records=[]
(r/'supplement-inputs.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'helpers':{name:hashlib.file_digest((r/name).open('rb'),'sha256').hexdigest() for name in names},'reason':'Native supplements stopped before any product due to expanded compiler preflight. Resume once quiet, never rerun completed products.'},indent=2)+'\n')
for name in names:
 command=[sys.executable,str(r/name)];began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'-final.log')).open('x') as log:p=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':command,'begin_utc':began,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode});(r/'supplement-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,p.returncode,flush=True);assert p.returncode==0
