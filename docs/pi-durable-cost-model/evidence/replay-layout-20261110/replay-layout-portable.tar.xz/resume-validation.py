from pathlib import Path
import datetime,hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='86bf61a3050dbf85818386d7242d141c59785439'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
files=['run-memory-resume.py','audit-memory-complete.py','run-native-controlled.py','audit-native.py','run-deep-controlled.py'];(r/'resume-inputs.json').write_text(json.dumps({'head':'86bf61a3050dbf85818386d7242d141c59785439','decision':'Continue completed memory products without rerunning them; pair 0 is retained but excluded because its candidate overlapped rustc. Add one replacement pair for four clean pairs. This decision precedes those additional measurements. Compiler guard expanded to Clippy/cargo/linkers.','helpers':{name:hashlib.file_digest((r/name).open('rb'),'sha256').hexdigest() for name in files}},indent=2)+'\n')
records=[]
for name in files:
 command=[sys.executable,str(r/name)];began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'.log')).open('x') as log:run=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':command,'begin_utc':began,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':run.returncode});(r/'resume-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,run.returncode,flush=True);assert run.returncode==0
