from pathlib import Path
import datetime,json,subprocess,sys,time
r=Path(__file__).resolve().parent;points=[];quiet=0
while quiet<3:
 ids=subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True).stdout.split()
 points.append({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'compiler_pids':ids})
 (r/'cpu-followup-preflight-wait.json').write_text(json.dumps(points,indent=2)+'\n')
 quiet=quiet+1 if not ids else 0
 if quiet<3:time.sleep(5)
with (r/'cpu-followup-driver.log').open('x') as log:
 result=subprocess.run([sys.executable,str(r/'run-cpu-followup.py')],stdout=log,stderr=subprocess.STDOUT)
print('validation',result.returncode,flush=True)
raise SystemExit(result.returncode)
