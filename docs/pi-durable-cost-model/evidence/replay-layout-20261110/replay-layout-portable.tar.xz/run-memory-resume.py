"""Four balanced ordinary native pairs, with depth sampled in each process."""
from pathlib import Path
import datetime,hashlib,json,subprocess,sys,time
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
fixture=repo/'benchmarks/runtime/app-server-capacity.py'
fixture_hash=hashlib.file_digest(fixture.open('rb'),'sha256').hexdigest()
binaries={'before':Path('/home/capi/.cache/rustx-pr485-block-coordinates-20261110/build/rustx'),'after':root/'candidate-build/rustx'}
records=json.loads((root/'memory-commands.json').read_text())
for pair in range(5):
 for side in (['before','after'] if pair%2==0 else ['after','before']):
  if any(v['pair']==pair and v['side']==side for v in records):continue
  assert hashlib.file_digest(fixture.open('rb'),'sha256').hexdigest()==fixture_hash
  quiet=0
  while quiet<3:
   busy=subprocess.run(['pgrep','-x','rustc|clippy-driver|cargo|rust-lld|ld.lld'],capture_output=True).returncode==0
   quiet=0 if busy else quiet+1
   if quiet<3:time.sleep(3)
  name=f'memory-{pair}-{side}'
  command=[sys.executable,str(fixture),'--binary',str(binaries[side]),'--output',str(root/name),'--sessions','128','--history','32','--history-checkpoints','8','16','--memory-only']
  record={'pair':pair,'side':side,'command':command,'fixture_sha256':fixture_hash,'binary_sha256':hashlib.file_digest(binaries[side].open('rb'),'sha256').hexdigest(),'begin_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  host=[]
  with (root/(name+'.log')).open('x') as log:
   process=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
   while process.poll() is None:
    host.append({'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'compiler_pids':subprocess.run(['pgrep','-x','rustc|clippy-driver|cargo|rust-lld|ld.lld'],capture_output=True,text=True).stdout.split()})
    time.sleep(.5)
  (root/(name+'-host.json')).write_text(json.dumps(host,indent=2)+'\n')
  record.update(exit=process.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
  records.append(record); (root/'memory-commands.json').write_text(json.dumps(records,indent=2)+'\n')
  print(name,process.returncode,flush=True)
  assert process.returncode==0 and json.loads((root/name/'completed.json').read_text())['accepted']
