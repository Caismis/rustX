from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');b=Path('/home/capi/.cache/rustx-pr485-block-coordinates-20261110/build/conformance');a=r/'candidate-build/conformance';profiler=Path('/home/capi/.cache/rustx-pr485-profilers')
# Additional question fixed before execution: does the all-pairs short-history CPU
# regression persist with both unchanged binaries constrained to the same two
# physical performance cores? Original unpinned results remain untouched.
cpus='8,10';assert set(map(int,cpus.split(',')))<=os.sched_getaffinity(0)
jobs=[('affinity',['taskset','-c',cpus,sys.executable,str(repo/'benchmarks/runtime/compare-revisions.py'),'--before',str(b),'--after',str(a),'--output',str(r/'affinity-short'),'--pairs','4','--observer-mode','live-subscriber','--case','short-small'])]
for side,binary in [('after',a),('before',b)]:
 jobs.append(('profile-'+side,['taskset','-c',cpus,sys.executable,str(r/'profile-cpu.py'),'--binary',str(binary),'--profiler-root',str(profiler),'--output',str(r/('cpu-profile-'+side)),'--mode','cpu','--case','short-small','--observer-mode','live-subscriber']))
records=[]
for name,command in jobs:
 assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0
 host=[];began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'-driver.log')).open('x') as log:
  p=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  while p.poll() is None:
   host.append({'monotonic_ns':time.monotonic_ns(),'loadavg':Path('/proc/loadavg').read_text(),'compiler_pids':subprocess.run(['pgrep','-x','rustc'],capture_output=True,text=True).stdout.split()});time.sleep(.5)
 (r/(name+'-host.json')).write_text(json.dumps(host,indent=2)+'\n')
 records.append({'name':name,'command':command,'begin_utc':began,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode,'compiler_overlap_samples':sum(bool(v['compiler_pids']) for v in host)})
 (r/'cpu-followup-commands.json').write_text(json.dumps({'question':'Separate CPU-placement effects from the new layout: one four-pair short-history follow-up on the same two performance cores, then one 1000-Hz diagnostic profile per side. Not a replacement matrix or pooled significance claim. All original adverse products remain.','cpu_affinity':cpus,'binary_sha256':{'before':hashlib.file_digest(b.open('rb'),'sha256').hexdigest(),'after':hashlib.file_digest(a.open('rb'),'sha256').hexdigest()},'commands':records},indent=2)+'\n');print(name,p.returncode,flush=True)
 assert p.returncode==0
