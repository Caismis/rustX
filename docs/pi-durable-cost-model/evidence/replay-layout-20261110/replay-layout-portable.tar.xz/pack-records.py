from pathlib import Path
import hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');packed=r/'packed';packed.mkdir(exist_ok=True)
patterns=['*.py','*.json','*.jsonl','*.log','*.patch','*.csv','*.txt','*.md','clippy-probe/*.toml','ordinary/*','functional/*','affinity-short/*']
for family in ['candidate-build','baseline-diagnostic-build','candidate-diagnostic-build','candidate-correctness','candidate-correctness-final']:
 patterns += [family+'/'+suffix for suffix in ['*.json','*.jsonl','*.log','*.stdout','*.stderr','*.patch']]
for family in ['baseline-census-128x32','candidate-census-128x32','memory-*','native-*','deep-*']:
 patterns += [family+'/'+suffix for suffix in ['*.json','*.log','*.stdout','*.stderr','native-snapshots/0000.sqlite','native-snapshots/0127.sqlite','native-snapshots/0015.sqlite']]
patterns += ['cpu-profile-*/*.json','cpu-profile-*/*.log','cpu-profile-*/*.cpu','cpu-profile-*/*.txt','cpu-profile-*/*.stderr']
full=patterns+[family+'/native-snapshots/*.sqlite' for family in ['baseline-census-128x32','candidate-census-128x32','memory-*','native-*','deep-*']]
index={'root':str(r),'scope':'Both archives retain every raw measurement/per-turn/process counter/provider request, adverse and failed result, compiler/preflight monitor, build/helper identity, verification record and backup hash. Full includes every one of 2080 consistent native backups. Portable includes first/last representative DBs, not every image. Product ELF/dependency trees and private/live runtime/workspace roots are excluded; originals remain locally. Census requested allocations and ordinary PSS/CPU/writes remain separate.','archives':{}}
(r/'archive-scope.json').write_text(json.dumps(index,indent=2)+'\n')
for name,selected in [('full',full),('portable',patterns)]:
 out=packed/f'replay-layout-{name}.tar.xz';command=[sys.executable,str(repo/'benchmarks/runtime/pack-evidence.py'),'--root',str(r),'--output',str(out),*selected]
 subprocess.run(command,cwd=repo,check=True)
 manifest=out.with_suffix('.manifest.json');index['archives'][name]={'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.file_digest(out.open('rb'),'sha256').hexdigest(),'manifest':str(manifest),'files':len(json.loads(manifest.read_text())),'verified':True}
 (r/'archive-index.json').write_text(json.dumps(index,indent=2)+'\n')
