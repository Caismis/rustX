"""One supplementary native pair per active pattern, preserving all endpoints."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
repo = Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
fixture = repo / 'benchmarks/runtime/app-server-capacity.py'
fixture_hash = hashlib.file_digest(fixture.open('rb'), 'sha256').hexdigest()
binaries = {'before': Path('/home/capi/.cache/rustx-pr485-block-coordinates-20261110/build/rustx'),
            'after': root / 'candidate-build/rustx'}
records = []
for family in ['fixed', 'rotating']:
    for side in (['before', 'after'] if family == 'fixed' else ['after', 'before']):
        assert hashlib.file_digest(fixture.open('rb'), 'sha256').hexdigest() == fixture_hash
        assert subprocess.run(['pgrep', '-x', 'rustc|clippy-driver|cargo|rust-lld|ld.lld'], capture_output=True).returncode != 0
        name = f'native-{family}-{side}'
        command = [sys.executable, str(fixture), '--binary', str(binaries[side]),
                   '--output', str(root / name), '--sessions', '128', '--history', '8',
                   '--widths', '4', '--rounds', '64']
        if family == 'rotating':
            command.append('--rotate-active')
        record = {'family': family, 'side': side, 'command': command, 'fixture_sha256': fixture_hash,
                  'binary_sha256': hashlib.file_digest(binaries[side].open('rb'), 'sha256').hexdigest(),
                  'begin_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        host = []
        with (root / (name + '.log')).open('x') as log:
            process = subprocess.Popen(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
            while process.poll() is None:
                host.append({'monotonic_ns': time.monotonic_ns(), 'loadavg': Path('/proc/loadavg').read_text(),
                             'compiler_pids': subprocess.run(['pgrep', '-x', 'rustc|clippy-driver|cargo|rust-lld|ld.lld'], capture_output=True, text=True).stdout.split()})
                time.sleep(.5)
        (root / (name + '-host.json')).write_text(json.dumps(host, indent=2) + '\n')
        record.update(exit=process.returncode, end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        records.append(record)
        (root / 'native-commands.json').write_text(json.dumps(records, indent=2) + '\n')
        print(name, process.returncode, flush=True)
        assert process.returncode == 0 and json.loads((root / name / 'completed.json').read_text())['accepted']
        assert hashlib.file_digest(fixture.open('rb'), 'sha256').hexdigest() == fixture_hash
