from pathlib import Path
import hashlib,json,re,subprocess
r=Path(__file__).resolve().parent;pprof=Path('/home/capi/.cache/rustx-pr485-profilers/unpacked/usr/bin/google-pprof');binaries={'before':Path('/home/capi/.cache/rustx-pr485-block-coordinates-20261110/build/conformance'),'after':r/'candidate-build/conformance'};records=[]
for side,binary in binaries.items():
 directory=r/('cpu-profile-'+side);command=[str(pprof),'--text','--cum','--no_strip_temp','--nodecount=100',str(binary),str(directory/'before_measured_turns.cpu')]
 with (directory/'steady-cumulative.txt').open('x') as out,(directory/'pprof.stderr').open('x') as err:p=subprocess.run(command,stdout=out,stderr=err)
 rows=[]
 if p.returncode==0:
  lines=(directory/'steady-cumulative.txt').read_text().splitlines()
  for line in lines[1:]:
   m=re.match(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)',line)
   if m:rows.append({'symbol':m[3],'flat_samples':int(m[1]),'cumulative_samples':int(m[2])})
 records.append({'side':side,'command':command,'exit':p.returncode,'rows':rows,'binary_sha256':hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()})
(r/'cpu-profile-symbols.json').write_text(json.dumps({'scope':'One diagnostic profile per side on CPUs 8,10, GNU allocation, requested 1000-Hz signal samples. Numerators are samples, cumulative stacks overlap, profiles are too small for precise single-function regressions or exclusive timers. They do not establish cause of the ordinary short-history adverse result.','profiles':records},indent=2)+'\n')
for record in records:
 print(record['side'],record['exit'],record['rows'][:8])
