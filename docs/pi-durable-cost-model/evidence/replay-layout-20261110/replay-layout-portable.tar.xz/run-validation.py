from pathlib import Path
import datetime,hashlib,json,subprocess,sys
r=Path(__file__).resolve().parent;repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX');before=Path('/home/capi/.cache/rustx-pr485-block-coordinates-20261110/build');after=r/'candidate-build'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head=='86bf61a3050dbf85818386d7242d141c59785439'
identity=json.loads((after/'identity.json').read_text());control=json.loads((before/'identity.json').read_text());assert identity['verified'] and identity['head']==head and identity['harness']==control['harness']
for directory in [before,after]:
 i=json.loads((directory/'identity.json').read_text())
 assert hashlib.file_digest((directory/'conformance').open('rb'),'sha256').hexdigest()==i['sha256']
 assert hashlib.file_digest((directory/'rustx').open('rb'),'sha256').hexdigest()==i['cli']['sha256']
files=[r/name for name in ['run-ordinary.py','ordinary_summary.py','run-memory.py','audit-memory.py','run-native.py','audit-native.py','run-deep.py']]
frozen={str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in files}
(r/'validation-inputs.json').write_text(json.dumps({'head':head,'production_tree':identity['production_tree'],'helpers':frozen,'harness':identity['harness'],'ordinary_build_verified':True},indent=2)+'\n')
jobs=[('ordinary',[sys.executable,str(r/'run-ordinary.py')]),('functional',[sys.executable,str(repo/'benchmarks/runtime/compare-revisions.py'),'--before',str(before/'conformance'),'--after',str(after/'conformance'),'--observer-mode','live-subscriber','--output',str(r/'functional'),'--pairs','1','--case','tool','--case','cancel']),('memory',[sys.executable,str(r/'run-memory.py')]),('audit-memory',[sys.executable,str(r/'audit-memory.py')]),('native',[sys.executable,str(r/'run-native.py')]),('audit-native',[sys.executable,str(r/'audit-native.py')]),('deep',[sys.executable,str(r/'run-deep.py')])]
records=[]
for name,command in jobs:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()==head
 assert not subprocess.check_output(['git','diff','--name-only','HEAD','--','src','tests','benchmarks/runtime'],cwd=repo,text=True).strip()
 assert all(hashlib.file_digest(Path(p).open('rb'),'sha256').hexdigest()==v for p,v in frozen.items())
 assert subprocess.run(['pgrep','-x','rustc'],capture_output=True).returncode!=0,'compiler active; preserve this stopped sequence'
 began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (r/(name+'-driver.log')).open('x') as log:
  run=subprocess.run(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
 record={'name':name,'command':command,'begin_utc':began,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':run.returncode}
 records.append(record);(r/'validation-commands.json').write_text(json.dumps(records,indent=2)+'\n');print(name,run.returncode,flush=True)
 assert run.returncode==0
