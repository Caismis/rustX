"""Authenticate every memory product and compare ordinary allocator endpoints."""
from pathlib import Path
import hashlib,importlib,json,sqlite3,statistics,sys
root=Path(__file__).resolve().parent
repo=Path('/home/capi/.codex/worktrees/pr485-main-reconciliation/rustX')
sys.path.insert(0,str(repo/'benchmarks/runtime'))
metrics=importlib.import_module('summarize-http')
commands=json.loads((root/'memory-commands.json').read_text()); assert len(commands)==8
names=['empty_server','all_subscribed_empty','seeded_history_8','seeded_history_16','seeded_history_32','all_unloaded']
rows=[]
for command in commands:
 directory=Path(command['command'][command['command'].index('--output')+1]); complete=json.loads((directory/'completed.json').read_text())
 assert command['exit']==0 and complete['accepted'] and complete['requests']==4096
 assert all(value==32 for value in complete['turn_counts'].values()) and len(complete['turn_counts'])==128
 phases={p['phase']:p for p in json.loads((directory/'phases.json').read_text())}
 backups=json.loads((directory/'native-closed.json').read_text()); assert len(backups)==128
 for backup in backups:
  index=backup['session_index'];p=directory/'native-snapshots'/f'{index:04}.sqlite'
  assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==backup['consistent_backup_sha256']
  with sqlite3.connect(p.as_uri()+'?mode=ro',uri=True) as c:
   assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
   assert c.execute('PRAGMA foreign_key_check').fetchall()==[]
   assert c.execute('PRAGMA page_size').fetchone()[0]==2048
   assert c.execute('SELECT schema_version FROM rustx_store WHERE id=1').fetchone()[0]==106
   messages=[json.loads(x) for x, in c.execute('SELECT message_json FROM message_ledger ORDER BY position')]
  assert len(messages)==64==backup['messages']
  for turn in range(32):
   user,answer=messages[turn*2:turn*2+2]
   assert user['role']=='user' and user['content']==[{'type':'text','text':f'capacity turn session={index:04} turn={turn:04}'}]
   assert answer['role']=='assistant' and answer['content']==[{'type':'text','text':'capacity response'}]
 row={k:command[k] for k in ['pair','side','binary_sha256','fixture_sha256']};row['directory']=directory.name
 row['phases']={name:{'anon_pss_mib':metrics.counters(phases[name])['anon_pss_kib']/1024,'pss_mib':metrics.counters(phases[name])['pss_kib']/1024,'retained_files':phases[name]['retained_files'],'notifications':phases[name]['notifications']} for name in names}
 row['growth_8_to_32_mib']=row['phases']['seeded_history_32']['anon_pss_mib']-row['phases']['seeded_history_8']['anon_pss_mib']
 row['seed_cpu_ms_per_turn']=metrics.delta(phases['all_subscribed_empty'],phases['seeded_history_32'],'cpu_ms')/4096
 row['seed_write_kib_per_turn']=metrics.delta(phases['all_subscribed_empty'],phases['seeded_history_32'],'write_bytes')/1024/4096
 host=json.loads((root/(directory.name+'-host.json')).read_text());row['compiler_overlap_samples']=sum(bool(p['compiler_pids']) for p in host)
 rows.append(row)
summary={}
for name in names+['growth_8_to_32_mib','seed_cpu_ms_per_turn','seed_write_kib_per_turn']:
 value=lambda r:r['phases'][name]['anon_pss_mib'] if name in names else r[name]
 group={side:{'median':statistics.median(vs),'range':[min(vs),max(vs)],'values':vs} for side in ['before','after'] if (vs:=[value(r) for r in rows if r['side']==side])}
 changes=[];deltas=[]
 for pair in range(4):
  a,b=[value(next(r for r in rows if r['pair']==pair and r['side']==side)) for side in ['before','after']]
  deltas.append(b-a)
  if a: changes.append((b-a)/a*100)
 group['paired_delta']=deltas;group['paired_percent']=changes;group['median_paired_percent']=statistics.median(changes)
 summary[name]=group
 print(name,round(group['before']['median'],3),round(group['after']['median'],3),round(group['median_paired_percent'],3),flush=True)
report={'scope':'Four balanced independent pairs, 128 sessions in each process, sampled after 8/16/32 turns. Ordinary GNU allocator; server PID only. PSS endpoints, retained file sizes and cumulative process writes remain distinct. No statistical-significance claim. All 1024 consistent backup hashes, schema 106 on both sides, integrity, FKs and exact ordered messages independently checked.','rows':rows,'summary':summary}
(root/'memory-summary.json').write_text(json.dumps(report,indent=2)+'\n')
