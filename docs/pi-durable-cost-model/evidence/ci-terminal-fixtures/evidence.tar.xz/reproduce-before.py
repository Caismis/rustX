from pathlib import Path
import json,subprocess,os,time
root=Path('/workspace/issue-481-evidence/ci-final-diagnosis');records=[json.loads(x) for x in (root/'build-before.jsonl').read_text().splitlines()];bins=[r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')=='rustx'];assert len(bins)==1
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/rustX-pi-durable',text=True).strip()=='770248f10fe63ba50f7457ed17436ea339521618'
results=[]
for label,name in [('host','runtime_client::host::tests::incremental_projection_independent_snapshot_capture'),('terminal','runtime::conversation_runtime::tests::terminal_event_durable_failure_degrades_without_fabricated_terminal')]:
 cmd=[bins[0],name,'--exact','--nocapture'];started=time.monotonic()
 with (root/(label+'-before.log')).open('w') as f:
  try:result=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=30);exit_code=result.returncode;timed_out=False
  except subprocess.TimeoutExpired:exit_code=None;timed_out=True
 results.append({'name':name,'command':cmd,'exit':exit_code,'diagnostic_guard_seconds':30,'timed_out':timed_out,'elapsed_seconds':time.monotonic()-started});print(label,results[-1],flush=True)
(root/'reproduce-before.json').write_text(json.dumps(results,indent=2)+'\n')
assert results[0]['exit']==101 and results[1]['timed_out']
