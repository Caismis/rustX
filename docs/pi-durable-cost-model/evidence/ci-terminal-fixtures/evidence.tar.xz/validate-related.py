from pathlib import Path
import json,subprocess,os,re,time,hashlib
root=Path('/workspace/issue-481-evidence/ci-final-diagnosis');repo=Path('/workspace/rustX-pi-durable');records=[json.loads(x) for x in (root/'build-after.jsonl').read_text().splitlines()];bins=[r['executable'] for r in records if r.get('reason')=='compiler-artifact' and r.get('executable') and r.get('target',{}).get('name')=='rustx'];assert len(bins)==1
checks=[('native-final','durable::sqlite::tests::final_settlement_tests::',False),('publication','scripted_suites::agent::publication::',False),('projection','runtime_client::projection::',False)]
results=json.loads((root/'initial-validation-with-empty-filter.json').read_text())[:3]
for label,name,exact in checks:
 cmd=[bins[0],name,*(['--exact'] if exact else []),'--nocapture'];env=dict(os.environ);env['RUSTX_PROJECTION_CAPTURE']=str(root/'fresh-native-capture.json')
 started=time.monotonic()
 with (root/(label+'-after.log')).open('w') as f:p=subprocess.run(cmd,cwd=repo,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 txt=(root/(label+'-after.log')).read_text();match=re.search(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;',txt);passed=int(match[1]) if match else 0
 result={'label':label,'command':cmd,'exit':p.returncode,'passed':passed,'seconds':time.monotonic()-started};results.append(result);(root/'validation-after.json').write_text(json.dumps(results,indent=2)+'\n');print(result,flush=True);assert p.returncode==0 and passed>0
cmd=['node',str(root/'check-fresh-capture.mjs'),str(root/'fresh-native-capture.json')]
with (root/'fresh-capture-fold.log').open('w') as f:p=subprocess.run(cmd,cwd=repo,stdout=f,stderr=subprocess.STDOUT)
results.append({'label':'fresh-typescript-fold','command':cmd,'exit':p.returncode});(root/'validation-after.json').write_text(json.dumps(results,indent=2)+'\n');assert p.returncode==0
print((root/'fresh-capture-fold.log').read_text(),flush=True)
