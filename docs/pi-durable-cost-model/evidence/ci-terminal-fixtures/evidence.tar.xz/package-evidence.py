from pathlib import Path
import json,hashlib,tarfile,shutil
root=Path('/workspace/issue-481-evidence/ci-final-diagnosis');repo=Path('/workspace/rustX-pi-durable');dest=repo/'docs/pi-durable-cost-model/evidence/ci-terminal-fixtures';dest.mkdir(parents=True,exist_ok=True)
checks=json.loads((root/'validation-after.json').read_text());assert all(x['exit']==0 for x in checks);assert sum(x.get('passed',0) for x in checks)==104
assert 'Finished' in (root/'clippy.log').read_text() and '\nerror:' not in (root/'clippy.log').read_text()
shutil.copy2('/workspace/issue-481-evidence/ci-39146279121-linux.log',root/'original-linux-ci.log')
report=(root/'root-cause.md').read_text().rstrip()+'''\n\nFinal targeted results: standalone terminal **1 pass**, atomic terminal **1 pass**,\nnative snapshot **1 pass**, native final settlement **5 passes**, publication\n**14 passes**, and projection **82 passes** (104 total). The fresh native capture\ncontains 22 contiguous events; its exact TypeScript checkpoint fold and expired\nLiveRef progress checks pass. `cargo clippy --offline --locked --all-features\n--lib --tests -- -D warnings`, `cargo fmt --all -- --check`, and diff whitespace\nchecks pass. The initial native-final command selected zero tests because its\nfilter omitted `tests::`; that invocation is retained and not counted as a pass.\n\n[Readable results and logs](evidence/ci-terminal-fixtures/validation-after.json),\n[before-fix reproduction](evidence/ci-terminal-fixtures/reproduce-before.json),\nand [complete preserved evidence archive](evidence/ci-terminal-fixtures/evidence.tar.xz)\ninclude commands, original failures, exact patch, compiler build records and the\nfresh capture. Readable log copies omit trailing blank lines; the archive retains\nthe original files. This report is prepared locally before pushing the fix, as\nrequested by the parent. No merge or benchmark rerun was performed.\n'''
(repo/'docs/pi-durable-cost-model/ci-terminal-fixtures.md').write_text(report)
readable=['ci-diagnosis.json','reproduce-before.json','validation-after.json','test-only-proof.json','host-before.log','terminal-before.log','standalone-terminal-after.log','atomic-terminal-after.log','host-capture-after.log','native-final-after.log','publication-after.log','projection-after.log','fresh-capture-fold.log','clippy.log']
for name in readable:
 p=root/name
 if p.suffix=='.log':(dest/name).write_text(p.read_text().rstrip()+'\n')
 else:shutil.copy2(p,dest/name)
files=sorted(p for p in root.iterdir() if p.is_file());archive=dest/'evidence.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for p in files:t.add(p,arcname=p.name)
manifest={}
with tarfile.open(archive) as t:
 for p in files:
  data=p.read_bytes();assert t.extractfile(p.name).read()==data;manifest[p.name]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
(dest/'manifest.json').write_text(json.dumps({'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':manifest,'readable_logs':'Trailing blank lines omitted only from readable copies; original files retained in archive.'},indent=2)+'\n')
print('Packaged',len(files),'preserved files and',len(readable),'readable results/logs')
