import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {checkpointSnapshot,foldRuntimeEvent,observationCheckpoint} from '/workspace/rustX-pi-durable/protocol/app-server/projection.ts';
const capture=JSON.parse(readFileSync(process.argv[2],'utf8'));
const facts=e=>e.type==='projection_transition'?e.events.flatMap(facts):[e];
const witness=capture.expired_live_reference;
assert.equal(witness.reference.source.type,'live_publication_prefix');
assert.ok(witness.reference.readable_end>0);
const original=capture.events.find(row=>row.params.cursor===witness.cursor);
assert.ok(original);
assert.ok(facts(original.params.event).some(e=>e.type==='block_content_advanced'&&JSON.stringify(e.content_ref)===JSON.stringify(witness.reference)));
let state=checkpointSnapshot(capture.initial.result.checkpoint),cursor=BigInt(capture.initial.result.checkpoint.cursor);
let settled=false,canonical=false;
for(const row of capture.events){
 assert.equal(BigInt(row.params.cursor),cursor+1n);
 state=foldRuntimeEvent(state,row.params.event);cursor++;
 if(cursor>BigInt(witness.cursor))for(const event of facts(row.params.event)){
  if(event.type==='attempt_settled')settled=true;
  if(event.type==='message_descriptor_committed'||event.type==='message_committed')canonical=true;
 }
}
assert.ok(settled);assert.ok(canonical);
assert.equal(cursor,BigInt(capture.expected.result.checkpoint.cursor));
assert.deepStrictEqual(JSON.parse(JSON.stringify(observationCheckpoint(state,String(cursor)))),capture.expected.result.checkpoint);
console.log(`PASS: ${capture.events.length} contiguous fresh native events, genuine expired LiveRef, canonical/terminal progress, exact independent checkpoint equality`);
