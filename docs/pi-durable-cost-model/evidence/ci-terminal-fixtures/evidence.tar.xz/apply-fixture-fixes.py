from pathlib import Path
r=Path('/workspace/rustX-pi-durable')
p=r/'src/runtime_client/host.rs';s=p.read_text();start=s.index('    async fn incremental_projection_independent_snapshot_capture()');end=s.index('\n    /// Submitting while idle',start);old=s[start:end];new=old.replace('        let call_id = ToolCallId::new("capture-call");','        let call_id = ToolCallId::new("capture-call");\n        let (continue_stream, live_prefix_gate) = model_release();').replace('                text: "first ".into(),\n            }),','                text: "first ".into(),\n            }),\n            GatedStep::ParkUntilReleased(live_prefix_gate),',1)
needle='        let mut events = receive_until(&subscription, |event| {'
replacement='''        // Hold provider completion until an actual nonempty LiveRef has been
        // committed and published. The tiny stream must not depend on beating
        // the production coalescer deadline; preserve the original live/expiry
        // assertions and the exact response bytes consumed by the client oracle.
        let mut events = receive_until(&subscription, |event| {
            event.event.facts().iter().any(|fact| matches!(
                fact,
                RuntimeClientEvent::BlockContentAdvanced { content_ref, .. }
                    if content_ref.readable_end > 0 && matches!(
                        &content_ref.source,
                        crate::runtime_client::content::ContentSource::LivePublicationPrefix { .. }
                    )
            ))
        })
        .await;
        continue_stream.send_replace(true);
        events.extend(receive_until(&subscription, |event| {'''
new=new.replace(needle,replacement,1).replace('        .await;\n        // Attempt settlement','        .await);\n        // Attempt settlement',1);assert new!=old;s=s[:start]+new+s[end:];p.write_text(s)
p=r/'src/runtime/conversation_runtime.rs';s=p.read_text();start=s.index('    /// A terminal Event Journal failure must degrade');end=s.index('    /// A gated background executor',start)
new='''    /// A separately committed failed-attempt terminal still owns the Event
    /// Journal failure classification and must never publish a rejected event.
    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn terminal_event_durable_failure_degrades_without_fabricated_terminal() {
        assert_terminal_commit_failure(false).await;
    }

    /// Ordinary successful output now includes its terminal in the canonical
    /// transaction. Rejecting that terminal rolls back P/U/C together, then
    /// records the truthful runtime failure rather than a fabricated success.
    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn atomic_terminal_durable_failure_rolls_back_and_degrades() {
        assert_terminal_commit_failure(true).await;
    }

    #[allow(clippy::too_many_lines)] // Compare both native transaction owners with the same assertions.
    async fn assert_terminal_commit_failure(atomic: bool) {
        use crate::model::error::{ModelError, ModelErrorKind};
        use crate::model::event::ModelEvent;

        let dir = tempfile::tempdir().expect("temp dir");
        let store = Arc::new(
            crate::durable::SqliteConversationStore::in_memory(ConversationId::new(
                "conv_8a56d655-7b4e-7b7a-870c-20e586d7d16f",
            ))
            .expect("in-memory store"),
        );
        let script = if atomic {
            one_turn_script()
        } else {
            vec![
                FakeStep::Emit(ModelEvent::Started),
                FakeStep::Emit(ModelEvent::Failed {
                    error: ModelError {
                        kind: ModelErrorKind::InvalidRequest,
                        message: "fixture provider rejected request".to_owned(),
                        retry_disposition: crate::model::error::ModelRetryDisposition::Never,
                        retry_after_ms: None,
                        provider_code: None,
                        context_overflow: None,
                        malformed_tool_proposal: None,
                        timeout_phase: None,
                        generation: None,
                    },
                }),
            ]
        };
        let (runtime, model) = headless_runtime_over_store_with(
            &dir,
            "conv_8a56d655-7b4e-7b7a-870c-20e586d7d16f",
            store.clone(),
            vec![script],
            None,
        )
        .await;
        let pending = Arc::new(PendingObservations::new());
        runtime.install_fixture_observation_bridge(&pending).expect("bridge");
        runtime.activate();
        store.arm_fail_next_terminal_event();
        let admission = runtime.submit_inbound(text_content("terminal fault")).expect("accepted");
        // Wait for any degradation, then assert its owner. A changed operation
        // must fail immediately instead of silently waiting for an impossible
        // observation. The timeout is a liveness guard, not synchronization.
        let observations = within_liveness_guard(
            "terminal commit durability failure",
            await_observation(pending.as_ref(), |observation| matches!(
                observation, ConversationObservation::DurabilityFailed { .. }
            )),
        )
        .await;
        let expected_operation = if atomic { "canonical_commit" } else { "event_journal" };
        assert!(matches!(observations.last(),
            Some(ConversationObservation::DurabilityFailed { operation, .. })
                if operation == expected_operation
        ));
        assert_eq!(model.requests().len(), 1, "exactly one provider invocation");
        let observed_terminals: Vec<_> = observations.iter().filter_map(|observation| match observation {
            ConversationObservation::Event { event, .. } if is_terminal_event(event) => Some(event),
            _ => None,
        }).collect();
        let journal = store.read_events(None, 128).expect("event journal").events;
        let durable_terminals: Vec<_> = journal.iter().filter(|envelope| is_terminal_event(&envelope.event)).collect();
        if atomic {
            assert_eq!(observed_terminals.len(), 1);
            assert_eq!(durable_terminals.len(), 1);
            assert!(matches!(observed_terminals[0], RuntimeEvent::AttemptFailed { .. }));
            assert!(matches!(durable_terminals[0].event, RuntimeEvent::AttemptFailed { .. }));
            assert!(journal.iter().all(|envelope| !matches!(envelope.event,
                RuntimeEvent::ModelRequestCompleted { .. }
                    | RuntimeEvent::AssistantMessageCommitted { .. }
                    | RuntimeEvent::TurnCompleted
                    | RuntimeEvent::AttemptCompleted { .. }
            )), "the rejected compound transaction publishes none of its success facts");
            assert_eq!(store.terminal_event_attempts(), 2,
                "one rejected compound terminal and one truthful failure terminal");
        } else {
            assert!(observed_terminals.is_empty(), "the rejected journal terminal is never observed");
            assert!(durable_terminals.is_empty(), "the rejected journal terminal is never durable");
            assert_eq!(store.terminal_event_attempts(), 1);
        }
        let canonical = store.load_canonical().expect("canonical ledger");
        assert!(canonical.iter().any(|message| matches!(message,
            MessageBlock::User(user) if user.id == admission.message_id
        )));
        assert!(canonical.iter().all(|message| !matches!(message, MessageBlock::Assistant(_))),
            "no rejected final output enters canonical history");
        assert!(!runtime.has_current_attempt());
        assert!(matches!(runtime.submit_inbound(text_content("late")),
            Err(InboundAdmissionError::DurabilityFailed { .. })
        ));
    }

'''
s=s[:start]+new+s[end:];p.write_text(s)
