import subprocess,json,datetime
from pathlib import Path
root=Path('/workspace/issue-481-evidence');final=root/'selected-conformance'
stages=[]
for name,before in [('selected-source-paired','reservations-conformance'),('selected-continued-paired','attribution-conformance'),('selected-baseline-paired','baseline-final-conformance'),('selected-sql-removal-paired','compact-source-conformance')]:
 stages.append((name,['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/before),'--after',str(final),'--output',str(root/name),'--pairs','3']))
stages.extend([('selected-pi-paired',['python3','benchmarks/runtime/controller.py','--rust',str(final),'--pi','/workspace/pi-481','--output',str(root/'selected-pi-paired'),'--pairs','3']),('selected-append-paired',['python3','benchmarks/runtime/compare-append.py','--before',str(root/'source-append-conformance'),'--after',str(final),'--output',str(root/'selected-append-paired'),'--pairs','3'])])
records=[]
for name,cmd in stages:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',name,start,flush=True)
 with (root/(name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 records.append({'stage':name,'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode})
 (root/'selected-matrix-status.json').write_text(json.dumps(records,indent=2));print('END',name,p.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in records))
