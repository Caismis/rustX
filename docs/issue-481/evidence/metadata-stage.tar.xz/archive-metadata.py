import hashlib,json,tarfile
from pathlib import Path
root=Path('/workspace/issue-481-evidence');out=Path('docs/issue-481/evidence/metadata-stage.tar.xz');manifest={};files=[]
for directory in ['metadata-runtime-paired','metadata-append-warm-paired','metadata-append-cold-paired','metadata-append-cold-fixed-paired','metadata-pi-paired','metadata-profile']:
 files.extend(p for p in (root/directory).rglob('*') if p.is_file())
for pattern in ['metadata-*.json','metadata-*.jsonl','metadata-*.log','metadata-*.patch','structural-baseline*.json','structural-baseline*.jsonl','structural-baseline*.log','structural-baseline*.patch']:
 files.extend(root.glob(pattern))
for name in ['run-metadata-stage.py','repair-metadata-cold.py','profile-metadata.py','analyze-metadata-profiles.py','write-metadata-report.py','archive-metadata.py','cold-summary-review-tests-2.log']:
 files.append(root/name)
files=sorted(set(files));assert len(json.loads((root/'metadata-profile-status.json').read_text()))==6
for p in files:
 if p.is_socket():continue
 manifest[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
with tarfile.open(out,'w:xz',preset=3) as tar:
 for path in manifest:tar.add(root/path,arcname=path,recursive=False)
Path('docs/issue-481/evidence/metadata-stage.tar.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
with tarfile.open(out,'r:xz') as tar:
 for member in tar:
  content=tar.extractfile(member).read();assert len(content)==manifest[member.name]['bytes'];assert hashlib.sha256(content).hexdigest()==manifest[member.name]['sha256']
print('verified',len(manifest),'files; archive bytes',out.stat().st_size,flush=True)
