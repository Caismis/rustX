import datetime,json,subprocess,time
from pathlib import Path
root=Path('/workspace/issue-481-evidence')
while Path('/proc/63506').exists():time.sleep(5)
if json.loads((root/'certificate-focused-tests-2-status.json').read_text())['exit']:raise SystemExit('Focused tests failed; profile not started')
records=[]
for stage,binary in [('before','structural-baseline-conformance'),('after','metadata-conformance')]:
 for case in ['short-small','short-large','syscalls']:
  out=root/'metadata-profile'/f'{stage}-{case}'
  if case=='syscalls':cmd=['python3','benchmarks/runtime/profiling/syscalls.py','--binary',str(root/binary),'--output',str(out)]
  else:cmd=['python3','benchmarks/runtime/profiling/run.py','--binary',str(root/binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(out),'--mode','cpu','--case',case]
  print('PROFILE',stage,case,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (root/f'metadata-profile-{stage}-{case}.log').open('w') as log:r=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
  records.append({'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode})
  (root/'metadata-profile-status.json').write_text(json.dumps(records,indent=2))
  if r.returncode:raise SystemExit(r.returncode)
  if case=='syscalls':
   with (out/'source-writes.json').open('w') as dest:subprocess.run(['python3','benchmarks/runtime/profile-source.py',str(out/'calls.strace')],stdout=dest,check=True)
  else:
   with (out/'steady-cumulative.txt').open('w') as dest,(out/'symbolize.log').open('w') as err:subprocess.run(['/workspace/issue-481-profilers/unpacked/usr/bin/google-pprof','--text','--cum','--no_strip_temp','--nodecount=100',str(root/binary),str(out/'before_measured_turns.cpu')],stdout=dest,stderr=err,check=True)
