import datetime,hashlib,json,os,subprocess,shutil
from pathlib import Path
root=Path('/workspace/issue-481-evidence');main=Path('/workspace/rustX-481')
assert not (root/'metadata-measurements-active').exists()
fixture='tests/conformance/agent_loop/runtime_benchmark.rs'
env=os.environ|{'PATH':'/workspace/.cargo/bin:'+os.environ['PATH'],'CARGO_HOME':'/workspace/.cargo','RUSTUP_HOME':'/workspace/.rustup','CARGO_TARGET_DIR':'/workspace/issue-481-target','CARGO_BUILD_JOBS':'2','BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include'}
for name,path in [('metadata','/workspace/rustX-481-metadata'),('structural-baseline','/workspace/rustX-481-structural-baseline')]:
 repo=Path(path);shutil.copy2(main/fixture,repo/fixture);tag=name+'-cold-fixed'
 assert not subprocess.check_output(['git','diff','--','src','Cargo.toml','Cargo.lock'],cwd=repo)
 patch=root/(tag+'-harness.patch');patch.write_bytes(subprocess.check_output(['git','diff','--',fixture],cwd=repo))
 record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'production_tree':subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip(),'fixture_sha256':hashlib.file_digest((repo/fixture).open('rb'),'sha256').hexdigest(),'harness_patch':str(patch),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 cmd=['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json'];record['command']=cmd
 print('BUILD',tag,flush=True)
 with (root/(tag+'-build.jsonl')).open('w') as out,(root/(tag+'-build.log')).open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 record['exit']=r.returncode;record['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if not r.returncode:
  rows=[json.loads(s) for s in (root/(tag+'-build.jsonl')).read_text().splitlines() if s.startswith('{')]
  binary=next(Path(x['executable']) for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='conformance' and x.get('executable'))
  dest=root/(tag+'-conformance');assert not dest.exists();shutil.copy2(binary,dest);record['binary']=str(dest);record['sha256']=hashlib.file_digest(dest.open('rb'),'sha256').hexdigest()
 (root/(tag+'-executable.json')).write_text(json.dumps(record,indent=2))
 if r.returncode:raise SystemExit(r.returncode)
cmd=['python3','benchmarks/runtime/compare-append.py','--before',str(root/'structural-baseline-cold-fixed-conformance'),'--after',str(root/'metadata-cold-fixed-conformance'),'--output',str(root/'metadata-append-cold-fixed-paired'),'--pairs','3','--cold']
(root/'metadata-measurements-active').write_text('Corrected cold measurements; do not build or profile.\n')
try:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/'metadata-append-cold-fixed.log').open('w') as log:r=subprocess.run(cmd,cwd=main,stdout=log,stderr=subprocess.STDOUT)
 (root/'metadata-cold-fixed-status.json').write_text(json.dumps({'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode},indent=2))
finally:(root/'metadata-measurements-active').unlink()
if r.returncode:raise SystemExit(r.returncode)
with (root/'metadata-append-cold-fixed-summary.json').open('w') as out:subprocess.run(['python3','benchmarks/runtime/summarize-comparisons.py','--append',str(root/'metadata-append-cold-fixed-paired')],cwd=main,stdout=out,check=True)
