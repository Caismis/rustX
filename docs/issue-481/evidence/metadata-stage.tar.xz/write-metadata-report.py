import json,statistics
from pathlib import Path
root=Path('/workspace/issue-481-evidence');dest=Path('docs/issue-481/source-metadata.md')
runtime=json.loads((root/'metadata-runtime-summary.json').read_text())['medians']
text='''# Exact Source metadata reuse: fresh structural comparison

Production baseline is `5457e1c34106b8d49de0edfb40b49ca8267d0383`; production
candidate is `76ecc9d765e5c63080950e7dc5710a32b0b1caa7`. The later commits
242597cb/a42e7bfa repair summary validation and a test-only lint; 6b044654 repairs
the new cold benchmark fixture. They do not change the candidate production tree.
Verified origin/main remains `3c355f152d405a201482d53b6e45497df4f44a7f`.

The candidate borrows exact span/path/key/container/node metadata from Source's
existing byte index and selects fragment spans before generating previews. It
retains bounded subtree validation when a truncated preview cannot prove numeric
or depth validity. Original bytes, witnesses, authenticated pages and roots remain
byte-identical in differential tests; this stage changes no persisted format.

## Fresh paired results

Three paired, alternating runs per case, clean processes and stores, identical
optimized builds and local HTTP/SSE scripts. Each ratio below is the median of
same-pair candidate/baseline ratios; it is not a ratio of unrelated medians.
CPU includes the product and driver, at 10 ms counter resolution. Writes are
process-attributed lifecycle writes through cleanup, with evidence JSON emitted
after sampling; they are not physical-device writes. Anonymous PSS is the maximum
of observed samples, not a measured peak. Native allocator counts are unavailable.

| Case | Turn wall ratio | Turn CPU ratio | Lifecycle write ratio | Sampled anonymous PSS ratio |
|---|---:|---:|---:|---:|
'''
for case in ['short-small','short-large','large','stream','tool','cancel']:
 x=runtime[case]['after_over_before'];text+='| '+case+' | '+' | '.join(f"{x[k]:.4f}" for k in ['mean_turn_ms','turn_cpu_ms_per_turn','lifecycle_write_mib','max_sampled_anon_pss_mib'])+' |\n'
text+='''
Repeated large-history work improves by 6.0% wall and 4.2% CPU in this matrix.
Short-history performance is essentially flat; one-response large and cancellation
wall ratios are adverse, and Tool CPU is adverse. No general memory or disk gain
is established. These measurements retain every slow sample.

The marginal append control is intentionally separate from HTTP/context work.
The Source stage does not change native append; variation and adverse samples
remain visible. Warm CPU covers the whole append phase including driver overhead.
Cold CPU sums the recorded operation windows, which include counter/sampling
overhead; reopen/close work belongs to separately retained lifecycle counters.

| Mode | Seed history | Append wall ratio | Append CPU ratio | Lifecycle write ratio |
|---|---:|---:|---:|---:|
'''
for mode,name in [('warm','append-warm'),('cold','append-cold-fixed')]:
 data=json.loads((root/f'metadata-{name}-summary.json').read_text())['medians']
 for history in ['0','64','512','2048']:
  x=data[history]['after_over_before'];text+=f'| {mode} | {history} | '+' | '.join(f"{x[k]:.4f}" for k in ['mean_append_ms','append_cpu_ms_per_append','lifecycle_write_mib'])+' |\n'
text+='''
Each sample measures 32 appends. Coarse CPU ticks make ratios for these short
windows noisy; the raw counters and per-operation observations remain available.
The first cold attempt failed all 24 samples because the fixture used the read-only
management opener. Those failures and empty summary output are retained. The
corrected fixture uses the writable opener before each measured append. Both
production revisions were rebuilt with that identical fixture, and all 24 rerun
samples passed. The original successful runtime/warm/Pi samples remain unchanged.

## Same-provider Pi comparison

Actual Pi Durable SQLite is pinned to
`90d863f7c1183b965f099855715d6e88c7b8a52c`, using Node 24.19.0 and its production
OpenAI completions adapter. Both engines call the same local fake HTTP/SSE provider
as controller-owned sibling processes. Provider lifetime extends beyond product
cleanup; its child I/O cannot enter product counters. Native Tool schemas remain
explicitly different (rustX 7, Pi 4); only legitimate identities are normalized.
No real model API or inference credential is used.

The 36 successful paired engine samples contain 846 complete requests. The
Source revision comparison separately contains another 846 requests in 36
samples. Full ordered expected/wire/captured/frozen/reopened oracles pass, with
18 paired core-request comparisons in each matrix. In the Pi matrix, median
short-small wall is 66.39 ms/turn for rustX and 4.88 ms/turn for Pi; CPU is
98.13 versus 9.38 ms/turn. Lifecycle writes are 127.99 versus 8.88 MiB. These
include the documented driver and verification work and do not establish pure
engine/DB costs or equivalent native Tool schemas. This is not the old in-process
fake comparison and does not reuse its 49–57x ratios.

## Validation and reproducibility

Source stage validation passed 22 Source tests, 11 composed tests, 373 durable
SQLite tests, and 30 benchmark/summary regression tests. The differential oracle
checks exact generated pages/root and original chunks, lexical JSON/u64/key
aliases, dense fields, malformed numeric/deep input, and physical byte-read
reduction. Independent review found and fixed cross-directory warm/cold summary
mixing and omitted cold memory samples. Negative regressions cover both defects.
The structural baseline's FULL/Merge pass is historical evidence, not validation
of later production changes; final combined HEAD still requires FULL/Merge.

Binary SHA-256 identities:

'''
for tag in ['structural-baseline','metadata','structural-baseline-cold-fixed','metadata-cold-fixed']:
 x=json.loads((root/f'{tag}-executable.json').read_text());text+=f"- {tag}: `{x['sha256']}`; fixture `{x['fixture_sha256']}`.\n"
text+='''
The archived manifests retain commands, UTC boundaries, complete logical/allocated
DB/WAL/temp footprints, startup/steady/close/reopen/cleanup counters, provider
startup/control costs, and every successful/failed sample. Formal matrices ran
without concurrent builds or profilers. Diagnostic profiles run separately.
'''
dest.write_text(text)
