import hashlib,json,re,struct
from pathlib import Path
root=Path('/workspace/issue-481-evidence/metadata-profile');records=[]
for stage in ['before','after']:
 for case in ['short-small','short-large']:
  d=root/f'{stage}-{case}';raw=d/'before_measured_turns.cpu';report=d/'steady-cumulative.txt'
  data=raw.read_bytes();header=struct.unpack_from('<5Q',data);assert header[:3]==(0,3,0)
  offset=40;total=0
  while True:
   count,depth=struct.unpack_from('<2Q',data,offset);offset+=16;assert 0<depth<=1024
   pcs=struct.unpack_from(f'<{depth}Q',data,offset);offset+=8*depth
   if count==0 and pcs==(0,):break
   total+=count
  lines=report.read_text().splitlines();assert total==int(re.fullmatch(r'Total: (\d+) samples',lines[0])[1])
  rows=[]
  for line in lines[1:]:
   m=re.match(r'\s*(\d+)\s+[\d.]+%\s+[\d.]+%\s+(\d+)\s+[\d.]+%\s+(.*)',line)
   if m:rows.append({'symbol':m[3],'flat_samples':int(m[1]),'cumulative_samples':int(m[2])})
  digest=lambda p:hashlib.file_digest(p.open('rb'),'sha256').hexdigest()
  records.append({'stage':stage,'case':case,'binary_sha256':json.loads((d/'manifest.json').read_text())['binary_sha256'],'denominator_samples':total,'requested_interval_us':header[3],'raw_profile':{'path':str(raw.relative_to(root)),'sha256':digest(raw)},'symbolized_report':{'path':str(report.relative_to(root)),'sha256':digest(report)},'rows':rows})
Path('docs/issue-481/evidence/metadata-cpu-counts.json').write_text(json.dumps({'scope':'250Hz CPU samples include product and driver. Cumulative rows overlap; do not add them or equate them to elapsed-timer percentages. Counts independently checked against raw complete profile. Separate from formal measurements. Native allocator counts unavailable.','profiles':records},indent=2))
for stage in ['before','after']:
 d=json.loads((root/f'{stage}-syscalls/source-writes.json').read_text());print(stage,{k:v for k,v in d.items() if k not in ('completed_calls','limitations')})
for r in records:
 print(r['stage'],r['case'],'total',r['denominator_samples'])
 print([(x['symbol'],x['cumulative_samples']) for x in r['rows'] if any(t in x['symbol'] for t in ['sqlite3Prepare','capture_facts','visit_field_metadata','persist_encoded_fact','process_sample'])])
