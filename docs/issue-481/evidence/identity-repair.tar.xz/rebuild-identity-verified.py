import datetime,hashlib,json,os,subprocess,shutil
from pathlib import Path
root=Path('/workspace/issue-481-evidence');main=Path('/workspace/rustX-481')
env=os.environ|{'PATH':'/workspace/.cargo/bin:'+os.environ['PATH'],'CARGO_HOME':'/workspace/.cargo','RUSTUP_HOME':'/workspace/.rustup','CARGO_TARGET_DIR':'/workspace/issue-481-target','CARGO_BUILD_JOBS':'2','BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include'}
identities={}
for stage,path in [('metadata','/workspace/rustX-481-metadata'),('structural-baseline','/workspace/rustX-481-structural-baseline')]:
 repo=Path(path);tag=stage+'-verified';assert not subprocess.check_output(['git','status','--porcelain','--','src','Cargo.toml','Cargo.lock'],cwd=repo)
 identity={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'production_tree':subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip(),'fixture_sha256':hashlib.file_digest((repo/'tests/conformance/agent_loop/runtime_benchmark.rs').open('rb'),'sha256').hexdigest(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 clean=['cargo','clean','--release','--package','rustx'];identity['clean_command']=clean
 print('CLEAN',stage,flush=True)
 with (root/(tag+'-clean.log')).open('w') as out:r=subprocess.run(clean,cwd=repo,env=env,stdout=out,stderr=subprocess.STDOUT)
 identity['clean_exit']=r.returncode
 if r.returncode:raise SystemExit(r.returncode)
 cmd=['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json'];identity['command']=cmd
 print('BUILD',stage,flush=True)
 with (root/(tag+'-build.jsonl')).open('w') as out,(root/(tag+'-build.log')).open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
 identity['exit']=r.returncode;identity['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 if not r.returncode:
  rows=[json.loads(line) for line in (root/(tag+'-build.jsonl')).read_text().splitlines() if line.startswith('{')]
  artifacts=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name') in ['rustx','conformance']]
  identity['root_artifacts']=[{'name':x['target']['name'],'kind':x['target']['kind'],'fresh':x['fresh'],'source_path':x['target']['src_path']} for x in artifacts]
  lib=next(x for x in artifacts if x['target']['kind']==['lib']);test=next(x for x in artifacts if x['target']['name']=='conformance')
  assert lib['fresh'] is False and test['fresh'] is False,identity['root_artifacts']
  assert Path(lib['target']['src_path']).resolve()==repo/'src/lib.rs'
  assert not subprocess.check_output(['git','status','--porcelain','--','src','Cargo.toml','Cargo.lock'],cwd=repo)
  dest=root/(tag+'-conformance');assert not dest.exists();shutil.copy2(test['executable'],dest)
  identity['binary']=str(dest);identity['sha256']=hashlib.file_digest(dest.open('rb'),'sha256').hexdigest()
  identity['library_sha256']=hashlib.file_digest(Path(next(p for p in lib['filenames'] if p.endswith('.rlib'))).open('rb'),'sha256').hexdigest()
  if stage=='metadata':
   identity['previous_metadata_sha256']=json.loads((root/'metadata-cold-fixed-executable.json').read_text())['sha256'];identity['matches_previous_metadata_binary']=identity['sha256']==identity['previous_metadata_sha256']
 (root/(tag+'-executable.json')).write_text(json.dumps(identity,indent=2));print('IDENTITY',json.dumps(identity),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 identities[stage]=identity
assert identities['metadata']['fixture_sha256']==identities['structural-baseline']['fixture_sha256']
assert identities['metadata']['sha256']!=identities['structural-baseline']['sha256']
(root/'identity-measurements-active').write_text('Fresh verified stage-1 cold matrix; no builds/tests/profiles.\n')
try:
 cmd=['python3','benchmarks/runtime/compare-append.py','--before',identities['structural-baseline']['binary'],'--after',identities['metadata']['binary'],'--output',str(root/'metadata-append-cold-verified-paired'),'--pairs','3','--cold'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/'metadata-append-cold-verified.log').open('w') as log:r=subprocess.run(cmd,cwd=main,stdout=log,stderr=subprocess.STDOUT)
 (root/'metadata-cold-verified-status.json').write_text(json.dumps({'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode},indent=2))
finally:(root/'identity-measurements-active').unlink()
if r.returncode:raise SystemExit(r.returncode)
with (root/'metadata-append-cold-verified-summary.json').open('w') as out:subprocess.run(['python3','benchmarks/runtime/summarize-comparisons.py','--append',str(root/'metadata-append-cold-verified-paired')],cwd=main,stdout=out,check=True)
