import hashlib,json,re
from pathlib import Path
root=Path('/workspace/issue-481-evidence');out=Path('docs/issue-481/evidence/pair-inputs');out.mkdir(exist_ok=True)
for stage in ['metadata','certificate']:
 for mode in (['runtime','append-warm','append-cold-fixed','append-cold-verified'] if stage=='metadata' else ['runtime','append-warm','append-cold']):
  if not (root/f'{stage}-{mode}-summary.json').exists():continue
  summary=json.loads((root/f'{stage}-{mode}-summary.json').read_text());records=[]
  invalid=stage=='metadata' and mode=='append-cold-fixed'
  for case,pairs in summary['samples'].items():
   for pair in pairs:
    row={'case':case,'pair':pair['pair']}
    for side in ['before','after']:
     data=pair[side];path=Path(data.get('file',root/f'{stage}-{mode}-paired'/f"{pair['pair']}-{case}-{side}.json"));row[side]={'input':str(path.relative_to(root)),'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'metrics':{k:v for k,v in data.items() if isinstance(v,(int,float)) or v is None}}
    records.append(row)
  payload={'valid_revision_comparison':False if invalid else True,'identity_review':'invalid same-binary comparison; rerun pending' if invalid else ('metadata baseline independently clean-rebuilt byte-identical; candidate root freshly compiled' if stage=='certificate' else 'fresh library+conformance builds verified'),'method':'For each case/metric, compute after/before within each pair, then median across all pairs. Null or zero denominators are unavailable, not zero ratios. No slow samples removed.','executables':json.loads((root/f'{stage}-{mode}-paired'/'manifest.json').read_text())['executables'],'scope':summary['scope'],'append_mode':summary.get('append_mode'),'append_counter_scope':summary.get('append_counter_scope'),'memory_scope':summary.get('memory_scope'),'pairs':records}
  (out/f'{stage}-{mode}.json').write_text(json.dumps(payload,indent=2,sort_keys=True))
 summary=json.loads((root/f'{stage}-pi-summary.json').read_text());records=[]
 for group,samples in summary['groups'].items():
  for data in samples:
   path=Path(data['file']);pair=int(path.name.split('-')[0]);records.append({'case_engine':group,'pair':pair,'input':str(path.relative_to(root)),'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'metrics':{k:v for k,v in data.items() if isinstance(v,(int,float)) or v is None}})
 (out/f'{stage}-pi.json').write_text(json.dumps({'scope':summary['scope'],'method':'Group by case/engine; medians retain all samples. Pair IDs permit paired engine ratios while keeping native-schema differences explicit.','samples':records},indent=2,sort_keys=True))
audit=[]
for stage in ['structural-baseline','metadata','metadata-cold-fixed','structural-baseline-cold-fixed','certificate']:
 identity=json.loads((root/f'{stage}-executable.json').read_text());artifacts=[]
 for line in (root/f'{stage}-build.jsonl').read_text().splitlines():
  try:d=json.loads(line)
  except ValueError:continue
  if d.get('reason')=='compiler-artifact' and d.get('target',{}).get('name') in ['rustx','conformance']:artifacts.append({'target':d['target']['name'],'kind':d['target']['kind'],'fresh':d['fresh'],'source_path':d['target']['src_path']})
 audit.append({'name':stage,'reported_identity':identity,'root_artifacts':artifacts,'verdict':'INVALID claimed baseline identity: returned cached metadata executable' if stage=='structural-baseline-cold-fixed' else ('metadata library cache chain independently confirmed by byte-identical clean rebuild' if stage=='metadata-cold-fixed' else 'root library and conformance freshly compiled')})
Path('docs/issue-481/evidence/build-identity-audit.json').write_text(json.dumps({'finding':'Stage-1 corrected cold A/B executed the same metadata binary twice. With shared Cargo target, checkout source mtimes did not invalidate older-root artifacts. Original records retained; new builds must clean root crate and assert fresh:false for library and conformance.','builds':audit,'clean_metadata_confirmation':json.loads((root/'metadata-verified-executable.json').read_text()),'clean_baseline_replacement':json.loads((root/'structural-baseline-verified-executable.json').read_text()) if (root/'structural-baseline-verified-executable.json').exists() else None},indent=2))
print('exported available structural matrices and build identity audit')
