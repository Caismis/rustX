import hashlib,json,statistics
from pathlib import Path
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-481');results=[]
for p in (repo/'docs/issue-481/evidence/pair-inputs').glob('*.json'):
 if not p.name.startswith(('metadata-','certificate-','compact-pages-','whole-issue-')):continue
 data=json.loads(p.read_text());checked=0;medians=0
 if 'pairs' in data:
  summary=json.loads((root/(p.stem+'-summary.json')).read_text())
  assert len(data['pairs'])==sum(map(len,summary['samples'].values()))
  for row in data['pairs']:
   for side in ('before','after'):
    record=row[side];path=root/record['input'];assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==record['sha256'];checked+=1
    status=json.loads(path.with_name(path.stem+'.process.json').read_text());assert status['accepted']
  for case,expected in summary['medians'].items():
   pairs=[row for row in data['pairs'] if row['case']==case];assert len(pairs)==3
   for metric,want in expected['after_over_before'].items():
    ratios=[row['after']['metrics'][metric]/row['before']['metrics'][metric] if row['before']['metrics'].get(metric) not in (None,0) and row['after']['metrics'].get(metric) is not None else None for row in pairs]
    actual=statistics.median(ratios) if all(ratio is not None for ratio in ratios) else None
    assert actual==want,(p,case,metric,actual,want)
    medians+=1
 else:
  for record in data['samples']:
   path=root/record['input'];assert hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==record['sha256'];checked+=1
   status=json.loads(path.with_name(path.stem+'.process.json').read_text());assert status['accepted']
 results.append({'matrix':p.name,'checked_input_hashes':checked,'recomputed_paired_medians':medians,'valid_revision_comparison':data.get('valid_revision_comparison')})
(root/'structural-plain-input-verification.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
