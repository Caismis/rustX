import json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-481');origin=root/'origin-verified-build/identity.json'
print('Waiting for independently cleaned origin/main build.',flush=True)
while not origin.exists():time.sleep(1)
assert json.loads(origin.read_text())['verified'] is True
assert not list(root.glob('*measurements-active'))
env=os.environ|{'PATH':'/workspace/.cargo/bin:'+os.environ['PATH'],'CARGO_HOME':'/workspace/.cargo','RUSTUP_HOME':'/workspace/.rustup','BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include'}
cmd=['python3','benchmarks/runtime/build-revision.py','--repo','/workspace/rustX-481-compact-pages','--target','/workspace/issue-481-target','--output',str(root/'compact-verified-build')]
print('BUILD compact pages',flush=True)
with (root/'compact-verified-build-driver.log').open('x') as log:r=subprocess.run(cmd,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
print('BUILD compact pages exit',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
after=root/'compact-verified-build/identity.json';candidate=json.loads(after.read_text());assert candidate['verified'] is True
assert candidate['harness']==json.loads(origin.read_text())['harness']
for stage,before,extra in [('compact-pages',root/'certificate-executable.json',['--pi']),('whole-issue',origin,[])]:
 cmd=['python3',str(root/'measure-verified-stage.py'),'--before',str(before),'--after',str(after),'--stage',stage,*extra]
 print('MATRIX',stage,flush=True);r=subprocess.run(cmd,cwd=repo)
 if r.returncode:raise SystemExit(r.returncode)
cmd=['python3',str(root/'profile-final-structural.py'),'--baseline',json.loads(origin.read_text())['binary'],'--candidate',candidate['binary']]
print('PROFILES after formal matrices',flush=True)
raise SystemExit(subprocess.run(cmd,cwd=repo).returncode)
