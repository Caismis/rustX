import json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/issue-481-evidence');status=root/'compact-pages-durable-2-status.json'
print('Waiting for durable tests before the independent origin/main release rebuild.',flush=True)
while not status.exists():time.sleep(1)
assert json.loads(status.read_text())['exit']==0
assert not list(root.glob('*measurements-active'))
env=os.environ|{'PATH':'/workspace/.cargo/bin:'+os.environ['PATH'],'CARGO_HOME':'/workspace/.cargo','RUSTUP_HOME':'/workspace/.rustup','BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include'}
cmd=['python3','benchmarks/runtime/build-revision.py','--repo','/workspace/rustX-481-origin-baseline','--target','/workspace/issue-481-target','--output',str(root/'origin-verified-build')]
print('BUILD origin/main with identical benchmark fixture inputs.',flush=True)
with (root/'origin-verified-build-driver.log').open('x') as log:r=subprocess.run(cmd,cwd='/workspace/rustX-481',env=env,stdout=log,stderr=subprocess.STDOUT)
print('BUILD origin/main exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
