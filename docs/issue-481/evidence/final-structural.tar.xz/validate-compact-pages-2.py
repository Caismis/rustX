import json,os,subprocess
from pathlib import Path
root=Path('/workspace/issue-481-evidence')
assert not list(root.glob('*measurements-active'))
env=os.environ|{'PATH':'/workspace/.cargo/bin:'+os.environ['PATH'],'CARGO_HOME':'/workspace/.cargo','RUSTUP_HOME':'/workspace/.rustup','CARGO_TARGET_DIR':'/workspace/issue-481-target','CARGO_BUILD_JOBS':'2','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include'}
cmd=['cargo','test','--lib','durable::sqlite']
with (root/'compact-pages-durable-2.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'compact-pages-durable-2-status.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}));print('durable exit',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
subprocess.run(['cargo','fmt','--all'],env=env,check=True)
env['CARGO_TARGET_DIR']='/workspace/issue-481-clippy';env['CARGO_BUILD_JOBS']='1'
cmd=['cargo','clippy','--all-targets','--all-features','--','-D','warnings']
with (root/'compact-pages-clippy.log').open('w') as log:r=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
(root/'compact-pages-clippy-status.json').write_text(json.dumps({'command':cmd,'exit':r.returncode}));print('clippy exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
