import argparse,datetime,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--baseline',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);a=p.parse_args()
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-481');assert not list(root.glob('*measurements-active'));records=[]
for stage,binary in [('origin',a.baseline),('certificate',root/'certificate-conformance'),('compact',a.candidate)]:
 for case in ['short-small-control','short-small','short-large-control','short-large','syscalls','footprints']:
  out=root/'final-structural-profile'/f'{stage}-{case}'
  if case=='footprints':cmd=['python3','benchmarks/runtime/profile-footprints.py','--rust',str(binary),'--output',str(out)]
  elif case=='syscalls':cmd=['python3','benchmarks/runtime/profiling/syscalls.py','--binary',str(binary),'--output',str(out)]
  else:cmd=['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(out),'--mode','control' if case.endswith('-control') else 'cpu','--case',case.removesuffix('-control')]
  print('PROFILE',stage,case,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (root/f'final-structural-profile-{stage}-{case}.log').open('x') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  records.append({'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode});(root/'final-structural-profile-status.json').write_text(json.dumps(records,indent=2))
  if r.returncode:raise SystemExit(r.returncode)
  if case=='syscalls':
   with (out/'source-writes.json').open('w') as dest:subprocess.run(['python3','benchmarks/runtime/profile-source.py',str(out/'calls.strace')],cwd=repo,stdout=dest,check=True)
  elif case!='footprints' and not case.endswith('-control'):
   with (out/'steady-cumulative.txt').open('w') as dest,(out/'symbolize.log').open('w') as err:subprocess.run(['/workspace/issue-481-profilers/unpacked/usr/bin/google-pprof','--text','--cum','--no_strip_temp','--nodecount=100',str(binary),str(out/'before_measured_turns.cpu')],cwd=repo,stdout=dest,stderr=err,check=True)
