import hashlib,importlib.util,json,statistics,sys
from pathlib import Path
repo=Path('/workspace/rustX-481');root=Path('/workspace/issue-481-evidence');sys.path.insert(0,str(repo/'benchmarks/runtime'))
spec=importlib.util.spec_from_file_location('summary',repo/'benchmarks/runtime/summarize-http.py');summary=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary)
all_groups={}
for stage in ['compact-pages-runtime','whole-issue-runtime','compact-pages-pi']:
 groups={}
 for path in sorted((root/(stage+'-paired')).glob('*.process.json')):
  status=json.loads(path.read_text());assert status['accepted'];raw_path=path.with_name(path.name.replace('.process.json','.json'));raw=json.loads(raw_path.read_text());pair,case_side=raw_path.stem.split('-',1);case,side=case_side.rsplit('-',1)
  sample=summary.sample(raw_path);initial=summary.counters(raw['lifecycle'][0]);final=summary.counters(raw['lifecycle'][-1]);values={
   'product_startup_to_ready_ms':status['product_startup_ns']/1e6,
   'provider_startup_ms':status['provider_startup_ns']/1e6,
   'provider_teardown_ms':status['provider_teardown_ns']/1e6,
   'controller_complete_ms':status['complete_lifecycle_ns']/1e6,
   'through_product_exit_ms':status['through_product_exit_ns']/1e6,
   'self_cpu_before_first_lifecycle_sample_ms':initial['cpu_ms'],
   'self_cpu_process_start_through_cleanup_ms':final['cpu_ms'],
   'process_attributed_writes_start_through_cleanup_bytes':final['write_bytes'],
   **{key:value for key,value in sample.items() if isinstance(value,(int,float)) or value is None},
  }
  for phase in sample['phases']:
   for key in ['wall_ms','cpu_ms','write_bytes']:values['phase/'+phase['through']+'/'+key]=phase[key]
  for phase in ['checkpoint_footprint','before_close','closed_footprint']:
   if phase not in raw:continue
   for kind in ['db','wal','shm','other','total']:
    files=[]
    for file in raw[phase]:
     name=file.get('path',file.get('name'));assert name is not None;category='wal' if name.endswith('-wal') else 'shm' if name.endswith('-shm') else 'db' if name.endswith(('.sqlite','.db')) else 'other'
     if kind in (category,'total'):files.append(file)
    for metric in ['logical','allocated']:
     values['footprint/'+phase+'/'+kind+'/'+metric+'_bytes']=sum(f[metric] for f in files) if all(f.get(metric) is not None for f in files) else None
  groups.setdefault(case+'/'+side,[]).append({'pair':int(pair),'input':str(raw_path.relative_to(root)),'sha256':hashlib.file_digest(raw_path.open('rb'),'sha256').hexdigest(),'values':values})
 medians={}
 for case,records in groups.items():
  assert len(records)==3
  medians[case]={key:statistics.median([record['values'][key] for record in records]) if all(record['values'][key] is not None for record in records) else None for key in records[0]['values']}
 all_groups[stage]={'samples':groups,'medians':medians}
payload={'scope':'Each phase is differenced within one process before any median. Complete product self CPU through cleanup is the absolute fresh-process utime+stime total (10 ms resolution), including loader/test-harness/import startup before the first lifecycle sample; child/provider CPU is excluded. Post-cleanup evidence serialization/output is excluded from those counters but included in controller/product-exit wall. Product-startup-to-ready includes pre-provider fixture setup, not just loader time. Provider startup/control and teardown wall remain explicit. DB/WAL/SHM footprints are logical and allocated file sizes, not device writes. Other/total preserve the native driver listing: Rust recursively lists files, whereas Pi lists direct root entries (including its workspace directory); those other/total scopes are not equivalent engine comparisons; separate Source-temp sampled footprints are diagnostic profiles. RSS/PSS are observed samples, not peaks. No unrelated medians are subtracted.','groups':all_groups}
(repo/'docs/issue-481/evidence/final-lifecycle-details.json').write_text(json.dumps(payload,indent=2)+'\n')
print('Exported',sum(len(v['samples']) for v in all_groups.values()),'case/side groups with 3 samples each')
