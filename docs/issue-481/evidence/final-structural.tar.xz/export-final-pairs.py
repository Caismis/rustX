import hashlib,json,statistics
from pathlib import Path
root=Path('/workspace/issue-481-evidence');out=Path('/workspace/rustX-481/docs/issue-481/evidence/pair-inputs')
for stage in ['compact-pages','whole-issue']:
 for mode in ['runtime','append-warm','append-cold']:
  name=stage+'-'+mode;directory=root/(name+'-paired');summary=json.loads((root/(name+'-summary.json')).read_text());executables=json.loads((directory/'manifest.json').read_text())['executables'];assert executables['before']['sha256']!=executables['after']['sha256'];records=[]
  for case,pairs in summary['samples'].items():
   assert len(pairs)==3
   for pair in pairs:
    row={'case':case,'pair':pair['pair']}
    for side in ['before','after']:
     data=pair[side];path=Path(data.get('file',directory/f"{pair['pair']}-{case}-{side}.json"));assert json.loads(path.with_name(path.stem+'.process.json').read_text())['accepted']
     row[side]={'input':str(path.relative_to(root)),'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'metrics':{k:v for k,v in data.items() if isinstance(v,(int,float)) or v is None}}
    records.append(row)
  payload={'valid_revision_comparison':True,'identity_review':'Fresh product library and conformance artifacts; distinct preserved executable hashes; identical benchmark fixture inputs. See matrix identities/build logs.','method':'For each case/metric compute after/before within each pair, then median across all three pairs. Null or zero denominators are unavailable, not zero ratios. No failed or slow samples discarded.','executables':executables,'scope':summary['scope'],'append_mode':summary.get('append_mode'),'append_counter_scope':summary.get('append_counter_scope'),'memory_scope':summary.get('memory_scope'),'pairs':records}
  (out/(name+'.json')).write_text(json.dumps(payload,indent=2,sort_keys=True))
name='compact-pages-pi';summary=json.loads((root/(name+'-summary.json')).read_text());records=[]
for group,samples in summary['groups'].items():
 assert len(samples)==3
 for data in samples:
  path=Path(data['file']);pair=int(path.name.split('-')[0]);assert json.loads(path.with_name(path.stem+'.process.json').read_text())['accepted'];records.append({'case_engine':group,'pair':pair,'input':str(path.relative_to(root)),'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'metrics':{k:v for k,v in data.items() if isinstance(v,(int,float)) or v is None}})
(out/(name+'.json')).write_text(json.dumps({'scope':summary['scope'],'method':'All three samples retained per case/engine. Native-schema and contract differences remain explicit.','samples':records},indent=2,sort_keys=True))
print('Exported six revision matrices and same-provider Pi matrix.')
