from pathlib import Path
import subprocess
root=Path('/workspace/issue-481-evidence')
patterns=['compact-pages-*','compact-pages-*-paired/*','whole-issue-*','whole-issue-*-paired/*','final-structural-profile/**/*','final-structural-profile-*.log','final-structural-profile-status.json','final-structural-environment.json','origin-verified-build/*.stdout','origin-verified-build/*.stderr','origin-verified-build/identity.json','compact-verified-build/*.stdout','compact-verified-build/*.stderr','compact-verified-build/identity.json','*verified-build-driver.log','origin-baseline-harness.*','structural-harness-identity-check.json','build-measure-final-structural.py','measure-verified-stage.py','profile-final-structural.py','build-origin-after-durable.py','validate-compact-pages-2.py','export-final-pairs.py','verify-structural-pair-inputs.py','export-final-lifecycle.py','analyze-final-structural-profiles.py','write-final-reports.py','compact-final-cpu-display.py','pack-final-evidence.py','final-plain-input-verification.log','structural-plain-input-verification.json','final-profile-analysis.log','structural-pi-oracle-tests.log','build-identity-python-tests-2.log','clippy-resource-pause.json']
cmd=['python3','benchmarks/runtime/pack-evidence.py','--root',str(root),'--output','docs/issue-481/evidence/final-structural.tar.xz',*patterns]
r=subprocess.run(cmd,cwd='/workspace/rustX-481',text=True,capture_output=True)
(root/'final-evidence-pack-status.json').write_text(r.stdout)
print(r.stdout,r.stderr)
raise SystemExit(r.returncode)
