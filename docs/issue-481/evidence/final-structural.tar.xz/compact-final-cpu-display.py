import json
from pathlib import Path
path=Path('/workspace/rustX-481/docs/issue-481/evidence/final-structural-cpu-counts.json')
data=json.loads(path.read_text())
for record in data['profiles']:
 if 'symbol_rows_reported' in record:continue
 rows=record['rows'];record['symbol_rows_reported']=len(rows)
 record['rows']=rows[:40]+[row for row in rows[40:] if row['symbol'].startswith(('rustx::runtime::read_layout::','rustx::durable::sqlite::observation_request::composed::fragments::','rustx::durable::sqlite::observation_request::composed::index::')) or row['symbol'] in ('sqlite3Prepare','conformance::agent_loop::runtime_benchmark::process_sample','conformance::agent_loop::runtime_benchmark::footprint','conformance::agent_loop::runtime_benchmark::verify_requests')]
 record['display_selection']='First 40 cumulative rows plus Source construction/index and harness measurement functions. Complete symbolized report and raw profile remain in the archive; denominator is unchanged.'
 assert all(row in rows for row in record['rows'])
path.write_text(json.dumps(data,indent=2))
print('Displayed',sum(len(r['rows']) for r in data['profiles']),'of',sum(r['symbol_rows_reported'] for r in data['profiles']),'symbol rows; all complete reports retained')
