import argparse,datetime,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--before',type=Path,required=True);p.add_argument('--after',type=Path,required=True);p.add_argument('--stage',required=True);p.add_argument('--pi',action='store_true');a=p.parse_args()
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-481')
identities=[json.loads(path.read_text()) for path in [a.before,a.after]]
assert identities[0]['sha256']!=identities[1]['sha256']
for identity in identities:
 assert hashlib.file_digest(Path(identity['binary']).open('rb'),'sha256').hexdigest()==identity['sha256']
fixture='tests/conformance/agent_loop/runtime_benchmark.rs'
assert identities[0].get('fixture_sha256',identities[0].get('harness',{}).get(fixture))==identities[1].get('fixture_sha256',identities[1].get('harness',{}).get(fixture))
if all('harness' in identity for identity in identities):assert identities[0]['harness']==identities[1]['harness']
(root/(a.stage+'-matrix-identities.json')).write_text(json.dumps(identities,indent=2))
assert not list(root.glob('*measurements-active'))
marker=root/(a.stage+'-measurements-active');marker.write_text('Formal interleaved matrix: no builds/tests/profiles/compression.\n')
stages=[('runtime','compare-revisions.py',[]),('append-warm','compare-append.py',[]),('append-cold','compare-append.py',['--cold'])]
if a.pi:stages.append(('pi','controller.py',['--pi','/workspace/pi-481']))
records=[]
try:
 for mode,script,extra in stages:
  name=a.stage+'-'+mode
  paths=['--rust',identities[1]['binary']] if mode=='pi' else ['--before',identities[0]['binary'],'--after',identities[1]['binary']]
  cmd=['python3','benchmarks/runtime/'+script,*paths,'--output',str(root/(name+'-paired')),'--pairs','3',*extra]
  print('START',name,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (root/(name+'.log')).open('x') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  records.append({'command':cmd,'stage':name,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode})
  (root/(a.stage+'-matrix-status.json')).write_text(json.dumps(records,indent=2));print('END',name,r.returncode,flush=True)
finally:marker.unlink()
for mode,_,_ in stages:
 name=a.stage+'-'+mode;script='summarize-http.py' if mode=='pi' else 'summarize-comparisons.py';extra=['--append'] if mode.startswith('append-') else []
 with (root/(name+'-summary.json')).open('x') as out:r=subprocess.run(['python3','benchmarks/runtime/'+script,*extra,str(root/(name+'-paired'))],cwd=repo,stdout=out)
 if r.returncode:print('SUMMARY FAILED',name,r.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in records))
