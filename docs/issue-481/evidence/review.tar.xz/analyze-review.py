import hashlib,json,statistics
from pathlib import Path
r=Path('/workspace/issue-481-evidence')
result={'scope':'Diagnostics, not replacements for the original untrimmed headline matrices. External 10 ms sampling can perturb scheduling. Raw inputs and all paired observations are preserved.','groups':{},'memory_median_paired_deltas_kib':{}}
def memory(point):
    return {k:int(v.split()[0]) for k,v in (line.split(':',1) for line in point['process']['smaps_rollup'].splitlines() if ':' in line)}
for folder in ('contention-workspace','contention-tmpfs','contention-warm-executables'):
 records=[]
 for i in range(3):
  pair={'pair':i}
  for side in ('before','after'):
   path=r/folder/f'{i}-short-small-{side}.json';dp=path.with_suffix('.diagnostic.json');s=json.loads(path.read_text());d=json.loads(dp.read_text())
   counters=lambda p:{k:int(v) for k,v in (l.split() for l in p['cpu_stat'].splitlines())}
   c0,c1=[counters(d[k]) for k in ('before','after')]
   ss=[p for p in s['samples'] if p['measured']]
   exe='source-append-conformance' if side=='before' else 'combined-conformance'
   maps=[p['mappings'] for p in d['samples'] if p.get('mappings')]
   pair[side]={'input':str(path.relative_to(r)),'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'diagnostic_sha256':hashlib.file_digest(dp.open('rb'),'sha256').hexdigest(),
               'mean_turn_ms':statistics.mean(p['settled_us']/1000 for p in ss),
               'measured_turn_ms':[p['settled_us']/1000 for p in ss],
               'cgroup_throttled_ms':(c1['throttled_usec']-c0['throttled_usec'])/1000,
               'wchan_samples':d['wchan_samples'],'cpu_max':d['before']['cpu_max'],
               'dirty_pages_before_after':[d[k]['vmstat']['nr_dirty'] for k in ('before','after')],
               'max_sampled_executable_pss_kib':max((sum(v['Pss'] for name,v in m.items() if name.endswith('/'+exe)) for m in maps),default=None),
               'max_sampled_rss_kib':max(memory(p)['Rss'] for p in [*s['samples'],*s['lifecycle']]),
               'executable_warm_ms':d.get('executable_warm_ns',0)/1e6 if d.get('executable_warm_ns') is not None else None}
  pair['wall_ratio']=pair['after']['mean_turn_ms']/pair['before']['mean_turn_ms'];records.append(pair)
 result['groups'][folder]={'pairs':records,'median_wall_ratio':statistics.median(p['wall_ratio'] for p in records)}
for label,dirs in [('Source',['source-paired']),('Canonical',['canonical-runtime-paired','canonical-runtime-confirmation']),('Combined',['combined-paired','combined-confirmation']),('Append',['canonical-append-paired','canonical-append-confirmation'])]:
 out={}
 for directory in dirs:
  for before in (r/directory).glob('*-2048-before.json' if label=='Append' else '*-short-small-before.json'):
   after=before.with_name(before.name.replace('-before.json','-after.json'));b,a=[json.loads(p.read_text()) for p in (before,after)]
   for phase in ('after_initialization','after_turns','after_cleanup') if label!='Append' else ('after_seed','after_appends','after_cleanup'):
    vals=[memory(next(p for p in s['lifecycle'] if p['phase']==phase)) for s in (b,a)]
    for key in ('Rss','Pss_Anon','Pss_File'):out.setdefault(phase,{}).setdefault(key,[]).append(vals[1][key]-vals[0][key])
 result['memory_median_paired_deltas_kib'][label]={phase:{key:{'pairs':values,'median':statistics.median(values)} for key,values in fields.items()} for phase,fields in out.items()}
Path('docs/issue-481/evidence/review-analysis.json').write_text(json.dumps(result,indent=2))
print({k:v['median_wall_ratio'] for k,v in result['groups'].items()})
