import datetime,hashlib,json,os,subprocess,shutil
from pathlib import Path
root=Path('/workspace/issue-481-evidence');repo=Path('/workspace/rustX-481-certificate')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();assert head.startswith('563279ac')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo)
fixture=repo/'tests/conformance/agent_loop/runtime_benchmark.rs'
identity={'head':head,'production_tree':subprocess.check_output(['git','rev-parse','HEAD:src'],cwd=repo,text=True).strip(),'fixture_sha256':hashlib.file_digest(fixture.open('rb'),'sha256').hexdigest(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
before=json.loads((root/'metadata-cold-fixed-executable.json').read_text());assert identity['fixture_sha256']==before['fixture_sha256']
env=os.environ|{'PATH':'/workspace/.cargo/bin:'+os.environ['PATH'],'CARGO_HOME':'/workspace/.cargo','RUSTUP_HOME':'/workspace/.rustup','CARGO_TARGET_DIR':'/workspace/issue-481-target','CARGO_BUILD_JOBS':'2','BINDGEN_EXTRA_CLANG_ARGS':'-isystem /usr/lib/gcc/x86_64-linux-gnu/14/include'}
cmd=['cargo','test','--release','--locked','--test','conformance','--no-run','--message-format=json'];identity['command']=cmd
with (root/'certificate-build.jsonl').open('w') as out,(root/'certificate-build.log').open('w') as err:r=subprocess.run(cmd,cwd=repo,env=env,stdout=out,stderr=err)
identity['exit']=r.returncode;identity['end_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
if r.returncode==0:
 records=[json.loads(s) for s in (root/'certificate-build.jsonl').read_text().splitlines() if s.startswith('{')]
 binary=next(Path(x['executable']) for x in records if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='conformance' and x.get('executable'))
 dest=root/'certificate-conformance';assert not dest.exists();shutil.copy2(binary,dest);identity['binary']=str(dest);identity['sha256']=hashlib.file_digest(dest.open('rb'),'sha256').hexdigest()
(root/'certificate-executable.json').write_text(json.dumps(identity,indent=2));print('BUILD',r.returncode,flush=True)
if r.returncode:raise SystemExit(r.returncode)
(root/'certificate-measurements-active').write_text('No concurrent compilation, tests or profiling.\n')
records=[]
try:
 for name,script,args in [('certificate-runtime','compare-revisions.py',[]),('certificate-append-warm','compare-append.py',[]),('certificate-append-cold','compare-append.py',['--cold']),('certificate-pi','controller.py',['--pi','/workspace/pi-481'])]:
  common=['--rust',identity['binary']] if script=='controller.py' else ['--before',before['binary'],'--after',identity['binary']]
  cmd=['python3','benchmarks/runtime/'+script,*common,'--output',str(root/(name+'-paired')),'--pairs','3',*args];start=datetime.datetime.now(datetime.timezone.utc).isoformat();print('START',name,flush=True)
  with (root/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
  records.append({'command':cmd,'stage':name,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':r.returncode});(root/'certificate-matrix-status.json').write_text(json.dumps(records,indent=2));print('END',name,r.returncode,flush=True)
finally:(root/'certificate-measurements-active').unlink()
for name,script,args in [('certificate-runtime','summarize-comparisons.py',[]),('certificate-append-warm','summarize-comparisons.py',['--append']),('certificate-append-cold','summarize-comparisons.py',['--append']),('certificate-pi','summarize-http.py',[])]:
 with (root/(name+'-summary.json')).open('w') as out:r=subprocess.run(['python3','benchmarks/runtime/'+script,*args,str(root/(name+'-paired'))],cwd=repo,stdout=out)
 if r.returncode:print('SUMMARY FAILED',name,r.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in records))
