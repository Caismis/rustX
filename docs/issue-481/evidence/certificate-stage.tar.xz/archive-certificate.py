import hashlib,json,tarfile
from pathlib import Path
root=Path('/workspace/issue-481-evidence');out=Path('docs/issue-481/evidence/certificate-stage.tar.xz');files=[];manifest={}
for directory in ['certificate-runtime-paired','certificate-append-warm-paired','certificate-append-cold-paired','certificate-pi-paired']:files.extend(p for p in (root/directory).rglob('*') if p.is_file())
for pattern in ['certificate-*.json','certificate-*.jsonl','certificate-*.log']:files.extend(root.glob(pattern))
for name in ['build-measure-certificate.py','report-certificate.py','archive-certificate.py']:files.append(root/name)
for p in sorted(set(files)):manifest[str(p.relative_to(root))]={'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()}
with tarfile.open(out,'w:xz',preset=3) as tar:
 for name in manifest:tar.add(root/name,arcname=name,recursive=False)
Path('docs/issue-481/evidence/certificate-stage.tar.manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True))
with tarfile.open(out,'r:xz') as tar:
 for member in tar:
  b=tar.extractfile(member).read();assert len(b)==manifest[member.name]['bytes'];assert hashlib.sha256(b).hexdigest()==manifest[member.name]['sha256']
print('verified',len(manifest),'files;',out.stat().st_size,'archive bytes')
