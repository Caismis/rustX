import json
from pathlib import Path
root=Path('/workspace/issue-481-evidence');candidate=json.loads((root/'certificate-executable.json').read_text());before=json.loads((root/'metadata-cold-fixed-executable.json').read_text())
s='''# Incremental append certificate measurements

Production candidate `563279ac8b6aeac29b36e75f5682195df9dd6c0b` is compared with
Source-metadata stage `76ecc9d765e5c63080950e7dc5710a32b0b1caa7`, using the same
corrected benchmark fixture. This isolates the connection-local certificate;
compact page/spool changes are not included. All 120 fresh-process samples pass:
36 runtime, 24 warm append, 24 cold append and 36 same-provider Pi samples.
Each case/history has three paired, alternating runs. No build or profiler ran
during these formal matrices. Failures from development checks remain archived.

Ratios are median same-pair candidate/baseline ratios, not ratios of independent
medians. CPU is product plus driver at 10 ms resolution, memory is sampled rather
than peak, and writes are process-attributed rather than physical-device writes.
Warm CPU covers the entire append phase; cold CPU sums operation windows with
counter/sampling overhead. Native allocator counts are unavailable. Evidence JSON
is written after cleanup counters. Startup, provider control, seed, close,
checkpoint, reopen verification and cleanup remain separately recorded.

## Marginal append

| Mode | Seed history | Append wall ratio | Append CPU ratio | Lifecycle write ratio | Sampled anonymous PSS ratio |
|---|---:|---:|---:|---:|---:|
'''
for mode in ['warm','cold']:
 d=json.loads((root/f'certificate-append-{mode}-summary.json').read_text())['medians']
 for h in ['0','64','512','2048']:
  x=d[h]['after_over_before'];s+=f'| {mode} | {h} | '+' | '.join(f'{x[k]:.4f}' for k in ['mean_append_ms','append_cpu_ms_per_append','lifecycle_write_mib','max_sampled_anon_pss_mib'])+' |\n'
s+='''
Warm marginal wall improves 8.5% at 2,048 retained messages and 5.9% at 512;
the 64-message control is slightly adverse. Cold append at 2,048 is 10.3% slower.
The certificate does not remove cold validation and adds version checks. Coarse
CPU windows are noisy, especially at small histories; their large adverse ratios
are retained rather than called pure engine CPU. Lifecycle gains include the
warm seeding phase even in cold-mode samples and do not negate cold-operation
regressions. No disk or sampled-memory improvement is established.

Deterministic work-counter tests prove that warm native appends reuse validated
counts, while first/cold/invalidation paths use the existing validator. These are
logical validation counts, not whole-request complexity claims. Native frontier,
publication, duplicate/order and checkpoint checks remain. The accepted arbitrary
out-of-band historical-corruption detection tradeoff and full consumer/mutation
audit are in [append validation](append-validation.md).

## Whole runtime

| Case | Turn wall ratio | Turn CPU ratio | Lifecycle write ratio | Sampled anonymous PSS ratio |
|---|---:|---:|---:|---:|
'''
d=json.loads((root/'certificate-runtime-summary.json').read_text())['medians']
for case in ['short-small','short-large','large','stream','tool','cancel']:
 x=d[case]['after_over_before'];s+='| '+case+' | '+' | '.join(f'{x[k]:.4f}' for k in ['mean_turn_ms','turn_cpu_ms_per_turn','lifecycle_write_mib','max_sampled_anon_pss_mib'])+' |\n'
s+='''
Short-small wall/CPU improve 3.3%/4.0%; short-large is slightly adverse. This is
not a general whole-request speedup, and context construction remains separate
unavoidable work. The same-provider Pi matrix retains the actual pinned Durable
SQLite production adapter, native Tool-schema differences and full ordered
oracles. It is a contemporaneous engine comparison, not a pure DB-cost comparison.
The runtime revision matrix and Pi matrix each validate 846 complete requests.

## Identity and validation

'''
s+=f"- Baseline executable SHA-256: `{before['sha256']}`.\n- Candidate executable SHA-256: `{candidate['sha256']}`.\n- Shared fixture SHA-256: `{candidate['fixture_sha256']}`.\n"
s+='''
The 383-test durable suite passed. All-target/all-feature Clippy passed after
semantics-preserving match cleanup. The final 15-test focused rerun includes
sparse frontiers, exact 8,192 admission behavior, new-ID error timing, rollback,
trigger replacement, checkpoint Original deletion, schema changes, overflow
fail-closed behavior, reopen, and an external writer between COMMIT and seating.
Final combined FULL/Merge and independent review are still required.

The [compact evidence archive](evidence/certificate-stage.tar.xz) includes every
sample, process result, oracle output, full logical/allocated DB/WAL/temp footprint,
summary, build identity and development-check failure. Its
[SHA-256 manifest](evidence/certificate-stage.tar.manifest.json) is checked against
the archive; original evidence remains in the cloud workspace.
'''
Path('docs/issue-481/append-certificate-results.md').write_text(s)
