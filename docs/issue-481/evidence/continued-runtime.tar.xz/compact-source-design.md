# Compact Source candidate

The attribution checkpoint observed ~31.9 MB of Source index initialization
allocation traffic per 32 short-small turns. Sources at most 4,096 encoded bytes
now keep a bounded vector of navigation records instead of a SQLite connection.
Original byte files and the existing parser remain authoritative for this derived
layout. The parser assigns preorder IDs and completes each record once; sealing
sorts records in place and validates IDs, parent ordering, spans, direct-child
ordinals and counts before publishing the Source. The number of nodes and decoded
key bytes is bounded by the encoded admission limit. Larger Sources still build
and query the disk index; canonical key ordering still uses that disk path.

Small metadata selection scans only the bounded resident records, never the
original bytes or a reconstructed JSON tree. Node IDs index the sealed vector.
Generic ranges, named and ordinal paths, previews and pagination retain their
interfaces. Byte-range copies keep the same chunks and verification path, while
parse/copy buffers request at most the actual source length up to 64 KiB.

No persisted format, authority, publication cadence, event or transaction changes
are introduced by this stage. Original capture witnesses are not regenerated.
The vector contains no connection mutex held over callbacks; small and disk
traversal are tested with nested reads from the same immutable Source.

Tests cover the exact 4,096/4,097-byte boundary, dense pagination, lexical JSON,
u64/key order, malformed metadata, backend corruption and original-byte copying.
The first test attempt caught a test injection mistake (DROP TABLE through the
read-only disk reader); the corrected fixture uses a separate writable connection
to inject corruption while the product continues opening read-only readers.

This file is a design checkpoint, not a performance result. Formal samples await
completed builds/tests and an immutable executable with recorded hash.
