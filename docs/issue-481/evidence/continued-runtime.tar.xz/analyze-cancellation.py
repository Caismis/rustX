import json,hashlib,statistics
from pathlib import Path
root=Path('/workspace/issue-481-evidence');rows=[]
for directory in ['reservations-paired','reservation-cancel-confirmation']:
 for before in sorted((root/directory).glob('*-cancel-before.json')):
  pair=int(before.name.split('-')[0]);row={'directory':directory,'pair':pair}
  for side in ['before','after']:
   path=before.with_name(f'{pair}-cancel-{side}.json');s=json.loads(path.read_text());q=s['samples'][0];phases={p['phase']:p for p in s['lifecycle']}
   cpu=lambda p:sum(int(v) for v in p['process']['stat'].rsplit(')',1)[1].split()[11:13])*10
   row[side]={'path':str(path.relative_to(root)),'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),**{k:q[k] for k in ['accepted_us','settled_us','first_consumed_publication_us','notification_records']},'cpu_ms':cpu(q)-cpu(phases['after_initialization'])}
  row['ratios']={key:row['after'][key]/row['before'][key] for key in ['accepted_us','settled_us','cpu_ms']};rows.append(row)
result={'scope':'All original and confirmation cancellation samples retained; confirmation pairs continue original IDs with alternating order. accepted_us measures submit completion, not provider cancellation latency. first_consumed_publication_us is sampled only after cancel/disconnect/release, not native publication timestamp. Aggregate product CPU has 10ms tick resolution; it cannot be subtracted from wall time to derive waiting.', 'pairs':rows,'medians':{group:{k:statistics.median(r['ratios'][k] for r in rows if group=='all' or r['directory']==group) for k in ['accepted_us','settled_us','cpu_ms']} for group in ['all','reservations-paired','reservation-cancel-confirmation']}}
(root/'reservation-cancellation-diagnostics.json').write_text(json.dumps(result,indent=2));print(result['medians'])
