import subprocess,json,datetime
from pathlib import Path
root=Path('/workspace/issue-481-evidence')
final=root/'compact-source-conformance'
stages=[
 ('compact-source-paired',['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/'statement-reuse-conformance'),'--after',str(final),'--output',str(root/'compact-source-paired'),'--pairs','3']),
 ('continued-combined-paired',['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/'attribution-conformance'),'--after',str(final),'--output',str(root/'continued-combined-paired'),'--pairs','3']),
 ('final-combined-paired',['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/'baseline-final-conformance'),'--after',str(final),'--output',str(root/'final-combined-paired'),'--pairs','3']),
 ('final-pi-paired',['python3','benchmarks/runtime/controller.py','--rust',str(final),'--pi','/workspace/pi-481','--output',str(root/'final-pi-paired'),'--pairs','3']),
 ('final-append-paired',['python3','benchmarks/runtime/compare-append.py','--before',str(root/'source-append-conformance'),'--after',str(final),'--output',str(root/'final-append-paired'),'--pairs','3']),
]
stages.append(('reservation-cancel-confirmation',['python3','benchmarks/runtime/compare-revisions.py','--before',str(root/'attribution-conformance'),'--after',str(root/'reservations-conformance'),'--output',str(root/'reservation-cancel-confirmation'),'--pairs','12','--pair-offset','3','--case','cancel']))
records=[]
for name,cmd in stages:
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 print('START',name,start,flush=True)
 with (root/(name+'.log')).open('w') as log: result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 records.append({'stage':name,'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':result.returncode})
 (root/'continued-matrix-status.json').write_text(json.dumps(records,indent=2))
 print('END',name,result.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in records))
