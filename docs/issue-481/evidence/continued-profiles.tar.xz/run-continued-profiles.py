import subprocess,json,datetime
from pathlib import Path
root=Path('/workspace/issue-481-evidence');out=root/'continued-profile';binary=root/'compact-source-conformance'
records=[]
commands=[]
for case,short in [('short-small','small'),('short-large','large')]:
 commands.append((f'cpu-{short}',['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(out/f'attr-cpu-{short}'),'--mode','cpu','--case',case]))
commands += [('heap-sql',['python3','benchmarks/runtime/profiling/run.py','--binary',str(root/'statement-reuse-conformance'),'--profiler-root','/workspace/issue-481-profilers','--output',str(out/'attr-heap-sql'),'--mode','heap','--case','short-small']),('heap-small',['python3','benchmarks/runtime/profiling/run.py','--binary',str(binary),'--profiler-root','/workspace/issue-481-profilers','--output',str(out/'attr-heap-small'),'--mode','heap','--case','short-small']),('syscalls-small',['python3','benchmarks/runtime/profiling/syscalls.py','--binary',str(binary),'--output',str(out/'attr-syscalls-small')])]
for name,cmd in commands:
 print('START',name,flush=True);start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (root/('continued-'+name+'.log')).open('w') as log:p=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':cmd,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit':p.returncode})
 (root/'continued-profile-status.json').write_text(json.dumps(records,indent=2));print('END',name,p.returncode,flush=True)
raise SystemExit(any(r['exit'] for r in records))
