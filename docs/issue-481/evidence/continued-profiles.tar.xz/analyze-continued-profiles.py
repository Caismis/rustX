from pathlib import Path
import subprocess,json
root=Path('/workspace/issue-481-evidence');p=root/'continued-profile';binary=root/'compact-source-conformance'
pprof='/workspace/issue-481-profilers/unpacked/usr/bin/google-pprof'
for case in ['small','large']:
 d=p/('attr-cpu-'+case)
 with (d/'steady-cumulative.txt').open('w') as out, (d/'symbolize.log').open('w') as err:
  subprocess.run([pprof,'--text','--cum','--no_strip_temp',('--nodecount=200' if case=='small' else '--nodecount=100'),str(binary),str(d/'before_measured_turns.cpu')],stdout=out,stderr=err,check=True)
subprocess.run(['python3','benchmarks/runtime/profiling/export-cpu-counts.py',str(p),'docs/issue-481/evidence/continued-cpu-counts.json'],check=True)
for name,exe in [('sql',root/'statement-reuse-conformance'),('small',binary)]:
 d=p/('attr-heap-'+name);symbols=d/'symbols.txt'
 with symbols.open('w') as out:subprocess.run(['nm','-n','-C',str(exe)],stdout=out,check=True)
 with (d/'elf-program-headers.txt').open('w') as out:subprocess.run(['readelf','-l',str(exe)],stdout=out,check=True)
 with (d/'steady-allocations.json').open('w') as out:
  subprocess.run(['python3','benchmarks/runtime/profiling/analyze-heap.py','--binary',str(exe),str(symbols),str(d/'alloc.0004.heap'),str(d/'alloc.0005.heap')],stdout=out,check=True)
 print('analyzed heap',name,flush=True)
with (p/'attr-syscalls-small'/'source-writes.json').open('w') as out:
 subprocess.run(['python3','benchmarks/runtime/profile-source.py',str(p/'attr-syscalls-small'/'calls.strace')],stdout=out,check=True)
