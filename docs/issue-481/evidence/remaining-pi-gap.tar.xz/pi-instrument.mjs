import {DatabaseSync} from 'node:sqlite';
import {writeFile} from 'node:fs/promises';
import net from 'node:net';
import {Session} from 'node:inspector/promises';
const stats=new Map();
const tick=(sql,method,fn)=>{const t=process.hrtime.bigint();try{return fn();}finally{const key=method+' '+sql;const s=stats.get(key)||{calls:0,ns:0};s.calls++;s.ns+=Number(process.hrtime.bigint()-t);stats.set(key,s);}};
const prepare=DatabaseSync.prototype.prepare,exec=DatabaseSync.prototype.exec;
DatabaseSync.prototype.exec=function(sql){return tick(sql,'exec',()=>exec.call(this,sql));};
DatabaseSync.prototype.prepare=function(sql){const stmt=tick(sql,'prepare',()=>prepare.call(this,sql));for(const name of ['run','get','all']){const f=stmt[name];stmt[name]=function(...args){return tick(sql,name,()=>f.apply(this,args));};}return stmt;};
const inspector=new Session();inspector.connect();await inspector.post('Profiler.enable');await inspector.post('Profiler.setSamplingInterval',{interval:1000});
globalThis.gapBoundary=async function(phase){
 if(phase==='after_turns'){const {profile}=await inspector.post('Profiler.stop');await writeFile(process.env.GAP_OUTPUT+'/pi-steady.cpuprofile',JSON.stringify(profile));}
 await writeFile(process.env.GAP_OUTPUT+'/pi-sql-'+phase+'.json',JSON.stringify(Object.fromEntries(stats),null,2));
 await new Promise((resolve,reject)=>{const socket=net.createConnection(process.env.RUSTX_BENCH_PROFILE_SOCKET);socket.on('connect',()=>socket.write(phase+'\n'));socket.on('error',reject);socket.once('data',data=>{socket.end();data.toString()==='K'?resolve():reject(new Error('bad ack'));});});
 if(phase==='before_measured_turns')await inspector.post('Profiler.start');
 if(phase==='after_cleanup')inspector.disconnect();
};
