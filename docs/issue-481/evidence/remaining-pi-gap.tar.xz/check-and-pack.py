from pathlib import Path
import hashlib,json,subprocess,tarfile
root=Path(__file__).resolve().parent;dest=Path('/workspace/rustX-481/docs/issue-481/evidence')
# Both incomplete trace variants must fail closed when asked for steady counts.
source=(root/'analyze.py').read_text()
checks=[]
for prefix in ['','matched-']:
 bad=source.replace("('complete-'+engine)","('"+prefix+"'+engine)")
 p=root/('negative-'+('pilot' if not prefix else 'writev')+'.py');p.write_text(bad)
 r=subprocess.run(['python3',str(p)],capture_output=True,text=True);assert r.returncode!=0 and 'AssertionError' in r.stderr,r.stderr
 checks.append({'input_prefix':prefix,'returncode':r.returncode,'stderr':r.stderr})
# Recompute final valid result after negative cases, and corroborate Pi commits.
subprocess.run(['python3',str(root/'analyze.py')],stdout=subprocess.DEVNULL,check=True)
s=json.loads((root/'summary.json').read_text());assert s['pi']['wal_write_commits']==s['pi']['sql_counts']['exec COMMIT']['calls']==160
assert s['rust']['new_source_leaves']==64 and s['rust']['source_derived_width_loads']==5120
(root/'analysis-checks.json').write_text(json.dumps(checks,indent=2))
(dest/'remaining-pi-gap-summary.json').write_text((root/'summary.json').read_text())
files=sorted(p for p in root.rglob('*') if p.is_file())
manifest={'scope':'Remaining-gap diagnostics; 3 pairs (first two incomplete Rust phase tracing), all product oracles passed; final complete pair only for steady counters; no headline samples','files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.file_digest(p.open('rb'),'sha256').hexdigest()} for p in files]}
archive=dest/'remaining-pi-gap.tar.xz'
with tarfile.open(archive,'w:xz',preset=6) as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(root)),recursive=False)
with tarfile.open(archive,'r:xz') as tar:
 for item in manifest['files']:
  f=tar.extractfile(item['path']);assert hashlib.file_digest(f,'sha256').hexdigest()==item['sha256']
manifest.update(archive_bytes=archive.stat().st_size,archive_sha256=hashlib.file_digest(archive.open('rb'),'sha256').hexdigest())
(dest/'remaining-pi-gap.tar.manifest.json').write_text(json.dumps(manifest,indent=2));print(json.dumps({'files':len(files),'bytes':manifest['archive_bytes'],'sha256':manifest['archive_sha256']}))
